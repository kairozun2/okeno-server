-- Migration: Add verification system
-- Run this in Supabase SQL Editor AFTER running the main schema

-- Add is_verified and is_admin columns to profiles table
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE;

-- Set specific user as admin
UPDATE profiles
SET is_admin = TRUE, is_verified = TRUE
WHERE id = '6172b2d4-284c-4f08-84bb-5b415fdb6c59';

-- Create function to allow admins to verify users
CREATE OR REPLACE FUNCTION verify_user(target_user_id UUID, verified_status BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
BEGIN
  -- Check if current user is admin
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  -- If not admin, reject
  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can verify users';
  END IF;

  -- Update verification status
  UPDATE profiles
  SET is_verified = verified_status
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION verify_user TO authenticated;

-- Update RLS policies to allow admins to update verification status
-- (Profiles table should already have RLS enabled from main schema)
