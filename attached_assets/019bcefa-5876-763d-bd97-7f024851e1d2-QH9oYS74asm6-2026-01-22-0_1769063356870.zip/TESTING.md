# Multi-Device Testing Guide

## Backend is Now Running! 🎉

Your Memories app backend is fully operational with a SQLite database. You can now test real multi-device synchronization.

## What's Available

### ✅ Fully Functional Backend
- **Server**: Running on port 3000
- **Database**: SQLite (memories.db in backend folder)
- **Authentication**: JWT tokens with Visual Key Pattern
- **All endpoints**: Working and tested

### 📱 Current Setup

**Backend URL (local)**: `http://localhost:3000/api`

This works great for testing on the same device, but to test from another device (like your phone), you need to make the backend accessible over the network.

## How to Test from Another Device

### Option 1: Local Network (Easiest for Same WiFi)

**Step 1: Get Your Computer's IP Address**

On macOS/Linux:
```bash
ifconfig | grep "inet " | grep -v 127.0.0.1
```

On Windows:
```bash
ipconfig
```

Look for something like `192.168.1.100` (your local network IP).

**Step 2: Update the .env File**

Edit `/home/user/workspace/.env` and change:

```
EXPO_PUBLIC_API_BASE_URL=http://YOUR_IP_HERE:3000/api
```

For example:
```
EXPO_PUBLIC_API_BASE_URL=http://192.168.1.100:3000/api
```

**Step 3: Restart the Expo App**

The app will now connect to your backend!

**Step 4: Test Multi-Device Sync**

1. Register a new account on Device 1 (using the pattern lock)
2. The app will show you a Recovery ID - **write it down!**
3. On Device 2, tap "Already have an account?"
4. Enter the Recovery ID from step 2
5. Draw the same pattern you created on Device 1
6. You should be logged in!

Now create a memory on Device 1 → it should appear on Device 2!

### Option 2: Internet Access with ngrok (For Remote Testing)

If you want to test from a device that's NOT on the same WiFi network:

**Step 1: Install ngrok**

```bash
npm install -g ngrok
```

Or download from: https://ngrok.com/

**Step 2: Start ngrok Tunnel**

```bash
ngrok http 3000
```

You'll see output like:
```
Forwarding  https://abc123def.ngrok.io -> http://localhost:3000
```

**Step 3: Update .env with ngrok URL**

```
EXPO_PUBLIC_API_BASE_URL=https://abc123def.ngrok.io/api
```

**Important**: Use the HTTPS URL (not HTTP) for secure connections.

**Step 4: Restart Expo and Test**

Now you can test from anywhere in the world! The ngrok URL makes your local backend accessible over the internet.

## Testing Checklist

### Basic Authentication
- [ ] Register a new user with Visual Key Pattern
- [ ] Copy the Recovery ID shown after registration
- [ ] Login on another device using Recovery ID + Pattern
- [ ] Verify you see the same user info on both devices

### Memory Sync
- [ ] Create a memory on Device 1
- [ ] Pull to refresh on Device 2 → memory appears
- [ ] Echo (like) a memory on Device 2
- [ ] Check Device 1 → echo count updates
- [ ] Save a memory on Device 1
- [ ] Check Device 2 saved tab → memory appears

### Comments
- [ ] Add a comment on Device 1
- [ ] Refresh on Device 2 → comment appears
- [ ] Reply on Device 2
- [ ] Check Device 1 → reply appears

### Archive
- [ ] Archive a memory on Device 1
- [ ] Refresh on Device 2 → memory disappears from main feed
- [ ] Check archive on both devices → memory in archive

## Troubleshooting

### "Network request failed"
- Make sure backend is running: `cd backend && npm run dev`
- Check the IP address in `.env` is correct
- Make sure both devices are on the same WiFi network
- Try `http://YOUR_IP:3000/health` in a browser to test

### "Invalid credentials" on login
- Make sure you're using the exact same pattern
- The Recovery ID is case-sensitive
- Make sure the backend has the user in the database

### No synchronization between devices
- Check both devices are using the same backend URL
- Pull to refresh to force a data sync
- Check the backend logs for errors

### Backend won't start
- Make sure port 3000 is not in use: `lsof -i :3000`
- Check for errors: `cd backend && npm run dev`
- Verify dependencies installed: `npm install` in backend folder

## Backend Server Management

### Start the server:
```bash
cd backend
npm run dev
```

### Stop the server:
Press `Ctrl+C` in the terminal running the server

### View the database:
```bash
cd backend
sqlite3 memories.db
.tables
SELECT * FROM users;
.quit
```

### Reset the database (delete all data):
```bash
cd backend
rm memories.db
npm run db:setup
```

## Next Steps

Once multi-device sync is working:

1. **Deploy to a Cloud Server** (for permanent access)
   - Railway.app (easiest)
   - Fly.io
   - Render.com
   - AWS/GCP/Azure

2. **Upgrade Database to PostgreSQL** (for production)
   - More robust than SQLite
   - Better for multiple concurrent users
   - Required for scaling

3. **Add WebSocket Support** (for real-time updates)
   - See live updates without pulling to refresh
   - Instant notifications when someone likes your memory

4. **Upgrade File Storage to S3** (for production media)
   - AWS S3
   - Cloudflare R2
   - DigitalOcean Spaces

## Current Backend Status

✅ **Working:**
- User registration & authentication
- JWT token management
- Create/read/update/delete memories
- Echo (like) system
- Save/bookmark functionality
- Archive system
- Comments
- File uploads (local storage)

🔜 **Ready to Add:**
- User search & follow system
- Feed from followed users only
- Real-time WebSocket updates
- Push notifications
- Cloud media storage

---

**Questions?** Check the backend logs for detailed error messages when testing.
