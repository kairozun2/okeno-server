-- Migration: Add social_links column to profiles table
-- Run this SQL in your Supabase SQL Editor

-- Add social_links column to profiles table
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS social_links JSONB DEFAULT '[]'::jsonb;

-- Verify the column was added successfully
SELECT column_name, data_type, column_default
FROM information_schema.columns
WHERE table_name = 'profiles' AND column_name = 'social_links';
