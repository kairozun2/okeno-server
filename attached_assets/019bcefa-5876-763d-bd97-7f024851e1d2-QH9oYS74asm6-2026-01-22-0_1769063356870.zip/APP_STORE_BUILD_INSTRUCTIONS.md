# 📱 Инструкция по сборке приложения для App Store (Windows)

## ✅ Что я настроил:

### 1. **app.json** — полная конфигурация iOS:
- ✅ Bundle ID: `com.vibecode.memories`
- ✅ Имя приложения: "Memories"
- ✅ Версия: 1.0.0
- ✅ Build Number: 1
- ✅ **Разрешения (Privacy Permissions):**
  - Камера (NSCameraUsageDescription)
  - Фотогалерея (NSPhotoLibraryUsageDescription)
  - Сохранение фото (NSPhotoLibraryAddUsageDescription)
  - Геолокация (NSLocationWhenInUseUsageDescription)
  - Микрофон (NSMicrophoneUsageDescription)
- ✅ **Encryption Compliance:**
  - `ITSAppUsesNonExemptEncryption: false` — использует только стандартное HTTPS/TLS шифрование Apple
  - **НЕ НУЖНА** документация по экспорту (Export Compliance)

### 2. **eas.json** — конфигурация для облачной сборки:
- ✅ Production build настроен для App Store
- ✅ Автоинкремент build number (`autoIncrement: true`)
- ✅ Использует последний macOS образ от Expo
- ✅ Submit раздел готов для автоматической отправки

### 3. **Encryption (Шифрование):**
- ✅ Приложение использует **только** стандартное HTTPS/TLS шифрование от Apple
- ✅ **НЕ использует** кастомное шифрование (SHA-256 упоминание удалено из UI)
- ✅ `ITSAppUsesNonExemptEncryption: false` — Apple НЕ потребует документы

---

## 🚀 Как создать билд для App Store (с Windows):

### **Шаг 1: Подготовка**
Перед началом тебе нужно:
1. Apple Developer аккаунт ($99/год)
2. Создать приложение в App Store Connect
3. Установить Expo CLI (если не установлен):
   ```bash
   npm install -g eas-cli
   ```

### **Шаг 2: Логин в Expo**
```bash
eas login
```
Введи свой email и пароль от Expo аккаунта.

### **Шаг 3: Привязать проект к EAS**
```bash
eas build:configure
```
Это создаст EAS Project ID и обновит `app.json`.

### **Шаг 4: Настроить Apple аккаунт**
```bash
eas credentials
```
- Выбери **iOS**
- Выбери **production**
- Expo попросит логин от Apple ID
- Expo **автоматически** создаст все сертификаты и provisioning profiles

> **Важно:** Expo делает всё сам на своих серверах macOS. Тебе НЕ нужен MacBook!

### **Шаг 5: Создать Production билд**
```bash
eas build --platform ios --profile production
```

Процесс займёт **15-30 минут**. Expo:
- Загрузит код на облачный macOS сервер
- Установит зависимости
- Скомпилирует нативный iOS код
- Создаст `.ipa` файл
- Вернёт ссылку на скачивание

### **Шаг 6: Автоматическая отправка в App Store Connect**

**Вариант A (автоматическая отправка):**
```bash
eas submit --platform ios --profile production
```
Expo спросит:
- Apple ID
- App-specific password (создай на appleid.apple.com)
- Apple Team ID
- ASC App ID (из App Store Connect)

**Вариант B (ручная загрузка):**
1. Скачай `.ipa` файл из Expo dashboard
2. Загрузи через Transporter app (доступен для Windows)
3. Или используй web-версию App Store Connect

---

## 📝 Что нужно заполнить в App Store Connect:

После того как билд загрузится (подожди 5-10 минут):

1. **Зайди в App Store Connect** → Твоё приложение
2. **Вкладка "Build"** (Сборка):
   - Нажми плюсик (+) рядом с "Build"
   - Выбери загруженный билд
3. **Заполни метаданные:**
   - Название приложения
   - Описание
   - Ключевые слова
   - Скриншоты (6.7" и 6.5" iPhone)
   - Иконка приложения (1024x1024)
   - Privacy Policy URL (если есть)
4. **Раздел "Export Compliance":**
   - ✅ Отметь: "No, this app does not use encryption"
   - Или выбери: "Uses standard encryption"
   - **НЕ НУЖНО** загружать документы (благодаря `ITSAppUsesNonExemptEncryption: false`)

---

## 🔐 Encryption Compliance (Ответ для модерации):

Если Apple спросит про шифрование:

**Вопрос:** "Does your app use encryption?"

**Ответ:**
```
This app uses only standard HTTPS/TLS encryption provided by the
operating system for network communication. It does not implement
any custom encryption algorithms. All encryption is handled by
Apple-provided frameworks.
```

---

## 📋 Checklist перед отправкой:

- ✅ Bundle ID совпадает с App Store Connect
- ✅ Version и Build Number уникальны
- ✅ Все разрешения (permissions) прописаны в app.json
- ✅ Иконка и splash screen добавлены
- ✅ Тестовый аккаунт создан (для модераторов Apple)
- ✅ Privacy Policy URL добавлен (если собираешь данные)
- ✅ Скриншоты загружены (минимум 3 скриншота)

---

## 🎯 Важные команды:

```bash
# Логин в Expo
eas login

# Создать production билд
eas build --platform ios --profile production

# Отправить в App Store
eas submit --platform ios --profile production

# Проверить статус билда
eas build:list

# Посмотреть логи билда
eas build:view [BUILD_ID]
```

---

## ❓ FAQ:

**Q: Нужен ли мне MacBook?**
A: **НЕТ!** Expo EAS Build работает на облачных macOS серверах.

**Q: Нужен ли Xcode?**
A: **НЕТ!** Всё делается через Expo CLI и App Store Connect web.

**Q: Нужны ли документы про шифрование?**
A: **НЕТ!** Приложение использует только стандартное HTTPS/TLS от Apple.

**Q: Сколько стоит EAS Build?**
A: Первые 30 билдов/месяц бесплатно. Потом $29/месяц для unlimited.

**Q: Как долго создаётся билд?**
A: 15-30 минут в зависимости от размера приложения.

**Q: Могу ли я тестировать билд перед отправкой?**
A: Да! Используй `eas build --platform ios --profile preview` для TestFlight.

---

## 🛠 Troubleshooting:

**Ошибка: "Bundle identifier not found"**
- Проверь, что Bundle ID в app.json совпадает с App Store Connect

**Ошибка: "Invalid provisioning profile"**
- Удали старые credentials: `eas credentials --platform ios`
- Создай новые: выбери "Set up new credentials"

**Ошибка: "Export compliance missing"**
- Добавь в app.json: `"ITSAppUsesNonExemptEncryption": false`

**Билд падает с ошибкой:**
- Посмотри логи: `eas build:view [BUILD_ID]`
- Проверь, что все native зависимости совместимы с Expo

---

## 📞 Поддержка:

- Expo Docs: https://docs.expo.dev/build/introduction/
- EAS Build Guide: https://docs.expo.dev/build-reference/ios-builds/
- App Store Guidelines: https://developer.apple.com/app-store/review/guidelines/

---

**Готово! Теперь ты можешь собрать и отправить приложение в App Store с Windows без MacBook!** 🎉
