# App Store Privacy Setup - ОБЯЗАТЕЛЬНО перед отправкой

## 🔴 КРИТИЧЕСКИ ВАЖНО для прохождения модерации Apple

### 1. Добавьте Privacy Permissions в app.json

Откройте `/app.json` и добавьте эти разрешения в секцию `expo.ios.infoPlist`:

```json
{
  "expo": {
    "name": "vibecode",
    "slug": "vibecode",
    "scheme": ["vibecode", "memories"],
    "version": "1.0.0",
    "orientation": "portrait",
    "userInterfaceStyle": "automatic",
    "newArchEnabled": true,
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.yourcompany.memories",
      "infoPlist": {
        "NSCameraUsageDescription": "Memories использует камеру для создания фотографий и видео ваших воспоминаний.",
        "NSPhotoLibraryUsageDescription": "Memories нужен доступ к вашей фотогалерее, чтобы вы могли выбрать фото и видео для своих воспоминаний.",
        "NSPhotoLibraryAddUsageDescription": "Memories сохраняет созданные воспоминания с фото и видео в вашу галерею.",
        "NSLocationWhenInUseUsageDescription": "Memories использует вашу геолокацию, чтобы отметить место, где было создано воспоминание (опционально).",
        "NSMicrophoneUsageDescription": "Memories использует микрофон для записи видео со звуком.",
        "NSUserTrackingUsageDescription": "Это приложение НЕ отслеживает вас и не собирает данные для рекламы.",
        "ITSAppUsesNonExemptEncryption": false
      }
    },
    "android": {
      "edgeToEdgeEnabled": true,
      "package": "com.yourcompany.memories",
      "permissions": [
        "CAMERA",
        "READ_EXTERNAL_STORAGE",
        "WRITE_EXTERNAL_STORAGE",
        "ACCESS_FINE_LOCATION",
        "ACCESS_COARSE_LOCATION",
        "RECORD_AUDIO"
      ]
    },
    "plugins": ["expo-router"],
    "experiments": {
      "typedRoutes": true
    }
  }
}
```

### 2. App Store Connect - Privacy Settings

При загрузке приложения в App Store Connect, вам нужно заполнить секцию **"App Privacy"**:

#### **Данные, которые собираются:**

✅ **Contact Info:**
- Email Address: НЕТ
- Name: НЕТ (используем только username)
- Phone Number: НЕТ

✅ **User Content:**
- Photos or Videos: ДА
  - Purpose: App Functionality
  - Linked to User: YES
  - Used for Tracking: NO
- Other User Content (текст постов): ДА
  - Purpose: App Functionality
  - Linked to User: YES
  - Used for Tracking: NO

✅ **Identifiers:**
- User ID: ДА (внутренний UUID)
  - Purpose: App Functionality
  - Linked to User: YES
  - Used for Tracking: NO

✅ **Location:**
- Precise Location: ДА (если пользователь разрешает)
  - Purpose: App Functionality (optional feature)
  - Linked to User: YES
  - Used for Tracking: NO

#### **Данные, которые НЕ собираются:**
- ❌ Health & Fitness
- ❌ Financial Info
- ❌ Contacts
- ❌ Browsing History
- ❌ Search History
- ❌ Purchases
- ❌ Diagnostics
- ❌ Other Data Types

### 3. Privacy Policy URL

**ОБЯЗАТЕЛЬНО**: создайте Privacy Policy и укажите URL в App Store Connect.

Можно использовать генераторы:
- https://www.privacypolicygenerator.info/
- https://app-privacy-policy-generator.firebaseapp.com/

**Важные пункты для включения:**
1. Какие данные собираются (фото, видео, текст, геолокация)
2. Как данные используются (только для функционала приложения)
3. Где хранятся данные (Supabase cloud, encrypted)
4. Права пользователя (удаление аккаунта и данных)
5. Отсутствие рекламы и трекинга
6. Контактная информация для вопросов

### 4. App Review Information

В App Store Connect заполните "App Review Information":

**Demo Account (ОБЯЗАТЕЛЬНО!):**
- Username: `demo_user_apple`
- Visual Key Pattern: укажите какой паттерн использовать
- ИЛИ: укажите Recovery ID для демо-аккаунта

**Notes for Reviewer:**
```
English:
This app uses a unique Visual Key Pattern authentication (3x3 grid) instead of passwords.
The app requires camera and photo library access to create memory posts with images/videos.
Location access is OPTIONAL and only used when user wants to tag a location.
No data is shared with third parties. All data is encrypted and stored securely.

Russian:
Приложение использует уникальную систему аутентификации через визуальный паттерн (сетка 3x3) вместо паролей.
Доступ к камере и галерее нужен для создания постов с фото/видео.
Геолокация опциональна и используется только если пользователь хочет отметить место.
Данные не передаются третьим лицам. Всё зашифровано и безопасно хранится.
```

### 5. Категория приложения

Выберите правильную категорию в App Store Connect:
- **Primary Category**: Social Networking
- **Secondary Category**: Lifestyle

### 6. Возрастной рейтинг (Age Rating)

Заполните анкету честно:
- Alcohol, Tobacco, or Drug Use: NO
- Medical/Treatment Information: NO
- Profanity or Crude Humor: NO (есть фильтр)
- Sexual Content or Nudity: NO (есть модерация)
- Horror/Fear Themes: NO
- Mature/Suggestive Themes: NO
- Violence: NO
- Realistic Violence: NO
- Prolonged Graphic or Sadistic Violence: NO
- Sexual Violence or Assault: NO
- Gambling: NO

**Результат**: скорее всего 4+ или 12+ (в зависимости от контента пользователей)

### 7. Скриншоты и превью

**Обязательные размеры для iPhone:**
- 6.7" (iPhone 15 Pro Max): 1290 x 2796 px
- 6.5" (iPhone 11 Pro Max): 1242 x 2688 px
- 5.5" (iPhone 8 Plus): 1242 x 2208 px

**Рекомендации:**
- Минимум 4-6 скриншотов
- Показать основные функции: лента, создание поста, профиль, чаты
- НЕ показывать реальные данные пользователей
- Использовать демо-контент

### 8. App Description

**App Store Description (Английский):**
```
Memories - Your Private Digital Diary

✨ Features:
• Visual Key Pattern authentication - no passwords needed
• Share your moments with photos, videos, and text
• Emotion tags to capture how you feel
• Private and secure - your data is encrypted
• Clean, minimal design inspired by Apple aesthetics

🔒 Privacy First:
• No email required
• No phone number needed
• No third-party tracking
• Your data belongs to you

📱 Modern & Beautiful:
• iOS-native design
• Smooth animations
• Dark mode support
• Premium user experience

Join Memories today and start preserving your precious moments!
```

**Keywords (до 100 символов):**
```
diary,journal,memory,moments,social,photos,private,secure,emotional
```

### 9. Support URL

Укажите в App Store Connect:
- **Support URL**: https://memories.app/support
- **Marketing URL** (optional): https://memories.app

### 10. Final Checklist перед отправкой

- [ ] app.json содержит все NSUsageDescription
- [ ] Privacy Policy создана и размещена онлайн
- [ ] Demo account создан и работает
- [ ] Все скриншоты загружены
- [ ] App Description написано на английском
- [ ] Age Rating заполнен
- [ ] App Privacy информация заполнена в App Store Connect
- [ ] Категория выбрана
- [ ] Support URL указан
- [ ] Build загружен через EAS Build
- [ ] Тестирование на реальном iPhone (через TestFlight)

---

## ⚠️ Частые причины отклонения

**1. Недостаточное объяснение разрешений**
- ✅ ИСПРАВЛЕНО: добавлены понятные NSUsageDescription

**2. Отсутствие Privacy Policy**
- ✅ ИСПРАВЛЕНО: добавлен раздел Privacy в настройках + ссылка на политику

**3. Демо-аккаунт не работает**
- ⚠️ ВАЖНО: создайте рабочий demo аккаунт перед отправкой

**4. Нечёткие скриншоты**
- ⚠️ ВАЖНО: используйте высокое разрешение, симулятор iOS

**5. Неполная App Privacy информация**
- ✅ ИСПРАВЛЕНО: выше указан полный чеклист

---

## 🎉 После утверждения

1. Отметьте приложение как "Ready for Sale"
2. Оно появится в App Store в течение 24 часов
3. Отслеживайте отзывы и рейтинги
4. Реагируйте на баги быстро через TestFlight beta

**Удачи с модерацией! 🚀**
