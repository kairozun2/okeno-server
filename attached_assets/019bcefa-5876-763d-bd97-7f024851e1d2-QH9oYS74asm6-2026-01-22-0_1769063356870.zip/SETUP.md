# 🚀 Запуск Memories с Backend

## Что готово:
✅ Backend сервер (Node.js + PostgreSQL)
✅ Frontend приложение (React Native)
✅ API endpoints для всех функций
✅ Синхронизация данных

---

## 📋 Как запустить:

### ШАГ 1: Установить PostgreSQL

**Mac:**
```bash
brew install postgresql
brew services start postgresql
```

**Windows/Linux:**
Скачать с https://www.postgresql.org/download/

### ШАГ 2: Создать базу данных

```bash
psql postgres
CREATE DATABASE memories;
\q
```

### ШАГ 3: Запустить Backend

```bash
cd backend
npm install
cp .env.example .env
npm run db:setup
npm run dev
```

Сервер запустится на http://localhost:3000

### ШАГ 4: Узнать IP компьютера

**Mac/Linux:**
```bash
ifconfig | grep "inet " | grep -v 127.0.0.1
```

**Windows:**
```bash
ipconfig
```

Например: `192.168.1.100`

### ШАГ 5: Настроить Frontend

В файле `/.env` изменить:
```
EXPO_PUBLIC_API_BASE_URL=http://192.168.1.100:3000/api
```

Замените `192.168.1.100` на ВАШ IP адрес!

### ШАГ 6: Запустить приложение

```bash
bun start
```

---

## ✅ Готово!

Теперь все данные синхронизируются с сервером:
- ✅ Регистрация/логин
- ✅ Создание воспоминаний
- ✅ Лайки и сохранения
- ✅ Комментарии
- ✅ Загрузка фото/видео

Все работает даже без интернета (оффлайн режим), а когда интернет появляется - синхронизируется автоматически!

---

## 📁 Структура проекта

```
/                     - Frontend (React Native)
/backend             - Backend (Node.js)
  /src
    /routes          - API endpoints
    /config          - База данных
    /middleware      - Авторизация
```

## 🔧 Troubleshooting

**Проблема:** Frontend не подключается к backend
**Решение:** Проверьте что в `.env` указан правильный IP адрес компьютера

**Проблема:** Backend не запускается
**Решение:** Проверьте что PostgreSQL запущен: `brew services list` (Mac)

**Проблема:** Ошибка базы данных
**Решение:** Пересоздайте базу: `npm run db:setup`
