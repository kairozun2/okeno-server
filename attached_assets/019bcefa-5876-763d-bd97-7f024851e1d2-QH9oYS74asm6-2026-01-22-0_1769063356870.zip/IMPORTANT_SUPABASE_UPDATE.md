# 🚨 ВАЖНО: Обновление схемы Supabase

## Проблемы которые были исправлены:

1. ✅ **Ошибка создания поста с геолокацией** - добавлены поля `location`, `latitude`, `longitude`
2. ✅ **Ошибка загрузки изображений (400 Bad Request)** - добавлены Storage политики
3. ✅ **Recovery ID не работал** - исправлена логика входа

## ⚠️ ЧТО ВАМ НУЖНО СДЕЛАТЬ:

### Шаг 1: Обновить таблицу `memories`

Откройте **Supabase Dashboard** → **SQL Editor** → вставьте и выполните:

```sql
-- Добавить поля геолокации в таблицу memories
ALTER TABLE memories
ADD COLUMN IF NOT EXISTS location TEXT,
ADD COLUMN IF NOT EXISTS latitude DOUBLE PRECISION,
ADD COLUMN IF NOT EXISTS longitude DOUBLE PRECISION;
```

### Шаг 2: Настроить Storage bucket и политики

В **Supabase Dashboard** → **SQL Editor** → вставьте и выполните:

```sql
-- Создать bucket для медиа (если еще не создан)
INSERT INTO storage.buckets (id, name, public)
VALUES ('memories', 'memories', true)
ON CONFLICT (id) DO NOTHING;

-- Удалить старые политики если они существуют
DROP POLICY IF EXISTS "Users can upload their own media" ON storage.objects;
DROP POLICY IF EXISTS "Media is publicly accessible" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their own media" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own media" ON storage.objects;

-- Создать новые политики для Storage
CREATE POLICY "Users can upload their own media"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'memories' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Media is publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'memories');

CREATE POLICY "Users can update their own media"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'memories' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own media"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'memories' AND
  auth.uid()::text = (storage.foldername(name))[1]
);
```

### Шаг 3: Проверка

После выполнения SQL:

1. Попробуйте создать пост с **изображением** и **геолокацией**
2. Проверьте что изображение загружается и отображается
3. Проверьте что геолокация сохраняется

## Как работает Recovery ID:

1. Зайдите в **Профиль**
2. Нажмите на **Аккаунт**
3. **Скопируйте Recovery ID** (это UUID, например: `adbb3a3f-2dab-44b7-8969-68493690479a`)
4. Выйдите из аккаунта
5. На экране входа вставьте **Recovery ID** вместо имени пользователя
6. Введите ваш **Visual Key Pattern**
7. Вход выполнится, и ваше имя пользователя загрузится автоматически

---

## ✅ После выполнения этих шагов:

- ✅ Посты с геолокацией будут работать
- ✅ Загрузка изображений будет работать
- ✅ Recovery ID будет работать правильно
- ✅ Все данные будут сохраняться в Supabase

**Если возникнут ошибки при выполнении SQL, скопируйте текст ошибки и покажите мне.**
