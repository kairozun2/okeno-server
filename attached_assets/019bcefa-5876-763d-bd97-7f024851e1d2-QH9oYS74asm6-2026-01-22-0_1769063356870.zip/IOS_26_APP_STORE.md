# iOS 26 SDK & App Store Submission Guide

**Updated: January 2026**

## Critical Requirements

Starting **April 2026**, Apple requires all App Store submissions to:
- Be built with **iOS 26 SDK or later**
- Use **Xcode 26 or later**
- Support iOS 18.0+ as minimum deployment target

## Current Project Configuration

### SDK & Deployment Target

The project is configured for iOS 26 compatibility:

```json
// app.json (Expo config)
{
  "expo": {
    "ios": {
      "deploymentTarget": "18.0",  // Minimum iOS version
      "buildNumber": "1"
    }
  }
}
```

### Build Requirements

**Required:**
- Xcode 26.0+ (includes iOS 26 SDK)
- macOS 15.0 (Sequoia) or later
- Expo SDK 53 (supports iOS 26 SDK)
- React Native 0.76.7 (compatible with iOS 26)

## EAS Build Configuration

For building with Expo Application Services (EAS):

```json
// eas.json
{
  "build": {
    "production": {
      "ios": {
        "buildConfiguration": "Release",
        "cocoapodsVersion": "1.15.0",
        "image": "latest"  // Uses Xcode 26
      }
    },
    "development": {
      "ios": {
        "buildConfiguration": "Debug",
        "image": "latest"
      }
    }
  }
}
```

## Local Build Setup

### 1. Install Xcode 26

```bash
# Download from Mac App Store or Apple Developer Portal
xcode-select --install
xcode-select -p  # Verify: /Applications/Xcode.app/Contents/Developer
```

### 2. Verify iOS 26 SDK

```bash
xcodebuild -showsdks
# Should show: iOS 26.0
```

### 3. Build Locally

```bash
# Install dependencies
bun install

# Generate iOS project
npx expo prebuild --platform ios --clean

# Open in Xcode
open ios/vibecode.xcworkspace

# Or build via CLI
npx expo run:ios --configuration Release
```

## App Store Submission Checklist

### Pre-Submission

- [ ] **SDK Version**: Built with iOS 26 SDK (Xcode 26+)
- [ ] **Deployment Target**: iOS 18.0+ set in app.json
- [ ] **No Deprecated APIs**: All iOS 26 deprecated APIs removed
- [ ] **Privacy Manifest**: `PrivacyInfo.xcprivacy` included (if using third-party SDKs)
- [ ] **App Icon**: 1024x1024 without alpha channel
- [ ] **Launch Screen**: Configured via `expo-splash-screen`

### Build & Archive

```bash
# Using EAS (recommended)
eas build --platform ios --profile production

# Or local Xcode archive
# Product → Archive → Distribute App → App Store Connect
```

### Upload to App Store Connect

```bash
# Via Xcode Organizer or:
xcrun altool --upload-app --type ios --file YourApp.ipa \
  --apiKey YOUR_API_KEY \
  --apiIssuer YOUR_ISSUER_ID
```

### Common Errors & Solutions

#### ITMS-90725: SDK Version Mismatch

```
ERROR ITMS-90725: "SDK Version Issue. This app was built with iOS SDK 25.x"
```

**Solution:**
- Ensure Xcode 26+ is installed
- Clean build folder: `npx expo prebuild --clean`
- Verify `eas.json` uses `"image": "latest"`
- Check `xcodebuild -version` shows 26.0+

#### ITMS-90809: Deprecated API Usage

```
ERROR ITMS-90809: "Deprecated API Usage - Apple will stop accepting submissions"
```

**Solution:**
- Check for deprecated APIs: `UIWebView`, old location APIs, etc.
- Update all Expo packages: `npx expo install --fix`
- Review third-party libraries for iOS 26 compatibility

## Dependency Compatibility

### Verified iOS 26 Compatible

- ✅ Expo SDK 53
- ✅ React Native 0.76.7
- ✅ `@tanstack/react-query` v5
- ✅ `react-native-reanimated` v3
- ✅ `expo-camera`, `expo-image-picker`, `expo-av`
- ✅ `expo-blur`, `expo-haptics`, `expo-location`

### Package Verification

```bash
# Check for outdated packages
npx expo-doctor

# Update to latest compatible versions
npx expo install --fix
```

## Expo EAS Cloud Build

**Recommended approach** — automatically uses correct SDK:

```bash
# Install EAS CLI
npm install -g eas-cli

# Configure project
eas build:configure

# Build for production
eas build --platform ios --profile production

# Submit to App Store
eas submit --platform ios
```

## Testing iOS 26 Compatibility

### Simulator Testing

```bash
# List available simulators
xcrun simctl list devices

# Boot iOS 26 simulator
xcrun simctl boot "iPhone 15 Pro"

# Run app
npx expo run:ios
```

### Physical Device Testing

- Use TestFlight for beta testing
- Test on devices running iOS 18.0 - 26.0
- Verify all features work across iOS versions

## Privacy & Permissions

### Required Info.plist Entries

```xml
<!-- ios/YourApp/Info.plist -->
<key>NSCameraUsageDescription</key>
<string>Capture photos for your memories</string>

<key>NSPhotoLibraryUsageDescription</key>
<string>Choose photos for your memories</string>

<key>NSLocationWhenInUseUsageDescription</key>
<string>Add location to your memories</string>
```

Expo handles this automatically via `app.json` permissions.

## Final Verification

Before submission, verify:

```bash
# 1. Check iOS SDK version in build
unzip -p YourApp.ipa Payload/YourApp.app/Info.plist | grep DTSDKName
# Should show: iphoneos26.0

# 2. Check minimum OS version
unzip -p YourApp.ipa Payload/YourApp.app/Info.plist | grep MinimumOSVersion
# Should show: 18.0

# 3. Validate archive
xcrun altool --validate-app --type ios --file YourApp.ipa \
  --apiKey YOUR_API_KEY --apiIssuer YOUR_ISSUER_ID
```

## App Store Review Guidelines

### Compliance Checklist

- [ ] **Human Interface Guidelines**: Follows iOS design patterns
- [ ] **Privacy**: No tracking without permission
- [ ] **Data Security**: Encryption for sensitive data
- [ ] **Performance**: No crashes, smooth animations
- [ ] **Content**: Appropriate for all audiences

### Metadata

- **App Name**: "Memories" (or your chosen name)
- **Category**: Lifestyle / Health & Fitness
- **Keywords**: memory, journal, diary, mindfulness
- **Privacy Policy**: Required (host on website)

## Resources

- [Apple Developer Portal](https://developer.apple.com/)
- [Expo EAS Build Docs](https://docs.expo.dev/build/introduction/)
- [iOS 26 Release Notes](https://developer.apple.com/documentation/ios-ipados-release-notes)
- [App Store Review Guidelines](https://developer.apple.com/app-store/review/guidelines/)

## Support

For Expo/EAS issues:
- [Expo Discord](https://chat.expo.dev/)
- [Expo Forums](https://forums.expo.dev/)

For App Store issues:
- Apple Developer Support
- App Review Board

---

**Last Updated**: January 2026
**Minimum Requirements**: Xcode 26, iOS 26 SDK, macOS 15.0
