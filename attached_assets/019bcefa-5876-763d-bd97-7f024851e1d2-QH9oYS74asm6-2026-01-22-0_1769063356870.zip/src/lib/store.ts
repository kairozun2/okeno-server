import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Types
export interface Memory {
  id: string;
  text: string;
  emotion: Emotion;
  createdAt: string;
  imageUrl?: string;
  videoUrl?: string;
  echoCount: number;
  isSaved: boolean;
  isArchived: boolean;
  hasEchoed?: boolean; // Whether current user has echoed this
  authorId: string; // User ID of the author
  authorName?: string; // Author's username (from Supabase)
  authorAvatar?: string; // Author's avatar emoji (from Supabase)
  authorUsernameColor?: string | null; // Author's username color/gradient (from Supabase)
  authorSocialLinks?: Array<{ platform: string; url: string }>; // Author's social media links
  isVerified?: boolean; // Whether author is verified
  location?: string; // Location name (e.g., "San Francisco, CA")
  latitude?: number; // GPS latitude
  longitude?: number; // GPS longitude
}

export type Emotion =
  | 'peaceful'
  | 'grateful'
  | 'nostalgic'
  | 'hopeful'
  | 'reflective'
  | 'joyful';

export interface Notification {
  id: string;
  type: 'like' | 'comment';
  userName: string;
  userAvatar: string;
  memoryId: string;
  memoryThumbnail: string;
  commentText?: string;
  createdAt: string;
}

export const EMOTIONS: { key: Emotion; label: string; icon: string }[] = [
  { key: 'peaceful', label: 'Peaceful', icon: '🌿' },
  { key: 'grateful', label: 'Grateful', icon: '✨' },
  { key: 'nostalgic', label: 'Nostalgic', icon: '🌅' },
  { key: 'hopeful', label: 'Hopeful', icon: '🌱' },
  { key: 'reflective', label: 'Reflective', icon: '🌙' },
  { key: 'joyful', label: 'Joyful', icon: '☀️' },
];

// Visual Key Pattern - unique 3x3 grid pattern for authentication
export type VisualKeyPattern = number[];

interface AppState {
  // Auth
  isAuthenticated: boolean;
  isOnboarded: boolean;
  visualKeyPattern: VisualKeyPattern;
  userName: string;
  userId: string; // Unique ID for account recovery

  // Premium subscription
  isPremium: boolean;

  // Memories
  memories: Memory[];

  // Notifications
  notifications: Notification[];

  // Hidden users
  hiddenUsers: string[];

  // Actions - Auth
  setAuthenticated: (value: boolean) => void;
  setOnboarded: (value: boolean) => void;
  setVisualKeyPattern: (pattern: VisualKeyPattern) => void;
  setUserName: (name: string) => void;
  setUserId: (id: string) => void;
  clearUserData: () => void; // NEW: Clear all user data on logout

  // Actions - Premium
  setPremium: (value: boolean) => void;

  // Actions - Memories
  addMemory: (memory: Omit<Memory, 'id' | 'createdAt' | 'echoCount' | 'isSaved' | 'isArchived' | 'authorId'>) => void;
  updateMemoryText: (id: string, text: string) => void;
  toggleEcho: (id: string) => void;
  toggleSave: (id: string) => void;
  toggleArchive: (id: string) => void;
  deleteMemory: (id: string) => void;

  // Actions - Notifications
  addNotification: (notification: Omit<Notification, 'id' | 'createdAt'>) => void;
  clearNotifications: () => void;

  // Actions - Hidden Users
  hideUser: (userId: string) => void;
  unhideUser: (userId: string) => void;
}

// Generate mock memories
const generateMockMemories = (): Memory[] => {
  const now = new Date();
  return [
    {
      id: '1',
      text: 'Walked through the morning mist today. The world felt softer, quieter. Everything slowed down for a moment.',
      emotion: 'peaceful' as Emotion,
      createdAt: new Date(now.getTime() - 2 * 60 * 60 * 1000).toISOString(),
      echoCount: 12,
      isSaved: false,
      isArchived: false,
      authorId: 'current-user', // Current user's memories
    },
    {
      id: '2',
      text: 'Found an old photograph of grandma\'s garden. The colors have faded but the feeling hasn\'t.',
      emotion: 'nostalgic' as Emotion,
      createdAt: new Date(now.getTime() - 24 * 60 * 60 * 1000).toISOString(),
      imageUrl: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=800',
      echoCount: 24,
      isSaved: true,
      isArchived: false,
      authorId: 'current-user',
    },
    {
      id: '3',
      text: 'Sometimes the smallest conversations leave the deepest marks. Thank you for listening.',
      emotion: 'grateful' as Emotion,
      createdAt: new Date(now.getTime() - 48 * 60 * 60 * 1000).toISOString(),
      echoCount: 8,
      isSaved: false,
      isArchived: false,
      authorId: 'current-user',
    },
    {
      id: '4',
      text: 'Planted seeds today. Won\'t see them grow for weeks, but that\'s the beautiful part — trusting the unseen.',
      emotion: 'hopeful' as Emotion,
      createdAt: new Date(now.getTime() - 72 * 60 * 60 * 1000).toISOString(),
      imageUrl: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?w=800',
      echoCount: 31,
      isSaved: true,
      isArchived: false,
      authorId: 'current-user',
    },
  ];
};

// Generate mock notifications
const generateMockNotifications = (): Notification[] => {
  const now = new Date();
  return [
    {
      id: '1',
      type: 'like',
      userName: 'Emma Wilson',
      userAvatar: '🌸',
      memoryId: '2',
      memoryThumbnail: 'https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=400',
      createdAt: new Date(now.getTime() - 1000 * 60 * 5).toISOString(),
    },
    {
      id: '2',
      type: 'comment',
      userName: 'John Smith',
      userAvatar: '🎨',
      memoryId: '4',
      memoryThumbnail: 'https://images.unsplash.com/photo-1523348837708-15d4a09cfac2?w=400',
      commentText: 'This is amazing! Love it 💪',
      createdAt: new Date(now.getTime() - 1000 * 60 * 30).toISOString(),
    },
    {
      id: '3',
      type: 'like',
      userName: 'Sarah Johnson',
      userAvatar: '✨',
      memoryId: '1',
      memoryThumbnail: 'https://images.unsplash.com/photo-1506748686214-e9df14d4d9d0?w=400',
      createdAt: new Date(now.getTime() - 1000 * 60 * 120).toISOString(),
    },
  ];
};

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Initial State
      isAuthenticated: false,
      isOnboarded: false,
      visualKeyPattern: [],
      userName: '',
      userId: '',
      isPremium: false,
      memories: [], // Empty for new users
      notifications: [], // Empty for new users
      hiddenUsers: [], // Empty for new users

      // Auth Actions
      setAuthenticated: (value) => set({ isAuthenticated: value }),
      setOnboarded: (value) => set({ isOnboarded: value }),
      setVisualKeyPattern: (pattern) => set({ visualKeyPattern: pattern }),
      setUserName: (name) => set({ userName: name }),
      setUserId: (id) => set({ userId: id }),

      // Clear all user data on logout
      clearUserData: () => set({
        isAuthenticated: false,
        isOnboarded: false,
        visualKeyPattern: [],
        userName: '',
        userId: '',
        isPremium: false,
        memories: [],
        notifications: [],
        hiddenUsers: [],
      }),

      // Premium Actions
      setPremium: (value) => set({ isPremium: value }),

      // Memory Actions
      addMemory: (memory) => set((state) => ({
        memories: [{
          ...memory,
          id: Date.now().toString(),
          createdAt: new Date().toISOString(),
          echoCount: 0,
          isSaved: false,
          isArchived: false,
          authorId: state.userId, // Set current user as author
        }, ...state.memories]
      })),

      updateMemoryText: (id, text) => set((state) => ({
        memories: state.memories.map(m =>
          m.id === id
            ? { ...m, text }
            : m
        )
      })),

      toggleEcho: (id) => set((state) => ({
        memories: state.memories.map(m =>
          m.id === id
            ? { ...m, echoCount: m.echoCount + 1 }
            : m
        )
      })),

      toggleSave: (id) => set((state) => ({
        memories: state.memories.map(m =>
          m.id === id
            ? { ...m, isSaved: !m.isSaved }
            : m
        )
      })),

      toggleArchive: (id) => set((state) => ({
        memories: state.memories.map(m =>
          m.id === id
            ? { ...m, isArchived: !m.isArchived }
            : m
        )
      })),

      deleteMemory: (id) => set((state) => ({
        memories: state.memories.filter(m => m.id !== id)
      })),

      // Notification Actions
      addNotification: (notification) => set((state) => ({
        notifications: [{
          ...notification,
          id: Date.now().toString(),
          createdAt: new Date().toISOString(),
        }, ...state.notifications]
      })),

      clearNotifications: () => set({ notifications: [] }),

      // Hidden Users Actions
      hideUser: (userId) => set((state) => ({
        hiddenUsers: [...state.hiddenUsers, userId]
      })),

      unhideUser: (userId) => set((state) => ({
        hiddenUsers: state.hiddenUsers.filter(id => id !== userId)
      })),
    }),
    {
      name: 'memories-app-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        isAuthenticated: state.isAuthenticated,
        isOnboarded: state.isOnboarded,
        visualKeyPattern: state.visualKeyPattern,
        userName: state.userName,
        isPremium: state.isPremium,
        memories: state.memories,
        notifications: state.notifications,
        hiddenUsers: state.hiddenUsers,
      }),
    }
  )
);
