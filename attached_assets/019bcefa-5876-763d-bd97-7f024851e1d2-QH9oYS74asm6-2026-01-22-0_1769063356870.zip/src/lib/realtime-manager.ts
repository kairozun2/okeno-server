import { supabase } from './supabase';
import { RealtimeChannel } from '@supabase/supabase-js';

type SubscriptionCallback<T> = (payload: T) => void;
type UnsubscribeFn = () => void;

interface ChannelSubscription {
  channel: RealtimeChannel;
  callbacks: Set<SubscriptionCallback<any>>;
  status: 'CONNECTING' | 'SUBSCRIBED' | 'CHANNEL_ERROR' | 'TIMED_OUT' | 'CLOSED';
  retryCount: number;
  retryTimeout?: ReturnType<typeof setTimeout>;
}

/**
 * Singleton manager for Supabase Realtime subscriptions
 * Prevents duplicate channel subscriptions and handles reconnection logic
 */
class RealtimeManager {
  private subscriptions: Map<string, ChannelSubscription> = new Map();
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 2000; // 2 seconds base delay

  /**
   * Subscribe to a Realtime channel with automatic deduplication
   * Multiple components can subscribe to the same channel - only one actual subscription is created
   */
  subscribe<T>(
    channelName: string,
    config: {
      event: string;
      schema: string;
      table: string;
      filter?: string;
    },
    callback: SubscriptionCallback<T>
  ): UnsubscribeFn {
    console.log(`[RealtimeManager] 📡 Subscribe request: ${channelName}`);

    // Get existing subscription or create new one
    let sub = this.subscriptions.get(channelName);

    if (!sub) {
      console.log(`[RealtimeManager] ✨ Creating NEW channel: ${channelName}`);
      sub = this.createSubscription(channelName, config);
      this.subscriptions.set(channelName, sub);
    } else {
      console.log(`[RealtimeManager] ♻️  Reusing EXISTING channel: ${channelName} (${sub.callbacks.size} callbacks)`);
    }

    // Add callback to this subscription
    sub.callbacks.add(callback);

    // Return unsubscribe function
    return () => {
      this.unsubscribe(channelName, callback);
    };
  }

  /**
   * Create a new channel subscription with error handling
   */
  private createSubscription<T>(
    channelName: string,
    config: {
      event: string;
      schema: string;
      table: string;
      filter?: string;
    }
  ): ChannelSubscription {
    const channel = supabase.channel(channelName);

    const sub: ChannelSubscription = {
      channel,
      callbacks: new Set(),
      status: 'CONNECTING',
      retryCount: 0,
    };

    // Configure channel with postgres_changes event
    channel.on(
      'postgres_changes' as any,
      {
        event: config.event as any,
        schema: config.schema,
        table: config.table,
        filter: config.filter,
      },
      (payload: any) => {
        console.log(`[RealtimeManager] 📨 Received update on ${channelName}:`, payload.eventType);
        // Broadcast to all callbacks
        sub.callbacks.forEach((cb) => {
          try {
            cb(payload);
          } catch (error) {
            console.error(`[RealtimeManager] ❌ Callback error on ${channelName}:`, error);
          }
        });
      }
    );

    // Subscribe with status handling
    channel.subscribe((status) => {
      console.log(`[RealtimeManager] 🔌 ${channelName} status: ${status}`);
      sub.status = status as any;

      if (status === 'SUBSCRIBED') {
        console.log(`[RealtimeManager] ✅ ${channelName} successfully subscribed`);
        // Reset retry count on success
        sub.retryCount = 0;
        if (sub.retryTimeout) {
          clearTimeout(sub.retryTimeout);
          sub.retryTimeout = undefined;
        }
      } else if (status === 'CHANNEL_ERROR') {
        // Use console.warn instead of console.error to avoid crashing UI
        console.warn(`[RealtimeManager] ⚠️  ${channelName} CHANNEL_ERROR`);
        this.handleError(channelName, sub, config);
      } else if (status === 'TIMED_OUT') {
        console.warn(`[RealtimeManager] ⏱️  ${channelName} TIMED_OUT`);
        this.handleError(channelName, sub, config);
      } else if (status === 'CLOSED') {
        console.warn(`[RealtimeManager] 🔒 ${channelName} CLOSED`);
      }
    });

    return sub;
  }

  /**
   * Handle subscription errors with exponential backoff retry
   */
  private handleError(
    channelName: string,
    sub: ChannelSubscription,
    config: {
      event: string;
      schema: string;
      table: string;
      filter?: string;
    }
  ) {
    if (sub.retryCount >= this.MAX_RETRIES) {
      console.warn(
        `[RealtimeManager] 💀 ${channelName} failed after ${this.MAX_RETRIES} retries - giving up`
      );
      return;
    }

    sub.retryCount++;
    // Exponential backoff: 2s, 4s, 8s
    const delay = this.RETRY_DELAY * Math.pow(2, sub.retryCount - 1);

    console.log(
      `[RealtimeManager] 🔄 Retrying ${channelName} in ${delay}ms (attempt ${sub.retryCount}/${this.MAX_RETRIES})`
    );

    sub.retryTimeout = setTimeout(() => {
      console.log(`[RealtimeManager] 🔌 Reconnecting ${channelName}...`);

      // Cleanup old channel
      try {
        sub.channel.unsubscribe();
      } catch (error) {
        console.warn(`[RealtimeManager] Warning during unsubscribe:`, error);
      }

      // Create new subscription with same config
      const newSub = this.createSubscription(channelName, config);
      // Transfer callbacks from old subscription
      newSub.callbacks = sub.callbacks;
      newSub.retryCount = sub.retryCount; // Keep retry count
      this.subscriptions.set(channelName, newSub);
    }, delay);
  }

  /**
   * Unsubscribe a specific callback from a channel
   * Channel is automatically cleaned up when last callback is removed
   */
  private unsubscribe<T>(
    channelName: string,
    callback: SubscriptionCallback<T>
  ) {
    const sub = this.subscriptions.get(channelName);
    if (!sub) return;

    console.log(`[RealtimeManager] 🔕 Unsubscribe from: ${channelName}`);
    sub.callbacks.delete(callback);

    // If no more callbacks, cleanup the channel completely
    if (sub.callbacks.size === 0) {
      console.log(`[RealtimeManager] 🧹 Cleaning up channel: ${channelName} (no more listeners)`);

      // Clear any pending retry
      if (sub.retryTimeout) {
        clearTimeout(sub.retryTimeout);
      }

      // Unsubscribe from Supabase
      try {
        sub.channel.unsubscribe();
      } catch (error) {
        console.warn(`[RealtimeManager] Warning during cleanup:`, error);
      }

      // Remove from map
      this.subscriptions.delete(channelName);
    } else {
      console.log(`[RealtimeManager] 👥 ${channelName} still has ${sub.callbacks.size} listeners`);
    }
  }

  /**
   * Cleanup all subscriptions (call on app unmount/exit)
   */
  cleanup() {
    console.log(`[RealtimeManager] 🧹 Cleanup all subscriptions (${this.subscriptions.size} channels)`);

    this.subscriptions.forEach((sub, channelName) => {
      if (sub.retryTimeout) {
        clearTimeout(sub.retryTimeout);
      }
      try {
        sub.channel.unsubscribe();
      } catch (error) {
        console.warn(`[RealtimeManager] Warning cleaning up ${channelName}:`, error);
      }
    });

    this.subscriptions.clear();
    console.log('[RealtimeManager] ✅ All subscriptions cleaned up');
  }

  /**
   * Get status of all active subscriptions (for debugging)
   */
  getStatus(): Record<string, { status: string; callbackCount: number }> {
    const status: Record<string, { status: string; callbackCount: number }> = {};
    this.subscriptions.forEach((sub, channelName) => {
      status[channelName] = {
        status: sub.status,
        callbackCount: sub.callbacks.size,
      };
    });
    return status;
  }
}

// Export singleton instance
export const realtimeManager = new RealtimeManager();
