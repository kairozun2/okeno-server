/**
 * Validation utilities for user input
 */

// Profanity/offensive words filter (multi-language)
const BLOCKED_WORDS = [
  // Russian profanity
  'сука', 'сук', 'блять', 'блят', 'хуй', 'хуя', 'пизд', 'ебать', 'ебат', 'ебал', 'ебан', 'мудак', 'мудач', 'уебок', 'уебк',
  'дебил', 'идиот', 'долбоеб', 'гондон', 'пидор', 'пидар', 'залупа', 'шлюха',

  // English profanity
  'fuck', 'shit', 'bitch', 'ass', 'dick', 'cock', 'pussy', 'cunt', 'bastard', 'damn', 'hell',
  'whore', 'slut', 'fag', 'nigger', 'nigga', 'retard',

  // Politics (Russian)
  'путин', 'putin', 'зеленский', 'zelensky', 'байден', 'biden', 'трамп', 'trump',
  'кремль', 'kremlin', 'украина', 'ukraine', 'россия', 'russia', 'война', 'war',

  // Family/personal (Russian)
  'мама', 'mama', 'папа', 'papa', 'родител', 'parent', 'семья', 'family', 'отец', 'father',
  'мать', 'mother', 'сын', 'son', 'дочь', 'daughter', 'брат', 'brother', 'сестра', 'sister',
  'ребенок', 'child', 'дети', 'children', 'kid',

  // Sensitive topics
  'смерть', 'death', 'убийство', 'murder', 'kill', 'die', 'suicide', 'самоубийство',
  'террор', 'terror', 'bomb', 'бомба', 'weapon', 'оружие',
];

/**
 * Check if text contains blocked words
 */
export function containsBlockedWords(text: string): boolean {
  const normalized = text.toLowerCase().trim();

  return BLOCKED_WORDS.some(word => {
    // Check for exact match or as part of word
    const regex = new RegExp(`\\b${word}|${word}\\b`, 'i');
    return regex.test(normalized);
  });
}

/**
 * Validate username
 * Rules:
 * - Only Latin letters (a-z, A-Z), numbers (0-9), underscore (_), dot (.)
 * - Minimum 4 characters
 * - Maximum 20 characters
 * - No blocked words
 */
export function validateUsername(username: string): {
  valid: boolean;
  error?: string;
} {
  const trimmed = username.trim();

  // Check length
  if (trimmed.length < 4) {
    return { valid: false, error: 'Username must be at least 4 characters' };
  }

  if (trimmed.length > 20) {
    return { valid: false, error: 'Username must be at most 20 characters' };
  }

  // Check for Latin characters only (a-z, A-Z, 0-9, _, .)
  const latinRegex = /^[a-zA-Z0-9_.]+$/;
  if (!latinRegex.test(trimmed)) {
    return { valid: false, error: 'Username must contain only Latin letters, numbers, underscore or dot' };
  }

  // Check for blocked words
  if (containsBlockedWords(trimmed)) {
    return { valid: false, error: 'Username contains inappropriate content' };
  }

  return { valid: true };
}

/**
 * Validate memory text (post content)
 */
export function validateMemoryText(text: string): {
  valid: boolean;
  error?: string;
} {
  const trimmed = text.trim();

  if (trimmed.length === 0) {
    return { valid: false, error: 'Memory text cannot be empty' };
  }

  if (trimmed.length > 5000) {
    return { valid: false, error: 'Memory text is too long (max 5000 characters)' };
  }

  // Check for blocked words
  if (containsBlockedWords(trimmed)) {
    return { valid: false, error: 'Memory contains inappropriate content' };
  }

  return { valid: true };
}

/**
 * Generate unique user ID for account recovery
 * Format: XXXX-XXXX-XXXX (12 chars, base36)
 */
export function generateUniqueId(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 10).toUpperCase();

  const combined = (timestamp + random).padEnd(12, '0').substring(0, 12);

  return `${combined.substring(0, 4)}-${combined.substring(4, 8)}-${combined.substring(8, 12)}`;
}
