/**
 * React Query hooks for Memories API
 * Manages server state, caching, and synchronization
 */

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import * as api from '@/lib/api';
import { Memory, Emotion } from '@/lib/store';

// Query Keys
export const queryKeys = {
  memories: ['memories'] as const,
  memoriesAll: () => [...queryKeys.memories, 'all'] as const,
  memoriesSaved: () => [...queryKeys.memories, 'saved'] as const,
  user: ['user'] as const,
};

/**
 * Fetch all memories
 */
export function useMemories(params?: { saved?: boolean }) {
  return useQuery({
    queryKey: [...queryKeys.memories, params?.saved ? 'saved' : 'all', params] as const,
    queryFn: () => api.memories.getAll(params),
    staleTime: 1000 * 60 * 5, // 5 minutes
    gcTime: 1000 * 60 * 30, // 30 minutes (formerly cacheTime)
  });
}

/**
 * Create a new memory
 */
export function useCreateMemory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: {
      text: string;
      emotion: Emotion;
      imageUrl?: string;
      locationText?: string;
      latitude?: number;
      longitude?: number;
    }) => api.memories.create(data),
    onSuccess: () => {
      // Invalidate and refetch memories
      queryClient.invalidateQueries({ queryKey: queryKeys.memories });
    },
  });
}

/**
 * Echo (like) a memory
 */
export function useEchoMemory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (memoryId: string) => api.memories.echo(memoryId),
    onMutate: async (memoryId) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: queryKeys.memories });

      // Snapshot the previous value
      const previousMemories = queryClient.getQueryData(queryKeys.memoriesAll());

      // Optimistically update
      queryClient.setQueriesData({ queryKey: queryKeys.memories }, (old: any) => {
        if (!old?.memories) return old;
        return {
          ...old,
          memories: old.memories.map((m: Memory) =>
            m.id === memoryId ? { ...m, echoCount: m.echoCount + 1 } : m
          ),
        };
      });

      return { previousMemories };
    },
    onError: (_err, _memoryId, context) => {
      // Rollback on error
      if (context?.previousMemories) {
        queryClient.setQueryData(queryKeys.memoriesAll(), context.previousMemories);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.memories });
    },
  });
}

/**
 * Toggle save status
 */
export function useToggleSaveMemory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (memoryId: string) => api.memories.toggleSave(memoryId),
    onMutate: async (memoryId) => {
      await queryClient.cancelQueries({ queryKey: queryKeys.memories });

      const previousMemories = queryClient.getQueryData(queryKeys.memoriesAll());

      // Optimistically update
      queryClient.setQueriesData({ queryKey: queryKeys.memories }, (old: any) => {
        if (!old?.memories) return old;
        return {
          ...old,
          memories: old.memories.map((m: Memory) =>
            m.id === memoryId ? { ...m, isSaved: !m.isSaved } : m
          ),
        };
      });

      return { previousMemories };
    },
    onError: (_err, _memoryId, context) => {
      if (context?.previousMemories) {
        queryClient.setQueryData(queryKeys.memoriesAll(), context.previousMemories);
      }
    },
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.memories });
    },
  });
}

/**
 * Delete a memory
 */
export function useDeleteMemory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (memoryId: string) => api.memories.delete(memoryId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.memories });
    },
  });
}

/**
 * Upload media file
 */
export function useUploadMedia() {
  return useMutation({
    mutationFn: (file: { uri: string; type: string; name: string }) =>
      api.media.upload(file),
  });
}

/**
 * Authentication hooks
 */
export function useRegister() {
  return useMutation({
    mutationFn: (data: { username: string; visualKeyPattern: number[] }) =>
      api.auth.register(data.username, data.visualKeyPattern),
  });
}

export function useLogin() {
  return useMutation({
    mutationFn: (data: { username: string; visualKeyPattern: number[] }) =>
      api.auth.login(data.username, data.visualKeyPattern),
  });
}

export function useLogout() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: () => api.auth.logout(),
    onSuccess: () => {
      // Clear all cached data
      queryClient.clear();
    },
  });
}
