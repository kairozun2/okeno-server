import 'react-native-url-polyfill/auto';
import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Supabase configuration from environment variables
const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

// Create Supabase client with AsyncStorage for session persistence
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Database types for TypeScript
export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          username: string;
          avatar_emoji: string;
          visual_key_hash: string;
          is_verified: boolean;
          is_admin: boolean;
          is_super_admin: boolean;
          is_banned: boolean;
          banned_at: string | null;
          banned_by: string | null;
          ban_reason: string | null;
          username_color: string | null;
          username_last_changed: string | null;
          color_last_changed: string | null;
          social_links: Array<{ platform: string; url: string }>;
          is_private: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          username: string;
          avatar_emoji: string;
          visual_key_hash: string;
          is_verified?: boolean;
          is_admin?: boolean;
          is_super_admin?: boolean;
          is_banned?: boolean;
          banned_at?: string | null;
          banned_by?: string | null;
          ban_reason?: string | null;
          username_color?: string | null;
          username_last_changed?: string | null;
          color_last_changed?: string | null;
          social_links?: Array<{ platform: string; url: string }>;
          is_private?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          username?: string;
          avatar_emoji?: string;
          visual_key_hash?: string;
          is_verified?: boolean;
          is_admin?: boolean;
          is_super_admin?: boolean;
          is_banned?: boolean;
          banned_at?: string | null;
          banned_by?: string | null;
          ban_reason?: string | null;
          username_color?: string | null;
          username_last_changed?: string | null;
          color_last_changed?: string | null;
          social_links?: Array<{ platform: string; url: string }>;
          is_private?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      memories: {
        Row: {
          id: string;
          user_id: string;
          text: string;
          emotion: string;
          image_url: string | null;
          video_url: string | null;
          echo_count: number;
          is_archived: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          text: string;
          emotion: string;
          image_url?: string | null;
          video_url?: string | null;
          echo_count?: number;
          is_archived?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          text?: string;
          emotion?: string;
          image_url?: string | null;
          video_url?: string | null;
          echo_count?: number;
          is_archived?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      echoes: {
        Row: {
          id: string;
          user_id: string;
          memory_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          memory_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          memory_id?: string;
          created_at?: string;
        };
      };
      saves: {
        Row: {
          id: string;
          user_id: string;
          memory_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          memory_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          memory_id?: string;
          created_at?: string;
        };
      };
      comments: {
        Row: {
          id: string;
          user_id: string;
          memory_id: string;
          text: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          memory_id: string;
          text: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          memory_id?: string;
          text?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      notifications: {
        Row: {
          id: string;
          user_id: string;
          type: 'like' | 'comment' | 'follow';
          from_user_id: string;
          memory_id: string | null;
          comment_text: string | null;
          is_read: boolean;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          type: 'like' | 'comment' | 'follow';
          from_user_id: string;
          memory_id?: string | null;
          comment_text?: string | null;
          is_read?: boolean;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          type?: 'like' | 'comment' | 'follow';
          from_user_id?: string;
          memory_id?: string | null;
          comment_text?: string | null;
          is_read?: boolean;
          created_at?: string;
        };
      };
      follows: {
        Row: {
          id: string;
          follower_id: string;
          following_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          follower_id: string;
          following_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          follower_id?: string;
          following_id?: string;
          created_at?: string;
        };
      };
      hidden_users: {
        Row: {
          id: string;
          user_id: string;
          hidden_user_id: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          hidden_user_id: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          hidden_user_id?: string;
          created_at?: string;
        };
      };
      conversations: {
        Row: {
          id: string;
          user1_id: string;
          user2_id: string;
          last_message_at: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user1_id: string;
          user2_id: string;
          last_message_at?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user1_id?: string;
          user2_id?: string;
          last_message_at?: string;
          created_at?: string;
        };
      };
      messages: {
        Row: {
          id: string;
          conversation_id: string;
          sender_id: string;
          text: string;
          is_read: boolean;
          reply_to_id: string | null;
          edited_at: string | null;
          deleted_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          conversation_id: string;
          sender_id: string;
          text: string;
          is_read?: boolean;
          reply_to_id?: string | null;
          edited_at?: string | null;
          deleted_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          conversation_id?: string;
          sender_id?: string;
          text?: string;
          is_read?: boolean;
          reply_to_id?: string | null;
          edited_at?: string | null;
          deleted_at?: string | null;
          created_at?: string;
        };
      };
      message_reactions: {
        Row: {
          id: string;
          message_id: string;
          user_id: string;
          emoji: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          message_id: string;
          user_id: string;
          emoji: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          message_id?: string;
          user_id?: string;
          emoji?: string;
          created_at?: string;
        };
      };
    };
    Views: {};
    Functions: {};
  };
};
