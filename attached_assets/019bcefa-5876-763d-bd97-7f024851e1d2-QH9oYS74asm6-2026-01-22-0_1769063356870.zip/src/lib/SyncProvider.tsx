import React, { useEffect } from 'react';
import { AppState } from 'react-native';
import { useRealtimeSync } from './realtime';
import { startAutoSync, stopAutoSync, useSyncStore } from './sync-store';

/**
 * Sync Provider - handles real-time sync and offline queue
 * Must be placed inside QueryClientProvider
 */
export function SyncProvider({ children }: { children: React.ReactNode }) {
  const { isConnected } = useRealtimeSync();
  const syncPendingActions = useSyncStore(s => s.syncPendingActions);

  useEffect(() => {
    // Start auto-sync when component mounts
    startAutoSync();

    // Handle app state changes (background/foreground)
    const subscription = AppState.addEventListener('change', (nextAppState) => {
      if (nextAppState === 'active') {
        // App came to foreground - sync pending actions
        syncPendingActions();
      }
    });

    return () => {
      stopAutoSync();
      subscription.remove();
    };
  }, [syncPendingActions]);

  // Log connection status (development only)
  useEffect(() => {
    if (__DEV__) {
      console.log('[Sync] WebSocket:', isConnected ? 'Connected' : 'Disconnected');
    }
  }, [isConnected]);

  return <>{children}</>;
}
