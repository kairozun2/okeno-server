import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from './api-client';
import { useAppStore } from './store';

// Auth hooks
export function useRegister() {
  const queryClient = useQueryClient();
  const setUserId = useAppStore(s => s.setUserId);
  const setUserName = useAppStore(s => s.setUserName);
  const setAuthenticated = useAppStore(s => s.setAuthenticated);

  return useMutation({
    mutationFn: async ({
      username,
      password,
    }: {
      username: string;
      password: string;
    }) => {
      const response = await apiClient.register(username, password);
      return response;
    },
    onSuccess: (data) => {
      apiClient.setAuthToken(data.token);
      setUserId(data.user.id);
      setUserName(data.user.username);
      setAuthenticated(true);
      queryClient.invalidateQueries({ queryKey: ['user'] });
    },
  });
}

export function useLogin() {
  const queryClient = useQueryClient();
  const setUserId = useAppStore(s => s.setUserId);
  const setUserName = useAppStore(s => s.setUserName);
  const setAuthenticated = useAppStore(s => s.setAuthenticated);

  return useMutation({
    mutationFn: async ({
      username,
      password,
    }: {
      username: string;
      password: string;
    }) => {
      const response = await apiClient.login(username, password);
      return response;
    },
    onSuccess: (data) => {
      apiClient.setAuthToken(data.token);
      setUserId(data.user.id);
      setUserName(data.user.username);
      setAuthenticated(true);
      queryClient.invalidateQueries({ queryKey: ['user'] });
    },
  });
}

export function useCurrentUser() {
  return useQuery({
    queryKey: ['user'],
    queryFn: () => apiClient.getCurrentUser(),
    enabled: !!apiClient.getAuthToken(),
    retry: false,
  });
}

// Memory hooks
export function useMemories(params?: { skip?: number; limit?: number }) {
  return useQuery({
    queryKey: ['memories', params],
    queryFn: () => apiClient.getMemories(params),
  });
}

export function useMemory(id: string) {
  return useQuery({
    queryKey: ['memory', id],
    queryFn: () => apiClient.getMemoryById(id),
    enabled: !!id,
  });
}

export function useCreateMemory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: { text: string; emotion: string; imageUrl?: string }) =>
      apiClient.createMemory(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['memories'] });
      queryClient.invalidateQueries({ queryKey: ['feed'] });
    },
  });
}

export function useUpdateMemory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      id,
      data,
    }: {
      id: string;
      data: { text?: string; emotion?: string };
    }) => apiClient.updateMemory(id, data),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['memory', variables.id] });
      queryClient.invalidateQueries({ queryKey: ['memories'] });
    },
  });
}

export function useDeleteMemory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => apiClient.deleteMemory(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['memories'] });
    },
  });
}

export function useToggleEcho() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (memoryId: string) => apiClient.toggleEcho(memoryId),
    onSuccess: (_, memoryId) => {
      queryClient.invalidateQueries({ queryKey: ['memory', memoryId] });
      queryClient.invalidateQueries({ queryKey: ['memories'] });
    },
  });
}

export function useToggleSave() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (memoryId: string) => apiClient.toggleSave(memoryId),
    onSuccess: (_, memoryId) => {
      queryClient.invalidateQueries({ queryKey: ['memory', memoryId] });
      queryClient.invalidateQueries({ queryKey: ['memories'] });
    },
  });
}

export function useToggleArchive() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (memoryId: string) => apiClient.toggleArchive(memoryId),
    onSuccess: (_, memoryId) => {
      queryClient.invalidateQueries({ queryKey: ['memory', memoryId] });
      queryClient.invalidateQueries({ queryKey: ['memories'] });
    },
  });
}

// Comments hooks
export function useComments(memoryId: string) {
  return useQuery({
    queryKey: ['comments', memoryId],
    queryFn: () => apiClient.getComments(memoryId),
    enabled: !!memoryId,
  });
}

export function useCreateComment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ memoryId, text }: { memoryId: string; text: string }) =>
      apiClient.createComment(memoryId, text),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['comments', variables.memoryId] });
    },
  });
}

export function useDeleteComment() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({
      memoryId,
      commentId,
    }: {
      memoryId: string;
      commentId: string;
    }) => apiClient.deleteComment(memoryId, commentId),
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['comments', variables.memoryId] });
    },
  });
}

// Upload hook
export function useUploadMedia() {
  return useMutation({
    mutationFn: (file: { uri: string; name: string; type: string }) =>
      apiClient.uploadMedia(file),
  });
}

// User search hook
export function useSearchUsers(query: string) {
  return useQuery({
    queryKey: ['users', 'search', query],
    queryFn: () => apiClient.searchUsers(query),
    enabled: query.length > 0,
  });
}

// Follow hooks
export function useFollowUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (userId: string) => apiClient.followUser(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
  });
}

export function useUnfollowUser() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (userId: string) => apiClient.unfollowUser(userId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['users'] });
    },
  });
}

// Feed hook
export function useFeed(params?: { skip?: number; limit?: number }) {
  return useQuery({
    queryKey: ['feed', params],
    queryFn: () => apiClient.getFeed(params),
  });
}
