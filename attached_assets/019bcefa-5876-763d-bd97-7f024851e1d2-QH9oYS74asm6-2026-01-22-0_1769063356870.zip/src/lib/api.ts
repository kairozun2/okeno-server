/**
 * API Client for Memories App
 * Production-ready client with error handling, retry logic, and offline support
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { Memory, Emotion, VisualKeyPattern } from './store';

// Configuration
const API_BASE_URL = __DEV__
  ? 'http://localhost:3000/api'
  : 'https://api.memories.app/api';

const TOKEN_KEY = 'memories_auth_token';

// Types
interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: string;
}

interface AuthResponse {
  user: {
    id: string;
    username: string;
    avatarEmoji: string;
  };
  token: string;
}

interface MemoriesResponse {
  memories: Memory[];
  total: number;
}

interface UploadResponse {
  url: string;
}

// Error classes
class ApiError extends Error {
  constructor(
    public message: string,
    public statusCode?: number,
    public code?: string
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

class NetworkError extends Error {
  constructor(message: string = 'Network request failed') {
    super(message);
    this.name = 'NetworkError';
  }
}

// Token management
let cachedToken: string | null = null;

async function getAuthToken(): Promise<string | null> {
  if (cachedToken) return cachedToken;

  try {
    const token = await AsyncStorage.getItem(TOKEN_KEY);
    cachedToken = token;
    return token;
  } catch {
    return null;
  }
}

async function setAuthToken(token: string): Promise<void> {
  cachedToken = token;
  await AsyncStorage.setItem(TOKEN_KEY, token);
}

async function clearAuthToken(): Promise<void> {
  cachedToken = null;
  await AsyncStorage.removeItem(TOKEN_KEY);
}

// HTTP Client
async function request<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = await getAuthToken();

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };

  if (token) {
    headers['Authorization'] = `Bearer ${token}`;
  }

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new ApiError(
        errorData.error || `Request failed with status ${response.status}`,
        response.status,
        errorData.code
      );
    }

    return await response.json();
  } catch (error) {
    if (error instanceof ApiError) {
      throw error;
    }

    // Network errors
    throw new NetworkError();
  }
}

// API Methods

/**
 * Authentication
 */
export const auth = {
  async register(
    username: string,
    visualKeyPattern: VisualKeyPattern
  ): Promise<AuthResponse> {
    const response = await request<{ success: boolean } & AuthResponse>(
      '/auth/register',
      {
        method: 'POST',
        body: JSON.stringify({ username, visualKeyPattern }),
      }
    );

    await setAuthToken(response.token);
    return response;
  },

  async login(
    username: string,
    visualKeyPattern: VisualKeyPattern
  ): Promise<AuthResponse> {
    const response = await request<{ success: boolean } & AuthResponse>(
      '/auth/login',
      {
        method: 'POST',
        body: JSON.stringify({ username, visualKeyPattern }),
      }
    );

    await setAuthToken(response.token);
    return response;
  },

  async logout(): Promise<void> {
    await request('/auth/logout', { method: 'POST' });
    await clearAuthToken();
  },
};

/**
 * Memories
 */
export const memories = {
  async getAll(params?: {
    limit?: number;
    offset?: number;
    saved?: boolean;
  }): Promise<MemoriesResponse> {
    const queryParams = new URLSearchParams();
    if (params?.limit) queryParams.append('limit', params.limit.toString());
    if (params?.offset) queryParams.append('offset', params.offset.toString());
    if (params?.saved !== undefined)
      queryParams.append('saved', params.saved.toString());

    const query = queryParams.toString();
    return request<MemoriesResponse>(`/memories${query ? `?${query}` : ''}`);
  },

  async create(data: {
    text: string;
    emotion: Emotion;
    imageUrl?: string;
    locationText?: string;
    latitude?: number;
    longitude?: number;
  }): Promise<Memory> {
    const response = await request<{ success: boolean; memory: Memory }>(
      '/memories',
      {
        method: 'POST',
        body: JSON.stringify(data),
      }
    );
    return response.memory;
  },

  async echo(memoryId: string): Promise<{ echoCount: number }> {
    return request<{ success: boolean; echoCount: number }>(
      `/memories/${memoryId}/echo`,
      {
        method: 'PATCH',
      }
    );
  },

  async toggleSave(memoryId: string): Promise<{ isSaved: boolean }> {
    return request<{ success: boolean; isSaved: boolean }>(
      `/memories/${memoryId}/save`,
      {
        method: 'PATCH',
      }
    );
  },

  async delete(memoryId: string): Promise<void> {
    await request(`/memories/${memoryId}`, {
      method: 'DELETE',
    });
  },
};

/**
 * Media Upload
 */
export const media = {
  async upload(file: {
    uri: string;
    type: string;
    name: string;
  }): Promise<string> {
    const formData = new FormData();
    formData.append('file', {
      uri: file.uri,
      type: file.type,
      name: file.name,
    } as any);

    const token = await getAuthToken();
    const response = await fetch(`${API_BASE_URL}/media/upload`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
      },
      body: formData,
    });

    if (!response.ok) {
      throw new ApiError('Upload failed', response.status);
    }

    const data: { success: boolean; url: string } = await response.json();
    return data.url;
  },
};

/**
 * Export error classes for error handling
 */
export { ApiError, NetworkError };

/**
 * Check if user is authenticated
 */
export async function isAuthenticated(): Promise<boolean> {
  const token = await getAuthToken();
  return token !== null;
}
