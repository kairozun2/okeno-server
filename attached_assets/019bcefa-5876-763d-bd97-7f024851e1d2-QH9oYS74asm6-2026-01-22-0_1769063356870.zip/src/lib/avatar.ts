/**
 * Deterministic emoji avatar generator
 * Same user = same emoji always, but practically infinite variations
 */

const AVATAR_EMOJIS = [
  '🌲', '🌳', '🌴', '🌵', '🌾', '🌿', '☘️', '🍀', '🍁', '🍂',
  '🍃', '🌺', '🌻', '🌼', '🌷', '🌱', '🌸', '🏵️', '🌹', '🥀',
  '🌊', '🌙', '⭐', '✨', '🌟', '💫', '☄️', '🌠', '🌌', '🌈',
  '🔥', '💧', '❄️', '🌪️', '☀️', '⛅', '🌤️', '⛈️', '🌥️', '☁️',
  '🦋', '🐝', '🐞', '🦗', '🕊️', '🦢', '🦚', '🦜', '🦉', '🦅',
  '🐢', '🐸', '🦎', '🐍', '🐠', '🐟', '🐡', '🦈', '🐙', '🦑',
  '🍄', '🌰', '🥜', '🫘', '🌽', '🥕', '🫐', '🍇', '🍊', '🍋',
];

/**
 * Improved hash function with better distribution
 * Uses FNV-1a algorithm for better randomness
 */
function hashString(str: string): number {
  let hash = 2166136261; // FNV offset basis
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return Math.abs(hash >>> 0); // Convert to unsigned 32-bit
}

/**
 * Generates a deterministic emoji avatar based on user identifier
 * @param identifier - Any unique string (name, id, pattern hash)
 */
export function generateAvatar(identifier: string): string {
  if (!identifier || identifier.trim().length === 0) {
    return '🌿'; // Default
  }

  const hash = hashString(identifier.toLowerCase().trim());
  const index = hash % AVATAR_EMOJIS.length;
  return AVATAR_EMOJIS[index];
}

/**
 * Generates avatar from Visual Key Pattern with added timestamp salt for uniqueness
 */
export function generateAvatarFromPattern(pattern: number[]): string {
  if (!pattern || pattern.length === 0) {
    return '🌿';
  }

  // Create a more complex hash by combining pattern with its reversed version
  // and adding position weights to ensure different patterns produce different emojis
  const weightedPattern = pattern.map((val, idx) => `${val * (idx + 1)}`).join('-');
  const reversedPattern = [...pattern].reverse().join('-');
  const patternString = `${weightedPattern}:${reversedPattern}:${pattern.length}`;

  return generateAvatar(patternString);
}
