import React from 'react';
import { useMutation, useQuery, useQueryClient, keepPreviousData } from '@tanstack/react-query';
import { supabase } from './supabase';
import * as Crypto from 'expo-crypto';
import { Emotion } from './store';
import { generateAvatar } from './avatar';
import { MessageCache } from './message-cache';
import { persistData, getData, getDataSync } from './data-persistence';
import { realtimeManager } from './realtime-manager';

// Helper to hash visual key pattern
async function hashVisualKey(pattern: number[]): Promise<string> {
  const patternString = pattern.join(',');
  const hash = await Crypto.digestStringAsync(
    Crypto.CryptoDigestAlgorithm.SHA256,
    patternString
  );
  return hash;
}

// ============================================================================
// AUTH HOOKS
// ============================================================================

export function useAuth() {
  return useQuery({
    queryKey: ['auth'],
    queryFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return null;

      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .single();

      // Check if user is banned
      if (profile?.is_banned) {
        console.log('[Auth] User is banned, logging out...', {
          username: profile.username,
          ban_reason: profile.ban_reason,
          banned_at: profile.banned_at,
        });

        // Sign out immediately
        await supabase.auth.signOut();

        // Return null to indicate no session
        return null;
      }

      return { session, profile };
    },
    // Refetch every 30 seconds to check ban status
    refetchInterval: 30000,
  });
}

export function useSignUp() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ username, pattern }: { username: string; pattern: number[] }) => {
      // Hash the visual key pattern
      const visualKeyHash = await hashVisualKey(pattern);
      // Generate avatar from username for better uniqueness
      const avatarEmoji = generateAvatar(username);

      // Create a deterministic email from username (for Supabase auth)
      const email = `${username.toLowerCase()}@memories.app`;

      // Sign up with Supabase Auth
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password: visualKeyHash, // Use hash as password
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error('Failed to create user');

      // Create profile
      const { error: profileError } = await supabase
        .from('profiles')
        .insert({
          id: authData.user.id,
          username,
          avatar_emoji: avatarEmoji,
          visual_key_hash: visualKeyHash,
        });

      if (profileError) throw profileError;

      return { user: authData.user, username, avatarEmoji };
    },
    onSuccess: async () => {
      // CRITICAL: Clear ALL caches for new user
      console.log('[SignUp] Clearing all cached data for new user');
      queryClient.clear();

      // Clear persistent data cache
      const { clearAllData } = await import('./data-persistence');
      await clearAllData();

      // Clear message cache
      const { MessageCache } = await import('./message-cache');
      await MessageCache.clearAll();

      // Refetch auth
      queryClient.invalidateQueries({ queryKey: ['auth'] });
    },
  });
}

export function useSignIn() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ username, pattern }: { username: string; pattern: number[] }) => {
      const visualKeyHash = await hashVisualKey(pattern);

      // Check if input is a UUID (Recovery ID)
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      let actualUsername = username;

      if (uuidRegex.test(username)) {
        // Input is a UUID (Recovery ID) - look up the actual username
        console.log('[Login] Detected UUID, looking up username...');
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('username')
          .eq('id', username)
          .single();

        if (profileError || !profile) {
          console.error('[Login] Profile lookup failed:', profileError);
          throw new Error('Invalid Recovery ID');
        }

        actualUsername = profile.username;
        console.log('[Login] Found username:', actualUsername);
      }

      const email = `${actualUsername.toLowerCase()}@memories.app`;

      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password: visualKeyHash,
      });

      if (error) throw error;

      // Check if user is banned
      if (data.user) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('is_banned, ban_reason, username')
          .eq('id', data.user.id)
          .single();

        if (profile?.is_banned) {
          console.log('[Login] User is banned:', {
            username: profile.username,
            reason: profile.ban_reason,
          });

          // Sign out immediately
          await supabase.auth.signOut();

          throw new Error(
            profile.ban_reason
              ? `Account banned: ${profile.ban_reason}`
              : 'Your account has been banned'
          );
        }
      }

      return data;
    },
    onSuccess: async () => {
      // CRITICAL: Clear ALL React Query cache to prevent showing old user's data
      console.log('[Login] Clearing all cached data for new session');
      queryClient.clear();

      // Clear the persistent data cache
      const { clearAllData } = await import('./data-persistence');
      await clearAllData();

      // Clear message cache
      const { MessageCache } = await import('./message-cache');
      await MessageCache.clearAll();

      // Force refetch critical queries for new user
      console.log('[Login] Triggering refetch for new user data');
      await queryClient.refetchQueries({ queryKey: ['auth'] });
      await queryClient.refetchQueries({ queryKey: ['memories'] });
      await queryClient.refetchQueries({ queryKey: ['conversations'] });
    },
  });
}

export function useSignOut() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async () => {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
    },
    onSuccess: async () => {
      // CRITICAL: Clear ALL React Query cache on sign out
      console.log('[SignOut] Clearing all cached data');
      queryClient.clear();

      // Clear the persistent data cache
      const { clearAllData } = await import('./data-persistence');
      await clearAllData();

      // Clear message cache
      const { MessageCache } = await import('./message-cache');
      await MessageCache.clearAll();

      // Clear Zustand store user data
      const { useAppStore } = await import('./store');
      console.log('[SignOut] Clearing user data from Zustand store');
      useAppStore.getState().clearUserData();

      // Clear Realtime subscriptions
      const { realtimeManager } = await import('./realtime-manager');
      console.log('[SignOut] Cleaning up Realtime subscriptions');
      realtimeManager.cleanup();
    },
  });
}

// ============================================================================
// MEMORIES HOOKS
// ============================================================================

export function useMemories() {
  const { data: auth } = useAuth();
  const queryClient = useQueryClient();

  // Setup Realtime subscriptions
  React.useEffect(() => {
    if (!auth?.profile?.id) return;

    console.log('[Memories] Setting up Realtime subscriptions');

    // Subscribe to NEW memories (INSERT events)
    const unsubscribeInsert = realtimeManager.subscribe(
      'memories:insert',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'memories',
      },
      async (payload: any) => {
        console.log('[Memories] New memory created:', payload.new);

        const newMemory = payload.new;

        // Fetch full memory data with profile info
        const { data: fullMemory } = await supabase
          .from('memories')
          .select(`
            *,
            profile:profiles(username, avatar_emoji, is_verified, username_color, social_links, is_private),
            echoes(user_id),
            saves(user_id)
          `)
          .eq('id', newMemory.id)
          .single();

        if (!fullMemory) return;

        // Transform to UI format
        const transformed = {
          id: fullMemory.id,
          text: fullMemory.text,
          emotion: fullMemory.emotion as Emotion,
          createdAt: fullMemory.created_at,
          imageUrl: fullMemory.image_url,
          videoUrl: fullMemory.video_url,
          location: fullMemory.location,
          latitude: fullMemory.latitude,
          longitude: fullMemory.longitude,
          echoCount: fullMemory.echoes?.length || 0,
          isSaved: fullMemory.saves?.some((s: any) => s.user_id === auth?.profile?.id) || false,
          isArchived: fullMemory.is_archived,
          authorId: fullMemory.user_id,
          authorName: fullMemory.profile?.username,
          authorAvatar: fullMemory.profile?.avatar_emoji,
          authorUsernameColor: fullMemory.profile?.username_color || null,
          authorSocialLinks: fullMemory.profile?.social_links || [],
          isVerified: (fullMemory.profile as any)?.is_verified || false,
          hasEchoed: fullMemory.echoes?.some((e: any) => e.user_id === auth?.profile?.id) || false,
        };

        // Add to main feed cache if it's not my own post (my posts are added by useCreateMemory)
        if (fullMemory.user_id !== auth.profile.id) {
          queryClient.setQueryData(['memories', auth.profile.id], (oldData: any[] | undefined) => {
            if (!oldData) return [transformed];
            // Prevent duplicates
            if (oldData.some((m: any) => m.id === transformed.id)) {
              console.log('[Memories] Memory already in cache, skipping');
              return oldData;
            }
            console.log('[Memories] Adding new memory to feed cache');
            return [transformed, ...oldData];
          });
        }

        console.log('[Memories] New memory processed');
      }
    );

    // Subscribe to echoes table changes
    const unsubscribeEchoes = realtimeManager.subscribe(
      'echoes:all',
      {
        event: '*',
        schema: 'public',
        table: 'echoes',
      },
      async (payload: any) => {
        console.log('[Supabase] Echo changed:', payload.eventType);

        // Get the memory_id from the echo change
        const echoData = payload.new || payload.old;
        const memoryId = echoData?.memory_id;
        const userId = echoData?.user_id;

        if (!memoryId) return;

        // Fetch updated echo count for this memory
        const { data: echoes } = await supabase
          .from('echoes')
          .select('user_id')
          .eq('memory_id', memoryId);

        const echoCount = echoes?.length || 0;
        const hasEchoed = echoes?.some((e: any) => e.user_id === auth.profile.id) || false;

        // Update all memory caches with new echo count
        const updateMemoryInCache = (memories: any[] | undefined) => {
          if (!memories) return memories;
          return memories.map((m: any) =>
            m.id === memoryId
              ? { ...m, echoCount, hasEchoed }
              : m
          );
        };

        // Update main feed
        queryClient.setQueryData(['memories', auth.profile.id], updateMemoryInCache);

        // Update my memories
        queryClient.setQueryData(['my-memories', auth.profile.id], updateMemoryInCache);

        // Update user profile memories
        queryClient.setQueriesData({ queryKey: ['user-memories'] }, updateMemoryInCache);

        console.log('[Memories] Updated echo count in cache for memory:', memoryId, 'count:', echoCount);
      }
    );

    return () => {
      console.log('[Memories] Cleaning up Realtime subscriptions');
      unsubscribeInsert();
      unsubscribeEchoes();
    };
  }, [auth?.profile?.id, queryClient]);

  return useQuery({
    queryKey: ['memories', auth?.profile?.id],
    queryFn: async () => {
      console.log('[Memories] Fetching memories for user:', auth?.profile?.id);

      try {
        // Get hidden users first
        const { data: hiddenUsers } = await supabase
          .from('hidden_users')
          .select('hidden_user_id')
          .eq('user_id', auth?.profile?.id || '');

        const hiddenUserIds = hiddenUsers?.map((h: any) => h.hidden_user_id) || [];
        console.log('[Memories] Hidden users:', hiddenUserIds.length);

        // Get following list (to check private profiles)
        const { data: following } = await supabase
          .from('follows')
          .select('following_id')
          .eq('follower_id', auth?.profile?.id || '');

        const followingIds = following?.map((f: any) => f.following_id) || [];
        console.log('[Memories] Following:', followingIds.length, 'users');

        // Get all memories with user profiles, excluding hidden users and archived memories
        let query = supabase
          .from('memories')
          .select(`
            *,
            profile:profiles!inner(username, avatar_emoji, is_verified, username_color, social_links, is_private),
            echoes(user_id),
            saves(user_id)
          `)
          .eq('is_archived', false)
          .order('created_at', { ascending: false })
          .limit(50); // Limit to 50 most recent memories for performance

        if (hiddenUserIds.length > 0) {
          query = query.not('user_id', 'in', `(${hiddenUserIds.join(',')})`);
        }

        const { data, error } = await query;

        if (error) {
          console.error('[Memories] Error fetching:', error);
          // Return cached data on error instead of throwing
          const cachedData = getDataSync<any[]>('memories');
          if (cachedData && cachedData.length > 0) {
            console.log('[Memories] Using cached data due to error');
            return cachedData;
          }
          throw error;
        }

        console.log('[Memories] Fetched', data?.length, 'memories');
        if (data && data.length > 0) {
          console.log('[Memories] First memory:', {
            text: data[0].text?.slice(0, 50),
            hasImage: !!data[0].image_url,
            hasVideo: !!data[0].video_url,
            author: data[0].profile?.username
          });
        }

        // Transform to app format
        const transformed = data?.map((memory: any) => {
          // Ensure profile exists (should always be there due to !inner join)
          if (!memory.profile) {
            console.warn('[Memories] Missing profile for memory:', memory.id);
            return null;
          }

          // Filter private profiles: hide posts from private accounts if not following
          const isPrivateProfile = memory.profile.is_private === true;
          const isOwnPost = memory.user_id === auth?.profile?.id;
          const isFollowing = followingIds.includes(memory.user_id);

          if (isPrivateProfile && !isOwnPost && !isFollowing) {
            console.log('[Memories] Filtering private post from', memory.profile.username);
            return null;
          }

          return {
            id: memory.id,
            text: memory.text,
            emotion: memory.emotion as Emotion,
            createdAt: memory.created_at,
            imageUrl: memory.image_url,
            videoUrl: memory.video_url,
            location: memory.location,
            latitude: memory.latitude,
            longitude: memory.longitude,
            echoCount: memory.echo_count,
            isSaved: memory.saves?.some((s: any) => s.user_id === auth?.profile?.id) || false,
            isArchived: memory.is_archived,
            authorId: memory.user_id,
            authorName: memory.profile?.username,
            authorAvatar: memory.profile?.avatar_emoji,
            authorUsernameColor: memory.profile?.username_color || null,
            authorSocialLinks: memory.profile?.social_links || [],
            isVerified: (memory.profile as any)?.is_verified || false,
            hasEchoed: memory.echoes?.some((e: any) => e.user_id === auth?.profile?.id) || false,
          };
        }).filter(Boolean) || []; // Remove null entries

        console.log('[Memories] Transformed', transformed.length, 'memories');

        // Persist to cache (non-blocking)
        if (transformed.length > 0) {
          persistData('memories', transformed).catch(err =>
            console.warn('[Memories] Cache persist error:', err)
          );
        }

        return transformed;
      } catch (error) {
        console.error('[Memories] Critical error:', error);
        // Try to return cached data
        const cachedData = getDataSync<any[]>('memories');
        if (cachedData && cachedData.length > 0) {
          console.log('[Memories] Using cached data due to critical error');
          return cachedData;
        }
        // Return empty array instead of throwing to prevent app crash
        return [];
      }
    },
    // CRITICAL: Show cached data INSTANTLY using placeholderData
    placeholderData: () => {
      // First try React Query cache
      const cachedData = queryClient.getQueryData<any[]>(['memories', auth?.profile?.id]);
      if (cachedData && cachedData.length > 0) {
        console.log('[Memories] ✅ Using cached data (', cachedData.length, 'memories)');
        return cachedData;
      }

      // Fallback to sync memory cache for instant display
      const syncData = getDataSync<any[]>('memories');
      if (syncData && syncData.length > 0) {
        console.log('[Memories] ✅ Using sync cache data (', syncData.length, 'memories)');
        return syncData;
      }

      return undefined;
    },
    staleTime: 0, // Always fetch fresh data
    gcTime: 0, // Don't cache
    refetchOnMount: 'always', // Always refetch on mount
    refetchOnWindowFocus: true, // Refetch on window focus
    refetchOnReconnect: true, // Refetch on reconnect
    retry: 2, // Retry failed requests twice
    retryDelay: 1000, // Wait 1 second between retries
    enabled: !!auth?.profile?.id,
  });
}

export function useMyMemories() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useQuery({
    queryKey: ['my-memories', auth?.profile?.id],
    queryFn: async () => {
      console.log('[MyMemories] Fetching my memories from server');

      const { data, error } = await supabase
        .from('memories')
        .select(`
          *,
          profile:profiles(username, avatar_emoji, is_verified, username_color, social_links),
          echoes(user_id),
          saves(user_id)
        `)
        .eq('user_id', auth?.profile?.id || '')
        .eq('is_archived', false)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const result = data?.map(memory => ({
        id: memory.id,
        text: memory.text,
        emotion: memory.emotion as Emotion,
        createdAt: memory.created_at,
        imageUrl: memory.image_url,
        videoUrl: memory.video_url,
        location: memory.location,
        latitude: memory.latitude,
        longitude: memory.longitude,
        echoCount: memory.echo_count,
        isSaved: memory.saves?.some((s: any) => s.user_id === auth?.profile?.id) || false,
        isArchived: memory.is_archived,
        authorId: memory.user_id,
        authorName: memory.profile?.username,
        authorAvatar: memory.profile?.avatar_emoji,
        authorUsernameColor: memory.profile?.username_color || null,
        authorSocialLinks: memory.profile?.social_links || [],
        isVerified: (memory.profile as any)?.is_verified || false,
        hasEchoed: memory.echoes?.some((e: any) => e.user_id === auth?.profile?.id) || false,
      })) || [];

      return result;
    },
    // Always fetch fresh data
    staleTime: 0,
    gcTime: 0,
    refetchOnMount: 'always',
    enabled: !!auth?.profile?.id,
  });
}

export function useArchivedMemories() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useQuery({
    queryKey: ['archived-memories', auth?.profile?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('memories')
        .select(`
          *,
          profile:profiles(username, avatar_emoji, is_verified, username_color, social_links),
          echoes(user_id),
          saves(user_id)
        `)
        .eq('user_id', auth?.profile?.id || '')
        .eq('is_archived', true)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Transform to app format (same as useMemories)
      const transformed = data?.map(memory => ({
        id: memory.id,
        text: memory.text,
        emotion: memory.emotion as Emotion,
        createdAt: memory.created_at,
        imageUrl: memory.image_url,
        videoUrl: memory.video_url,
        location: memory.location,
        latitude: memory.latitude,
        longitude: memory.longitude,
        echoCount: memory.echo_count,
        isSaved: memory.saves?.some((s: any) => s.user_id === auth?.profile?.id) || false,
        isArchived: memory.is_archived,
        authorId: memory.user_id,
        authorName: memory.profile?.username,
        authorAvatar: memory.profile?.avatar_emoji,
        authorUsernameColor: memory.profile?.username_color || null,
        authorSocialLinks: memory.profile?.social_links || [],
        isVerified: (memory.profile as any)?.is_verified || false,
        hasEchoed: memory.echoes?.some((e: any) => e.user_id === auth?.profile?.id) || false,
      })) || [];

      // Persist to AsyncStorage for offline access
      if (transformed.length > 0) {
        await persistData(`archived-memories:${auth?.profile?.id}`, transformed);
      }

      return transformed;
    },
    placeholderData: keepPreviousData,
    enabled: !!auth?.profile?.id,
    gcTime: Infinity,
    initialData: () => {
      return queryClient.getQueryData(['archived-memories', auth?.profile?.id]);
    },
  });
}

export function useCreateMemory() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async ({
      text,
      emotion,
      imageUrl,
      videoUrl,
      location,
      latitude,
      longitude,
    }: {
      text: string;
      emotion: Emotion;
      imageUrl?: string;
      videoUrl?: string;
      location?: string;
      latitude?: number;
      longitude?: number;
    }) => {
      console.log('[CreateMemory] Starting...', { text, emotion, userId: auth?.profile?.id, location });

      const { data, error } = await supabase
        .from('memories')
        .insert({
          user_id: auth?.profile?.id || '',
          text,
          emotion,
          image_url: imageUrl,
          video_url: videoUrl,
          location,
          latitude,
          longitude,
        })
        .select()
        .single();

      if (error) {
        console.error('[CreateMemory] Error:', error);
        throw error;
      }

      console.log('[CreateMemory] Success!', data);
      return data;
    },
    onSuccess: async (newMemory) => {
      console.log('[CreateMemory] ✅ Adding new memory to cache immediately');

      // ✅ Transform new memory to match UI format
      const transformedMemory = {
        id: newMemory.id,
        text: newMemory.text,
        emotion: newMemory.emotion as Emotion,
        createdAt: newMemory.created_at,
        imageUrl: newMemory.image_url,
        videoUrl: newMemory.video_url,
        location: newMemory.location,
        latitude: newMemory.latitude,
        longitude: newMemory.longitude,
        echoCount: 0,
        isSaved: false,
        isArchived: false,
        authorId: auth?.profile?.id,
        authorName: auth?.profile?.username,
        authorAvatar: auth?.profile?.avatar_emoji,
        authorUsernameColor: auth?.profile?.username_color || null,
        isVerified: auth?.profile?.is_verified || false,
        hasEchoed: false,
      };

      // ✅ Add to main feed IMMEDIATELY (at the TOP)
      queryClient.setQueryData(['memories', auth?.profile?.id], (oldData: any[] | undefined) => {
        console.log('[CreateMemory] Adding to main feed cache');
        const newData = oldData ? [transformedMemory, ...oldData] : [transformedMemory];
        // Save to persistent cache
        persistData('memories', newData).catch(console.error);
        return newData;
      });

      // ✅ Add to my memories IMMEDIATELY (at the TOP)
      queryClient.setQueryData(['my-memories', auth?.profile?.id], (oldData: any[] | undefined) => {
        console.log('[CreateMemory] Adding to my-memories cache');
        const newData = oldData ? [transformedMemory, ...oldData] : [transformedMemory];
        // Save to persistent cache
        persistData(`my-memories:${auth?.profile?.id}`, newData).catch(console.error);
        return newData;
      });

      // ✅ Add to user profile memories IMMEDIATELY (at the TOP)
      queryClient.setQueryData(['user-memories', auth?.profile?.id], (oldData: any[] | undefined) => {
        console.log('[CreateMemory] Adding to user-memories cache');
        const newData = oldData ? [transformedMemory, ...oldData] : [transformedMemory];
        // Save to persistent cache
        persistData(`user-memories:${auth?.profile?.id}`, newData).catch(console.error);
        return newData;
      });

      console.log('[CreateMemory] ✅ New memory added to all caches!');
    },
  });
}

export function useDeleteMemory() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async (memoryId: string) => {
      const { error } = await supabase
        .from('memories')
        .delete()
        .eq('id', memoryId);

      if (error) throw error;
      return memoryId;
    },
    onSuccess: async (memoryId) => {
      console.log('[DeleteMemory] Memory deleted, updating caches:', memoryId);
      console.log('[DeleteMemory] Current user ID:', auth?.profile?.id);

      // Update memories cache (global feed) - USE CORRECT KEY WITH USER ID
      if (auth?.profile?.id) {
        queryClient.setQueryData(['memories', auth.profile.id], (oldData: any[] | undefined) => {
          if (!oldData) return [];
          const newData = oldData.filter((m: any) => m.id !== memoryId);
          console.log('[DeleteMemory] Updated memories cache:', oldData.length, '->', newData.length);
          persistData('memories', newData).catch(console.error);
          return newData;
        });
      }

      // Update my-memories cache - CRITICAL: Must update to trigger re-render
      if (auth?.profile?.id) {
        const queryKey = ['my-memories', auth.profile.id];

        // Get current cache
        const currentCache = queryClient.getQueryData<any[]>(queryKey);
        console.log('[DeleteMemory] my-memories BEFORE:', currentCache?.length || 0);

        if (currentCache) {
          const newData = currentCache.filter((m: any) => m.id !== memoryId);
          console.log('[DeleteMemory] my-memories AFTER:', newData.length);

          // Update cache
          queryClient.setQueryData(queryKey, newData);

          // Persist to disk
          persistData(`my-memories:${auth.profile.id}`, newData).catch(console.error);

          // Force invalidate to ensure UI updates
          queryClient.invalidateQueries({ queryKey, refetchType: 'none' });
        }

        // Update user-memories cache (for user profile view)
        queryClient.setQueryData(['user-memories', auth.profile.id], (oldData: any[] | undefined) => {
          if (!oldData) return [];
          const newData = oldData.filter((m: any) => m.id !== memoryId);
          console.log('[DeleteMemory] Updated user-memories cache:', oldData.length, '->', newData.length);
          return newData;
        });

        // Invalidate ALL user-memories caches to force refresh on next view
        queryClient.invalidateQueries({
          queryKey: ['user-memories'],
          refetchType: 'none'
        });
      }

      // Update saved-memories cache if it exists
      queryClient.setQueryData(['saved-memories', auth?.profile?.id], (oldData: any[] | undefined) => {
        if (!oldData) return oldData;
        const newData = oldData.filter((m: any) => m.id !== memoryId);
        if (auth?.profile?.id) {
          persistData(`saved-memories:${auth.profile.id}`, newData).catch(console.error);
        }
        return newData;
      });

      console.log('[DeleteMemory] ✅ All caches updated');
    },
  });
}

export function useUpdateMemory() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async ({ memoryId, text, emotion }: { memoryId: string; text: string; emotion: Emotion }) => {
      console.log('[UpdateMemory] Updating memory:', memoryId);

      const { data, error } = await supabase
        .from('memories')
        .update({
          text,
          emotion,
          updated_at: new Date().toISOString(),
        })
        .eq('id', memoryId)
        .select()
        .single();

      if (error) {
        console.error('[UpdateMemory] Error:', error);
        throw error;
      }

      console.log('[UpdateMemory] Success!', data);
      return data;
    },
    onSuccess: async (updatedMemory) => {
      console.log('[UpdateMemory] ✅ Updating caches with edited memory:', updatedMemory.id);

      const memoryId = updatedMemory.id;

      // Helper function to update memory in array
      const updateMemoryInArray = (oldData: any[] | undefined) => {
        if (!oldData) return oldData;
        return oldData.map((m: any) =>
          m.id === memoryId
            ? {
                ...m,
                text: updatedMemory.text,
                emotion: updatedMemory.emotion as Emotion,
              }
            : m
        );
      };

      // Update all caches
      if (auth?.profile?.id) {
        // Update main feed
        queryClient.setQueryData(['memories', auth.profile.id], updateMemoryInArray);

        // Update my memories
        queryClient.setQueryData(['my-memories', auth.profile.id], updateMemoryInArray);

        // Update user profile memories
        queryClient.setQueryData(['user-memories', auth.profile.id], updateMemoryInArray);

        // Update saved memories
        queryClient.setQueryData(['saved-memories', auth.profile.id], updateMemoryInArray);
      }

      console.log('[UpdateMemory] ✅ All caches updated');
    },
  });
}

// ============================================================================
// ECHO (LIKE) HOOKS
// ============================================================================

export function useToggleEcho() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async (memoryId: string) => {
      console.log('[useToggleEcho] Starting toggle for memory:', memoryId, 'user:', auth?.profile?.id);

      // Check if already echoed
      const { data: existing, error: checkError } = await supabase
        .from('echoes')
        .select('id')
        .eq('user_id', auth?.profile?.id || '')
        .eq('memory_id', memoryId)
        .single();

      if (checkError && checkError.code !== 'PGRST116') {
        console.error('[useToggleEcho] Error checking existing echo:', checkError);
        throw checkError;
      }

      if (existing) {
        console.log('[useToggleEcho] Removing echo:', existing.id);
        // Remove echo
        const { error } = await supabase
          .from('echoes')
          .delete()
          .eq('id', existing.id);

        if (error) {
          console.error('[useToggleEcho] Error removing echo:', error);
          throw error;
        }
        console.log('[useToggleEcho] Echo removed successfully');
        return { action: 'removed', memoryId };
      } else {
        console.log('[useToggleEcho] Adding new echo');
        // Add echo
        const { error } = await supabase
          .from('echoes')
          .insert({
            user_id: auth?.profile?.id || '',
            memory_id: memoryId,
          });

        if (error) {
          console.error('[useToggleEcho] Error adding echo:', error);
          throw error;
        }

        // Create notification for memory author
        const { data: memory } = await supabase
          .from('memories')
          .select('user_id')
          .eq('id', memoryId)
          .single();

        if (memory && memory.user_id !== auth?.profile?.id) {
          console.log('[useToggleEcho] Creating notification for author:', memory.user_id);
          await supabase.from('notifications').insert({
            user_id: memory.user_id,
            type: 'like',
            from_user_id: auth?.profile?.id || '',
            memory_id: memoryId,
          });
        }

        console.log('[useToggleEcho] Echo added successfully');
        return { action: 'added', memoryId };
      }
    },
    onMutate: async (memoryId) => {
      console.log('[useToggleEcho] Optimistic update for memory:', memoryId);

      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: ['memories'] });
      await queryClient.cancelQueries({ queryKey: ['my-memories'] });
      await queryClient.cancelQueries({ queryKey: ['user-memories'] });

      // Get current echo state
      const { data: existing } = await supabase
        .from('echoes')
        .select('id')
        .eq('user_id', auth?.profile?.id || '')
        .eq('memory_id', memoryId)
        .single();

      const isCurrentlyEchoed = !!existing;
      const newEchoedState = !isCurrentlyEchoed;

      // Update all memory caches optimistically
      const updateMemoryInCache = (memories: any[] | undefined) => {
        if (!memories) return memories;
        return memories.map((m: any) =>
          m.id === memoryId
            ? {
                ...m,
                echoCount: newEchoedState ? (m.echoCount || 0) + 1 : Math.max(0, (m.echoCount || 0) - 1),
                hasEchoed: newEchoedState, // Use hasEchoed to match the field name in useMemories
              }
            : m
        );
      };

      // Update main feed
      if (auth?.profile?.id) {
        queryClient.setQueryData(['memories', auth.profile.id], updateMemoryInCache);
      }

      // Update my memories
      if (auth?.profile?.id) {
        queryClient.setQueryData(['my-memories', auth.profile.id], updateMemoryInCache);
      }

      // Update user profile memories
      queryClient.setQueriesData({ queryKey: ['user-memories'] }, updateMemoryInCache);

      console.log('[useToggleEcho] Optimistic update applied, new echoed state:', newEchoedState);

      return { previousState: isCurrentlyEchoed };
    },
    onSuccess: (data) => {
      console.log('[useToggleEcho] Success, action:', data.action);

      // Invalidate to sync with server
      if (auth?.profile?.id) {
        queryClient.invalidateQueries({ queryKey: ['memories', auth.profile.id] });
        queryClient.invalidateQueries({ queryKey: ['my-memories', auth.profile.id] });
      }
      queryClient.invalidateQueries({ queryKey: ['user-memories'] });
      queryClient.invalidateQueries({ queryKey: ['notifications'] });
    },
    onError: (error, memoryId, context: any) => {
      console.error('[useToggleEcho] Error, rolling back optimistic update:', error);

      // Rollback optimistic update
      if (auth?.profile?.id) {
        queryClient.invalidateQueries({ queryKey: ['memories', auth.profile.id] });
        queryClient.invalidateQueries({ queryKey: ['my-memories', auth.profile.id] });
      }
      queryClient.invalidateQueries({ queryKey: ['user-memories'] });
    },
  });
}

// ============================================================================
// SAVE/BOOKMARK HOOKS
// ============================================================================

export function useToggleSave() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async (memoryId: string) => {
      const { data: existing } = await supabase
        .from('saves')
        .select('id')
        .eq('user_id', auth?.profile?.id || '')
        .eq('memory_id', memoryId)
        .single();

      if (existing) {
        const { error } = await supabase
          .from('saves')
          .delete()
          .eq('id', existing.id);

        if (error) throw error;
        return { action: 'unsaved' };
      } else {
        const { error } = await supabase
          .from('saves')
          .insert({
            user_id: auth?.profile?.id || '',
            memory_id: memoryId,
          });

        if (error) throw error;
        return { action: 'saved' };
      }
    },
    // Optimistic update - update UI immediately
    onMutate: async (memoryId) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: ['memories'] });
      await queryClient.cancelQueries({ queryKey: ['my-memories'] });

      // Snapshot previous values
      const previousMemories = queryClient.getQueryData(['memories', auth?.profile?.id]);
      const previousMyMemories = queryClient.getQueryData(['my-memories', auth?.profile?.id]);

      // Optimistically update
      queryClient.setQueryData(['memories', auth?.profile?.id], (old: any[]) => {
        if (!old) return old;
        return old.map(memory =>
          memory.id === memoryId
            ? { ...memory, isSaved: !memory.isSaved }
            : memory
        );
      });

      queryClient.setQueryData(['my-memories', auth?.profile?.id], (old: any[]) => {
        if (!old) return old;
        return old.map(memory =>
          memory.id === memoryId
            ? { ...memory, isSaved: !memory.isSaved }
            : memory
        );
      });

      return { previousMemories, previousMyMemories };
    },
    // If mutation fails, rollback
    onError: (err, memoryId, context: any) => {
      queryClient.setQueryData(['memories', auth?.profile?.id], context?.previousMemories);
      queryClient.setQueryData(['my-memories', auth?.profile?.id], context?.previousMyMemories);
    },
    // Always refetch after error or success
    onSettled: () => {
      queryClient.invalidateQueries({ queryKey: ['memories'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['my-memories'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['saved-memories'] });
    },
  });
}

export function useSavedMemories() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useQuery({
    queryKey: ['saved-memories', auth?.profile?.id],
    queryFn: async () => {
      // ✅ Check cache FIRST - only fetch if not in cache
      const cachedData = queryClient.getQueryData<any[]>(['saved-memories', auth?.profile?.id]);
      if (cachedData && cachedData.length > 0) {
        console.log('[SavedMemories] ✅ Using cached data (', cachedData.length, 'memories) - NO FETCH');
        return cachedData;
      }

      console.log('[SavedMemories] Fetching saved memories from server');

      const { data, error } = await supabase
        .from('saves')
        .select(`
          memory:memories(
            *,
            profile:profiles(username, avatar_emoji, is_verified, username_color, social_links),
            echoes(user_id),
            saves(user_id)
          )
        `)
        .eq('user_id', auth?.profile?.id || '')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const transformed = data
        ?.filter((save: any) => save.memory !== null) // Filter out deleted memories
        ?.map((save: any) => ({
          id: save.memory.id,
          text: save.memory.text,
          emotion: save.memory.emotion as Emotion,
          createdAt: save.memory.created_at,
          imageUrl: save.memory.image_url,
          videoUrl: save.memory.video_url,
          location: save.memory.location,
          latitude: save.memory.latitude,
          longitude: save.memory.longitude,
          echoCount: save.memory.echo_count,
          isSaved: true,
          isArchived: save.memory.is_archived,
          authorId: save.memory.user_id,
          authorName: save.memory.profile?.username,
          authorAvatar: save.memory.profile?.avatar_emoji,
          authorUsernameColor: save.memory.profile?.username_color || null,
          isVerified: (save.memory.profile as any)?.is_verified || false,
          hasEchoed: save.memory.echoes?.some((e: any) => e.user_id === auth?.profile?.id) || false,
        })) || [];

      // Persist to AsyncStorage for offline access
      if (transformed.length > 0) {
        await persistData(`saved-memories:${auth?.profile?.id}`, transformed);
      }

      return transformed;
    },
    // Pre-populate cache before query runs
    placeholderData: () => {
      // Check if data exists in cache
      const existingData = queryClient.getQueryData<any[]>(['saved-memories', auth?.profile?.id]);
      if (existingData && existingData.length > 0) {
        console.log('[SavedMemories] ✅ Using placeholder data from cache (', existingData.length, 'memories)');
        return existingData;
      }

      // Try sync cache
      const syncData = getDataSync<any[]>(`saved-memories:${auth?.profile?.id}`);
      if (syncData && syncData.length > 0) {
        console.log('[SavedMemories] ✅ Using placeholder data from sync cache (', syncData.length, 'memories)');
        // Set it in React Query cache too
        queryClient.setQueryData(['saved-memories', auth?.profile?.id], syncData);
        return syncData;
      }

      return undefined;
    },
    staleTime: Infinity, // TELEGRAM-STYLE: Data NEVER becomes stale
    gcTime: Infinity, // TELEGRAM-STYLE: Keep data in cache FOREVER
    refetchOnMount: false, // DON'T refetch when component mounts
    refetchOnWindowFocus: false, // DON'T refetch on window focus
    refetchOnReconnect: false, // DON'T refetch on reconnect
    enabled: !!auth?.profile?.id,
  });
}

// ============================================================================
// ARCHIVE HOOKS
// ============================================================================

export function useToggleArchive() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ memoryId, isArchived }: { memoryId: string; isArchived: boolean }) => {
      const { error } = await supabase
        .from('memories')
        .update({ is_archived: !isArchived })
        .eq('id', memoryId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['memories'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['my-memories'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['archived-memories'] });
      queryClient.invalidateQueries({ queryKey: ['user-memories'] });
    },
  });
}

// ============================================================================
// COMMENTS HOOKS
// ============================================================================

export function useComments(memoryId: string) {
  return useQuery({
    queryKey: ['comments', memoryId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('comments')
        .select(`
          *,
          profile:profiles(username, avatar_emoji, is_verified, username_color)
        `)
        .eq('memory_id', memoryId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      return data?.map(comment => ({
        id: comment.id,
        text: comment.text,
        createdAt: comment.created_at,
        userId: comment.user_id,
        userName: comment.profile?.username,
        userAvatar: comment.profile?.avatar_emoji,
        usernameColor: comment.profile?.username_color || null,
        isVerified: (comment.profile as any)?.is_verified || false,
      })) || [];
    },
    enabled: !!memoryId,
  });
}

export function useCreateComment() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async ({ memoryId, text }: { memoryId: string; text: string }) => {
      const { data, error } = await supabase
        .from('comments')
        .insert({
          user_id: auth?.profile?.id || '',
          memory_id: memoryId,
          text,
        })
        .select()
        .single();

      if (error) throw error;

      // Create notification for memory author
      const { data: memory } = await supabase
        .from('memories')
        .select('user_id')
        .eq('id', memoryId)
        .single();

      if (memory && memory.user_id !== auth?.profile?.id) {
        await supabase.from('notifications').insert({
          user_id: memory.user_id,
          type: 'comment',
          from_user_id: auth?.profile?.id || '',
          memory_id: memoryId,
          comment_text: text,
        });
      }

      return data;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['comments', variables.memoryId] });
    },
  });
}

// ============================================================================
// NOTIFICATIONS HOOKS
// ============================================================================

export function useNotifications() {
  const { data: auth } = useAuth();

  return useQuery({
    queryKey: ['notifications', auth?.profile?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('notifications')
        .select(`
          *,
          from_profile:profiles!from_user_id(username, avatar_emoji, is_verified, username_color, social_links),
          memory:memories(image_url)
        `)
        .eq('user_id', auth?.profile?.id || '')
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;

      const transformed = data?.map(notif => ({
        id: notif.id,
        type: notif.type as 'like' | 'comment',
        userName: notif.from_profile?.username || 'Unknown',
        userAvatar: notif.from_profile?.avatar_emoji || '👤',
        isVerified: (notif.from_profile as any)?.is_verified || false,
        usernameColor: notif.from_profile?.username_color || null,
        memoryId: notif.memory_id || '',
        memoryThumbnail: notif.memory?.image_url || '',
        commentText: notif.comment_text,
        createdAt: notif.created_at,
        read: notif.is_read || false,
      })) || [];

      // Persist to AsyncStorage for offline access
      if (transformed.length > 0) {
        await persistData(`notifications:${auth?.profile?.id}`, transformed);
      }

      return transformed;
    },
    placeholderData: keepPreviousData,
    enabled: !!auth?.profile?.id,
  });
}

// Mark notification as read
export function useMarkNotificationRead() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async (notificationId: string) => {
      const { error } = await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notificationId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['notifications', auth?.profile?.id] });
    },
  });
}

// ============================================================================
// MEDIA UPLOAD HOOK
// ============================================================================

export function useUploadMedia() {
  return useMutation({
    mutationFn: async ({
      uri,
      type,
      onProgress
    }: {
      uri: string;
      type: 'image' | 'video';
      onProgress?: (progress: number) => void;
    }) => {
      const { data: auth } = await supabase.auth.getSession();
      if (!auth.session) throw new Error('Not authenticated');

      console.log('[Upload] Starting upload...', { uri, type });

      // Get file extension from URI
      const ext = uri.split('.').pop()?.split('?')[0] || (type === 'video' ? 'mp4' : 'jpg');
      const fileName = `${auth.session.user.id}/${Date.now()}.${ext}`;

      // Determine MIME type
      let mimeType = 'image/jpeg';
      if (type === 'video') {
        mimeType = 'video/mp4';
      } else if (ext === 'png') {
        mimeType = 'image/png';
      } else if (ext === 'heic' || ext === 'heif') {
        mimeType = 'image/heic';
      } else if (ext === 'webp') {
        mimeType = 'image/webp';
      }

      // For React Native, we need to use FormData with the file URI directly
      const formData = new FormData();
      formData.append('file', {
        uri: uri,
        type: mimeType,
        name: fileName,
      } as any);

      console.log('[Upload] Uploading to Supabase Storage...', {
        fileName,
        mimeType,
        type,
      });

      // Upload using XMLHttpRequest for progress tracking
      const uploadUrl = `${process.env.EXPO_PUBLIC_SUPABASE_URL}/storage/v1/object/memories/${fileName}`;

      return new Promise<{ url: string }>((resolve, reject) => {
        const xhr = new XMLHttpRequest();

        // Track upload progress
        xhr.upload.addEventListener('progress', (event) => {
          if (event.lengthComputable) {
            const percentComplete = Math.round((event.loaded / event.total) * 100);
            console.log(`[Upload] Progress: ${percentComplete}%`);
            onProgress?.(percentComplete);
          }
        });

        // Handle completion
        xhr.addEventListener('load', async () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            console.log('[Upload] Upload successful');

            // Get public URL
            const { data: { publicUrl } } = supabase.storage
              .from('memories')
              .getPublicUrl(fileName);

            console.log('[Upload] Public URL:', publicUrl);
            onProgress?.(100);
            resolve({ url: publicUrl });
          } else {
            const errorText = xhr.responseText;
            console.error('[Upload] Error:', errorText);
            reject(new Error(`Upload failed: ${errorText}`));
          }
        });

        // Handle errors
        xhr.addEventListener('error', () => {
          console.error('[Upload] Network error');
          reject(new Error('Network error during upload'));
        });

        xhr.addEventListener('abort', () => {
          console.error('[Upload] Upload aborted');
          reject(new Error('Upload aborted'));
        });

        // Start upload
        xhr.open('POST', uploadUrl);
        xhr.setRequestHeader('Authorization', `Bearer ${auth.session.access_token}`);
        xhr.send(formData);
      });
    },
  });
}

// ============================================================================
// USER SEARCH HOOK
// ============================================================================

export function useSearchUsers(searchQuery: string) {
  return useQuery({
    queryKey: ['search-users', searchQuery],
    queryFn: async () => {
      if (!searchQuery.trim()) return [];

      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, avatar_emoji, is_verified, username_color, social_links')
        .ilike('username', `%${searchQuery}%`)
        .limit(20);

      if (error) throw error;

      return data?.map(profile => ({
        id: profile.id,
        userName: profile.username,
        avatar: profile.avatar_emoji,
        isVerified: (profile as any).is_verified || false,
        usernameColor: profile.username_color || null,
        socialLinks: (profile as any).social_links || [],
      })) || [];
    },
    enabled: searchQuery.trim().length > 0,
  });
}

// Get user profile by ID
export function useUserProfile(userId: string | undefined) {
  const queryClient = useQueryClient();

  return useQuery({
    queryKey: ['user-profile', userId],
    queryFn: async () => {
      if (!userId) return null;

      // CRITICAL: Check if we already have cached data - DON'T refetch
      const cachedData = queryClient.getQueryData<any>(['user-profile', userId]);
      if (cachedData) {
        console.log('[UserProfile] ✅ Already have cached data, skipping fetch');
        return cachedData;
      }

      console.log('[UserProfile] Fetching profile for user:', userId);

      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, avatar_emoji, is_verified, is_admin, created_at, username_color, social_links')
        .eq('id', userId)
        .single();

      if (error) throw error;

      console.log('[UserProfile] Fetched profile:', data.username);
      return data;
    },
    // CRITICAL: Show cached data INSTANTLY using placeholderData
    placeholderData: () => {
      // Try React Query cache
      const cachedData = queryClient.getQueryData<any>(['user-profile', userId]);
      if (cachedData) {
        console.log('[UserProfile] ✅ Using cached data');
        return cachedData;
      }
      return undefined;
    },
    staleTime: Infinity, // TELEGRAM-STYLE: Data NEVER becomes stale
    gcTime: Infinity,
    refetchOnMount: false,
    refetchOnWindowFocus: false,
    refetchOnReconnect: false,
    enabled: !!userId,
  });
}

// ============================================================================
// HIDDEN USERS HOOKS
// ============================================================================

export function useHiddenUsers() {
  const { data: auth } = useAuth();

  return useQuery({
    queryKey: ['hidden-users', auth?.profile?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('hidden_users')
        .select('hidden_user_id, profile:profiles!hidden_user_id(username, avatar_emoji)')
        .eq('user_id', auth?.profile?.id || '');

      if (error) throw error;

      return data || [];
    },
    enabled: !!auth?.profile?.id,
  });
}

export function useHideUser() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async (userIdToHide: string) => {
      const { error } = await supabase
        .from('hidden_users')
        .insert({
          user_id: auth?.profile?.id || '',
          hidden_user_id: userIdToHide,
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hidden-users'] });
      queryClient.invalidateQueries({ queryKey: ['memories'], refetchType: 'none' });
    },
  });
}

export function useUnhideUser() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async (userIdToUnhide: string) => {
      const { error } = await supabase
        .from('hidden_users')
        .delete()
        .eq('user_id', auth?.profile?.id || '')
        .eq('hidden_user_id', userIdToUnhide);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hidden-users'] });
      queryClient.invalidateQueries({ queryKey: ['memories'], refetchType: 'none' });
    },
  });
}

// ============================================================================
// CHAT HOOKS
// ============================================================================

// Get all conversations for current user
export function useConversations() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();
  const currentUserId = auth?.session?.user?.id;

  // Setup Realtime subscription using singleton manager
  React.useEffect(() => {
    if (!currentUserId) return;

    console.log('[Conversations] Setting up Realtime subscriptions for user:', currentUserId);

    // Subscribe to conversations table (when new conversation is created)
    const unsubscribe1 = realtimeManager.subscribe(
      `conversations:user1:${currentUserId}`,
      {
        event: '*',
        schema: 'public',
        table: 'conversations',
        filter: `user1_id=eq.${currentUserId}`,
      },
      (payload: any) => {
        console.log('[Conversations] Realtime update (user1):', payload.eventType);
        // Force refetch to show new conversation
        queryClient.refetchQueries({ queryKey: ['conversations'] });
      }
    );

    const unsubscribe2 = realtimeManager.subscribe(
      `conversations:user2:${currentUserId}`,
      {
        event: '*',
        schema: 'public',
        table: 'conversations',
        filter: `user2_id=eq.${currentUserId}`,
      },
      (payload: any) => {
        console.log('[Conversations] Realtime update (user2):', payload.eventType);
        // Force refetch to show new conversation
        queryClient.refetchQueries({ queryKey: ['conversations'] });
      }
    );

    // CRITICAL: Subscribe to messages table (when new message arrives)
    // This updates last_message_at timestamp in conversations
    const unsubscribe3 = realtimeManager.subscribe(
      `messages:all:${currentUserId}`,
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
      },
      async (payload: any) => {
        console.log('[Conversations] New message received:', payload.new);

        // Get the conversation for this message
        const messageConversationId = payload.new?.conversation_id;
        if (!messageConversationId) return;

        // Check if this conversation involves current user
        const { data: conversation } = await supabase
          .from('conversations')
          .select('user1_id, user2_id')
          .eq('id', messageConversationId)
          .single();

        if (!conversation) return;

        // If current user is part of this conversation, refetch
        if (conversation.user1_id === currentUserId || conversation.user2_id === currentUserId) {
          console.log('[Conversations] Message for current user - refreshing conversations');
          queryClient.refetchQueries({ queryKey: ['conversations'] });
        }
      }
    );

    // Cleanup on unmount
    return () => {
      console.log('[Conversations] Cleaning up Realtime subscriptions');
      unsubscribe1();
      unsubscribe2();
      unsubscribe3();
    };
  }, [currentUserId, queryClient]);

  return useQuery({
    queryKey: ['conversations'],
    queryFn: async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return [];

      console.log('[Conversations] Fetching conversations for user:', session.user.id);

      // Get hidden users first
      const { data: hiddenUsers } = await supabase
        .from('hidden_users')
        .select('hidden_user_id')
        .eq('user_id', session.user.id);

      const hiddenUserIds = hiddenUsers?.map(h => h.hidden_user_id) || [];

      // Fetch conversations WITHOUT JOIN (to avoid stale profile data)
      const { data, error } = await supabase
        .from('conversations')
        .select('*')
        .or(`user1_id.eq.${session.user.id},user2_id.eq.${session.user.id}`)
        .order('last_message_at', { ascending: false });

      if (error) {
        console.error('[Conversations] Error fetching:', error);
        // Don't throw error to prevent breaking the UI
        return [];
      }

      // Filter out conversations with hidden users
      const filteredData = (data || []).filter((conv) => {
        const otherUserId = conv.user1_id === session.user.id ? conv.user2_id : conv.user1_id;
        return !hiddenUserIds.includes(otherUserId);
      });

      // Fetch LIVE profile data for each conversation participant
      const conversationsWithUnread = await Promise.all(
        filteredData.map(async (conv) => {
          // Fetch current profile data (not stale JOIN data)
          const user1Id = conv.user1_id;
          const user2Id = conv.user2_id;

          const [user1Profile, user2Profile, unreadResult] = await Promise.all([
            supabase
              .from('profiles')
              .select('id, username, avatar_emoji, is_verified, username_color')
              .eq('id', user1Id)
              .single(),
            supabase
              .from('profiles')
              .select('id, username, avatar_emoji, is_verified, username_color')
              .eq('id', user2Id)
              .single(),
            supabase
              .from('messages')
              .select('*', { count: 'exact', head: true })
              .eq('conversation_id', conv.id)
              .eq('is_read', false)
              .neq('sender_id', session.user.id), // Don't count own messages
          ]);

          return {
            ...conv,
            user1: user1Profile.data,
            user2: user2Profile.data,
            unread_count: unreadResult.count || 0,
          };
        })
      );

      console.log('[Conversations] Fetched', conversationsWithUnread.length, 'conversations');

      // Persist to AsyncStorage for offline access
      if (conversationsWithUnread.length > 0) {
        await persistData('conversations', conversationsWithUnread);
      }

      return conversationsWithUnread;
    },
    // Pre-populate cache before query runs
    placeholderData: () => {
      // Check if data exists in cache
      const existingData = queryClient.getQueryData<any[]>(['conversations']);
      if (existingData && existingData.length > 0) {
        console.log('[Conversations] ✅ Using placeholder data from cache (', existingData.length, 'conversations)');
        return existingData;
      }

      // Try sync cache
      const syncData = getDataSync<any[]>('conversations');
      if (syncData && syncData.length > 0) {
        console.log('[Conversations] ✅ Using placeholder data from sync cache (', syncData.length, 'conversations)');
        queryClient.setQueryData(['conversations'], syncData);
        return syncData;
      }

      return undefined;
    },
    staleTime: Infinity, // TELEGRAM-STYLE: Data NEVER becomes stale
    gcTime: Infinity, // TELEGRAM-STYLE: Keep data in cache FOREVER
    refetchOnMount: false, // DON'T refetch when component mounts
    refetchOnWindowFocus: false, // DON'T refetch on window focus
    refetchOnReconnect: false, // DON'T refetch on reconnect
    retry: false, // Don't retry on error
  });
}

// Get messages for a specific conversation
export function useMessages(conversationId: string | undefined) {
  const queryClient = useQueryClient();

  // Setup Realtime subscription using singleton manager
  React.useEffect(() => {
    if (!conversationId) return;

    console.log('[Messages] Setting up Realtime subscriptions for conversation:', conversationId);

    // Subscribe to INSERT events (new messages)
    const unsubscribeInsert = realtimeManager.subscribe(
      `messages:insert:${conversationId}`,
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      },
      (payload: any) => {
        console.log('[Messages] New message received via Realtime:', payload.new);

        // Add new message to cache directly (optimistic update)
        queryClient.setQueryData(['messages', conversationId], (oldData: any[] | undefined) => {
          // Check if message already exists (prevent duplicates)
          if (oldData && oldData.some((msg: any) => msg.id === payload.new.id)) {
            console.log('[Messages] Message already exists, skipping duplicate');
            return oldData;
          }

          const newData = oldData ? [payload.new, ...oldData] : [payload.new];
          // CRITICAL: Save to persistData immediately for offline support
          persistData(`messages:${conversationId}`, newData).catch(console.error);
          return newData;
        });

        // CRITICAL: Update conversations list to show latest message with refetch
        queryClient.invalidateQueries({ queryKey: ['conversations'] });
      }
    );

    // Subscribe to DELETE events (deleted messages)
    const unsubscribeDelete = realtimeManager.subscribe(
      `messages:delete:${conversationId}`,
      {
        event: 'DELETE',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      },
      (payload: any) => {
        console.log('[Messages] Message deleted via Realtime:', payload.old);

        // Remove message from cache
        queryClient.setQueryData(['messages', conversationId], (oldData: any[] | undefined) => {
          if (!oldData) return oldData;

          const newData = oldData.filter((msg: any) => msg.id !== payload.old.id);
          console.log('[Messages] Removed deleted message from cache (', newData.length, 'messages remaining)');

          // CRITICAL: Save to persistData immediately
          persistData(`messages:${conversationId}`, newData).catch(console.error);
          return newData;
        });

        // CRITICAL: Update conversations list
        queryClient.invalidateQueries({ queryKey: ['conversations'] });
      }
    );

    // Subscribe to UPDATE events (edited messages, read status, etc.)
    const unsubscribeUpdate = realtimeManager.subscribe(
      `messages:update:${conversationId}`,
      {
        event: 'UPDATE',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      },
      (payload: any) => {
        console.log('[Messages] Message updated via Realtime:', payload.new);

        // Update message in cache
        queryClient.setQueryData(['messages', conversationId], (oldData: any[] | undefined) => {
          if (!oldData) return oldData;

          const newData = oldData.map((msg: any) =>
            msg.id === payload.new.id ? payload.new : msg
          );
          console.log('[Messages] Updated message in cache');

          // CRITICAL: Save to persistData immediately
          persistData(`messages:${conversationId}`, newData).catch(console.error);
          return newData;
        });
      }
    );

    // Cleanup on unmount or when conversationId changes
    return () => {
      console.log('[Messages] Cleaning up Realtime subscriptions');
      unsubscribeInsert();
      unsubscribeDelete();
      unsubscribeUpdate();
    };
  }, [conversationId, queryClient]);

  return useQuery({
    queryKey: ['messages', conversationId],
    queryFn: async () => {
      if (!conversationId) return [];

      console.log('[Messages] Fetching messages for conversation:', conversationId);

      // Fetch fresh data from server
      const { data, error } = await supabase
        .from('messages')
        .select(`
          *,
          sender:profiles(*)
        `)
        .eq('conversation_id', conversationId)
        .order('created_at', { ascending: false }) // Descending for inverted FlatList
        .limit(50); // Limit to last 50 messages for performance

      if (error) {
        console.error('[Messages] Error fetching:', error);
        // If conversation doesn't exist or access denied, return empty array
        if (error.code === 'PGRST116' || error.code === '42501') {
          console.warn('[Messages] Conversation not accessible, returning empty array');
          return [];
        }
        throw error;
      }

      console.log('[Messages] Fetched', data?.length || 0, 'messages from server');

      // Save to both caches
      const messages = data || [];
      if (conversationId) {
        // Save to MessageCache
        if (messages.length > 0) {
          await MessageCache.saveMessages(conversationId, messages as any);
        }
        // ALWAYS save to persistData (even if empty, to cache the "no messages" state)
        await persistData(`messages:${conversationId}`, messages);
      }

      return messages;
    },
    // Pre-populate cache before query runs (to prevent loading flicker)
    placeholderData: keepPreviousData,
    staleTime: 0, // Always fetch fresh data
    gcTime: 5 * 60 * 1000, // Keep in cache for 5 minutes
    refetchOnMount: 'always', // ALWAYS refetch when component mounts
    refetchOnWindowFocus: false, // Don't refetch on window focus
    refetchOnReconnect: true, // Refetch on reconnect
    enabled: !!conversationId,
    retry: false, // Don't retry if conversation doesn't exist
  });
}

// Create or get conversation with another user
export function useCreateConversation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ otherUserId }: { otherUserId: string }) => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      console.log('[Conversations] Creating conversation:', {
        currentUserId: session.user.id,
        otherUserId,
      });

      // Check if conversation already exists (in either direction)
      const { data: existing } = await supabase
        .from('conversations')
        .select('*')
        .or(
          `and(user1_id.eq.${session.user.id},user2_id.eq.${otherUserId}),` +
          `and(user1_id.eq.${otherUserId},user2_id.eq.${session.user.id})`
        )
        .maybeSingle(); // Changed from .single() to allow null result

      if (existing) {
        console.log('[Conversations] Conversation already exists:', existing.id);
        return existing;
      }

      // Create new conversation
      const { data, error } = await supabase
        .from('conversations')
        .insert({
          user1_id: session.user.id,
          user2_id: otherUserId,
        })
        .select()
        .single();

      if (error) {
        console.error('[Conversations] Failed to create conversation:', error);
        throw error;
      }

      console.log('[Conversations] New conversation created:', data.id);
      return data;
    },
    onSuccess: () => {
      // CRITICAL: Refetch conversations to show new chat in list
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
}

// Send a message
export function useSendMessage() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ conversationId, text, replyToId }: { conversationId: string; text: string; replyToId?: string | null }) => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      console.log('[Messages] Attempting to send message:', {
        conversationId,
        senderId: session.user.id,
        textLength: text.length,
        replyToId,
      });

      // Send message directly - RLS policies will check if user has access
      const { data, error } = await supabase
        .from('messages')
        .insert({
          conversation_id: conversationId,
          sender_id: session.user.id,
          text,
          reply_to_id: replyToId || null,
        })
        .select(`
          *,
          sender:profiles(*)
        `)
        .single();

      if (error) {
        console.error('[Messages] Insert failed:', error);
        throw error;
      }

      console.log('[Messages] Message sent successfully:', data.id);
      return data;
    },
    // Optimistic update - add message immediately to UI
    onMutate: async ({ conversationId, text, replyToId }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ queryKey: ['messages', conversationId] });

      // Get current messages
      const previousMessages = queryClient.getQueryData(['messages', conversationId]);

      // Get current user session
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return { previousMessages };

      // Optimistically add new message
      const optimisticMessage = {
        id: `temp-${Date.now()}`,
        conversation_id: conversationId,
        sender_id: session.user.id,
        text,
        is_read: false,
        reply_to_id: replyToId || null,
        edited_at: null,
        deleted_at: null,
        created_at: new Date().toISOString(),
        sender: {
          id: session.user.id,
          username: 'You',
          avatar_emoji: '💬',
        },
      };

      queryClient.setQueryData(['messages', conversationId], (old: any) => {
        return old ? [optimisticMessage, ...old] : [optimisticMessage];
      });

      return { previousMessages };
    },
    // On success, replace temp message with real one
    onSuccess: (data, { conversationId }) => {
      queryClient.setQueryData(['messages', conversationId], (old: any) => {
        if (!old) return [data];

        // Remove ALL messages with the same text and timestamp (within 1 second)
        // This handles both temp messages and potential duplicates from Realtime
        const filtered = old.filter((msg: any) => {
          // Keep if it's a different message entirely
          if (msg.text !== data.text) return true;

          // Remove temp messages
          if (msg.id.startsWith('temp-')) return false;

          // Remove duplicates with same real ID
          if (msg.id === data.id) return false;

          // Keep everything else
          return true;
        });

        // Add the new message at the beginning
        return [data, ...filtered];
      });
    },
    // On error, rollback
    onError: (err, { conversationId }, context: any) => {
      if (context?.previousMessages) {
        queryClient.setQueryData(['messages', conversationId], context.previousMessages);
      }
    },
    // Don't refetch - we already updated the cache
    onSettled: (_, __, { conversationId }) => {
      // CRITICAL: Refetch conversations list to show new chat
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
}

// Mark messages as read
export function useMarkMessagesAsRead() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async ({ conversationId }: { conversationId: string }) => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const { error } = await supabase
        .from('messages')
        .update({ is_read: true })
        .eq('conversation_id', conversationId)
        .neq('sender_id', session.user.id);

      if (error) throw error;
    },
    onSuccess: (_, variables) => {
      queryClient.invalidateQueries({ queryKey: ['messages', variables.conversationId] });
      // CRITICAL: Refetch conversations to update unread count
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
}

// Delete conversation
export function useDeleteConversation() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (conversationId: string) => {
      const { error } = await supabase
        .from('conversations')
        .delete()
        .eq('id', conversationId);

      if (error) throw error;
    },
    onSuccess: () => {
      // CRITICAL: Refetch conversations to remove deleted chat
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
}

// Block user (adds to hidden_users)
export function useBlockUser() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async (userIdToBlock: string) => {
      const { error } = await supabase
        .from('hidden_users')
        .insert({
          user_id: auth?.profile?.id || '',
          hidden_user_id: userIdToBlock,
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hidden-users'] });
      queryClient.invalidateQueries({ queryKey: ['memories'], refetchType: 'none' });
      // CRITICAL: Refetch conversations to hide blocked user's chats
      queryClient.invalidateQueries({ queryKey: ['conversations'] });
    },
  });
}

// Mute user (disable notifications)
export function useMuteUser() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async ({ userId, muted }: { userId: string; muted: boolean }) => {
      // Check if muted_users table exists, if not we'll store in profiles metadata
      const { error } = await supabase
        .from('profiles')
        .upsert({
          id: auth?.profile?.id || '',
          muted_users: muted
            ? [...((auth?.profile as any)?.muted_users || []), userId]
            : ((auth?.profile as any)?.muted_users || []).filter((id: string) => id !== userId),
        });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['auth'] });
    },
  });
}

// ============================================================================
// VERIFICATION HOOKS (ADMIN ONLY)
// ============================================================================

// Check if current user is admin
export function useIsAdmin() {
  const { data: auth } = useAuth();
  return auth?.profile?.is_admin === true;
}

// Check if current user is super admin
export function useIsSuperAdmin() {
  const { data: auth } = useAuth();
  return (auth?.profile as any)?.is_super_admin === true;
}

// Verify user (admin only)
export function useVerifyUser() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async ({ userId, verified }: { userId: string; verified: boolean }) => {
      // Check if current user is admin
      if (!auth?.profile?.is_admin) {
        throw new Error('Only admins can verify users');
      }

      // Call Supabase function to verify user
      const { data, error } = await supabase.rpc('verify_user', {
        target_user_id: userId,
        verified_status: verified,
      });

      if (error) throw error;
      return data;
    },
    onSuccess: async () => {
      // Invalidate all user-related queries to refresh verification badges
      await queryClient.invalidateQueries({ queryKey: ['profile'] });
      await queryClient.invalidateQueries({ queryKey: ['auth'] });
      await queryClient.invalidateQueries({ queryKey: ['memories'], refetchType: 'none' });
      await queryClient.invalidateQueries({ queryKey: ['conversations'], refetchType: 'none' });
      await queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      await queryClient.invalidateQueries({ queryKey: ['search-users'] });
      await queryClient.invalidateQueries({ queryKey: ['all-users'] });

      // Force refetch to see changes immediately
      await queryClient.refetchQueries({ queryKey: ['all-users'] });
    },
    onError: (error) => {
      console.error('[VerifyUser] Error:', error);
    }
  });
}

// Set admin status (admin only)
export function useSetAdmin() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async ({ userId, isAdmin }: { userId: string; isAdmin: boolean }) => {
      // Check if current user is admin
      if (!auth?.profile?.is_admin) {
        throw new Error('Only admins can manage admin status');
      }

      // Call Supabase function to set admin status
      const { data, error } = await supabase.rpc('set_admin', {
        target_user_id: userId,
        admin_status: isAdmin,
      });

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      // Invalidate all user-related queries
      queryClient.invalidateQueries({ queryKey: ['profile'] });
      queryClient.invalidateQueries({ queryKey: ['auth'] });
      queryClient.invalidateQueries({ queryKey: ['memories'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['conversations'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      queryClient.invalidateQueries({ queryKey: ['search-users'] });
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
    },
  });
}

// Ban user (admin only)
export function useBanUser() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();

  return useMutation({
    mutationFn: async ({
      userId,
      banned,
      reason
    }: {
      userId: string;
      banned: boolean;
      reason?: string;
    }) => {
      console.log('[BanUser] Starting ban mutation:', { userId, banned, reason });

      // Check if current user is admin
      if (!auth?.profile?.is_admin) {
        console.error('[BanUser] User is not admin:', auth?.profile);
        throw new Error('Only admins can ban users');
      }

      console.log('[BanUser] Admin check passed, calling ban_user function...');

      // Call the ban_user RPC function (bypasses RLS)
      const { data, error } = await supabase.rpc('ban_user', {
        target_user_id: userId,
        banned_status: banned,
        reason: reason || null,
      });

      if (error) {
        console.error('[BanUser] Error calling ban_user function:', error);
        throw error;
      }

      console.log('[BanUser] Successfully called ban_user function:', data);
      return { success: true };
    },
    onSuccess: (data) => {
      console.log('[BanUser] Mutation successful, invalidating queries...');
      // Invalidate all user-related queries
      queryClient.invalidateQueries({ queryKey: ['profile'] });
      queryClient.invalidateQueries({ queryKey: ['auth'] });
      queryClient.invalidateQueries({ queryKey: ['memories'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['conversations'], refetchType: 'none' });
      queryClient.invalidateQueries({ queryKey: ['user-profile'] });
      queryClient.invalidateQueries({ queryKey: ['search-users'] });
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      console.log('[BanUser] All queries invalidated');
    },
    onError: (error) => {
      console.error('[BanUser] Mutation error:', error);
    },
  });
}

// Get all users (for admin panel)
export function useAllUsers() {
  const { data: auth } = useAuth();

  return useQuery({
    queryKey: ['all-users'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, avatar_emoji, created_at, is_verified, is_admin, is_super_admin, is_banned, banned_at, banned_by, ban_reason')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Ensure all fields have defaults
      return data?.map(user => ({
        ...user,
        is_verified: user.is_verified ?? false,
        is_admin: user.is_admin ?? false,
        is_super_admin: user.is_super_admin ?? false,
        is_banned: user.is_banned ?? false,
        banned_at: user.banned_at ?? null,
        banned_by: user.banned_by ?? null,
        ban_reason: user.ban_reason ?? null,
      })) || [];
    },
    enabled: !!auth?.profile?.is_admin,
  });
}

