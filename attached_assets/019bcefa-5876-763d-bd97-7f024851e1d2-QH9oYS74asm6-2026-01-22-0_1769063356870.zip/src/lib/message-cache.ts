import AsyncStorage from '@react-native-async-storage/async-storage';

const MESSAGES_CACHE_PREFIX = 'messages_cache_';
const MAX_CACHED_MESSAGES = 50; // Store last 50 messages per conversation

interface CachedMessage {
  id: string;
  conversation_id: string;
  sender_id: string;
  text: string;
  is_read: boolean;
  created_at: string;
  sender: {
    id: string;
    username: string;
    avatar_emoji: string;
  };
}

export const MessageCache = {
  // Save messages to cache
  async saveMessages(conversationId: string, messages: CachedMessage[]) {
    try {
      // Keep only last MAX_CACHED_MESSAGES
      const messagesToCache = messages.slice(-MAX_CACHED_MESSAGES);

      await AsyncStorage.setItem(
        `${MESSAGES_CACHE_PREFIX}${conversationId}`,
        JSON.stringify({
          messages: messagesToCache,
          cachedAt: new Date().toISOString(),
        })
      );

      console.log(`[Cache] Saved ${messagesToCache.length} messages for conversation ${conversationId}`);
    } catch (error) {
      console.error('[Cache] Error saving messages:', error);
    }
  },

  // Get messages from cache
  async getMessages(conversationId: string): Promise<CachedMessage[]> {
    try {
      const cached = await AsyncStorage.getItem(`${MESSAGES_CACHE_PREFIX}${conversationId}`);

      if (!cached) {
        return [];
      }

      const { messages, cachedAt } = JSON.parse(cached);

      // Check if cache is older than 7 days
      const cacheAge = Date.now() - new Date(cachedAt).getTime();
      const maxAge = 7 * 24 * 60 * 60 * 1000; // 7 days

      if (cacheAge > maxAge) {
        console.log('[Cache] Cache expired, clearing');
        await this.clearConversation(conversationId);
        return [];
      }

      console.log(`[Cache] Retrieved ${messages.length} messages from cache`);
      return messages;
    } catch (error) {
      console.error('[Cache] Error getting messages:', error);
      return [];
    }
  },

  // Clear cache for specific conversation
  async clearConversation(conversationId: string) {
    try {
      await AsyncStorage.removeItem(`${MESSAGES_CACHE_PREFIX}${conversationId}`);
      console.log(`[Cache] Cleared cache for conversation ${conversationId}`);
    } catch (error) {
      console.error('[Cache] Error clearing conversation:', error);
    }
  },

  // Clear all message caches
  async clearAll() {
    try {
      const keys = await AsyncStorage.getAllKeys();
      const cacheKeys = keys.filter(key => key.startsWith(MESSAGES_CACHE_PREFIX));
      await AsyncStorage.multiRemove(cacheKeys);
      console.log(`[Cache] Cleared ${cacheKeys.length} conversation caches`);
    } catch (error) {
      console.error('[Cache] Error clearing all caches:', error);
    }
  },
};
