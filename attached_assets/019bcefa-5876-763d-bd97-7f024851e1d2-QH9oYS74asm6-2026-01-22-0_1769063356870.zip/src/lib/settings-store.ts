import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Haptics from 'expo-haptics';
import { Platform, NativeModules } from 'react-native';
import { ThemeKey } from './themes';

export type Language =
  | 'en' // English
  | 'ru' // Russian
  | 'es' // Spanish
  | 'fr' // French
  | 'de' // German
  | 'it' // Italian
  | 'pt' // Portuguese
  | 'pl' // Polish
  | 'nl' // Dutch
  | 'tr' // Turkish
  | 'sv' // Swedish
  | 'no' // Norwegian
  | 'da' // Danish
  | 'fi' // Finnish
  | 'cs' // Czech
  | 'sk' // Slovak
  | 'hu' // Hungarian
  | 'ro' // Romanian
  | 'el' // Greek
  | 'bg' // Bulgarian
  | 'uk' // Ukrainian
  | 'sr' // Serbian
  | 'hr' // Croatian
  | 'sl' // Slovenian
  | 'et' // Estonian
  | 'lv' // Latvian
  | 'lt' // Lithuanian
  | 'zh' // Chinese
  | 'ja' // Japanese
  | 'ko' // Korean
  | 'ar' // Arabic
  | 'he' // Hebrew
  | 'hi' // Hindi
  | 'bn' // Bengali
  | 'ur' // Urdu
  | 'fa' // Persian
  | 'th' // Thai
  | 'vi' // Vietnamese
  | 'id' // Indonesian
  | 'ms' // Malay
  | 'tl' // Tagalog
  | 'sw' // Swahili
  | 'am' // Amharic
  | 'km' // Khmer
  | 'lo' // Lao
  | 'my' // Burmese
  | 'ka' // Georgian
  | 'hy' // Armenian
  | 'az' // Azerbaijani
  | 'kk' // Kazakh
  | 'uz' // Uzbek
  | 'mn' // Mongolian;
export type PerformanceMode = 'high-performance' | 'balanced' | 'quality';

export interface SettingsState {
  // Sound & Haptics
  soundEnabled: boolean;
  hapticsEnabled: boolean;

  // Visual
  backgroundDimEnabled: boolean;
  glassEffectEnabled: boolean;
  theme: ThemeKey;

  // Language
  language: Language;

  // Performance
  performanceMode: PerformanceMode;

  // Actions
  setSoundEnabled: (enabled: boolean) => void;
  setHapticsEnabled: (enabled: boolean) => void;
  setBackgroundDimEnabled: (enabled: boolean) => void;
  setGlassEffectEnabled: (enabled: boolean) => void;
  setTheme: (theme: ThemeKey) => void;
  setLanguage: (language: Language) => void;
  setPerformanceMode: (mode: PerformanceMode) => void;

  // Helper to trigger haptics if enabled
  triggerHaptic: (style: Haptics.ImpactFeedbackStyle) => Promise<void>;

  // Helper to detect device language
  _hasHydrated: boolean;
}

// Detect device language
const getDeviceLanguage = (): Language => {
  let deviceLocale = 'en';

  if (Platform.OS === 'ios') {
    deviceLocale = NativeModules.SettingsManager?.settings?.AppleLocale ||
                   NativeModules.SettingsManager?.settings?.AppleLanguages?.[0] || 'en';
  } else if (Platform.OS === 'android') {
    deviceLocale = NativeModules.I18nManager?.localeIdentifier || 'en';
  }

  const locale = deviceLocale.toLowerCase().split(/[-_]/)[0];

  // Map common language codes
  const languageMap: Record<string, Language> = {
    'en': 'en', 'ru': 'ru', 'es': 'es', 'fr': 'fr', 'de': 'de',
    'it': 'it', 'pt': 'pt', 'pl': 'pl', 'nl': 'nl', 'tr': 'tr',
    'sv': 'sv', 'no': 'no', 'da': 'da', 'fi': 'fi', 'cs': 'cs',
    'sk': 'sk', 'hu': 'hu', 'ro': 'ro', 'el': 'el', 'bg': 'bg',
    'uk': 'uk', 'sr': 'sr', 'hr': 'hr', 'sl': 'sl', 'et': 'et',
    'lv': 'lv', 'lt': 'lt', 'zh': 'zh', 'ja': 'ja', 'ko': 'ko',
    'ar': 'ar', 'he': 'he', 'hi': 'hi', 'bn': 'bn', 'ur': 'ur',
    'fa': 'fa', 'th': 'th', 'vi': 'vi', 'id': 'id', 'ms': 'ms',
    'tl': 'tl', 'sw': 'sw', 'am': 'am', 'km': 'km', 'lo': 'lo',
    'my': 'my', 'ka': 'ka', 'hy': 'hy', 'az': 'az', 'kk': 'kk',
    'uz': 'uz', 'mn': 'mn',
  };

  return languageMap[locale] || 'en';
};

export const useSettingsStore = create<SettingsState>()(
  persist(
    (set, get) => ({
      // Initial State - defaults that respect iOS conventions
      soundEnabled: true,
      hapticsEnabled: true,
      backgroundDimEnabled: false,
      glassEffectEnabled: true,
      theme: 'forest',
      language: getDeviceLanguage(), // Auto-detect device language
      performanceMode: 'balanced', // Default to balanced mode
      _hasHydrated: false,

      // Actions
      setSoundEnabled: (enabled) => set({ soundEnabled: enabled }),
      setHapticsEnabled: (enabled) => set({ hapticsEnabled: enabled }),
      setBackgroundDimEnabled: (enabled) => set({ backgroundDimEnabled: enabled }),
      setGlassEffectEnabled: (enabled) => set({ glassEffectEnabled: enabled }),
      setTheme: (theme) => set({ theme }),
      setLanguage: (language) => set({ language }),
      setPerformanceMode: (mode) => set({ performanceMode: mode }),

      // Helper method
      triggerHaptic: async (style) => {
        if (get().hapticsEnabled) {
          await Haptics.impactAsync(style);
        }
      },
    }),
    {
      name: 'memories-settings-storage',
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        soundEnabled: state.soundEnabled,
        hapticsEnabled: state.hapticsEnabled,
        backgroundDimEnabled: state.backgroundDimEnabled,
        glassEffectEnabled: state.glassEffectEnabled,
        theme: state.theme,
        language: state.language,
        performanceMode: state.performanceMode,
      }),
      onRehydrateStorage: () => (state) => {
        if (state) {
          state._hasHydrated = true;
          // If no language was saved, use device language
          if (!state.language) {
            state.language = getDeviceLanguage();
          }
          // If no performance mode was saved, use balanced
          if (!state.performanceMode) {
            state.performanceMode = 'balanced';
          }
        }
      },
    }
  )
);
