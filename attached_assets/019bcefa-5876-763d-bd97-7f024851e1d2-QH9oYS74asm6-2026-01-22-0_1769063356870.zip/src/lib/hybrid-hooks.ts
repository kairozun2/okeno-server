import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from './api-client';
import { useAppStore } from './store';
import { useSyncStore } from './sync-store';
import type { Memory } from './store';

// Check if we're in online mode (have auth token)
const isOnlineMode = () => !!apiClient.getAuthToken();

/**
 * Hybrid hook for memories - works with both local store and API
 * - When online: fetches from API and syncs changes
 * - When offline: uses local Zustand store
 */
export function useMemoriesHybrid() {
  const localMemories = useAppStore(s => s.memories);
  const isOnline = useSyncStore(s => s.isOnline);

  const { data: apiMemories, isLoading, error, refetch } = useQuery({
    queryKey: ['memories'],
    queryFn: async () => {
      const response = await apiClient.getMemories();
      return response.memories;
    },
    enabled: isOnlineMode() && isOnline,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });

  // Return API data if available, otherwise local data
  const memories = (isOnlineMode() && isOnline && apiMemories) ? apiMemories : localMemories;

  return {
    memories,
    isLoading: isOnlineMode() && isOnline ? isLoading : false,
    error,
    refetch,
    isOnline: isOnlineMode() && isOnline,
  };
}

/**
 * Hybrid hook for creating memories
 */
export function useCreateMemoryHybrid() {
  const queryClient = useQueryClient();
  const addMemoryLocal = useAppStore(s => s.addMemory);
  const addPendingAction = useSyncStore(s => s.addPendingAction);
  const isOnline = useSyncStore(s => s.isOnline);

  return useMutation({
    mutationFn: async (data: {
      text: string;
      emotion: string;
      imageUrl?: string;
      location?: string;
      latitude?: number;
      longitude?: number;
    }) => {
      if (isOnlineMode() && isOnline) {
        // Online: send to API
        return await apiClient.createMemory(data);
      } else {
        // Offline: add to local store and queue for sync
        addMemoryLocal(data as any);
        if (isOnlineMode()) {
          // Queue action for later sync
          addPendingAction({
            type: 'create',
            entity: 'memory',
            data,
          });
        }
        return null;
      }
    },
    onSuccess: () => {
      if (isOnlineMode() && isOnline) {
        queryClient.invalidateQueries({ queryKey: ['memories'] });
      }
    },
  });
}

/**
 * Hybrid hook for toggling echo (like)
 */
export function useToggleEchoHybrid() {
  const queryClient = useQueryClient();
  const toggleEchoLocal = useAppStore(s => s.toggleEcho);
  const addPendingAction = useSyncStore(s => s.addPendingAction);
  const isOnline = useSyncStore(s => s.isOnline);

  return useMutation({
    mutationFn: async (memoryId: string) => {
      // Always update local state immediately (optimistic update)
      toggleEchoLocal(memoryId);

      if (isOnlineMode() && isOnline) {
        // Online: send to API
        return await apiClient.toggleEcho(memoryId);
      } else if (isOnlineMode()) {
        // Offline: queue for sync
        addPendingAction({
          type: 'echo',
          entity: 'memory',
          data: { memoryId },
        });
      }
      return null;
    },
    onSuccess: (_, memoryId) => {
      if (isOnlineMode() && isOnline) {
        queryClient.invalidateQueries({ queryKey: ['memory', memoryId] });
        queryClient.invalidateQueries({ queryKey: ['memories'] });
      }
    },
  });
}

/**
 * Hybrid hook for toggling save
 */
export function useToggleSaveHybrid() {
  const queryClient = useQueryClient();
  const toggleSaveLocal = useAppStore(s => s.toggleSave);
  const addPendingAction = useSyncStore(s => s.addPendingAction);
  const isOnline = useSyncStore(s => s.isOnline);

  return useMutation({
    mutationFn: async (memoryId: string) => {
      toggleSaveLocal(memoryId);

      if (isOnlineMode() && isOnline) {
        return await apiClient.toggleSave(memoryId);
      } else if (isOnlineMode()) {
        addPendingAction({
          type: 'save',
          entity: 'memory',
          data: { memoryId },
        });
      }
      return null;
    },
    onSuccess: (_, memoryId) => {
      if (isOnlineMode() && isOnline) {
        queryClient.invalidateQueries({ queryKey: ['memory', memoryId] });
        queryClient.invalidateQueries({ queryKey: ['memories'] });
      }
    },
  });
}

/**
 * Hybrid hook for updating memory
 */
export function useUpdateMemoryHybrid() {
  const queryClient = useQueryClient();
  const updateMemoryLocal = useAppStore(s => s.updateMemoryText);
  const addPendingAction = useSyncStore(s => s.addPendingAction);
  const isOnline = useSyncStore(s => s.isOnline);

  return useMutation({
    mutationFn: async ({ id, text }: { id: string; text: string }) => {
      updateMemoryLocal(id, text);

      if (isOnlineMode() && isOnline) {
        return await apiClient.updateMemory(id, { text });
      } else if (isOnlineMode()) {
        addPendingAction({
          type: 'update',
          entity: 'memory',
          data: { id, text },
        });
      }
      return null;
    },
    onSuccess: (_, variables) => {
      if (isOnlineMode() && isOnline) {
        queryClient.invalidateQueries({ queryKey: ['memory', variables.id] });
        queryClient.invalidateQueries({ queryKey: ['memories'] });
      }
    },
  });
}

/**
 * Hybrid hook for deleting memory
 */
export function useDeleteMemoryHybrid() {
  const queryClient = useQueryClient();
  const deleteMemoryLocal = useAppStore(s => s.deleteMemory);
  const addPendingAction = useSyncStore(s => s.addPendingAction);
  const isOnline = useSyncStore(s => s.isOnline);

  return useMutation({
    mutationFn: async (id: string) => {
      deleteMemoryLocal(id);

      if (isOnlineMode() && isOnline) {
        return await apiClient.deleteMemory(id);
      } else if (isOnlineMode()) {
        addPendingAction({
          type: 'delete',
          entity: 'memory',
          data: { id },
        });
      }
      return null;
    },
    onSuccess: () => {
      if (isOnlineMode() && isOnline) {
        queryClient.invalidateQueries({ queryKey: ['memories'] });
      }
    },
  });
}

/**
 * Hybrid hook for toggling archive
 */
export function useToggleArchiveHybrid() {
  const queryClient = useQueryClient();
  const toggleArchiveLocal = useAppStore(s => s.toggleArchive);
  const addPendingAction = useSyncStore(s => s.addPendingAction);
  const isOnline = useSyncStore(s => s.isOnline);

  return useMutation({
    mutationFn: async (memoryId: string) => {
      toggleArchiveLocal(memoryId);

      if (isOnlineMode() && isOnline) {
        return await apiClient.toggleArchive(memoryId);
      } else if (isOnlineMode()) {
        addPendingAction({
          type: 'archive',
          entity: 'memory',
          data: { memoryId },
        });
      }
      return null;
    },
    onSuccess: (_, memoryId) => {
      if (isOnlineMode() && isOnline) {
        queryClient.invalidateQueries({ queryKey: ['memory', memoryId] });
        queryClient.invalidateQueries({ queryKey: ['memories'] });
      }
    },
  });
}
