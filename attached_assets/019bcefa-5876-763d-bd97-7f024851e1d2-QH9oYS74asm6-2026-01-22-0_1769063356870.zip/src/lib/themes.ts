/**
 * Theme System - Expandable color themes
 */

export type ThemeKey = 'forest' | 'feldgrau' | 'wheat' | 'midnight' | 'mint' | 'merlot' | 'apricot';

export interface Theme {
  key: ThemeKey;
  name: string;
  colors: {
    primary: string;
    primaryLight: string;
    primaryDark: string;
    accent: string;
    accentDark: string;
    text: string;
    textSecondary: string;
    background: string;
  };
}

export const themes: Record<ThemeKey, Theme> = {
  forest: {
    key: 'forest',
    name: 'Forest',
    colors: {
      primary: '#064734',
      primaryLight: '#0A5C45',
      primaryDark: '#043325',
      accent: '#E8D5B7',
      accentDark: '#D4C5A8',
      text: '#F5F2ED',
      textSecondary: 'rgba(245, 242, 237, 0.6)',
      background: '#064734',
    },
  },
  feldgrau: {
    key: 'feldgrau',
    name: 'Feldgrau',
    colors: {
      primary: '#3A4B41',
      primaryLight: '#4A5D52',
      primaryDark: '#2A3831',
      accent: '#A8B5AC',
      accentDark: '#8FA598',
      text: '#F5F2ED',
      textSecondary: 'rgba(245, 242, 237, 0.6)',
      background: '#3A4B41',
    },
  },
  wheat: {
    key: 'wheat',
    name: 'Wheat',
    colors: {
      primary: '#E6CFA7',
      primaryLight: '#F0DFC0',
      primaryDark: '#D4BD8F',
      accent: '#8B7355',
      accentDark: '#7A6348',
      text: '#2A2520',
      textSecondary: 'rgba(42, 37, 32, 0.6)',
      background: '#E6CFA7',
    },
  },
  midnight: {
    key: 'midnight',
    name: 'Midnight Fjord',
    colors: {
      primary: '#053264',
      primaryLight: '#0A4A8A',
      primaryDark: '#031E3D',
      accent: '#FFD482', // Golden Apricot accent
      accentDark: '#E6BD6E',
      text: '#F5F2ED',
      textSecondary: 'rgba(245, 242, 237, 0.6)',
      background: '#053264',
    },
  },
  mint: {
    key: 'mint',
    name: 'Mint Cream',
    colors: {
      primary: '#ccffbc',
      primaryLight: '#E0FFD6',
      primaryDark: '#B8EBA8',
      accent: '#3b0000', // Burnt Merlot accent
      accentDark: '#2A0000',
      text: '#1a1a1a',
      textSecondary: 'rgba(26, 26, 26, 0.6)',
      background: '#ccffbc',
    },
  },
  merlot: {
    key: 'merlot',
    name: 'Burnt Merlot',
    colors: {
      primary: '#3b0000',
      primaryLight: '#560000',
      primaryDark: '#200000',
      accent: '#FFD482', // Golden Apricot accent
      accentDark: '#E6BD6E',
      text: '#F5F2ED',
      textSecondary: 'rgba(245, 242, 237, 0.6)',
      background: '#3b0000',
    },
  },
  apricot: {
    key: 'apricot',
    name: 'Golden Apricot',
    colors: {
      primary: '#ffd482',
      primaryLight: '#FFE0A0',
      primaryDark: '#E6BD6E',
      accent: '#053264', // Midnight Fjord accent
      accentDark: '#031E3D',
      text: '#1a1a1a',
      textSecondary: 'rgba(26, 26, 26, 0.6)',
      background: '#ffd482',
    },
  },
};

export function getTheme(key: ThemeKey): Theme {
  return themes[key];
}

export const themeList: Theme[] = Object.values(themes);
