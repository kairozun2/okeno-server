// AI Translation Service using GPT-5.2
// Premium feature for automatic post translation

const OPENAI_API_KEY = process.env.EXPO_PUBLIC_VIBECODE_OPENAI_API_KEY;

interface TranslationResult {
  translatedText: string;
  detectedLanguage?: string;
  success: boolean;
  error?: string;
}

// Language codes mapping
const LANGUAGE_NAMES: Record<string, string> = {
  en: 'English',
  ru: 'Russian',
  es: 'Spanish',
  fr: 'French',
  de: 'German',
  it: 'Italian',
  pt: 'Portuguese',
  zh: 'Chinese',
  ja: 'Japanese',
  ko: 'Korean',
  ar: 'Arabic',
  hi: 'Hindi',
  tr: 'Turkish',
  pl: 'Polish',
  nl: 'Dutch',
  uk: 'Ukrainian',
};

/**
 * Translate text to target language using GPT-5.2
 * @param text - Text to translate
 * @param targetLanguage - Target language code (e.g., 'en', 'ru')
 * @returns TranslationResult with translated text
 */
export async function translateText(
  text: string,
  targetLanguage: string
): Promise<TranslationResult> {
  if (!OPENAI_API_KEY) {
    console.error('[Translation] OpenAI API key not configured');
    return {
      translatedText: text,
      success: false,
      error: 'Translation service not configured',
    };
  }

  if (!text || text.trim().length === 0) {
    return {
      translatedText: text,
      success: true,
    };
  }

  const targetLangName = LANGUAGE_NAMES[targetLanguage] || 'English';

  try {
    console.log('[Translation] Translating to', targetLangName);

    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-5.2',
        messages: [
          {
            role: 'system',
            content: `You are a professional translator. Translate the following text to ${targetLangName}.
Rules:
- Preserve the original meaning and tone
- Keep emojis and special characters as-is
- If the text is already in ${targetLangName}, return it unchanged
- Only return the translated text, nothing else
- Do not add quotes or explanations`,
          },
          {
            role: 'user',
            content: text,
          },
        ],
        max_completion_tokens: 1000,
        temperature: 1,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[Translation] API error:', response.status, errorText);
      throw new Error(`Translation API error: ${response.status}`);
    }

    const data = await response.json();
    const translatedText = data.choices?.[0]?.message?.content?.trim();

    if (!translatedText) {
      throw new Error('Empty translation response');
    }

    console.log('[Translation] Success');

    return {
      translatedText,
      success: true,
    };
  } catch (error) {
    console.error('[Translation] Error:', error);
    return {
      translatedText: text,
      success: false,
      error: error instanceof Error ? error.message : 'Translation failed',
    };
  }
}

/**
 * Detect the language of the given text
 * @param text - Text to analyze
 * @returns Language code (e.g., 'en', 'ru')
 */
export async function detectLanguage(text: string): Promise<string | null> {
  if (!OPENAI_API_KEY || !text || text.trim().length < 3) {
    return null;
  }

  try {
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-5.2',
        messages: [
          {
            role: 'system',
            content: `Detect the language of the text. Reply with only the ISO 639-1 language code (e.g., "en", "ru", "es", "fr", "de", "zh", "ja"). Nothing else.`,
          },
          {
            role: 'user',
            content: text.substring(0, 200), // Limit for detection
          },
        ],
        max_completion_tokens: 10,
        temperature: 1,
      }),
    });

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    const detectedCode = data.choices?.[0]?.message?.content?.trim()?.toLowerCase();

    // Validate it's a valid language code
    if (detectedCode && detectedCode.length === 2 && /^[a-z]{2}$/.test(detectedCode)) {
      return detectedCode;
    }

    return null;
  } catch (error) {
    console.error('[Language Detection] Error:', error);
    return null;
  }
}

/**
 * Check if translation is needed (text is in different language than target)
 */
export async function needsTranslation(
  text: string,
  targetLanguage: string
): Promise<boolean> {
  const detectedLanguage = await detectLanguage(text);
  if (!detectedLanguage) return false;
  return detectedLanguage !== targetLanguage;
}
