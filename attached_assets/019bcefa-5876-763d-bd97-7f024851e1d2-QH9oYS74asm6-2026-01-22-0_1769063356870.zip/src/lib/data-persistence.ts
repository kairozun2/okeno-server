/**
 * Global data persistence layer for chat messages, profiles, and memories
 *
 * This ensures data survives component unmount/remount cycles and provides
 * Instagram/Telegram-level data persistence without reloads
 */

import AsyncStorage from '@react-native-async-storage/async-storage';

const CACHE_PREFIX = '@app_cache:';
const CACHE_VERSION = 'v1';

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  version: string;
}

/**
 * In-memory cache for instant synchronous access
 * This is the primary cache layer - AsyncStorage is backup
 */
const memoryCache = new Map<string, any>();

/**
 * Save data to both memory and persistent storage
 */
export async function persistData<T>(key: string, data: T): Promise<void> {
  const cacheKey = `${CACHE_PREFIX}${key}`;
  const entry: CacheEntry<T> = {
    data,
    timestamp: Date.now(),
    version: CACHE_VERSION,
  };

  // CRITICAL: Save to memory FIRST (synchronous, instant)
  memoryCache.set(cacheKey, entry);

  // Then persist to disk (asynchronous, backup)
  try {
    await AsyncStorage.setItem(cacheKey, JSON.stringify(entry));
  } catch (error) {
    console.warn('[DataPersistence] Error saving to AsyncStorage:', error);
  }
}

/**
 * Get data from memory cache (instant) or AsyncStorage (fallback)
 */
export async function getData<T>(key: string): Promise<T | null> {
  const cacheKey = `${CACHE_PREFIX}${key}`;

  // CRITICAL: Check memory cache FIRST (instant, synchronous)
  const memoryEntry = memoryCache.get(cacheKey) as CacheEntry<T> | undefined;
  if (memoryEntry && memoryEntry.version === CACHE_VERSION) {
    console.log('[DataPersistence] Memory cache HIT for', key);
    return memoryEntry.data;
  }

  // Fallback to AsyncStorage
  try {
    const stored = await AsyncStorage.getItem(cacheKey);
    if (!stored) return null;

    const entry: CacheEntry<T> = JSON.parse(stored);

    // Verify version
    if (entry.version !== CACHE_VERSION) {
      console.log('[DataPersistence] Cache version mismatch, ignoring');
      return null;
    }

    // Restore to memory cache
    memoryCache.set(cacheKey, entry);
    console.log('[DataPersistence] AsyncStorage cache HIT for', key);

    return entry.data;
  } catch (error) {
    console.warn('[DataPersistence] Error reading from AsyncStorage:', error);
    return null;
  }
}

/**
 * Get data synchronously from memory cache only
 * Returns null if not in memory (used for instant display)
 */
export function getDataSync<T>(key: string): T | null {
  const cacheKey = `${CACHE_PREFIX}${key}`;
  const memoryEntry = memoryCache.get(cacheKey) as CacheEntry<T> | undefined;

  console.log(`[DataPersistence] Looking up: ${cacheKey}, found: ${!!memoryEntry}, total keys in cache: ${memoryCache.size}`);

  if (memoryEntry && memoryEntry.version === CACHE_VERSION) {
    console.log(`[DataPersistence] ✅ Memory cache HIT for ${key} (${(memoryEntry.data as any)?.length || 0} items)`);
    return memoryEntry.data;
  }

  console.log(`[DataPersistence] ❌ Memory cache MISS for ${key}`);
  return null;
}

/**
 * Clear specific cache entry
 */
export async function clearData(key: string): Promise<void> {
  const cacheKey = `${CACHE_PREFIX}${key}`;
  memoryCache.delete(cacheKey);

  try {
    await AsyncStorage.removeItem(cacheKey);
  } catch (error) {
    console.warn('[DataPersistence] Error clearing AsyncStorage:', error);
  }
}

/**
 * Clear all cache entries
 */
export async function clearAllData(): Promise<void> {
  memoryCache.clear();

  try {
    const keys = await AsyncStorage.getAllKeys();
    const cacheKeys = keys.filter(k => k.startsWith(CACHE_PREFIX));
    await AsyncStorage.multiRemove(cacheKeys);
  } catch (error) {
    console.warn('[DataPersistence] Error clearing all AsyncStorage:', error);
  }
}

/**
 * Preload critical data into memory cache on app start
 */
export async function preloadCriticalData(): Promise<void> {
  try {
    const keys = await AsyncStorage.getAllKeys();
    const cacheKeys = keys.filter(k => k.startsWith(CACHE_PREFIX));

    console.log(`[DataPersistence] Found ${cacheKeys.length} total cache keys`);

    // Preload conversations, messages, memories, and notifications
    const criticalKeys = cacheKeys.filter(k =>
      k.includes('conversations') ||
      k.includes('messages:') ||
      k.includes('memories') ||
      k.includes('profile:') ||
      k.includes('notifications:')
    );

    console.log(`[DataPersistence] Found ${criticalKeys.length} critical keys to preload:`, criticalKeys);

    if (criticalKeys.length > 0) {
      const entries = await AsyncStorage.multiGet(criticalKeys);

      for (const [key, value] of entries) {
        if (value) {
          try {
            const entry = JSON.parse(value);
            if (entry.version === CACHE_VERSION) {
              memoryCache.set(key, entry);
              console.log(`[DataPersistence] ✅ Preloaded: ${key}`);
            }
          } catch (e) {
            console.warn('[DataPersistence] Error parsing preload entry:', e);
          }
        }
      }

      console.log(`[DataPersistence] ✅ Preloaded ${entries.length} critical cache entries into memory`);
    } else {
      console.log('[DataPersistence] No critical cache entries found - fresh start');
    }
  } catch (error) {
    console.warn('[DataPersistence] Error preloading data:', error);
  }
}
