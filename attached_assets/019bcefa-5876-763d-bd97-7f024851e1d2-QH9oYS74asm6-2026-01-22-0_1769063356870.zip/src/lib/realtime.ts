import { useEffect, useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from './supabase';
import { useSyncStore } from './sync-store';

/**
 * Hook for real-time updates via Supabase Realtime
 * Subscribes to database changes and updates React Query cache
 */
export function useRealtimeSync() {
  const queryClient = useQueryClient();
  const [isConnected, setIsConnected] = useState(false);
  const setOnline = useSyncStore(s => s.setOnline);
  const syncPendingActions = useSyncStore(s => s.syncPendingActions);

  useEffect(() => {
    // Check if Supabase is configured
    const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
    if (!supabaseUrl) {
      console.log('[Supabase] Not configured - working in offline mode');
      setOnline(false);
      setIsConnected(false);
      return;
    }

    setOnline(true);
    setIsConnected(true);
    console.log('[Supabase] Connected');

    // Subscribe to memories table changes
    const memoriesChannel = supabase
      .channel('memories-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'memories' },
        (payload) => {
          console.log('[Supabase] Memory changed:', payload.eventType);
          queryClient.invalidateQueries({ queryKey: ['memories'] });
          queryClient.invalidateQueries({ queryKey: ['feed'] });
        }
      )
      .subscribe();

    // Subscribe to echoes table changes
    const echoesChannel = supabase
      .channel('echoes-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'echoes' },
        (payload) => {
          console.log('[Supabase] Echo changed:', payload.eventType);
          queryClient.invalidateQueries({ queryKey: ['memories'] });
        }
      )
      .subscribe();

    // Subscribe to comments table changes
    const commentsChannel = supabase
      .channel('comments-changes')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'comments' },
        (payload) => {
          console.log('[Supabase] Comment changed:', payload.eventType);
          queryClient.invalidateQueries({ queryKey: ['comments'] });
        }
      )
      .subscribe();

    // Sync pending actions on mount
    syncPendingActions();

    // Cleanup
    return () => {
      memoriesChannel.unsubscribe();
      echoesChannel.unsubscribe();
      commentsChannel.unsubscribe();
    };
  }, [queryClient, setOnline, syncPendingActions]);

  return {
    isConnected,
  };
}
