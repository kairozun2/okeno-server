import AsyncStorage from '@react-native-async-storage/async-storage';

// API Base URL - берем из .env
const API_BASE_URL = process.env.EXPO_PUBLIC_API_BASE_URL || 'http://localhost:3000/api';

interface ApiRequestOptions extends RequestInit {
  requiresAuth?: boolean;
}

class ApiClient {
  private baseUrl: string;
  private authToken: string | null = null;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl;
    this.loadToken();
  }

  private async loadToken() {
    try {
      this.authToken = await AsyncStorage.getItem('authToken');
    } catch (error) {
      console.error('Failed to load auth token:', error);
    }
  }

  async setAuthToken(token: string | null) {
    this.authToken = token;
    if (token) {
      await AsyncStorage.setItem('authToken', token);
    } else {
      await AsyncStorage.removeItem('authToken');
    }
  }

  getAuthToken(): string | null {
    return this.authToken;
  }

  private async request<T>(
    endpoint: string,
    options: ApiRequestOptions = {}
  ): Promise<T> {
    const { requiresAuth = true, headers = {}, ...restOptions } = options;

    const config: RequestInit = {
      ...restOptions,
      headers: {
        'Content-Type': 'application/json',
        ...headers,
        ...(requiresAuth && this.authToken
          ? { Authorization: `Bearer ${this.authToken}` }
          : {}),
      },
    };

    const url = `${this.baseUrl}${endpoint}`;

    try {
      const response = await fetch(url, config);

      if (!response.ok) {
        const error = await response.json().catch(() => ({
          message: response.statusText,
        }));
        throw new Error(error.message || 'Request failed');
      }

      const data = await response.json();
      return data;
    } catch (error) {
      console.error('API request failed:', error);
      throw error;
    }
  }

  // Auth endpoints
  async register(username: string, password: string) {
    return this.request<{ token: string; user: any }>('/auth/register', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
      requiresAuth: false,
    });
  }

  async login(username: string, password: string) {
    return this.request<{ token: string; user: any }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ username, password }),
      requiresAuth: false,
    });
  }

  async getCurrentUser() {
    return this.request<any>('/auth/me');
  }

  // Memory endpoints
  async getMemories(params?: { skip?: number; limit?: number }) {
    const query = new URLSearchParams(params as any).toString();
    return this.request<{ memories: any[]; total: number }>(
      `/memories${query ? `?${query}` : ''}`
    );
  }

  async getMemoryById(id: string) {
    return this.request<any>(`/memories/${id}`);
  }

  async createMemory(data: {
    text: string;
    emotion: string;
    imageUrl?: string;
  }) {
    return this.request<any>('/memories', {
      method: 'POST',
      body: JSON.stringify(data),
    });
  }

  async updateMemory(
    id: string,
    data: { text?: string; emotion?: string }
  ) {
    return this.request<any>(`/memories/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    });
  }

  async deleteMemory(id: string) {
    return this.request<void>(`/memories/${id}`, {
      method: 'DELETE',
    });
  }

  async toggleEcho(memoryId: string) {
    return this.request<any>(`/memories/${memoryId}/echo`, {
      method: 'POST',
    });
  }

  async toggleSave(memoryId: string) {
    return this.request<any>(`/memories/${memoryId}/save`, {
      method: 'POST',
    });
  }

  async toggleArchive(memoryId: string) {
    return this.request<any>(`/memories/${memoryId}/archive`, {
      method: 'POST',
    });
  }

  // Comments endpoints
  async getComments(memoryId: string) {
    return this.request<any[]>(`/memories/${memoryId}/comments`);
  }

  async createComment(memoryId: string, text: string) {
    return this.request<any>(`/memories/${memoryId}/comments`, {
      method: 'POST',
      body: JSON.stringify({ text }),
    });
  }

  async deleteComment(memoryId: string, commentId: string) {
    return this.request<void>(`/memories/${memoryId}/comments/${commentId}`, {
      method: 'DELETE',
    });
  }

  // Upload endpoint
  async uploadMedia(file: {
    uri: string;
    name: string;
    type: string;
  }): Promise<{ url: string }> {
    const formData = new FormData();
    formData.append('file', file as any);

    const response = await fetch(`${this.baseUrl}/upload`, {
      method: 'POST',
      headers: {
        ...(this.authToken
          ? { Authorization: `Bearer ${this.authToken}` }
          : {}),
      },
      body: formData,
    });

    if (!response.ok) {
      throw new Error('Upload failed');
    }

    return response.json();
  }

  // User search
  async searchUsers(query: string) {
    return this.request<any[]>(`/users/search?q=${encodeURIComponent(query)}`);
  }

  // Follow/unfollow
  async followUser(userId: string) {
    return this.request<void>(`/users/${userId}/follow`, {
      method: 'POST',
    });
  }

  async unfollowUser(userId: string) {
    return this.request<void>(`/users/${userId}/unfollow`, {
      method: 'POST',
    });
  }

  // Feed
  async getFeed(params?: { skip?: number; limit?: number }) {
    const query = new URLSearchParams(params as any).toString();
    return this.request<{ memories: any[]; total: number }>(
      `/feed${query ? `?${query}` : ''}`
    );
  }
}

export const apiClient = new ApiClient(API_BASE_URL);
export default apiClient;
