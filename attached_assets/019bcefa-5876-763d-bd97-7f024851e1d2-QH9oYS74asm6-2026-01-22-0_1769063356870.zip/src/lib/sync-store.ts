import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';
import NetInfo from '@react-native-community/netinfo';
import { apiClient } from './api-client';

interface SyncState {
  isSyncing: boolean;
  lastSyncTime: string | null;
  pendingActions: PendingAction[];
  isOnline: boolean;
}

interface PendingAction {
  id: string;
  type: 'create' | 'update' | 'delete' | 'echo' | 'save' | 'archive';
  entity: 'memory' | 'comment';
  data: any;
  timestamp: string;
}

interface SyncStore extends SyncState {
  setOnline: (online: boolean) => void;
  addPendingAction: (action: Omit<PendingAction, 'id' | 'timestamp'>) => void;
  removePendingAction: (id: string) => void;
  syncPendingActions: () => Promise<void>;
  setLastSyncTime: (time: string) => void;
  clearPendingActions: () => void;
}

export const useSyncStore = create<SyncStore>()(
  persist(
    (set, get) => ({
      isSyncing: false,
      lastSyncTime: null,
      pendingActions: [],
      isOnline: true, // Default to true (optimistic)

      setOnline: (online) => {
        set({ isOnline: online });
        if (online) {
          // Sync when coming online
          get().syncPendingActions();
        }
      },

      addPendingAction: (action) => {
        const pendingAction: PendingAction = {
          ...action,
          id: `${Date.now()}_${Math.random()}`,
          timestamp: new Date().toISOString(),
        };
        set((state) => ({
          pendingActions: [...state.pendingActions, pendingAction],
        }));
      },

      removePendingAction: (id) => {
        set((state) => ({
          pendingActions: state.pendingActions.filter((a) => a.id !== id),
        }));
      },

      syncPendingActions: async () => {
        const state = get();
        if (state.isSyncing || !state.isOnline || state.pendingActions.length === 0) {
          return;
        }

        set({ isSyncing: true });

        try {
          // Process pending actions in order
          for (const action of state.pendingActions) {
            try {
              switch (action.entity) {
                case 'memory':
                  await syncMemoryAction(action);
                  break;
                case 'comment':
                  await syncCommentAction(action);
                  break;
              }
              // Remove successful action
              get().removePendingAction(action.id);
            } catch (error) {
              console.error('Failed to sync action:', action, error);
              // Keep action in queue for retry
            }
          }

          set({
            lastSyncTime: new Date().toISOString(),
            isSyncing: false,
          });
        } catch (error) {
          console.error('Sync failed:', error);
          set({ isSyncing: false });
        }
      },

      setLastSyncTime: (time) => set({ lastSyncTime: time }),
      clearPendingActions: () => set({ pendingActions: [] }),
    }),
    {
      name: 'sync-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);

async function syncMemoryAction(action: PendingAction) {
  switch (action.type) {
    case 'create':
      await apiClient.createMemory(action.data);
      break;
    case 'update':
      await apiClient.updateMemory(action.data.id, action.data);
      break;
    case 'delete':
      await apiClient.deleteMemory(action.data.id);
      break;
    case 'echo':
      await apiClient.toggleEcho(action.data.memoryId);
      break;
    case 'save':
      await apiClient.toggleSave(action.data.memoryId);
      break;
    case 'archive':
      await apiClient.toggleArchive(action.data.memoryId);
      break;
  }
}

async function syncCommentAction(action: PendingAction) {
  switch (action.type) {
    case 'create':
      await apiClient.createComment(action.data.memoryId, action.data.text);
      break;
    case 'delete':
      await apiClient.deleteComment(action.data.memoryId, action.data.commentId);
      break;
  }
}

// Auto-sync every 30 seconds when online
let syncInterval: ReturnType<typeof setInterval> | null = null;

export function startAutoSync() {
  if (syncInterval) return;

  syncInterval = setInterval(() => {
    const store = useSyncStore.getState();
    if (store.isOnline && !store.isSyncing && store.pendingActions.length > 0) {
      store.syncPendingActions();
    }
  }, 30000); // 30 seconds
}

export function stopAutoSync() {
  if (syncInterval) {
    clearInterval(syncInterval);
    syncInterval = null;
  }
}

// Initialize network listener
NetInfo.addEventListener(state => {
  const isConnected = !!(state.isConnected && state.isInternetReachable !== false);
  useSyncStore.getState().setOnline(isConnected);
});

// Check initial network state
NetInfo.fetch().then(state => {
  const isConnected = !!(state.isConnected && state.isInternetReachable !== false);
  useSyncStore.getState().setOnline(isConnected);
});
