import * as Linking from 'expo-linking';
import { router } from 'expo-router';

/**
 * Deep Linking Configuration
 *
 * Поддерживаемые форматы:
 * - memories://memory/[id] - открыть конкретное воспоминание
 * - memories://user/[id] - открыть профиль пользователя
 * - memories://chat/[id] - открыть чат
 *
 * В будущем можно добавить:
 * - https://memories.app/memory/[id] - универсальные ссылки
 */

export const DEEP_LINK_PREFIX = 'memories://';

export interface DeepLinkParams {
  type: 'memory' | 'user' | 'chat';
  id: string;
}

/**
 * Парсит deep link и возвращает параметры
 */
export function parseDeepLink(url: string): DeepLinkParams | null {
  try {
    // Убираем префикс
    const path = url.replace(DEEP_LINK_PREFIX, '');
    const parts = path.split('/');

    if (parts.length !== 2) return null;

    const [type, id] = parts;

    if (!['memory', 'user', 'chat'].includes(type)) return null;
    if (!id) return null;

    return { type: type as DeepLinkParams['type'], id };
  } catch (error) {
    console.error('[DeepLink] Parse error:', error);
    return null;
  }
}

/**
 * Обрабатывает deep link и открывает соответствующий экран
 */
export async function handleDeepLink(url: string) {
  console.log('[DeepLink] Handling:', url);

  const params = parseDeepLink(url);
  if (!params) {
    console.warn('[DeepLink] Invalid URL format:', url);
    return;
  }

  try {
    switch (params.type) {
      case 'memory':
        // Открываем модальное окно с деталями воспоминания
        router.push(`/memory-detail?id=${params.id}`);
        break;

      case 'user':
        // Открываем профиль пользователя
        router.push(`/user/${params.id}`);
        break;

      case 'chat':
        // Открываем чат
        router.push(`/chat?id=${params.id}`);
        break;

      default:
        console.warn('[DeepLink] Unknown type:', params.type);
    }
  } catch (error) {
    console.error('[DeepLink] Navigation error:', error);
  }
}

/**
 * Генерирует deep link для воспоминания
 */
export function generateMemoryLink(memoryId: string): string {
  return `${DEEP_LINK_PREFIX}memory/${memoryId}`;
}

/**
 * Генерирует deep link для пользователя
 */
export function generateUserLink(userId: string): string {
  return `${DEEP_LINK_PREFIX}user/${userId}`;
}

/**
 * Генерирует deep link для чата
 */
export function generateChatLink(chatId: string): string {
  return `${DEEP_LINK_PREFIX}chat/${chatId}`;
}

/**
 * Инициализирует обработчик deep links
 * Вызывается при запуске приложения
 */
export function initializeDeepLinking() {
  // Обрабатываем deep link при открытии приложения
  Linking.getInitialURL().then((url) => {
    if (url) {
      console.log('[DeepLink] Initial URL:', url);
      handleDeepLink(url);
    }
  });

  // Обрабатываем deep links когда приложение уже запущено
  const subscription = Linking.addEventListener('url', (event) => {
    console.log('[DeepLink] Event URL:', event.url);
    handleDeepLink(event.url);
  });

  return () => {
    subscription.remove();
  };
}
