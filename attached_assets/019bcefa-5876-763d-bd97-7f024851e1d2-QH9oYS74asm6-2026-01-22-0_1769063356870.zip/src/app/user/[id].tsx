import React, { useState } from 'react';
import { View, Text, Pressable, Image, Dimensions, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import Animated, { useAnimatedScrollHandler, useSharedValue, useAnimatedStyle, interpolate, Extrapolate } from 'react-native-reanimated';
import { ChevronLeft, MessageCircle, Lock } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/supabase-hooks';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ColoredUsername } from '@/components/ColoredUsername';
import { SocialIcons } from '@/components/SocialIcons';

const { width } = Dimensions.get('window');
const GRID_ITEM_SIZE = (width - 6) / 3;

const AnimatedScrollView = Animated.createAnimatedComponent(Animated.ScrollView);

// Grid item component to handle image loading state
const MemoryGridItem = ({ memory, theme, onPress }: {
  memory: any;
  theme: any;
  onPress: () => void;
}) => {
  const [imageError, setImageError] = useState(false);
  const [imageLoading, setImageLoading] = useState(true);

  return (
    <Pressable
      onPress={onPress}
      style={{ width: GRID_ITEM_SIZE, height: GRID_ITEM_SIZE }}
      className="active:opacity-70"
    >
      {memory.imageUrl && !imageError ? (
        <>
          <Image
            source={{ uri: memory.imageUrl }}
            style={{ width: '100%', height: '100%' }}
            resizeMode="cover"
            onLoadStart={() => setImageLoading(true)}
            onLoadEnd={() => setImageLoading(false)}
            onError={(e) => {
              console.log('[UserProfile] Image load error:', memory.imageUrl, e.nativeEvent);
              setImageError(true);
              setImageLoading(false);
            }}
          />
          {imageLoading && (
            <View
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: `${theme.colors.accent}20`,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <ActivityIndicator size="small" color={theme.colors.accent} />
            </View>
          )}
        </>
      ) : (
        <View
          className="items-center justify-center"
          style={{
            width: '100%',
            height: '100%',
            backgroundColor: `${theme.colors.accent}20`,
          }}
        >
          <Text style={{ fontSize: 32 }}>
            {memory.emotion === 'peaceful' ? '🌊' :
             memory.emotion === 'grateful' ? '🙏' :
             memory.emotion === 'nostalgic' ? '🌅' :
             memory.emotion === 'hopeful' ? '🌟' :
             memory.emotion === 'reflective' ? '🤔' : '😊'}
          </Text>
        </View>
      )}
    </Pressable>
  );
};

export default function UserProfileScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const scrollY = useSharedValue(0);

  // Get current user
  const { data: auth } = useAuth();
  const currentUserId = auth?.session?.user?.id;
  const isOwnProfile = currentUserId === id;

  // Fetch user profile
  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['user-profile', id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, avatar_emoji, is_verified, is_admin, username_color, social_links, is_private')
        .eq('id', id)
        .single();
      if (error) throw error;

      console.log('[UserProfile] Loaded profile:', {
        username: data.username,
        social_links: data.social_links,
      });

      return data;
    },
    // ВАЖНО: Не использовать кэш, всегда загружать свежие данные
    staleTime: 0,
    gcTime: 0,
  });

  // Check if current user is following this profile
  const { data: isFollowing = false } = useQuery({
    queryKey: ['is-following', currentUserId, id],
    queryFn: async () => {
      if (!currentUserId || currentUserId === id) return false;

      const { data, error } = await supabase
        .from('follows')
        .select('id')
        .eq('follower_id', currentUserId)
        .eq('following_id', id)
        .maybeSingle();

      if (error) {
        console.error('[UserProfile] Error checking follow status:', error);
        return false;
      }

      return !!data;
    },
    enabled: !!currentUserId && currentUserId !== id,
  });

  // Determine if profile is private and user can't see posts
  const isPrivateProfile = profile?.is_private === true;
  const canViewPosts = isOwnProfile || !isPrivateProfile || isFollowing;

  // Fetch user memories (only if can view)
  const { data: memories = [], isLoading: isLoadingMemories } = useQuery({
    queryKey: ['user-memories', id],
    queryFn: async () => {
      console.log('[UserProfile] Fetching memories for user:', id);

      const { data, error } = await supabase
        .from('memories')
        .select('*')
        .eq('user_id', id)
        .eq('is_archived', false)
        .order('created_at', { ascending: false });
      if (error) throw error;

      console.log('[UserProfile] Fetched memories:', data.length, 'items');
      // Log first memory to see structure
      if (data.length > 0) {
        console.log('[UserProfile] First memory:', JSON.stringify(data[0], null, 2));
      }

      // Transform snake_case to camelCase
      return data.map((memory: any) => ({
        id: memory.id,
        text: memory.text,
        emotion: memory.emotion,
        imageUrl: memory.image_url,
        videoUrl: memory.video_url,
        location: memory.location,
        latitude: memory.latitude,
        longitude: memory.longitude,
        echoCount: memory.echo_count,
        isArchived: memory.is_archived,
        createdAt: memory.created_at,
        authorId: memory.user_id,
      }));
    },
    // Add staleTime to prevent unnecessary refetches
    staleTime: 1000 * 60 * 5, // 5 minutes
    // Refetch when screen comes into focus
    refetchOnMount: 'always',
    // Only fetch if user can view posts
    enabled: canViewPosts,
  });

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  // Animated blur header opacity - appears on scroll
  const headerBlurStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 60],
      [0, 1],
      Extrapolate.CLAMP
    );

    return {
      opacity,
    };
  });

  // Animated avatar in header - appears on scroll
  const headerAvatarStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [60, 100],
      [0, 1],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollY.value,
      [60, 100],
      [0.5, 1],
      Extrapolate.CLAMP
    );

    return {
      opacity,
      transform: [{ scale }],
    };
  });

  // Hide main avatar on scroll
  const mainAvatarStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 80],
      [1, 0],
      Extrapolate.CLAMP
    );

    return {
      opacity,
    };
  });

  const isLoading = isLoadingProfile || isLoadingMemories;

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {isLoading ? (
          <View className="flex-1 items-center justify-center">
            <ActivityIndicator size="large" color={theme.colors.accent} />
          </View>
        ) : (
          <>
            <AnimatedScrollView
              className="flex-1"
              showsVerticalScrollIndicator={false}
              onScroll={scrollHandler}
              scrollEventThrottle={16}
            >
              {/* Content starts with top padding */}
              <View style={{ paddingTop: insets.top + 60 }}>
                {/* Avatar + Name - Animated main section */}
                <Animated.View
                  style={mainAvatarStyle}
                  className="items-center px-5 mb-8"
                >
                  <Text style={{ fontSize: 80, lineHeight: 88, marginBottom: 12 }}>
                    {profile?.avatar_emoji || '👤'}
                  </Text>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                    <ColoredUsername
                      username={profile?.username || 'Unknown'}
                      color={profile?.username_color}
                      size={24}
                      weight="600"
                      defaultColor={theme.colors.text}
                    />
                    <VerifiedBadge isVerified={profile?.is_verified === true} size={20} checkColor={theme.colors.primary} />
                    <SocialIcons socialLinks={profile?.social_links || []} size={18} gap={8} />
                  </View>
                  <Text style={{ color: theme.colors.textSecondary, fontSize: 14, marginTop: 8 }}>
                    {memories.length} {language === 'ru'
                      ? (memories.length === 1 ? 'воспоминание' : memories.length < 5 ? 'воспоминания' : 'воспоминаний')
                      : (memories.length === 1 ? 'memory' : 'memories')}
                  </Text>

                  {/* Message Button - only show if not own profile */}
                  {!isOwnProfile && (
                    <Pressable
                      onPress={() => {
                        triggerHaptic();
                        router.push(`/chat?id=${id}&userId=${id}&username=${profile?.username}`);
                      }}
                      className="active:opacity-70"
                      style={{
                        marginTop: 20,
                        paddingHorizontal: 24,
                        paddingVertical: 12,
                        borderRadius: 24,
                        backgroundColor: theme.colors.accent,
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: 8,
                      }}
                    >
                      <MessageCircle size={18} color={theme.colors.primary} strokeWidth={2} />
                      <Text style={{ color: theme.colors.primary, fontSize: 15, fontWeight: '600' }}>
                        {language === 'ru' ? 'Написать сообщение' : 'Send Message'}
                      </Text>
                    </Pressable>
                  )}
                </Animated.View>

                {/* Memories Grid - only show if can view posts */}
                {!canViewPosts ? (
                  <View className="items-center py-20 px-5">
                    <View
                      className="items-center justify-center mb-4"
                      style={{
                        width: 80,
                        height: 80,
                        borderRadius: 40,
                        backgroundColor: `${theme.colors.accent}20`,
                      }}
                    >
                      <Lock size={36} color={theme.colors.accent} strokeWidth={1.5} />
                    </View>
                    <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '600', marginBottom: 8, textAlign: 'center' }}>
                      {language === 'ru' ? 'Закрытый профиль' : 'Private Profile'}
                    </Text>
                    <Text style={{ color: theme.colors.textSecondary, fontSize: 14, textAlign: 'center' }}>
                      {language === 'ru'
                        ? 'Подпишитесь, чтобы видеть воспоминания этого пользователя'
                        : 'Follow this user to see their memories'}
                    </Text>
                  </View>
                ) : (
                  <>
                    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 2, padding: 2 }}>
                      {memories.map((memory) => (
                        <MemoryGridItem
                          key={memory.id}
                          memory={memory}
                          theme={theme}
                          onPress={() => {
                            triggerHaptic();
                            router.push(`/memory-detail?id=${memory.id}`);
                          }}
                        />
                      ))}
                    </View>

                    {memories.length === 0 && (
                      <View className="items-center py-20">
                        <Text style={{ color: theme.colors.textSecondary, fontSize: 14 }}>
                          {language === 'ru' ? 'Нет воспоминаний' : 'No memories yet'}
                        </Text>
                      </View>
                    )}
                  </>
                )}
              </View>
            </AnimatedScrollView>

            {/* Animated Blur Header */}
            <Animated.View
              style={[
                {
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  paddingTop: insets.top + 8,
                  paddingHorizontal: 16,
                  paddingBottom: 12,
                  zIndex: 10,
                },
                headerBlurStyle,
              ]}
              pointerEvents="box-none"
            >
              <BlurView intensity={80} tint="dark" style={{ borderRadius: 20, overflow: 'hidden' }}>
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    paddingVertical: 8,
                    paddingHorizontal: 12,
                    backgroundColor: `${theme.colors.primary}40`,
                  }}
                >
                  {/* Back Button */}
                  <Pressable
                    onPress={() => {
                      triggerHaptic();
                      router.back();
                    }}
                    className="flex-row items-center active:opacity-60"
                  >
                    <ChevronLeft size={20} color={theme.colors.accent} strokeWidth={1.5} />
                    <Text style={{ color: theme.colors.accent, fontSize: 14, marginLeft: 4 }}>
                      {language === 'ru' ? 'Назад' : 'Back'}
                    </Text>
                  </Pressable>

                  {/* Avatar in header - appears on scroll */}
                  <Animated.View style={[{ flexDirection: 'row', alignItems: 'center', gap: 8 }, headerAvatarStyle]}>
                    <Text style={{ fontSize: 24, lineHeight: 28 }}>
                      {profile?.avatar_emoji || '👤'}
                    </Text>
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '600' }}>
                      {profile?.username}
                    </Text>
                    <VerifiedBadge isVerified={profile?.is_verified === true} size={16} checkColor={theme.colors.primary} />
                  </Animated.View>

                  {/* Placeholder for layout balance */}
                  <View style={{ width: 60 }} />
                </View>
              </BlurView>
            </Animated.View>

            {/* Static Back Button (visible when header is transparent) */}
            <View
              style={{
                position: 'absolute',
                top: insets.top + 8,
                left: 16,
                zIndex: 5,
              }}
              pointerEvents="box-none"
            >
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.back();
                }}
                className="flex-row items-center active:opacity-60"
              >
                <ChevronLeft size={24} color={theme.colors.accent} strokeWidth={1.5} />
                <Text style={{ color: theme.colors.accent, fontSize: 16, marginLeft: 4, textDecorationLine: 'underline' }}>
                  {language === 'ru' ? 'Назад' : 'Back'}
                </Text>
              </Pressable>
            </View>
          </>
        )}
      </LinearGradient>
    </View>
  );
}
