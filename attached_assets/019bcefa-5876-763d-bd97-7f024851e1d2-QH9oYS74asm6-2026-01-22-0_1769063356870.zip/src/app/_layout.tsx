import React, { useEffect, useState } from 'react';
import { View, Alert } from 'react-native';
import { DarkTheme, ThemeProvider } from '@react-navigation/native';
import { Stack } from 'expo-router';
import * as SplashScreen from 'expo-splash-screen';
import { StatusBar } from 'expo-status-bar';
import { QueryClient } from '@tanstack/react-query';
import { PersistQueryClientProvider } from '@tanstack/react-query-persist-client';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import { KeyboardProvider } from 'react-native-keyboard-controller';
import { useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { OnboardingFlow } from '@/components/OnboardingFlow';
import { LoginFlow } from '@/components/LoginFlow';
import { LoadingScreen } from '@/components/LoadingScreen';
import { SyncProvider } from '@/lib/SyncProvider';
import { realtimeManager } from '@/lib/realtime-manager';
import { initializeDeepLinking } from '@/lib/deep-linking';
import { useAuth } from '@/lib/supabase-hooks';

export const unstable_settings = {
  initialRouteName: '(tabs)',
};

SplashScreen.preventAutoHideAsync();

// TELEGRAM-STYLE: Keep data in cache FOREVER, persist to disk
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      gcTime: Infinity, // ✅ NEVER remove data from cache
      staleTime: Infinity, // ✅ Data NEVER becomes stale
      refetchOnMount: false,
      refetchOnWindowFocus: false,
      refetchOnReconnect: false,
      retry: 3,
      retryDelay: (attemptIndex) => Math.min(1000 * 2 ** attemptIndex, 30000),
      networkMode: 'online',
    },
    mutations: {
      retry: 2,
      networkMode: 'online',
    },
  },
});

// ✅ TELEGRAM-STYLE: Custom persister for AsyncStorage
const asyncStoragePersister = {
  persistClient: async (client: any) => {
    try {
      const data = JSON.stringify(client);
      await AsyncStorage.setItem('REACT_QUERY_OFFLINE_CACHE', data);
    } catch (error) {
      console.warn('[ReactQuery] Error persisting cache:', error);
    }
  },
  restoreClient: async () => {
    try {
      const data = await AsyncStorage.getItem('REACT_QUERY_OFFLINE_CACHE');
      if (data) {
        console.log('[ReactQuery] ✅ Cache restored from disk');
        return JSON.parse(data);
      }
      console.log('[ReactQuery] No cache found on disk');
    } catch (error) {
      console.warn('[ReactQuery] Error restoring cache:', error);
    }
    return undefined;
  },
  removeClient: async () => {
    try {
      await AsyncStorage.removeItem('REACT_QUERY_OFFLINE_CACHE');
    } catch (error) {
      console.warn('[ReactQuery] Error removing cache:', error);
    }
  },
};

function RootLayoutNav() {
  const themeKey = useSettingsStore(s => s.theme);
  const theme = getTheme(themeKey);

  useEffect(() => {
    // Initialize deep linking
    const cleanup = initializeDeepLinking();

    return () => {
      console.log('[App] Cleaning up all Realtime subscriptions and deep links');
      realtimeManager.cleanup();
      if (cleanup) cleanup();
    };
  }, []);

  const navigationTheme = {
    ...DarkTheme,
    colors: {
      ...DarkTheme.colors,
      background: theme.colors.background,
      card: theme.colors.primaryLight,
      text: theme.colors.text,
      border: `${theme.colors.text}1A`,
      primary: theme.colors.accent,
    },
  };

  return (
    <ThemeProvider value={navigationTheme}>
      <Stack
        screenOptions={{
          headerShown: false,
          contentStyle: { backgroundColor: theme.colors.background },
          animation: 'default',
          gestureEnabled: true,
          fullScreenGestureEnabled: true,
          animationTypeForReplace: 'push',
        }}
      >
        <Stack.Screen name="(tabs)" />
        <Stack.Screen
          name="profile"
          options={{
            presentation: 'card',
            animation: 'slide_from_right',
            gestureEnabled: false, // Disable swipe back to avoid conflict with scrolling
          }}
        />
        <Stack.Screen
          name="settings"
          options={{
            presentation: 'card',
            animation: 'slide_from_right',
            gestureEnabled: false, // Disable swipe back to avoid conflict with scrolling
          }}
        />
        <Stack.Screen name="create-memory" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="select-theme" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="select-language" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="search-users" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="memory-detail" options={{
          presentation: 'modal',
          animation: 'slide_from_bottom',
          gestureEnabled: true,
          animationDuration: 300,
          gestureDirection: 'vertical',
          fullScreenGestureEnabled: true
        }} />
        <Stack.Screen name="archive" options={{ presentation: 'card', animation: 'slide_from_right' }} />
        <Stack.Screen name="account" options={{ presentation: 'card', animation: 'slide_from_right' }} />
        <Stack.Screen name="modal" options={{ presentation: 'modal', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="comments" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="settings-audio" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="settings-appearance" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="notifications" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="edit-username" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="qr-scanner" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="hidden-users" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="settings-performance" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="chat" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: false, fullScreenGestureEnabled: false, animationDuration: 300, gestureDirection: 'vertical' }} />
        <Stack.Screen name="user/[id]" options={{
          presentation: 'modal',
          animation: 'slide_from_bottom',
          gestureEnabled: true,
          animationDuration: 300,
          gestureDirection: 'vertical',
          fullScreenGestureEnabled: true
        }} />
        <Stack.Screen name="premium" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="admin" options={{ presentation: 'modal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
        <Stack.Screen name="admin-monitor" options={{ presentation: 'fullScreenModal', animation: 'slide_from_bottom', gestureEnabled: true, animationDuration: 300 }} />
      </Stack>
    </ThemeProvider>
  );
}

function AppContent() {
  const [isReady, setIsReady] = useState(false);
  const [showLoading, setShowLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [showLogin, setShowLogin] = useState(false);

  const isOnboarded = useAppStore(s => s.isOnboarded);
  const isAuthenticated = useAppStore(s => s.isAuthenticated);
  const themeKey = useSettingsStore(s => s.theme);
  const theme = getTheme(themeKey);

  // Check ban status
  const { data: auth } = useAuth();

  // If user is banned, force logout
  useEffect(() => {
    if (auth === null && isAuthenticated) {
      // User was logged out due to ban
      console.log('[App] User was logged out (banned), showing login screen');
      useAppStore.getState().setAuthenticated(false);
      setShowLogin(true);

      Alert.alert(
        'Account Banned',
        'Your account has been banned. Please contact support if you think this is a mistake.',
        [{ text: 'OK' }]
      );
    }
  }, [auth, isAuthenticated]);

  useEffect(() => {
    async function initializeApp() {
      // Preload critical data into memory cache BEFORE showing UI
      const { preloadCriticalData } = await import('@/lib/data-persistence');
      await preloadCriticalData();

      setIsReady(true);
      SplashScreen.hideAsync();
    }

    const timer = setTimeout(() => {
      initializeApp();
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (isReady) {
      if (!isOnboarded) {
        setShowOnboarding(true);
        setShowLogin(false);
      } else if (!isAuthenticated) {
        setShowOnboarding(false);
        setShowLogin(true);
      } else {
        setShowOnboarding(false);
        setShowLogin(false);
      }
    }
  }, [isReady, isOnboarded, isAuthenticated]);

  if (!isReady || (showLoading && !showOnboarding && !showLogin)) {
    return <LoadingScreen onFinish={() => setShowLoading(false)} />;
  }

  if (showOnboarding) {
    return (
      <OnboardingFlow
        onComplete={() => setShowOnboarding(false)}
        onSwitchToLogin={() => {
          setShowOnboarding(false);
          setShowLogin(true);
        }}
      />
    );
  }

  if (showLogin) {
    return (
      <LoginFlow
        onSuccess={() => setShowLogin(false)}
        onBack={() => {
          setShowLogin(false);
          setShowOnboarding(true);
        }}
      />
    );
  }

  return <RootLayoutNav />;
}

export default function RootLayout() {
  return (
    <PersistQueryClientProvider
      client={queryClient}
      persistOptions={{
        persister: asyncStoragePersister,
        maxAge: Infinity, // ✅ NEVER expire cached data
        buster: '', // No cache busting
      }}
      onSuccess={() => {
        console.log('[ReactQuery] ✅ Persistence ready - data restored');
      }}
    >
      <SyncProvider>
        <GestureHandlerRootView style={{ flex: 1 }}>
          <KeyboardProvider>
            <StatusBar style="light" />
            <AppContent />
          </KeyboardProvider>
        </GestureHandlerRootView>
      </SyncProvider>
    </PersistQueryClientProvider>
  );
}
