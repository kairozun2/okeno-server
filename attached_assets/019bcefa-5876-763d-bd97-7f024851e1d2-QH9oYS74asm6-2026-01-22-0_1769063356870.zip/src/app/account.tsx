import React, { useState, useCallback } from 'react';
import { View, Text, ScrollView, Pressable, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { ChevronLeft, User, Key, LogOut, Copy, Check, Edit3, Palette, Crown, Lock } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import * as Clipboard from 'expo-clipboard';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { useAuth, useIsAdmin } from '@/lib/supabase-hooks';
import { supabase } from '@/lib/supabase';
import { EditUsernameColorModal } from '@/components/EditUsernameColorModal';
import { ColoredUsername } from '@/components/ColoredUsername';
import { useQueryClient } from '@tanstack/react-query';

export default function AccountScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  const [copied, setCopied] = useState(false);
  const [showEditColor, setShowEditColor] = useState(false);
  const [isPrivateProfile, setIsPrivateProfile] = useState(false);
  const [isTogglingPrivate, setIsTogglingPrivate] = useState(false);

  // Use Supabase auth data
  const { data: auth } = useAuth();
  const isAdmin = useIsAdmin();
  const localUserName = useAppStore(s => s.userName);
  const setAuthenticated = useAppStore(s => s.setAuthenticated);
  const isPremium = useAppStore(s => s.isPremium);

  const userName = auth?.profile?.username || localUserName;
  const userId = auth?.profile?.id || '';
  const usernameColor = auth?.profile?.username_color || null;
  const usernameLastChanged = auth?.profile?.username_last_changed;
  const colorLastChanged = auth?.profile?.color_last_changed;

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  const canChangeColor = isPremium || isAdmin;
  const displayColor = usernameColor || theme.colors.text;

  // Load private profile status
  React.useEffect(() => {
    if (auth?.profile?.is_private !== undefined) {
      setIsPrivateProfile(auth.profile.is_private);
    }
  }, [auth?.profile?.is_private]);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleTogglePrivateProfile = useCallback(async (value: boolean) => {
    setIsTogglingPrivate(true);
    triggerHaptic();

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ is_private: value })
        .eq('id', userId);

      if (error) throw error;

      setIsPrivateProfile(value);

      // Refetch auth data to update UI
      queryClient.invalidateQueries({ queryKey: ['auth'] });

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    } catch (error) {
      console.error('Error toggling private profile:', error);
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Не удалось изменить настройку приватности' : 'Failed to change privacy setting'
      );
      setIsPrivateProfile(!value); // Revert on error
    } finally {
      setIsTogglingPrivate(false);
    }
  }, [userId, language, queryClient]);

  const handleCopyId = async () => {
    triggerHaptic();
    await Clipboard.setStringAsync(userId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSignOut = async () => {
    triggerHaptic();
    Alert.alert(
      t('account.signOutConfirm'),
      '',
      [
        {
          text: t('account.cancel'),
          style: 'cancel',
          onPress: () => triggerHaptic(),
        },
        {
          text: t('account.signOut'),
          style: 'destructive',
          onPress: async () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            await supabase.auth.signOut();
            setAuthenticated(false);
            router.replace('/');
          },
        },
      ]
    );
  };

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 8,
            paddingHorizontal: 20,
            paddingBottom: 12,
          }}
        >
          <View className="flex-row items-center justify-between">
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{ backgroundColor: `${theme.colors.accent}20` }}
            >
              <ChevronLeft size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>

            <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500', position: 'absolute', left: 0, right: 0, textAlign: 'center', zIndex: -1 }}>
              {t('account.title')}
            </Text>

            <View className="w-10" />
          </View>
        </View>

        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
        >
          {/* Username Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mt-6 mb-4 p-5 rounded-2xl"
            style={{ backgroundColor: `${theme.colors.accent}15` }}
          >
            <View className="flex-row items-center mb-3">
              <View
                className="w-10 h-10 rounded-full items-center justify-center mr-3"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <User size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </View>
              <View className="flex-1">
                <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginBottom: 2 }}>
                  {t('account.username')}
                </Text>
                <View className="flex-row items-center">
                  <ColoredUsername
                    username={userName}
                    color={usernameColor}
                    size={18}
                    weight="500"
                    defaultColor={theme.colors.text}
                  />
                  {isAdmin && (
                    <View className="ml-2">
                      <Crown size={16} color="#FFD700" fill="#FFD700" strokeWidth={0} />
                    </View>
                  )}
                </View>
              </View>
            </View>
          </Animated.View>

          {/* Edit Username Button */}
          <Animated.View
            entering={FadeIn.delay(100).duration(300)}
            className="mx-5 mb-4"
          >
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.push('/edit-username');
              }}
              className="rounded-2xl overflow-hidden active:opacity-80 p-4"
              style={{ backgroundColor: `${theme.colors.accent}15` }}
            >
              <View className="flex-row items-center">
                <Edit3 size={20} color={theme.colors.accent} strokeWidth={1.5} />
                <View className="ml-3 flex-1">
                  <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                    {language === 'ru' ? 'Изменить имя' : 'Edit Username'}
                  </Text>
                  <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginTop: 2 }}>
                    {language === 'ru' ? 'Раз в 15 дней' : 'Once every 15 days'}
                  </Text>
                </View>
              </View>
            </Pressable>
          </Animated.View>

          {/* Edit Color Button */}
          <Animated.View
            entering={FadeIn.delay(150).duration(300)}
            className="mx-5 mb-4"
          >
            <Pressable
              onPress={() => {
                triggerHaptic();
                if (canChangeColor) {
                  setShowEditColor(true);
                }
              }}
              disabled={!canChangeColor}
              className="rounded-2xl overflow-hidden active:opacity-80 p-4"
              style={{ backgroundColor: canChangeColor ? `${theme.colors.accent}15` : `${theme.colors.text}10` }}
            >
              <View className="flex-row items-center">
                <Palette size={20} color={canChangeColor ? theme.colors.accent : theme.colors.textSecondary} strokeWidth={1.5} />
                <View className="ml-3 flex-1">
                  <Text style={{ color: canChangeColor ? theme.colors.text : theme.colors.textSecondary, fontSize: 16, fontWeight: '500' }}>
                    {language === 'ru' ? 'Изменить цвет имени' : 'Edit Username Color'}
                  </Text>
                  <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginTop: 2 }}>
                    {canChangeColor
                      ? (language === 'ru' ? 'Раз в 15 дней' : 'Once every 15 days')
                      : (language === 'ru' ? 'Требуется Premium' : 'Premium required')}
                  </Text>
                </View>
                {!canChangeColor && (
                  <View className="px-2 py-1 rounded-full" style={{ backgroundColor: `${theme.colors.accent}20` }}>
                    <Text style={{ color: theme.colors.accent, fontSize: 11, fontWeight: '600' }}>
                      PRO
                    </Text>
                  </View>
                )}
              </View>
            </Pressable>
          </Animated.View>

          {/* Recovery ID Section */}
          <Animated.View
            entering={FadeIn.delay(100).duration(300)}
            className="mx-5 mb-4 p-5 rounded-2xl"
            style={{ backgroundColor: `${theme.colors.accent}15` }}
          >
            <View className="flex-row items-center mb-3">
              <View
                className="w-10 h-10 rounded-full items-center justify-center mr-3"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <Key size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </View>
              <View className="flex-1">
                <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginBottom: 2 }}>
                  {t('account.recoveryId')}
                </Text>
                <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '600', fontFamily: 'monospace' }}>
                  {userId}
                </Text>
              </View>
            </View>

            <Text style={{ color: theme.colors.textSecondary, fontSize: 13, marginBottom: 12, lineHeight: 18 }}>
              {t('account.recoveryIdDesc')}
            </Text>

            <Pressable
              onPress={handleCopyId}
              className="py-3 px-4 rounded-xl active:opacity-60"
              style={{ backgroundColor: theme.colors.accent }}
            >
              <View className="flex-row items-center justify-center">
                {copied ? (
                  <Check size={18} color={theme.colors.background} strokeWidth={2} />
                ) : (
                  <Copy size={18} color={theme.colors.background} strokeWidth={2} />
                )}
                <Text style={{ color: theme.colors.background, fontSize: 14, fontWeight: '600', marginLeft: 8 }}>
                  {copied ? t('account.copied') : t('account.copy')}
                </Text>
              </View>
            </Pressable>
          </Animated.View>

          {/* Private Profile Toggle */}
          <Animated.View
            entering={FadeIn.delay(250).duration(300)}
            className="mx-5 mt-8 mb-4"
          >
            <Pressable
              onPress={() => {
                if (!isTogglingPrivate) {
                  handleTogglePrivateProfile(!isPrivateProfile);
                }
              }}
              disabled={isTogglingPrivate}
              className="p-4 rounded-2xl active:opacity-80"
              style={{ backgroundColor: theme.colors.accent + '15' }}
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center flex-1">
                  <View
                    className="w-10 h-10 rounded-full items-center justify-center mr-3"
                    style={{ backgroundColor: theme.colors.accent + '20' }}
                  >
                    <Lock size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  </View>
                  <View className="flex-1">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                      {language === 'ru' ? 'Закрытый профиль' : 'Private Profile'}
                    </Text>
                    <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginTop: 2 }}>
                      {language === 'ru'
                        ? 'Скрыть ваши воспоминания'
                        : 'Hide your memories'}
                    </Text>
                  </View>
                </View>
                {/* Custom Toggle */}
                <View
                  style={{
                    width: 51,
                    height: 31,
                    borderRadius: 16,
                    backgroundColor: isPrivateProfile ? theme.colors.accent : theme.colors.textSecondary + '40',
                    padding: 2,
                    justifyContent: 'center',
                    opacity: isTogglingPrivate ? 0.5 : 1,
                  }}
                >
                  <View
                    style={{
                      width: 27,
                      height: 27,
                      borderRadius: 14,
                      backgroundColor: '#FFFFFF',
                      transform: [{ translateX: isPrivateProfile ? 20 : 0 }],
                    }}
                  />
                </View>
              </View>
            </Pressable>
          </Animated.View>

          {/* Sign Out Section */}
          <Animated.View
            entering={FadeIn.delay(300).duration(300)}
            className="mx-5"
          >
            <Pressable
              onPress={handleSignOut}
              className="py-4 px-5 rounded-2xl active:opacity-60 flex-row items-center justify-center"
              style={{ backgroundColor: `${theme.colors.accent}15` }}
            >
              <LogOut size={20} color={theme.colors.accent} strokeWidth={1.5} />
              <Text style={{ color: theme.colors.accent, fontSize: 16, fontWeight: '500', marginLeft: 12 }}>
                {t('account.signOut')}
              </Text>
            </Pressable>
          </Animated.View>
        </ScrollView>
      </LinearGradient>

      <EditUsernameColorModal
        visible={showEditColor}
        onClose={() => setShowEditColor(false)}
        currentColor={displayColor}
        lastChanged={colorLastChanged}
      />
    </View>
  );
}
