import React, { useState } from 'react';
import { View, Text, Pressable, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { CameraView, useCameraPermissions } from 'expo-camera';
import { X } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';

export default function QRScannerScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  if (!permission) {
    return <View style={{ flex: 1, backgroundColor: theme.colors.background }} />;
  }

  if (!permission.granted) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, justifyContent: 'center', alignItems: 'center', padding: 20 }}>
        <Text style={{ color: theme.colors.text, fontSize: 16, textAlign: 'center', marginBottom: 20 }}>
          {language === 'ru' ? 'Нужен доступ к камере для сканирования QR-кодов' : 'Camera permission is required to scan QR codes'}
        </Text>
        <Pressable
          onPress={requestPermission}
          style={{
            backgroundColor: theme.colors.accent,
            paddingVertical: 12,
            paddingHorizontal: 24,
            borderRadius: 12,
          }}
        >
          <Text style={{ color: theme.colors.primary, fontSize: 15, fontWeight: '600' }}>
            {language === 'ru' ? 'Разрешить доступ' : 'Grant Permission'}
          </Text>
        </Pressable>
      </View>
    );
  }

  const handleBarCodeScanned = ({ data }: { data: string }) => {
    if (scanned) return;

    setScanned(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

    try {
      // Try to parse as JSON
      const parsed = JSON.parse(data);

      if (parsed.userId && parsed.userName) {
        // Valid Memories QR code
        Alert.alert(
          language === 'ru' ? 'Пользователь найден!' : 'User Found!',
          `@${parsed.userName}`,
          [
            {
              text: language === 'ru' ? 'Открыть профиль' : 'Open Profile',
              onPress: () => {
                router.back();
                router.push(`/user/${parsed.userId}`);
              }
            },
            {
              text: language === 'ru' ? 'Отмена' : 'Cancel',
              onPress: () => setScanned(false),
              style: 'cancel',
            }
          ]
        );
      } else {
        throw new Error('Invalid format');
      }
    } catch (error) {
      // Not a valid Memories QR code
      Alert.alert(
        language === 'ru' ? 'Неверный QR-код' : 'Invalid QR Code',
        language === 'ru' ? 'Это не QR-код Memories' : 'This is not a Memories QR code',
        [
          {
            text: 'OK',
            onPress: () => setScanned(false),
          }
        ]
      );
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <CameraView
        style={{ flex: 1 }}
        facing="back"
        onBarcodeScanned={scanned ? undefined : handleBarCodeScanned}
        barcodeScannerSettings={{
          barcodeTypes: ['qr'],
        }}
      >
        {/* Header */}
        <View
          style={{
            position: 'absolute',
            top: insets.top + 16,
            left: 20,
            right: 20,
            flexDirection: 'row',
            justifyContent: 'space-between',
            alignItems: 'center',
          }}
        >
          <Pressable
            onPress={() => {
              triggerHaptic();
              router.back();
            }}
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: 'rgba(0, 0, 0, 0.6)',
              alignItems: 'center',
              justifyContent: 'center',
            }}
          >
            <X size={20} color="#FFFFFF" strokeWidth={1.5} />
          </Pressable>
        </View>

        {/* Scanning Frame */}
        <View
          style={{
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
            padding: 40,
          }}
        >
          <View
            style={{
              width: 250,
              height: 250,
              borderWidth: 2,
              borderColor: theme.colors.accent,
              borderRadius: 16,
              backgroundColor: 'transparent',
            }}
          />
          <Text
            style={{
              color: '#FFFFFF',
              fontSize: 16,
              marginTop: 24,
              textAlign: 'center',
              backgroundColor: 'rgba(0, 0, 0, 0.6)',
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 8,
            }}
          >
            {language === 'ru' ? 'Наведите камеру на QR-код' : 'Point camera at QR code'}
          </Text>
        </View>
      </CameraView>
    </View>
  );
}
