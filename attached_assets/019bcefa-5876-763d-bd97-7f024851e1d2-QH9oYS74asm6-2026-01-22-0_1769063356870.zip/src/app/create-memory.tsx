import React, { useState, useCallback } from 'react';
import { View, Text, Pressable, TextInput, ScrollView, KeyboardAvoidingView, Platform, Alert, Image, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X, Send, Image as ImageIcon, Camera, MapPin, Trash2, Play } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import { CustomVideoPlayer } from '@/components/CustomVideoPlayer';
import { ResizeMode } from 'expo-av';
import { Emotion, EMOTIONS } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { cn } from '@/lib/cn';
import { LinearGradient } from 'expo-linear-gradient';
import { useCreateMemory, useUploadMedia } from '@/lib/supabase-hooks';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export default function CreateMemoryScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [text, setText] = useState('');
  const [selectedEmotion, setSelectedEmotion] = useState<Emotion | null>(null);
  const [mediaUri, setMediaUri] = useState<string | undefined>(undefined);
  const [mediaType, setMediaType] = useState<'image' | 'video' | undefined>(undefined);
  const [location, setLocation] = useState<string | undefined>(undefined);
  const [latitude, setLatitude] = useState<number | undefined>(undefined);
  const [longitude, setLongitude] = useState<number | undefined>(undefined);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [imageAspectRatio, setImageAspectRatio] = useState<number | undefined>(undefined);
  const [isPickingMedia, setIsPickingMedia] = useState(false);

  // Use Supabase hooks
  const createMemoryMutation = useCreateMemory();
  const uploadMediaMutation = useUploadMedia();

  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  const isVideo = mediaType === 'video';

  // Pre-request permissions on mount for faster picker response
  React.useEffect(() => {
    ImagePicker.requestMediaLibraryPermissionsAsync();
    ImagePicker.requestCameraPermissionsAsync();
  }, []);

  // Get image dimensions to calculate aspect ratio
  React.useEffect(() => {
    if (mediaUri && mediaType === 'image') {
      Image.getSize(
        mediaUri,
        (width, height) => {
          setImageAspectRatio(width / height);
        },
        (error) => {
          console.log('Failed to get image size:', error);
          setImageAspectRatio(4 / 5); // Fallback
        }
      );
    } else if (mediaType === 'video') {
      setImageAspectRatio(9 / 16); // Portrait video default
    }
  }, [mediaUri, mediaType]);

  const triggerHaptic = useCallback(() => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  }, [hapticsEnabled]);

  const handleCreate = async () => {
    if (text.trim().length > 0 && selectedEmotion) {
      try {
        setIsUploading(true);
        setUploadProgress(0);

        let uploadedMediaUrl = mediaUri;

        // Upload media to Supabase if exists
        if (mediaUri && mediaType) {
          console.log('[Create] Starting media upload...');

          try {
            const result = await uploadMediaMutation.mutateAsync({
              uri: mediaUri,
              type: mediaType,
              onProgress: (progress) => {
                // Update progress in real-time
                setUploadProgress(progress);
                console.log(`[Create] Upload progress: ${progress}%`);
              },
            });
            uploadedMediaUrl = result.url;
            setUploadProgress(100);
            console.log('[Create] Upload completed successfully');
          } catch (error) {
            console.error('[Create] Media upload failed:', error);
            // Show error to user
            Alert.alert(
              language === 'ru' ? 'Ошибка загрузки' : 'Upload Error',
              language === 'ru'
                ? 'Не удалось загрузить медиа. Попробуйте снова.'
                : 'Failed to upload media. Please try again.'
            );
            setIsUploading(false);
            return;
          }
        }

        // Create memory
        console.log('[Create] Creating memory...');
        await createMemoryMutation.mutateAsync({
          text: text.trim(),
          emotion: selectedEmotion,
          imageUrl: mediaType === 'image' ? uploadedMediaUrl : undefined,
          videoUrl: mediaType === 'video' ? uploadedMediaUrl : undefined,
          location,
          latitude,
          longitude,
        });

        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        setIsUploading(false);
        router.back();
      } catch (error) {
        console.error('[Create] Create memory failed:', error);
        setIsUploading(false);
        Alert.alert(
          language === 'ru' ? 'Ошибка' : 'Error',
          language === 'ru' ? 'Не удалось создать воспоминание' : 'Failed to create memory'
        );
      }
    }
  };

  const pickMedia = useCallback(async () => {
    if (isPickingMedia) return; // Prevent double-taps

    setIsPickingMedia(true);
    triggerHaptic();

    try {
      const { status } = await ImagePicker.getMediaLibraryPermissionsAsync();

      if (status !== 'granted') {
        const { status: newStatus } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (newStatus !== 'granted') {
          Alert.alert(t('permission.library'), t('permission.library'));
          setIsPickingMedia(false);
          return;
        }
      }

      console.log('[MediaPicker] Opening picker...');

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images', 'videos'],
        allowsEditing: false,
        allowsMultipleSelection: false,
        quality: 0.8, // Reduced from 0.9 for smaller files
        videoQuality: ImagePicker.UIImagePickerControllerQualityType.Medium, // Changed from High to Medium
        videoMaxDuration: 60, // Reduced from 120 to 60 seconds (1 minute max)
        exif: false, // Don't include EXIF data to reduce size
      });

      console.log('[MediaPicker] Result:', result);

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        console.log('[MediaPicker] Selected asset:', {
          type: asset.type,
          uri: asset.uri,
          width: asset.width,
          height: asset.height,
          fileSize: asset.fileSize,
        });

        // Check file size - warn if too large
        const MAX_SIZE = 50 * 1024 * 1024; // 50 MB
        const MAX_VIDEO_DURATION = 60000; // 60 seconds in milliseconds

        if (asset.fileSize && asset.fileSize > MAX_SIZE) {
          const sizeMB = (asset.fileSize / (1024 * 1024)).toFixed(1);
          const durationSec = asset.duration ? (asset.duration / 1000).toFixed(0) : 'N/A';

          Alert.alert(
            language === 'ru' ? '⚠️ Большой файл' : '⚠️ Large File',
            language === 'ru'
              ? `Размер: ${sizeMB} МБ${asset.duration ? `, Длина: ${durationSec}с` : ''}\n\nРекомендуется:\n• Видео до 50 МБ\n• Длительность до 60 секунд\n\nЗагрузка займёт 2-5 минут. Продолжить?`
              : `Size: ${sizeMB} MB${asset.duration ? `, Duration: ${durationSec}s` : ''}\n\nRecommended:\n• Videos under 50 MB\n• Duration under 60 seconds\n\nUpload will take 2-5 minutes. Continue?`,
            [
              {
                text: language === 'ru' ? 'Отмена' : 'Cancel',
                style: 'cancel',
                onPress: () => {
                  console.log('[MediaPicker] User cancelled large file upload');
                }
              },
              {
                text: language === 'ru' ? 'Продолжить' : 'Continue',
                onPress: () => {
                  console.log('[MediaPicker] User confirmed large file upload');
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                  setMediaUri(asset.uri);
                  setMediaType(asset.type === 'video' ? 'video' : 'image');
                }
              }
            ]
          );
        } else if (asset.duration && asset.duration > MAX_VIDEO_DURATION) {
          // Video too long warning (even if size is OK)
          const durationSec = (asset.duration / 1000).toFixed(0);
          Alert.alert(
            language === 'ru' ? 'Длинное видео' : 'Long Video',
            language === 'ru'
              ? `Видео длится ${durationSec} секунд. Рекомендуется до 60 секунд для быстрой загрузки. Продолжить?`
              : `Video is ${durationSec} seconds long. Recommended under 60 seconds for fast upload. Continue?`,
            [
              {
                text: language === 'ru' ? 'Отмена' : 'Cancel',
                style: 'cancel',
                onPress: () => {
                  console.log('[MediaPicker] User cancelled long video');
                }
              },
              {
                text: language === 'ru' ? 'Продолжить' : 'Continue',
                onPress: () => {
                  console.log('[MediaPicker] User confirmed long video');
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                  setMediaUri(asset.uri);
                  setMediaType(asset.type === 'video' ? 'video' : 'image');
                }
              }
            ]
          );
        } else {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
          setMediaUri(asset.uri);
          setMediaType(asset.type === 'video' ? 'video' : 'image');
        }
      } else {
        console.log('[MediaPicker] User cancelled or no asset selected');
      }
    } catch (error) {
      console.error('[MediaPicker] Error picking media:', error);
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Не удалось выбрать медиа. Попробуйте еще раз.' : 'Failed to pick media. Please try again.'
      );
    } finally {
      setIsPickingMedia(false);
    }
  }, [isPickingMedia, triggerHaptic, t, language]);

  const takePhoto = useCallback(async () => {
    triggerHaptic();

    try {
      const { status } = await ImagePicker.getCameraPermissionsAsync();

      if (status !== 'granted') {
        const { status: newStatus } = await ImagePicker.requestCameraPermissionsAsync();
        if (newStatus !== 'granted') {
          Alert.alert(t('permission.camera'), t('permission.cameraDesc'));
          return;
        }
      }

      console.log('[Camera] Opening camera...');

      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: false,
        quality: 0.9, // Higher quality
        exif: false,
      });

      console.log('[Camera] Result:', result);

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        console.log('[Camera] Photo taken:', {
          uri: asset.uri,
          width: asset.width,
          height: asset.height,
        });

        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        setMediaUri(asset.uri);
        setMediaType('image');
      }
    } catch (error) {
      console.error('[Camera] Error taking photo:', error);
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Не удалось сделать фото. Попробуйте еще раз.' : 'Failed to take photo. Please try again.'
      );
    }
  }, [triggerHaptic, t, language]);

  const removeMedia = () => {
    triggerHaptic();
    setMediaUri(undefined);
    setMediaType(undefined);
  };

  const addLocationData = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert(t('permission.location'), t('permission.location'));
      return;
    }

    triggerHaptic();
    const loc = await Location.getCurrentPositionAsync({});

    // Save coordinates
    setLatitude(loc.coords.latitude);
    setLongitude(loc.coords.longitude);

    const address = await Location.reverseGeocodeAsync({
      latitude: loc.coords.latitude,
      longitude: loc.coords.longitude,
    });

    if (address[0]) {
      const locationString = `${address[0].city || ''}, ${address[0].region || ''}`.trim();
      setLocation(locationString);
    }
  };

  const canSubmit = text.trim().length > 0 && selectedEmotion !== null;

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]} locations={[0, 0.7, 1]}
        style={{ flex: 1 }}
      >
        <Animated.View
          entering={FadeIn.duration(200)}
          style={{ flex: 1 }}
        >
          <View
            style={{ paddingTop: insets.top + 8, paddingBottom: insets.bottom }}
            className="flex-1"
          >
            {/* Header */}
            <View className="flex-row items-center justify-between px-4 pb-4">
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.back();
                }}
                className="w-10 h-10 items-center justify-center rounded-full active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
              <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '300' }}>
                {t('create.title')}
              </Text>
              <Pressable
                onPress={handleCreate}
                disabled={!canSubmit || isUploading}
                className="w-10 h-10 items-center justify-center rounded-full"
                style={{
                  backgroundColor: canSubmit && !isUploading ? theme.colors.accent : 'rgba(255, 255, 255, 0.05)'
                }}
              >
                {isUploading ? (
                  <ActivityIndicator size="small" color={theme.colors.primary} />
                ) : (
                  <Send
                    size={18}
                    color={canSubmit ? theme.colors.primary : `${theme.colors.textSecondary}4D`}
                    strokeWidth={1.5}
                  />
                )}
              </Pressable>
            </View>

            {/* Content with KeyboardAvoidingView */}
            <KeyboardAvoidingView
              behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
              style={{ flex: 1 }}
              keyboardVerticalOffset={insets.top + 60}
            >
              <ScrollView
                className="flex-1 px-4"
                keyboardDismissMode="interactive"
                showsVerticalScrollIndicator={false}
                contentContainerStyle={{ paddingBottom: 20 }}
              >
                {/* Text Input */}
                <Animated.View entering={FadeIn.duration(200)}>
                  <TextInput
                    value={text}
                    onChangeText={setText}
                    placeholder={t('create.placeholder')}
                    placeholderTextColor="rgba(245, 242, 237, 0.25)"
                    multiline
                    autoFocus
                    className="text-lg font-light leading-7 min-h-[160px] py-4"
                    style={{ color: theme.colors.text }}
                    textAlignVertical="top"
                  />
                </Animated.View>

                {/* Media Preview */}
                {mediaUri && (
                  <Animated.View
                    entering={FadeIn.duration(300)}
                    className="mb-6"
                  >
                    <View className="rounded-2xl overflow-hidden relative">
                      {mediaType === 'video' ? (
                        <View>
                          <CustomVideoPlayer
                            uri={mediaUri}
                            aspectRatio={imageAspectRatio || 9 / 16}
                            resizeMode={ResizeMode.COVER}
                          />
                          <View
                            className="absolute top-3 right-3 w-10 h-10 rounded-full bg-forest/80 items-center justify-center"
                          >
                            <Play size={20} color="#E8D5B7" fill="#E8D5B7" strokeWidth={0} />
                          </View>
                        </View>
                      ) : (
                        <Image
                          source={{ uri: mediaUri }}
                          style={{ width: '100%', aspectRatio: imageAspectRatio || 4 / 5, borderRadius: 16 }}
                          resizeMode="cover"
                        />
                      )}
                      {/* Remove button */}
                      <Pressable
                        onPress={removeMedia}
                        className="absolute top-3 left-3 w-10 h-10 rounded-full bg-forest/80 items-center justify-center active:bg-forest"
                      >
                        <Trash2 size={18} color="#E8D5B7" strokeWidth={1.5} />
                      </Pressable>
                    </View>

                    {/* Upload Progress */}
                    {isUploading && uploadProgress > 0 && (
                      <Animated.View entering={FadeIn.duration(200)} className="mt-4 px-4 py-4 rounded-2xl" style={{ backgroundColor: `${theme.colors.accent}10` }}>
                        <View className="flex-row items-center justify-between mb-3">
                          <Text style={{ color: theme.colors.text, fontSize: 15, fontWeight: '600' }}>
                            {language === 'ru' ? 'Загрузка видео...' : 'Uploading video...'}
                          </Text>
                          <Text style={{ color: theme.colors.accent, fontSize: 15, fontWeight: '700' }}>
                            {uploadProgress}%
                          </Text>
                        </View>
                        <View
                          className="h-2 rounded-full overflow-hidden"
                          style={{ backgroundColor: `${theme.colors.accent}20` }}
                        >
                          <Animated.View
                            className="h-full rounded-full"
                            style={{
                              backgroundColor: theme.colors.accent,
                              width: `${uploadProgress}%`,
                            }}
                          />
                        </View>
                        {uploadProgress < 100 && (
                          <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginTop: 8 }}>
                            {language === 'ru'
                              ? 'Пожалуйста, не закрывайте экран...'
                              : 'Please don\'t close the screen...'}
                          </Text>
                        )}
                      </Animated.View>
                    )}
                  </Animated.View>
                )}

                {/* Media Buttons */}
                <Animated.View
                  entering={FadeIn.duration(200)}
                  className="flex-row mb-6"
                  style={{ gap: 10 }}
                >
                  <Pressable
                    onPress={pickMedia}
                    disabled={isPickingMedia}
                    className="flex-1 rounded-xl py-3 flex-row items-center justify-center active:opacity-80"
                    style={{ backgroundColor: `${theme.colors.accent}20`, opacity: isPickingMedia ? 0.5 : 1 }}
                  >
                    {isPickingMedia ? (
                      <ActivityIndicator size="small" color={theme.colors.accent} />
                    ) : (
                      <>
                        <ImageIcon size={18} color={theme.colors.accent} strokeWidth={1.5} />
                        <Text style={{ color: theme.colors.accent, fontSize: 14, marginLeft: 8 }}>
                          {t('create.gallery')}
                        </Text>
                      </>
                    )}
                  </Pressable>
                  <Pressable
                    onPress={takePhoto}
                    className="flex-1 rounded-xl py-3 flex-row items-center justify-center active:opacity-80"
                    style={{ backgroundColor: `${theme.colors.accent}20` }}
                  >
                    <Camera size={18} color={theme.colors.accent} strokeWidth={1.5} />
                    <Text style={{ color: theme.colors.accent, fontSize: 14, marginLeft: 8 }}>
                      {t('create.camera')}
                    </Text>
                  </Pressable>
                  <Pressable
                    onPress={addLocationData}
                    className="flex-1 rounded-xl py-3 flex-row items-center justify-center active:opacity-80"
                    style={{ backgroundColor: `${theme.colors.accent}20` }}
                  >
                    <MapPin size={18} color={theme.colors.accent} strokeWidth={1.5} />
                    <Text style={{ color: theme.colors.accent, fontSize: 14, marginLeft: 8 }}>
                      {t('create.location')}
                    </Text>
                  </Pressable>
                </Animated.View>

                {location && (
                  <Animated.View entering={FadeIn.duration(300)} className="mb-4">
                    <Text className="text-sand/60 text-xs">📍 {location}</Text>
                  </Animated.View>
                )}

                {/* Emotion Picker */}
                <Animated.View entering={FadeIn.duration(200)}>
                  <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 14, marginBottom: 12 }}>
                    {t('create.emotion')}
                  </Text>
                  <View className="flex-row flex-wrap" style={{ gap: 8 }}>
                    {EMOTIONS.map((emotion) => (
                      <AnimatedPressable
                        key={emotion.key}
                        onPress={() => {
                          triggerHaptic();
                          setSelectedEmotion(emotion.key);
                        }}
                        className="px-3 py-2.5 rounded-xl flex-row items-center"
                        style={{
                          backgroundColor: selectedEmotion === emotion.key
                            ? theme.colors.accent
                            : `${theme.colors.accent}20`
                        }}
                      >
                        <Text className="mr-1.5 text-sm">{emotion.icon}</Text>
                        <Text
                          className="text-xs font-medium"
                          style={{
                            color: selectedEmotion === emotion.key
                              ? theme.colors.primary
                              : theme.colors.accent
                          }}
                        >
                          {emotion.label}
                        </Text>
                      </AnimatedPressable>
                    ))}
                  </View>
                </Animated.View>
              </ScrollView>
            </KeyboardAvoidingView>
          </View>
        </Animated.View>
      </LinearGradient>
    </View>
  );
}
