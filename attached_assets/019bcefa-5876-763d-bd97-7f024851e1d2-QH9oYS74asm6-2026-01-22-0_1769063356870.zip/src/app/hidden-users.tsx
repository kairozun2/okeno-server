import React from 'react';
import { View, Text, ScrollView, Pressable, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X, Eye, UserX } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import * as Haptics from 'expo-haptics';
import { useHiddenUsers, useUnhideUser } from '@/lib/supabase-hooks';

export default function HiddenUsersScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { data: hiddenUsers = [], isLoading } = useHiddenUsers();
  const unhideUserMutation = useUnhideUser();

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleUnhide = (userId: string) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    unhideUserMutation.mutate(userId);
  };

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
        locations={[0, 0.7, 1]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 8,
            paddingHorizontal: 20,
            paddingBottom: 12,
            borderBottomWidth: 1,
            borderBottomColor: `${theme.colors.text}10`,
          }}
        >
          <Animated.View entering={FadeIn.duration(200)} className="flex-row items-center justify-between">
            <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '600' }}>
              {language === 'ru' ? 'Скрытые пользователи' : 'Hidden Users'}
            </Text>
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{ backgroundColor: `${theme.colors.accent}20` }}
            >
              <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>
          </Animated.View>
        </View>

        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingTop: 20, paddingBottom: insets.bottom + 40 }}
        >
          {isLoading ? (
            <View className="flex-1 items-center justify-center py-20">
              <ActivityIndicator size="large" color={theme.colors.accent} />
            </View>
          ) : hiddenUsers.length === 0 ? (
            <Animated.View
              entering={FadeIn.duration(300).delay(100)}
              className="items-center py-12 px-8"
            >
              <UserX size={48} color={`${theme.colors.textSecondary}40`} strokeWidth={1.5} />
              <Text style={{ color: `${theme.colors.textSecondary}66`, textAlign: 'center', fontSize: 14, marginTop: 16 }}>
                {language === 'ru' ? 'Нет скрытых пользователей' : 'No hidden users'}
              </Text>
              <Text style={{ color: `${theme.colors.textSecondary}40`, textAlign: 'center', fontSize: 12, marginTop: 8 }}>
                {language === 'ru'
                  ? 'Вы можете скрыть пользователя из управления чатами'
                  : 'You can hide users from the chat management'}
              </Text>
            </Animated.View>
          ) : (
            <Animated.View
              entering={FadeIn.duration(300).delay(100)}
              className="mx-5"
            >
              <View className="rounded-2xl overflow-hidden" style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}>
                {hiddenUsers.map((item: any, index: number) => {
                  const profile = item.profile;
                  const avatarEmoji = profile?.avatar_emoji || '👤';
                  const username = profile?.username || 'Unknown';

                  return (
                    <View
                      key={item.hidden_user_id}
                      className="flex-row items-center justify-between px-4 py-4"
                      style={{
                        borderBottomWidth: index < hiddenUsers.length - 1 ? 1 : 0,
                        borderBottomColor: `${theme.colors.text}0D`,
                      }}
                    >
                      <View className="flex-row items-center flex-1">
                        <Text className="text-3xl mr-3">{avatarEmoji}</Text>
                        <View className="flex-1">
                          <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                            {username}
                          </Text>
                          <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                            {language === 'ru' ? 'Скрытые посты не отображаются' : 'Posts are hidden'}
                          </Text>
                        </View>
                      </View>
                      <Pressable
                        onPress={() => handleUnhide(item.hidden_user_id)}
                        disabled={unhideUserMutation.isPending}
                        className="px-4 py-2 rounded-full active:opacity-70"
                        style={{ backgroundColor: theme.colors.accent }}
                      >
                        <View className="flex-row items-center" style={{ gap: 6 }}>
                          <Eye size={16} color={theme.colors.primary} strokeWidth={2} />
                          <Text style={{ color: theme.colors.primary, fontSize: 13, fontWeight: '600' }}>
                            {language === 'ru' ? 'Показать' : 'Unhide'}
                          </Text>
                        </View>
                      </Pressable>
                    </View>
                  );
                })}
              </View>
            </Animated.View>
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}
