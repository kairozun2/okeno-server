import React, { useState } from 'react';
import { View, Text, Pressable, ScrollView, Alert, ActivityIndicator, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { ChevronLeft, Smartphone, Tablet, Monitor, X } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import * as Device from 'expo-device';
import Constants from 'expo-constants';

interface Session {
  id: string;
  deviceName: string;
  deviceType: 'phone' | 'tablet' | 'desktop';
  platform: string;
  lastActive: string;
  ipAddress?: string;
  isCurrent: boolean;
}

export default function ActiveSessionsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [isLoading, setIsLoading] = useState(false);

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Get current device info
  const getCurrentDeviceInfo = (): Session => {
    const deviceType = Device.deviceType;
    let type: 'phone' | 'tablet' | 'desktop' = 'phone';

    if (deviceType === Device.DeviceType.TABLET) {
      type = 'tablet';
    } else if (deviceType === Device.DeviceType.DESKTOP) {
      type = 'desktop';
    }

    return {
      id: Constants.sessionId || 'current',
      deviceName: Device.modelName || Device.deviceName || 'Unknown Device',
      deviceType: type,
      platform: `${Platform.OS} ${Platform.Version}`,
      lastActive: new Date().toISOString(),
      isCurrent: true,
    };
  };

  // Mock sessions - in real app, fetch from Supabase
  const [sessions] = useState<Session[]>([
    getCurrentDeviceInfo(),
    // Add more sessions from database here
  ]);

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case 'phone':
        return Smartphone;
      case 'tablet':
        return Tablet;
      case 'desktop':
        return Monitor;
      default:
        return Smartphone;
    }
  };

  const formatLastActive = (isoDate: string) => {
    const date = new Date(isoDate);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) {
      return language === 'ru' ? 'Только что' : 'Just now';
    } else if (diffMins < 60) {
      return language === 'ru' ? `${diffMins} мин. назад` : `${diffMins} min ago`;
    } else if (diffHours < 24) {
      return language === 'ru' ? `${diffHours} ч. назад` : `${diffHours}h ago`;
    } else {
      return language === 'ru' ? `${diffDays} дн. назад` : `${diffDays}d ago`;
    }
  };

  const terminateSession = (sessionId: string) => {
    triggerHaptic();
    Alert.alert(
      language === 'ru' ? 'Завершить сеанс?' : 'Terminate Session?',
      language === 'ru'
        ? 'Это устройство будет отключено и потребуется повторный вход.'
        : 'This device will be logged out and will require re-authentication.',
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
        },
        {
          text: language === 'ru' ? 'Завершить' : 'Terminate',
          style: 'destructive',
          onPress: async () => {
            setIsLoading(true);
            try {
              // TODO: Call Supabase to terminate session
              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
              Alert.alert(
                language === 'ru' ? 'Готово' : 'Done',
                language === 'ru' ? 'Сеанс завершён' : 'Session terminated'
              );
            } catch (error) {
              console.error('[Sessions] Error terminating session:', error);
              Alert.alert(
                language === 'ru' ? 'Ошибка' : 'Error',
                language === 'ru' ? 'Не удалось завершить сеанс' : 'Failed to terminate session'
              );
            } finally {
              setIsLoading(false);
            }
          },
        },
      ]
    );
  };

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={{ paddingTop: insets.top + 8 }} className="px-5 pb-6">
          <Animated.View
            entering={FadeIn.duration(300)}
            className="flex-row items-center justify-between"
          >
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{ backgroundColor: `${theme.colors.accent}20` }}
            >
              <ChevronLeft size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>

            <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500', position: 'absolute', left: 0, right: 0, textAlign: 'center', zIndex: -1 }}>
              {language === 'ru' ? 'Активные сеансы' : 'Active Sessions'}
            </Text>

            <View className="w-10" />
          </Animated.View>
        </View>

        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 40 }}
        >
          {/* Info Banner */}
          <Animated.View
            entering={FadeIn.duration(400).delay(200)}
            className="mb-6 p-4 rounded-2xl"
            style={{ backgroundColor: `${theme.colors.accent}15` }}
          >
            <Text style={{ color: theme.colors.textSecondary, fontSize: 14, lineHeight: 20, textAlign: 'center' }}>
              {language === 'ru'
                ? 'Управляйте устройствами, с которых выполнен вход в ваш аккаунт'
                : 'Manage devices that are logged into your account'}
            </Text>
          </Animated.View>

          {/* Sessions List */}
          {sessions.map((session, index) => {
            const DeviceIcon = getDeviceIcon(session.deviceType);

            return (
              <Animated.View
                key={session.id}
                entering={FadeInDown.duration(300).delay(300 + index * 100)}
                className="mb-4 rounded-2xl overflow-hidden"
                style={{ backgroundColor: `${theme.colors.accent}10` }}
              >
                <View className="p-5">
                  {/* Device Header */}
                  <View className="flex-row items-start justify-between mb-4">
                    <View className="flex-row items-center flex-1">
                      <View
                        className="w-12 h-12 rounded-2xl items-center justify-center mr-4"
                        style={{ backgroundColor: theme.colors.accent }}
                      >
                        <DeviceIcon size={24} color={theme.colors.primary} strokeWidth={1.5} />
                      </View>
                      <View className="flex-1">
                        <View className="flex-row items-center">
                          <Text style={{ color: theme.colors.text, fontSize: 17, fontWeight: '600' }}>
                            {session.deviceName}
                          </Text>
                          {session.isCurrent && (
                            <View
                              className="ml-2 px-2 py-1 rounded-full"
                              style={{ backgroundColor: `${theme.colors.accent}30` }}
                            >
                              <Text style={{ color: theme.colors.accent, fontSize: 11, fontWeight: '600' }}>
                                {language === 'ru' ? 'ТЕКУЩИЙ' : 'CURRENT'}
                              </Text>
                            </View>
                          )}
                        </View>
                        <Text style={{ color: theme.colors.textSecondary, fontSize: 14, marginTop: 2 }}>
                          {session.platform}
                        </Text>
                      </View>
                    </View>

                    {/* Terminate Button */}
                    {!session.isCurrent && (
                      <Pressable
                        onPress={() => terminateSession(session.id)}
                        disabled={isLoading}
                        className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                        style={{ backgroundColor: '#FF3B3020' }}
                      >
                        {isLoading ? (
                          <ActivityIndicator size="small" color="#FF3B30" />
                        ) : (
                          <X size={18} color="#FF3B30" strokeWidth={2} />
                        )}
                      </Pressable>
                    )}
                  </View>

                  {/* Last Active */}
                  <View className="flex-row items-center justify-between pt-4 border-t" style={{ borderTopColor: `${theme.colors.text}10` }}>
                    <Text style={{ color: theme.colors.textSecondary, fontSize: 13 }}>
                      {language === 'ru' ? 'Последняя активность' : 'Last active'}
                    </Text>
                    <Text style={{ color: theme.colors.text, fontSize: 13, fontWeight: '500' }}>
                      {formatLastActive(session.lastActive)}
                    </Text>
                  </View>

                  {session.ipAddress && (
                    <View className="flex-row items-center justify-between pt-2">
                      <Text style={{ color: theme.colors.textSecondary, fontSize: 13 }}>
                        IP
                      </Text>
                      <Text style={{ color: theme.colors.text, fontSize: 13, fontWeight: '500' }}>
                        {session.ipAddress}
                      </Text>
                    </View>
                  )}
                </View>
              </Animated.View>
            );
          })}

          {/* Terminate All Button */}
          {sessions.length > 1 && (
            <Animated.View
              entering={FadeInDown.duration(400).delay(300 + sessions.length * 100)}
              className="mt-4"
            >
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  Alert.alert(
                    language === 'ru' ? 'Завершить все сеансы?' : 'Terminate All Sessions?',
                    language === 'ru'
                      ? 'Все остальные устройства будут отключены, кроме текущего.'
                      : 'All other devices will be logged out except the current one.',
                    [
                      {
                        text: language === 'ru' ? 'Отмена' : 'Cancel',
                        style: 'cancel',
                      },
                      {
                        text: language === 'ru' ? 'Завершить все' : 'Terminate All',
                        style: 'destructive',
                        onPress: () => {
                          // TODO: Implement terminate all
                          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
                        },
                      },
                    ]
                  );
                }}
                disabled={isLoading}
                className="rounded-2xl overflow-hidden active:opacity-80"
                style={{ backgroundColor: '#FF3B30' }}
              >
                <View className="py-5 flex-row items-center justify-center">
                  <X size={20} color="#FFFFFF" strokeWidth={2} />
                  <Text style={{ color: '#FFFFFF', fontSize: 17, fontWeight: '600', marginLeft: 10 }}>
                    {language === 'ru' ? 'Завершить все сеансы' : 'Terminate All Sessions'}
                  </Text>
                </View>
              </Pressable>
            </Animated.View>
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}
