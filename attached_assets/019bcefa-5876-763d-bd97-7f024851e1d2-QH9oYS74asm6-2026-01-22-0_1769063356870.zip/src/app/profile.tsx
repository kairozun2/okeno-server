import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, Platform, Image, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import Animated, { FadeIn, useAnimatedScrollHandler, useSharedValue, useAnimatedStyle, interpolate, Extrapolate, withTiming } from 'react-native-reanimated';
import { ChevronLeft, Settings, Play, QrCode, Shield } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { useAppStore, EMOTIONS } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { generateAvatarFromPattern } from '@/lib/avatar';
import { CustomVideoPlayer } from '@/components/CustomVideoPlayer';
import { QRCodeModal } from '@/components/QRCodeModal';
import { MediaViewerModal } from '@/components/MediaViewerModal';
import { ProfileGridSkeleton } from '@/components/ProfileGridSkeleton';
import { cn } from '@/lib/cn';
import { useMyMemories, useSavedMemories, useAuth, useIsAdmin } from '@/lib/supabase-hooks';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ColoredUsername } from '@/components/ColoredUsername';
import { EditSocialLinksModal } from '@/components/EditSocialLinksModal';
import { SocialIcons } from '@/components/SocialIcons';

type ProfileTab = 'all' | 'saved';

const AnimatedScrollView = Animated.createAnimatedComponent(ScrollView);
const { width } = Dimensions.get('window');
const GRID_ITEM_SIZE = (width - 6) / 3; // 3 columns with 2px gaps

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<ProfileTab>('all');
  const [showArchived, setShowArchived] = useState(false);
  const [showQRModal, setShowQRModal] = useState(false);
  const [showMediaViewer, setShowMediaViewer] = useState(false);
  const [selectedMedia, setSelectedMedia] = useState<{ url: string; isVideo: boolean } | null>(null);
  const [showSocialLinksModal, setShowSocialLinksModal] = useState(false);
  const scrollY = useSharedValue(0);

  // Use Supabase hooks for data
  const { data: auth } = useAuth();
  const isAdmin = useIsAdmin();
  const { data: myMemoriesData = [], isLoading: isLoadingMyMemories, isFetching: isFetchingMyMemories } = useMyMemories();
  const { data: savedMemoriesData = [], isLoading: isLoadingSaved, isFetching: isFetchingSaved } = useSavedMemories();

  const localUserName = useAppStore(s => s.userName);
  const userName = auth?.profile?.username || localUserName;
  const userId = auth?.profile?.id || '';
  // Use avatar from Supabase profile
  const avatar = auth?.profile?.avatar_emoji || '👤';

  // Filter memories from Supabase - CRITICAL: Use useMemo to prevent re-creating arrays
  const myMemories = React.useMemo(() =>
    myMemoriesData.filter(m => !m.isArchived),
    [myMemoriesData]
  );
  const savedMemories = React.useMemo(() =>
    savedMemoriesData.filter(m => !m.isArchived),
    [savedMemoriesData]
  );
  const archivedMemories = React.useMemo(() =>
    myMemoriesData.filter(m => m.isArchived),
    [myMemoriesData]
  );

  // Prefetch all images when component mounts for instant display
  React.useEffect(() => {
    const allMemories = [...myMemories, ...savedMemories];
    const imagesToPrefetch = allMemories
      .filter(m => m.imageUrl || m.videoUrl)
      .map(m => m.videoUrl || m.imageUrl)
      .filter(Boolean) as string[];

    // Prefetch ALL images INSTANTLY without delays for maximum performance
    console.log('[Profile] Prefetching', imagesToPrefetch.length, 'images');
    imagesToPrefetch.forEach((url) => {
      Image.prefetch(url).catch((error) => {
        console.log('[Profile] Prefetch error for', url, error);
      });
    });
  }, [myMemories.length, savedMemories.length]);

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  // Local haptic function that checks settings
  const triggerHaptic = (style: Haptics.ImpactFeedbackStyle = Haptics.ImpactFeedbackStyle.Light) => {
    if (hapticsEnabled) {
      Haptics.impactAsync(style);
    }
  };

  const totalEchoes = myMemories.reduce((sum, m) => sum + m.echoCount, 0);

  const displayedMemories = React.useMemo(() => {
    if (showArchived) return archivedMemories;
    if (activeTab === 'saved') return savedMemories;
    return myMemories;
  }, [activeTab, showArchived, myMemories, savedMemories, archivedMemories]);

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  // Animated blur header opacity - appears on scroll
  const headerBlurStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 60],
      [0, 1],
      Extrapolate.CLAMP
    );

    return {
      opacity,
    };
  });

  // Animated avatar in header - appears on scroll
  const headerAvatarStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [60, 100],
      [0, 1],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollY.value,
      [60, 100],
      [0.5, 1],
      Extrapolate.CLAMP
    );

    return {
      opacity,
      transform: [{ scale }],
    };
  });

  // Hide main avatar on scroll
  const mainAvatarStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 80],
      [1, 0],
      Extrapolate.CLAMP
    );

    return {
      opacity,
    };
  });

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        <AnimatedScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
          onScroll={scrollHandler}
          scrollEventThrottle={16}
        >
          {/* Content starts with top padding */}
          <View style={{ paddingTop: insets.top + 60 }}>
            {/* Avatar + Name - No container, minimal */}
            <Animated.View
              entering={FadeIn.duration(300)}
              style={mainAvatarStyle}
              className="items-center px-5 mb-8"
            >
              <Pressable
                onLongPress={() => {
                  triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
                  setShowSocialLinksModal(true);
                }}
                delayLongPress={500}
              >
                <Text className="text-7xl mb-4">{avatar}</Text>
              </Pressable>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <ColoredUsername
                  username={userName || t('profile.anonymous')}
                  color={auth?.profile?.username_color}
                  size={24}
                  weight="600"
                  defaultColor={theme.colors.text}
                />
                <VerifiedBadge isVerified={auth?.profile?.is_verified === true} size={20} checkColor={theme.colors.primary} />
                <SocialIcons socialLinks={auth?.profile?.social_links || []} size={18} gap={8} />
              </View>
            </Animated.View>

            {/* Stats - Simple, flat */}
            <Animated.View
              entering={FadeIn.duration(300)}
              className="flex-row justify-center mb-8"
              style={{ gap: 40 }}
            >
              <View className="items-center">
                <Text style={{ color: theme.colors.text, fontSize: 20, fontWeight: '300' }}>{myMemories.length}</Text>
                <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 4 }}>{t('profile.memories')}</Text>
              </View>
              <View className="items-center">
                <Text style={{ color: theme.colors.text, fontSize: 20, fontWeight: '300' }}>{totalEchoes}</Text>
                <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 4 }}>{t('profile.echoes')}</Text>
              </View>
              <View className="items-center">
                <Text style={{ color: theme.colors.text, fontSize: 20, fontWeight: '300' }}>{savedMemories.length}</Text>
                <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 4 }}>{t('profile.saved')}</Text>
              </View>
            </Animated.View>

            {/* Segment Control - Native iOS style (2 buttons only) */}
            <Animated.View
              entering={FadeIn.duration(300)}
              className="mx-5 mb-6"
            >
              <View className="rounded-xl p-1 flex-row" style={{ backgroundColor: `${theme.colors.accent}20` }}>
                <Pressable
                  onPress={() => {
                    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                    setActiveTab('all');
                    setShowArchived(false);
                  }}
                  className={cn('flex-1 py-2 rounded-lg items-center')}
                  style={{
                    backgroundColor: activeTab === 'all' && !showArchived ? theme.colors.accent : 'transparent'
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: '500',
                      color: activeTab === 'all' && !showArchived ? theme.colors.primary : `${theme.colors.textSecondary}80`
                    }}
                  >
                    {t('profile.all')}
                  </Text>
                </Pressable>
                <Pressable
                  onPress={() => {
                    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                    setActiveTab('saved');
                    setShowArchived(false);
                  }}
                  className={cn('flex-1 py-2 rounded-lg items-center')}
                  style={{
                    backgroundColor: activeTab === 'saved' && !showArchived ? theme.colors.accent : 'transparent'
                  }}
                >
                  <Text
                    style={{
                      fontSize: 14,
                      fontWeight: '500',
                      color: activeTab === 'saved' && !showArchived ? theme.colors.primary : `${theme.colors.textSecondary}80`
                    }}
                  >
                    {t('profile.saved')}
                  </Text>
                </Pressable>
              </View>
            </Animated.View>

            {/* Archive indicator - shows when swiped */}
            {showArchived && (
              <Animated.View
                entering={FadeIn.duration(200)}
                className="mx-5 mb-4 flex-row items-center justify-between"
              >
                <View className="flex-1 px-4 py-2 rounded-full" style={{ backgroundColor: `${theme.colors.accent}30` }}>
                  <Text style={{ color: theme.colors.text, fontSize: 14, fontWeight: '500', textAlign: 'center' }}>
                    {language === 'ru' ? '📦 Архив' : '📦 Archived'}
                  </Text>
                </View>
                <Pressable
                  onPress={() => {
                    setShowArchived(false);
                    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                  }}
                  className="ml-2 px-3 py-2 rounded-full"
                  style={{ backgroundColor: `${theme.colors.accent}20` }}
                >
                  <Text style={{ color: theme.colors.textSecondary, fontSize: 12 }}>
                    {language === 'ru' ? 'Закрыть' : 'Close'}
                  </Text>
                </Pressable>
              </Animated.View>
            )}

            {/* Memories Grid - Instagram style */}
            <View className="flex-row flex-wrap" style={{ gap: 2 }}>
              {((isLoadingMyMemories && activeTab === 'all' && displayedMemories.length === 0) || (isLoadingSaved && activeTab === 'saved' && displayedMemories.length === 0)) ? (
                // Show skeleton ONLY on first load when there's no cached data
                <ProfileGridSkeleton count={12} backgroundColor={`${theme.colors.accent}15`} />
              ) : displayedMemories.length > 0 ? (
                displayedMemories.map((memory) => {
                  const emotion = EMOTIONS.find(e => e.key === memory.emotion);
                  const isVideo = memory.imageUrl && (
                    memory.imageUrl.endsWith('.mp4') ||
                    memory.imageUrl.endsWith('.mov') ||
                    memory.imageUrl.endsWith('.m4v') ||
                    memory.imageUrl.includes('video')
                  );

                  return (
                    <View key={memory.id}>
                      <Pressable
                        onPress={() => {
                          triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                          router.push(`/memory-detail?id=${memory.id}`);
                        }}
                        onLongPress={() => {
                          // Long press opens fullscreen media viewer (only if there's media)
                          if (memory.imageUrl || memory.videoUrl) {
                            triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                            const isVideo = memory.videoUrl || (
                              memory.imageUrl && (
                                memory.imageUrl.endsWith('.mp4') ||
                                memory.imageUrl.endsWith('.mov') ||
                                memory.imageUrl.endsWith('.m4v') ||
                                memory.imageUrl.includes('video')
                              )
                            );
                            setSelectedMedia({
                              url: memory.videoUrl || memory.imageUrl || '',
                              isVideo: !!isVideo,
                            });
                            setShowMediaViewer(true);
                          }
                        }}
                        className="relative active:opacity-80"
                        style={{
                          width: GRID_ITEM_SIZE,
                          height: GRID_ITEM_SIZE,
                        }}
                      >
                        {memory.imageUrl ? (
                          isVideo ? (
                            <>
                              <CustomVideoPlayer
                                uri={memory.imageUrl}
                                width={GRID_ITEM_SIZE}
                                height={GRID_ITEM_SIZE}
                                isVisible={false}
                                autoPlay={false}
                              />
                              {/* Video play indicator */}
                              <View
                                className="absolute inset-0 items-center justify-center"
                                style={{ backgroundColor: 'rgba(0, 0, 0, 0.2)' }}
                              >
                                <View
                                  className="w-10 h-10 rounded-full items-center justify-center"
                                  style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)' }}
                                >
                                  <Play size={20} color="#000" fill="#000" />
                                </View>
                              </View>
                            </>
                          ) : (
                            <Image
                              source={{ uri: memory.imageUrl }}
                              style={{
                                width: '100%',
                                height: '100%',
                              }}
                              resizeMode="cover"
                              progressiveRenderingEnabled={true}
                              fadeDuration={0}
                            />
                          )
                        ) : (
                          <LinearGradient
                            colors={[`${theme.colors.accent}30`, `${theme.colors.accent}15`]}
                            style={{
                              width: '100%',
                              height: '100%',
                              justifyContent: 'center',
                              alignItems: 'center',
                              padding: 12,
                            }}
                          >
                            <Text
                              style={{
                                color: theme.colors.text,
                                fontSize: 12,
                                lineHeight: 16,
                                textAlign: 'center',
                              }}
                              numberOfLines={6}
                            >
                              {memory.text}
                            </Text>
                          </LinearGradient>
                        )}

                        {/* Emotion indicator overlay */}
                        <View
                          className="absolute bottom-1 right-1 rounded-full px-1.5 py-0.5"
                          style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
                        >
                          <Text style={{ fontSize: 10 }}>{emotion?.icon}</Text>
                        </View>

                        {/* Echo count overlay */}
                        {memory.echoCount > 0 && (
                          <View
                            className="absolute top-1 right-1 rounded-full px-1.5 py-0.5"
                            style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
                          >
                            <Text style={{ color: '#fff', fontSize: 10, fontWeight: '600' }}>
                              {memory.echoCount}
                            </Text>
                          </View>
                        )}
                      </Pressable>
                    </View>
                  );
                })
              ) : (
                <Animated.View
                  entering={FadeIn.duration(300)}
                  className="items-center py-12 px-8"
                  style={{ width: '100%' }}
                >
                  <Text style={{ color: `${theme.colors.textSecondary}66`, textAlign: 'center', fontSize: 14 }}>
                    {activeTab === 'saved'
                      ? t('profile.noSaved')
                      : t('profile.noMemories')}
                  </Text>
                </Animated.View>
              )}
            </View>
          </View>
        </AnimatedScrollView>

        {/* Fixed Header with Blur - appears on scroll */}
        <Animated.View
          style={[
            {
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              zIndex: 100,
            },
            headerBlurStyle,
          ]}
          pointerEvents="none"
        >
          {Platform.OS === 'ios' ? (
            <BlurView
              intensity={40}
              tint="dark"
              style={{
                paddingTop: insets.top + 8,
                paddingBottom: 12,
                paddingHorizontal: 20,
                backgroundColor: `${theme.colors.primary}CC`,
              }}
            >
              <View style={{ height: 40 }} />
            </BlurView>
          ) : (
            <View
              style={{
                paddingTop: insets.top + 8,
                paddingBottom: 12,
                paddingHorizontal: 20,
                backgroundColor: `${theme.colors.primary}F0`,
              }}
            >
              <View style={{ height: 40 }} />
            </View>
          )}
        </Animated.View>

        {/* Animated Avatar in Header */}
        <Animated.View
          style={[
            {
              position: 'absolute',
              top: insets.top + 8,
              left: 0,
              right: 0,
              zIndex: 102,
              alignItems: 'center',
              justifyContent: 'center',
              height: 40,
            },
            headerAvatarStyle,
          ]}
          pointerEvents="none"
        >
          <Text style={{ fontSize: 28, lineHeight: 32 }}>{avatar}</Text>
        </Animated.View>

        {/* Fixed Buttons - Always visible */}
        <View
          style={{
            position: 'absolute',
            top: insets.top + 8,
            left: 0,
            right: 0,
            zIndex: 101,
            paddingHorizontal: 20,
          }}
        >
          <Animated.View
            entering={FadeIn.duration(300)}
            className="flex-row items-center justify-between"
          >
            <Pressable
              onPress={() => {
                triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                router.back();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{
                backgroundColor: `${theme.colors.accent}20`,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
              }}
            >
              <ChevronLeft size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>
            <View style={{ flexDirection: 'row', gap: 8 }}>
              <Pressable
                onPress={() => {
                  triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                  setShowQRModal(true);
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{
                  backgroundColor: `${theme.colors.accent}20`,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                }}
              >
                <QrCode size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>

              {/* Admin Panel Button (only for admins) */}
              {isAdmin && (
                <Pressable
                  onPress={() => {
                    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
                    router.push('/admin');
                  }}
                  className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                  style={{
                    backgroundColor: `${theme.colors.accent}20`,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.1,
                    shadowRadius: 4,
                  }}
                >
                  <Shield size={20} color={theme.colors.accent} strokeWidth={1.5} fill={theme.colors.accent} />
                </Pressable>
              )}

              <Pressable
                onPress={() => {
                  triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                  router.push('/settings');
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{
                  backgroundColor: `${theme.colors.accent}20`,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                }}
              >
                <Settings size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </View>
          </Animated.View>
        </View>

        {/* QR Code Modal */}
        <QRCodeModal
          visible={showQRModal}
          onClose={() => setShowQRModal(false)}
          onScan={() => {
            setShowQRModal(false);
            router.push('/qr-scanner');
          }}
        />

        {/* Media Viewer Modal */}
        {selectedMedia && (
          <MediaViewerModal
            visible={showMediaViewer}
            onClose={() => {
              setShowMediaViewer(false);
              setSelectedMedia(null);
            }}
            mediaUrl={selectedMedia.url}
            isVideo={selectedMedia.isVideo}
          />
        )}

        {/* Social Links Modal */}
        <EditSocialLinksModal
          visible={showSocialLinksModal}
          onClose={() => setShowSocialLinksModal(false)}
          currentLinks={auth?.profile?.social_links || []}
          userId={userId}
        />
      </LinearGradient>
    </View>
  );
}
