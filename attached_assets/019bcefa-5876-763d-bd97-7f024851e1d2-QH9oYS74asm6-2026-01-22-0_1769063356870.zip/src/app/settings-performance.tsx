import React from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X, Zap, Scale, Sparkles } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useSettingsStore, PerformanceMode } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import * as Haptics from 'expo-haptics';

export default function PerformanceSettingsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const performanceMode = useSettingsStore(s => s.performanceMode);
  const setPerformanceMode = useSettingsStore(s => s.setPerformanceMode);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const performanceModes: Array<{
    key: PerformanceMode;
    icon: typeof Zap;
    title: { en: string; ru: string; [key: string]: string };
    description: { en: string; ru: string; [key: string]: string };
  }> = [
    {
      key: 'high-performance',
      icon: Zap,
      title: { en: 'High Performance', ru: 'Макс. производ.' },
      description: {
        en: 'Reduced animations',
        ru: 'Меньше анимаций',
      },
    },
    {
      key: 'balanced',
      icon: Scale,
      title: { en: 'Balanced', ru: 'Сбалансированный' },
      description: {
        en: 'Best for most devices',
        ru: 'Для большинства',
      },
    },
    {
      key: 'quality',
      icon: Sparkles,
      title: { en: 'Maximum Quality', ru: 'Макс. качество' },
      description: {
        en: 'All effects enabled',
        ru: 'Все эффекты',
      },
    },
  ];

  const handleSelect = (mode: PerformanceMode) => {
    triggerHaptic();
    setPerformanceMode(mode);
    setTimeout(() => router.back(), 150);
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
        locations={[0, 0.7, 1]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={{ paddingTop: insets.top + 12, paddingHorizontal: 20, paddingBottom: 16 }}>
          <Animated.View
            entering={FadeIn.duration(200)}
            style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
          >
            <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: '300' }}>
              {language === 'ru' ? 'Производительность' : 'Performance'}
            </Text>
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: `${theme.colors.accent}20`,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>
          </Animated.View>
        </View>

        <ScrollView
          style={{ flex: 1 }}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40, paddingHorizontal: 20 }}
        >
          {performanceModes.map((mode, index) => {
            const Icon = mode.icon;
            const isSelected = performanceMode === mode.key;

            return (
              <Animated.View
                key={mode.key}
                entering={FadeIn.duration(200).delay(index * 50)}
                style={{ marginBottom: 12 }}
              >
                <Pressable
                  onPress={() => handleSelect(mode.key)}
                  style={{
                    backgroundColor: isSelected
                      ? `${theme.colors.accent}30`
                      : `${theme.colors.primaryDark}60`,
                    borderRadius: 16,
                    padding: 16,
                    borderWidth: 2,
                    borderColor: isSelected
                      ? theme.colors.accent
                      : 'transparent',
                  }}
                >
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 12 }}>
                    <View
                      style={{
                        width: 44,
                        height: 44,
                        borderRadius: 22,
                        backgroundColor: isSelected
                          ? theme.colors.accent
                          : `${theme.colors.text}15`,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Icon
                        size={22}
                        color={isSelected ? theme.colors.primary : theme.colors.text}
                        strokeWidth={2}
                      />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text
                        style={{
                          fontSize: 17,
                          fontWeight: '600',
                          color: isSelected ? theme.colors.accent : theme.colors.text,
                          marginBottom: 2,
                        }}
                      >
                        {mode.title[language] || mode.title.en}
                      </Text>
                      <Text
                        style={{
                          fontSize: 13,
                          color: `${theme.colors.text}70`,
                        }}
                      >
                        {mode.description[language] || mode.description.en}
                      </Text>
                    </View>
                  </View>
                </Pressable>
              </Animated.View>
            );
          })}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}
