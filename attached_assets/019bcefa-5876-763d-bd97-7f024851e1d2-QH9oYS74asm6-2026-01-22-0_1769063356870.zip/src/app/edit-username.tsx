import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, ActivityIndicator, Alert, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { X, AlertCircle } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import Animated, { FadeIn } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useAuth } from '@/lib/supabase-hooks';
import { supabase } from '@/lib/supabase';

export default function EditUsernameScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { data: auth } = useAuth();

  const currentUsername = auth?.profile?.username || '';
  const lastChanged = auth?.profile?.username_last_changed;

  const [username, setUsername] = useState(currentUsername);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const themeKey = useSettingsStore(s => s.theme);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const language = useSettingsStore(s => s.language);
  const theme = getTheme(themeKey);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Check if user can change username (15 days cooldown)
  const canChangeUsername = () => {
    if (!lastChanged) return true;
    const daysSinceLastChange = (Date.now() - new Date(lastChanged).getTime()) / (1000 * 60 * 60 * 24);
    return daysSinceLastChange >= 15;
  };

  const getDaysUntilNextChange = () => {
    if (!lastChanged) return 0;
    const daysSinceLastChange = (Date.now() - new Date(lastChanged).getTime()) / (1000 * 60 * 60 * 24);
    return Math.ceil(15 - daysSinceLastChange);
  };

  // Validate username with Gemini API for comprehensive content moderation
  const validateUsername = async (name: string): Promise<{ valid: boolean; error?: string }> => {
    // Basic validation
    if (name.length < 3) {
      return { valid: false, error: language === 'ru' ? 'Минимум 3 символа' : 'Minimum 3 characters' };
    }
    if (name.length > 20) {
      return { valid: false, error: language === 'ru' ? 'Максимум 20 символов' : 'Maximum 20 characters' };
    }
    if (!/^[a-zA-Z0-9_]+$/.test(name)) {
      return { valid: false, error: language === 'ru' ? 'Только буквы, цифры и _' : 'Only letters, numbers and _' };
    }

    try {
      // Check if username is already taken
      const { data: existing } = await supabase
        .from('profiles')
        .select('id')
        .eq('username', name)
        .single();

      if (existing && existing.id !== auth?.profile?.id) {
        return { valid: false, error: language === 'ru' ? 'Имя занято' : 'Username taken' };
      }

      // Check content moderation using Gemini API
      const geminiApiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY;

      if (!geminiApiKey) {
        console.warn('[EditUsername] Gemini API key not found, skipping content moderation');
        return { valid: true };
      }

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${geminiApiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: `Analyze this username for inappropriate content: "${name}"\n\nCheck for:\n- Profanity and offensive language\n- Names of presidents, politicians, or political figures\n- Discriminatory terms (racism, sexism, homophobia, etc.)\n- Political ideology or party names\n- References to children or minors in inappropriate context\n- Country names or nationalism\n- Violence or harmful content\n- Sexual content\n\nRespond with ONLY "SAFE" if the username is appropriate, or "UNSAFE" if it contains any inappropriate content.`
              }]
            }],
            generationConfig: {
              temperature: 0.1,
              maxOutputTokens: 10,
            }
          })
        }
      );

      if (!response.ok) {
        console.error('[EditUsername] Gemini API error:', response.status);
        return { valid: true }; // Allow if API fails
      }

      const data = await response.json();
      const result = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim().toUpperCase();

      if (result === 'UNSAFE') {
        return { valid: false, error: language === 'ru' ? 'Недопустимое имя' : 'Inappropriate name' };
      }

      return { valid: true };
    } catch (error) {
      console.error('[EditUsername] Validation error:', error);
      return { valid: true }; // Allow if API fails
    }
  };

  const handleSave = async () => {
    triggerHaptic();

    if (!canChangeUsername()) {
      Alert.alert(
        language === 'ru' ? 'Слишком рано' : 'Too Soon',
        language === 'ru'
          ? `Вы сможете изменить имя через ${getDaysUntilNextChange()} дней`
          : `You can change your username in ${getDaysUntilNextChange()} days`,
        [{ text: 'OK' }]
      );
      return;
    }

    if (username === currentUsername) {
      router.back();
      return;
    }

    setIsSubmitting(true);
    setError(null);

    // Validate username
    const validation = await validateUsername(username);
    if (!validation.valid) {
      setError(validation.error || 'Invalid username');
      setIsSubmitting(false);
      return;
    }

    try {
      // Update username in database
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          username,
          username_last_changed: new Date().toISOString(),
        })
        .eq('id', auth?.profile?.id);

      if (updateError) throw updateError;

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (err: any) {
      console.error('[EditUsername] Error:', err);
      setError(err.message || 'Failed to update username');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 8,
            paddingHorizontal: 20,
            paddingBottom: 12,
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              style={{
                width: 36,
                height: 36,
                borderRadius: 18,
                alignItems: 'center',
                justifyContent: 'center',
                backgroundColor: `${theme.colors.accent}20`,
              }}
            >
              <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>

            <Text style={{
              color: theme.colors.text,
              fontSize: 16,
              fontWeight: '500',
              position: 'absolute',
              left: 0,
              right: 0,
              textAlign: 'center',
              zIndex: -1,
            }}>
              {language === 'ru' ? 'Изменить имя' : 'Edit Username'}
            </Text>

            <View style={{ width: 36 }} />
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
        >
          {/* Cooldown Warning */}
          {!canChangeUsername() && (
            <Animated.View
              entering={FadeIn.duration(300)}
              style={{
                marginHorizontal: 20,
                marginTop: 20,
                flexDirection: 'row',
                alignItems: 'flex-start',
                padding: 16,
                borderRadius: 20,
                backgroundColor: `${theme.colors.accent}15`,
              }}
            >
              <AlertCircle size={20} color={theme.colors.accent} strokeWidth={1.5} style={{ marginTop: 2, marginRight: 12 }} />
              <Text style={{ color: theme.colors.text, fontSize: 14, lineHeight: 20, flex: 1 }}>
                {language === 'ru'
                  ? `Вы сможете изменить имя через ${getDaysUntilNextChange()} дней`
                  : `You can change your username in ${getDaysUntilNextChange()} days`}
              </Text>
            </Animated.View>
          )}

          {/* Username Input */}
          <Animated.View
            entering={FadeIn.duration(300).delay(100)}
            style={{
              marginHorizontal: 20,
              marginTop: 20,
            }}
          >
            <Text style={{ color: theme.colors.textSecondary, fontSize: 14, marginBottom: 12 }}>
              {language === 'ru' ? 'Новое имя пользователя' : 'New username'}
            </Text>
            <TextInput
              value={username}
              onChangeText={(text) => {
                setUsername(text.toLowerCase().replace(/[^a-z0-9_]/g, ''));
                setError(null);
              }}
              placeholder={currentUsername}
              placeholderTextColor={`${theme.colors.textSecondary}40`}
              maxLength={20}
              autoCapitalize="none"
              autoCorrect={false}
              autoFocus={true}
              editable={canChangeUsername() && !isSubmitting}
              style={{
                backgroundColor: `${theme.colors.accent}10`,
                borderRadius: 16,
                paddingHorizontal: 20,
                paddingVertical: 16,
                color: theme.colors.text,
                fontSize: 17,
                fontWeight: '500',
                borderWidth: 1,
                borderColor: `${theme.colors.accent}20`,
              }}
            />
            {error && (
              <Text style={{ color: '#FF3B30', fontSize: 14, marginTop: 12 }}>
                {error}
              </Text>
            )}
            <Text style={{ color: theme.colors.textSecondary, fontSize: 13, marginTop: 12, lineHeight: 18 }}>
              {language === 'ru'
                ? '3-20 символов, только буквы, цифры и _'
                : '3-20 characters, letters, numbers and _ only'}
            </Text>
          </Animated.View>

          {/* Save Button */}
          <Animated.View
            entering={FadeIn.duration(300).delay(200)}
            style={{
              marginHorizontal: 20,
              marginTop: 32,
            }}
          >
            <Pressable
              onPress={handleSave}
              disabled={isSubmitting || !canChangeUsername() || username === currentUsername}
              style={{
                borderRadius: 20,
                overflow: 'hidden',
                backgroundColor: isSubmitting || !canChangeUsername() || username === currentUsername
                  ? `${theme.colors.accent}40`
                  : theme.colors.accent,
                opacity: isSubmitting || !canChangeUsername() || username === currentUsername ? 0.5 : 1,
              }}
            >
              <View style={{ paddingVertical: 16, alignItems: 'center' }}>
                {isSubmitting ? (
                  <ActivityIndicator size="small" color={theme.colors.primary} />
                ) : (
                  <Text style={{ color: theme.colors.primary, fontSize: 17, fontWeight: '600' }}>
                    {language === 'ru' ? 'Сохранить' : 'Save'}
                  </Text>
                )}
              </View>
            </Pressable>
          </Animated.View>
        </ScrollView>
      </LinearGradient>
    </View>
  );
}
