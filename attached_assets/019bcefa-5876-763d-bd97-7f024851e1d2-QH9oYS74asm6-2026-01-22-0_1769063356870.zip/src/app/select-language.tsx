import React from 'react';
import { View, Text, Pressable, ScrollView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useSettingsStore, Language } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import * as Haptics from 'expo-haptics';

const languages: Array<{ code: Language; nameKey: string; flag: string }> = [
  { code: 'en', nameKey: 'language.en', flag: '🇺🇸' },
  { code: 'ru', nameKey: 'language.ru', flag: '🇷🇺' },
];

export default function SelectLanguageScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const currentLanguage = useSettingsStore(s => s.language);
  const setLanguage = useSettingsStore(s => s.setLanguage);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const themeKey = useSettingsStore(s => s.theme);

  const theme = getTheme(themeKey);
  const t = useTranslation(currentLanguage);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleSelectLanguage = (languageCode: Language) => {
    triggerHaptic();
    setLanguage(languageCode);
    setTimeout(() => router.back(), 150);
  };

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]} locations={[0, 0.7, 1]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={{ paddingTop: insets.top + 12 }} className="px-5 pb-4">
          <Animated.View
            entering={FadeIn.duration(200)}
            className="flex-row items-center justify-between"
          >
            <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: '300' }}>
              {t('settings.language')}
            </Text>
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{ backgroundColor: `${theme.colors.accent}20` }}
            >
              <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>
          </Animated.View>
        </View>

        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40, paddingHorizontal: 20 }}
        >
          {languages.map((lang, index) => {
            const isSelected = currentLanguage === lang.code;

            return (
              <Animated.View
                key={lang.code}
                entering={FadeIn.duration(200)}
                className="mb-4"
              >
                <Pressable
                  onPress={() => handleSelectLanguage(lang.code)}
                  className="rounded-2xl overflow-hidden active:opacity-80"
                  style={{
                    backgroundColor: 'rgba(255, 255, 255, 0.05)',
                    borderWidth: isSelected ? 2 : 0,
                    borderColor: isSelected ? theme.colors.accent : 'transparent',
                  }}
                >
                  <View className="flex-row items-center justify-between p-5">
                    <View className="flex-row items-center" style={{ gap: 16 }}>
                      <Text style={{ fontSize: 32 }}>{lang.flag}</Text>
                      <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '500' }}>
                        {t(lang.nameKey as any)}
                      </Text>
                    </View>
                    {isSelected && (
                      <View
                        className="w-6 h-6 rounded-full items-center justify-center"
                        style={{ backgroundColor: theme.colors.accent }}
                      >
                        <Text style={{ color: theme.colors.primary, fontSize: 16 }}>✓</Text>
                      </View>
                    )}
                  </View>
                </Pressable>
              </Animated.View>
            );
          })}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}
