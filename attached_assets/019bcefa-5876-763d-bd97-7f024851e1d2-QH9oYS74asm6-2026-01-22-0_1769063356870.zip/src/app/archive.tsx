import React from 'react';
import { View, Text, ScrollView, Pressable, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { ChevronLeft, ArchiveRestore, Archive } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { MemoryCard } from '@/components/MemoryCard';
import { useArchivedMemories, useToggleArchive } from '@/lib/supabase-hooks';

export default function ArchiveScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { data: archivedMemories = [], isLoading } = useArchivedMemories();
  const toggleArchiveMutation = useToggleArchive();

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleRestore = (memoryId: string) => {
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    toggleArchiveMutation.mutate({ memoryId, isArchived: true });
  };

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={{ paddingTop: insets.top + 8 }} className="px-5 pb-6">
          <Animated.View
            entering={FadeIn.duration(300)}
            className="flex-row items-center justify-between"
          >
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{ backgroundColor: `${theme.colors.accent}20` }}
            >
              <ChevronLeft size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>

            <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500', position: 'absolute', left: 0, right: 0, textAlign: 'center', zIndex: -1 }}>
              {t('archive.title')}
            </Text>

            <View className="w-10" />
          </Animated.View>
        </View>

        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
        >
          {isLoading ? (
            <View className="flex-1 items-center justify-center py-20">
              <ActivityIndicator size="large" color={theme.colors.accent} />
            </View>
          ) : archivedMemories.length > 0 ? (
            archivedMemories.map((memory: any) => (
              <View key={memory.id} className="mb-4">
                <MemoryCard
                  memory={{
                    id: memory.id,
                    text: memory.text,
                    emotion: memory.emotion,
                    imageUrl: memory.imageUrl,
                    videoUrl: memory.videoUrl,
                    location: memory.location,
                    latitude: memory.latitude,
                    longitude: memory.longitude,
                    createdAt: memory.createdAt,
                    authorId: memory.authorId,
                    authorName: memory.authorName,
                    authorAvatar: memory.authorAvatar,
                    isVerified: memory.isVerified,
                    echoCount: memory.echoCount,
                    hasEchoed: memory.hasEchoed,
                    isSaved: memory.isSaved,
                    isArchived: memory.isArchived,
                  }}
                  onPress={() => {
                    triggerHaptic();
                    router.push(`/memory-detail?id=${memory.id}`);
                  }}
                  showRestoreButton={true}
                  onRestore={() => handleRestore(memory.id)}
                />
              </View>
            ))
          ) : (
            <Animated.View
              entering={FadeIn.duration(400)}
              className="items-center py-20 px-8"
            >
              <Archive size={64} color={`${theme.colors.textSecondary}40`} strokeWidth={1.5} />
              <Text style={{ color: `${theme.colors.textSecondary}80`, textAlign: 'center', fontSize: 16, lineHeight: 24, marginTop: 16 }}>
                {t('archive.empty')}{'\n'}
                {t('archive.emptyDesc')}
              </Text>
            </Animated.View>
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}
