import React, { useState, useEffect, useRef } from 'react';
import { View, Text, ScrollView, Pressable, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { X, Activity, AlertCircle, Info, Copy, Trash2 } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { LinearGradient } from 'expo-linear-gradient';
import * as Clipboard from 'expo-clipboard';

interface LogEntry {
  id: string;
  timestamp: Date;
  type: 'info' | 'warn' | 'error' | 'success';
  message: string;
  details?: any;
}

// Перехватываем console для логирования
const originalConsole = {
  log: console.log,
  warn: console.warn,
  error: console.error,
};

export default function AdminMonitorScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const scrollViewRef = useRef<ScrollView>(null);

  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [autoScroll, setAutoScroll] = useState(true);
  const [filter, setFilter] = useState<'all' | 'error' | 'warn' | 'info'>('all');

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Перехватываем console.log, console.warn, console.error
  useEffect(() => {
    const addLog = (type: LogEntry['type'], args: any[]) => {
      const message = args.map(arg =>
        typeof arg === 'object' ? JSON.stringify(arg, null, 2) : String(arg)
      ).join(' ');

      setLogs(prev => {
        const newLog: LogEntry = {
          id: Date.now().toString() + Math.random(),
          timestamp: new Date(),
          type,
          message,
          details: args.length > 1 ? args : undefined,
        };
        // Ограничиваем до 200 последних логов
        const updated = [...prev, newLog].slice(-200);
        return updated;
      });
    };

    console.log = (...args) => {
      originalConsole.log(...args);
      addLog('info', args);
    };

    console.warn = (...args) => {
      originalConsole.warn(...args);
      addLog('warn', args);
    };

    console.error = (...args) => {
      originalConsole.error(...args);
      addLog('error', args);
    };

    // Добавляем стартовое сообщение
    addLog('success', ['[Админ-панель] Мониторинг запущен']);

    return () => {
      // Восстанавливаем оригинальные функции при размонтировании
      console.log = originalConsole.log;
      console.warn = originalConsole.warn;
      console.error = originalConsole.error;
    };
  }, []);

  // Автоскролл к низу при новых логах
  useEffect(() => {
    if (autoScroll && scrollViewRef.current) {
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [logs, autoScroll]);

  const filteredLogs = logs.filter(log => {
    if (filter === 'all') return true;
    return log.type === filter;
  });

  const getLogIcon = (type: LogEntry['type']) => {
    switch (type) {
      case 'error':
        return <AlertCircle size={16} color="#EF4444" />;
      case 'warn':
        return <AlertCircle size={16} color="#F59E0B" />;
      case 'success':
        return <Activity size={16} color="#10B981" />;
      default:
        return <Info size={16} color={theme.colors.accent} />;
    }
  };

  const getLogColor = (type: LogEntry['type']) => {
    switch (type) {
      case 'error':
        return '#EF4444';
      case 'warn':
        return '#F59E0B';
      case 'success':
        return '#10B981';
      default:
        return theme.colors.textSecondary;
    }
  };

  const copyToClipboard = async (text: string) => {
    await Clipboard.setStringAsync(text);
    triggerHaptic();
    console.log('[Админ-панель] Скопировано в буфер обмена');
  };

  const clearLogs = () => {
    triggerHaptic();
    setLogs([]);
    console.log('[Админ-панель] Логи очищены');
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('ru-RU', {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    });
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 12,
            paddingBottom: 12,
            paddingHorizontal: 20,
            borderBottomWidth: 1,
            borderBottomColor: `${theme.colors.text}10`,
            backgroundColor: `${theme.colors.primary}CC`,
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={{ color: theme.colors.text, fontSize: 20, fontWeight: '600' }}>
              Мониторинг активности
            </Text>
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: `${theme.colors.text}15`,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <X size={18} color={theme.colors.text} strokeWidth={2} />
            </Pressable>
          </View>

          {/* Filter Buttons */}
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
            {(['all', 'error', 'warn', 'info'] as const).map((f) => (
              <Pressable
                key={f}
                onPress={() => {
                  triggerHaptic();
                  setFilter(f);
                }}
                style={{
                  paddingHorizontal: 12,
                  paddingVertical: 6,
                  borderRadius: 12,
                  backgroundColor: filter === f ? theme.colors.accent : `${theme.colors.text}10`,
                }}
              >
                <Text
                  style={{
                    color: filter === f ? theme.colors.primary : theme.colors.textSecondary,
                    fontSize: 13,
                    fontWeight: '600',
                  }}
                >
                  {f === 'all' ? 'Все' : f === 'error' ? 'Ошибки' : f === 'warn' ? 'Предупреждения' : 'Инфо'}
                </Text>
              </Pressable>
            ))}
          </View>

          {/* Action Buttons */}
          <View style={{ flexDirection: 'row', gap: 8, marginTop: 12 }}>
            <Pressable
              onPress={() => {
                triggerHaptic();
                setAutoScroll(!autoScroll);
              }}
              style={{
                flex: 1,
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderRadius: 12,
                backgroundColor: autoScroll ? theme.colors.accent : `${theme.colors.text}10`,
              }}
            >
              <Text
                style={{
                  color: autoScroll ? theme.colors.primary : theme.colors.textSecondary,
                  fontSize: 13,
                  fontWeight: '600',
                  textAlign: 'center',
                }}
              >
                {autoScroll ? '✓ Автоскролл' : 'Автоскролл'}
              </Text>
            </Pressable>
            <Pressable
              onPress={clearLogs}
              style={{
                flex: 1,
                paddingHorizontal: 12,
                paddingVertical: 8,
                borderRadius: 12,
                backgroundColor: `${theme.colors.text}10`,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'center',
                gap: 6,
              }}
            >
              <Trash2 size={14} color={theme.colors.textSecondary} />
              <Text
                style={{
                  color: theme.colors.textSecondary,
                  fontSize: 13,
                  fontWeight: '600',
                }}
              >
                Очистить
              </Text>
            </Pressable>
          </View>

          {/* Stats */}
          <View style={{ flexDirection: 'row', gap: 12, marginTop: 12 }}>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.colors.textSecondary, fontSize: 11 }}>Всего логов</Text>
              <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '600' }}>
                {logs.length}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.colors.textSecondary, fontSize: 11 }}>Ошибки</Text>
              <Text style={{ color: '#EF4444', fontSize: 16, fontWeight: '600' }}>
                {logs.filter(l => l.type === 'error').length}
              </Text>
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ color: theme.colors.textSecondary, fontSize: 11 }}>Предупреждения</Text>
              <Text style={{ color: '#F59E0B', fontSize: 16, fontWeight: '600' }}>
                {logs.filter(l => l.type === 'warn').length}
              </Text>
            </View>
          </View>
        </View>

        {/* Logs */}
        <ScrollView
          ref={scrollViewRef}
          style={{ flex: 1 }}
          contentContainerStyle={{ padding: 16, paddingBottom: insets.bottom + 20 }}
          onScrollBeginDrag={() => setAutoScroll(false)}
        >
          {filteredLogs.length === 0 ? (
            <View style={{ alignItems: 'center', paddingVertical: 40 }}>
              <Activity size={48} color={theme.colors.textSecondary} strokeWidth={1.5} />
              <Text style={{ color: theme.colors.textSecondary, fontSize: 15, marginTop: 12 }}>
                Нет логов для отображения
              </Text>
            </View>
          ) : (
            filteredLogs.map((log) => (
              <Pressable
                key={log.id}
                onLongPress={() => copyToClipboard(log.message)}
                style={{
                  marginBottom: 12,
                  padding: 12,
                  borderRadius: 12,
                  backgroundColor: `${theme.colors.text}05`,
                  borderLeftWidth: 3,
                  borderLeftColor: getLogColor(log.type),
                }}
              >
                <View style={{ flexDirection: 'row', alignItems: 'flex-start', gap: 8 }}>
                  <View style={{ marginTop: 2 }}>
                    {getLogIcon(log.type)}
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        color: theme.colors.textSecondary,
                        fontSize: 11,
                        marginBottom: 4,
                      }}
                    >
                      {formatTime(log.timestamp)}
                    </Text>
                    <Text
                      style={{
                        color: theme.colors.text,
                        fontSize: 13,
                        lineHeight: 18,
                        fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
                      }}
                    >
                      {log.message}
                    </Text>
                  </View>
                  <Pressable
                    onPress={() => copyToClipboard(log.message)}
                    style={{
                      padding: 4,
                      borderRadius: 6,
                      backgroundColor: `${theme.colors.text}10`,
                    }}
                  >
                    <Copy size={14} color={theme.colors.textSecondary} />
                  </Pressable>
                </View>
              </Pressable>
            ))
          )}
        </ScrollView>
      </LinearGradient>
    </View>
  );
}
