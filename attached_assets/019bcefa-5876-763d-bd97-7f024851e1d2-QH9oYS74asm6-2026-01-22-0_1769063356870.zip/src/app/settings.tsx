import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, Pressable, Platform, Alert, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { ChevronLeft, ChevronRight, Volume2, VolumeX, Eye, Palette, Languages, Archive, User, EyeOff, Zap, Sparkles, HardDrive, Trash2, Shield, Smartphone } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useQueryClient } from '@tanstack/react-query';
import { useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import * as Haptics from 'expo-haptics';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as FileSystem from 'expo-file-system';
import { SettingsAudioModal } from '@/components/SettingsAudioModal';
import { SettingsAppearanceModal } from '@/components/SettingsAppearanceModal';
import { SelectThemeModal } from '@/components/SelectThemeModal';
import { SelectLanguageModal } from '@/components/SelectLanguageModal';
import { CacheUsageModal } from '@/components/CacheUsageModal';
import { PrivacyModal } from '@/components/PrivacyModal';
import { useAuth, useIsAdmin } from '@/lib/supabase-hooks';

export default function SettingsScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();

  const isPremium = useAppStore(s => s.isPremium);

  const soundEnabled = useSettingsStore(s => s.soundEnabled);
  const backgroundDimEnabled = useSettingsStore(s => s.backgroundDimEnabled);
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  // Auth and admin check
  const { data: auth } = useAuth();
  const isAdmin = useIsAdmin();

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  // Local wrapper for haptic feedback
  const triggerHaptic = () => {
    if (hapticsEnabled) { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }
  };

  const [cacheSize, setCacheSize] = useState<string>('...');
  const [isCalculating, setIsCalculating] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const [showAudioModal, setShowAudioModal] = useState(false);
  const [showAppearanceModal, setShowAppearanceModal] = useState(false);
  const [showThemeModal, setShowThemeModal] = useState(false);
  const [showLanguageModal, setShowLanguageModal] = useState(false);
  const [showCacheModal, setShowCacheModal] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);


  // Calculate cache size - SAME METHOD as CacheUsageModal
  const calculateCacheSize = async () => {
    try {
      setIsCalculating(true);

      // Get only app cache keys (same as modal)
      const keys = await AsyncStorage.getAllKeys();
      const appKeys = keys.filter(k => k.startsWith('@app_cache:'));
      let totalSize = 0;

      // Calculate size using Blob (same as modal)
      for (const key of appKeys) {
        const value = await AsyncStorage.getItem(key);
        if (value) {
          const sizeInBytes = new Blob([value]).size;
          totalSize += sizeInBytes / 1024; // Convert to KB
        }
      }

      // Convert to KB or MB
      if (totalSize < 1024) {
        setCacheSize(`${totalSize.toFixed(2)} KB`);
      } else {
        setCacheSize(`${(totalSize / 1024).toFixed(2)} MB`);
      }
    } catch (error) {
      console.error('Error calculating cache size:', error);
      setCacheSize('Error');
    } finally {
      setIsCalculating(false);
    }
  };

  // Clear cache
  const clearCache = async () => {
    triggerHaptic();

    Alert.alert(
      language === 'ru' ? 'Очистить кэш?' : 'Clear Cache?',
      language === 'ru'
        ? 'Это удалит все локально сохранённые данные. Настройки приложения останутся.'
        : 'This will remove all locally cached data. App settings will remain.',
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
        },
        {
          text: language === 'ru' ? 'Очистить' : 'Clear',
          style: 'destructive',
          onPress: async () => {
            try {
              setIsClearing(true);

              // Get all keys
              const keys = await AsyncStorage.getAllKeys();

              // Filter out important keys (keep user preferences and essential data)
              const cacheKeys = keys.filter(key =>
                !key.startsWith('settings_') &&       // Keep user settings
                !key.startsWith('auth_') &&           // Keep auth data
                !key.startsWith('message_cache_') &&  // Keep message cache
                !key.startsWith('search_history_') && // Keep search history
                key !== 'hasCompletedOnboarding' &&   // Keep onboarding status
                key !== 'userName' &&                 // Keep username
                key !== 'visualKeyPattern'            // Keep pattern
              );

              // Clear cache keys only (this clears React Query cache in AsyncStorage)
              await AsyncStorage.multiRemove(cacheKeys);

              // Invalidate ONLY image/media queries in React Query
              // DO NOT invalidate auth, messages, or conversations
              await queryClient.invalidateQueries({
                queryKey: ['memories'],
                refetchType: 'none' // Don't auto-refetch, just mark as stale
              });

              // Recalculate size
              await calculateCacheSize();

              Alert.alert(
                language === 'ru' ? 'Готово' : 'Done',
                language === 'ru' ? 'Кэш очищен' : 'Cache cleared'
              );
            } catch (error) {
              console.error('Error clearing cache:', error);
              Alert.alert(
                language === 'ru' ? 'Ошибка' : 'Error',
                language === 'ru' ? 'Не удалось очистить кэш' : 'Failed to clear cache'
              );
            } finally {
              setIsClearing(false);
            }
          },
        },
      ]
    );
  };

  useEffect(() => {
    calculateCacheSize();
  }, []);

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={{ paddingTop: insets.top + 8 }} className="px-5 pb-6">
          <Animated.View
            entering={FadeIn.duration(300)}
            className="flex-row items-center justify-between"
          >
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{ backgroundColor: `${theme.colors.accent}20` }}
            >
              <ChevronLeft size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>

            <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: '300', position: 'absolute', left: 0, right: 0, textAlign: 'center', zIndex: -1 }}>
              {t('settings.title')}
            </Text>

            <View className="w-10" />
          </Animated.View>
        </View>

        <ScrollView
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
        >
          {/* Account Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {t('settings.account')}
            </Text>

            <Pressable
              onPress={() => {
                triggerHaptic();
                router.push('/account');
              }}
              className="rounded-2xl overflow-hidden active:opacity-80"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
            >
              <View className="flex-row items-center justify-between px-4 py-4">
                <View className="flex-row items-center flex-1">
                  <User size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  <View className="ml-3 flex-1">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                      {t('account.title')}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                      {t('settings.accountDesc')}
                    </Text>
                  </View>
                </View>
                <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
              </View>
            </Pressable>
          </Animated.View>

          {/* Privacy Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {language === 'ru' ? 'КОНФИДЕНЦИАЛЬНОСТЬ' : 'PRIVACY'}
            </Text>

            <View className="rounded-2xl overflow-hidden" style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  setShowPrivacyModal(true);
                }}
                className="active:opacity-80"
                style={{ borderBottomWidth: 1, borderBottomColor: `${theme.colors.text}0D` }}
              >
                <View className="flex-row items-center justify-between px-4 py-4">
                  <View className="flex-row items-center flex-1">
                    <Shield size={20} color={theme.colors.accent} strokeWidth={1.5} />
                    <View className="ml-3 flex-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {language === 'ru' ? 'Конфиденциальность и безопасность' : 'Privacy & Security'}
                      </Text>
                      <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                        {language === 'ru' ? 'Разрешения и защита данных' : 'Permissions and data protection'}
                      </Text>
                    </View>
                  </View>
                  <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
                </View>
              </Pressable>

              {/* Active Sessions */}
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.push('/active-sessions');
                }}
                className="active:opacity-80"
              >
                <View className="flex-row items-center justify-between px-4 py-4">
                  <View className="flex-row items-center flex-1">
                    <Smartphone size={20} color={theme.colors.accent} strokeWidth={1.5} />
                    <View className="ml-3 flex-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {language === 'ru' ? 'Активные сеансы' : 'Active Sessions'}
                      </Text>
                      <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                        {language === 'ru' ? 'Управление устройствами' : 'Manage devices'}
                      </Text>
                    </View>
                  </View>
                  <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
                </View>
              </Pressable>
            </View>
          </Animated.View>

          {/* Archive Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {t('settings.archive')}
            </Text>

            <View className="rounded-2xl overflow-hidden" style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.push('/archive');
                }}
                className="active:opacity-80"
                style={{ borderBottomWidth: 1, borderBottomColor: `${theme.colors.text}0D` }}
              >
                <View className="flex-row items-center justify-between px-4 py-4">
                  <View className="flex-row items-center flex-1">
                    <Archive size={20} color={theme.colors.accent} strokeWidth={1.5} />
                    <View className="ml-3 flex-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {t('archive.title')}
                      </Text>
                      <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                        {t('settings.archiveDesc')}
                      </Text>
                    </View>
                  </View>
                  <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
                </View>
              </Pressable>

              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.push('/hidden-users');
                }}
                className="active:opacity-80"
              >
                <View className="flex-row items-center justify-between px-4 py-4">
                  <View className="flex-row items-center flex-1">
                    <EyeOff size={20} color={theme.colors.accent} strokeWidth={1.5} />
                    <View className="ml-3 flex-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {language === 'ru' ? 'Скрытые пользователи' : 'Hidden Users'}
                      </Text>
                      <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                        {language === 'ru' ? 'Управление скрытыми пользователями' : 'Manage hidden users'}
                      </Text>
                    </View>
                  </View>
                  <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
                </View>
              </Pressable>
            </View>
          </Animated.View>

          {/* Audio & Feedback Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {t('settings.audioFeedback')}
            </Text>

            <Pressable
              onPress={() => {
                triggerHaptic();
                setShowAudioModal(true);
              }}
              className="rounded-2xl overflow-hidden active:opacity-80"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
            >
              <View className="flex-row items-center justify-between px-4 py-4">
                <View className="flex-row items-center flex-1">
                  {soundEnabled ? (
                    <Volume2 size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  ) : (
                    <VolumeX size={20} color={`${theme.colors.textSecondary}4D`} strokeWidth={1.5} />
                  )}
                  <View className="ml-3 flex-1">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                      {t('settings.soundEffects')}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                      {soundEnabled ? (language === 'ru' ? 'Включено' : 'Enabled') : (language === 'ru' ? 'Выключено' : 'Disabled')}
                    </Text>
                  </View>
                </View>
                <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
              </View>
            </Pressable>
          </Animated.View>

          {/* Background Dim Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {t('settings.appearance')}
            </Text>

            <Pressable
              onPress={() => {
                triggerHaptic();
                setShowAppearanceModal(true);
              }}
              className="rounded-2xl overflow-hidden active:opacity-80"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
            >
              <View className="flex-row items-center justify-between px-4 py-4">
                <View className="flex-row items-center flex-1">
                  <Eye size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  <View className="ml-3 flex-1">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                      {t('settings.dimBackground')}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                      {backgroundDimEnabled ? (language === 'ru' ? 'Включено' : 'Enabled') : (language === 'ru' ? 'Выключено' : 'Disabled')}
                    </Text>
                  </View>
                </View>
                <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
              </View>
            </Pressable>
          </Animated.View>

          {/* Performance Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {language === 'ru' ? 'Производительность' : 'Performance'}
            </Text>

            <Pressable
              onPress={() => {
                triggerHaptic();
                router.push('/settings-performance');
              }}
              className="rounded-2xl overflow-hidden active:opacity-80"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
            >
              <View className="flex-row items-center justify-between px-4 py-4">
                <View className="flex-row items-center flex-1">
                  <Zap size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  <View className="ml-3 flex-1">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                      {language === 'ru' ? 'Производительность' : 'Performance'}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                      {language === 'ru' ? 'Оптимизация под устройство' : 'Optimize for your device'}
                    </Text>
                  </View>
                </View>
                <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
              </View>
            </Pressable>
          </Animated.View>

          {/* Theme Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {t('settings.theme')}
            </Text>

            <Pressable
              onPress={() => {
                triggerHaptic();
                setShowThemeModal(true);
              }}
              className="rounded-2xl overflow-hidden active:opacity-80"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
            >
              <View className="flex-row items-center justify-between px-4 py-4">
                <View className="flex-row items-center flex-1">
                  <Palette size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  <View className="ml-3 flex-1">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                      {t(`theme.${themeKey}` as any)}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                      {t('settings.themeDesc')}
                    </Text>
                  </View>
                </View>
                <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
              </View>
            </Pressable>
          </Animated.View>

          {/* Language Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {t('settings.language')}
            </Text>

            <Pressable
              onPress={() => {
                triggerHaptic();
                setShowLanguageModal(true);
              }}
              className="rounded-2xl overflow-hidden active:opacity-80"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
            >
              <View className="flex-row items-center justify-between px-4 py-4">
                <View className="flex-row items-center flex-1">
                  <Languages size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  <View className="ml-3 flex-1">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                      {t(`language.${language}` as any)}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                      {t('settings.languageDesc')}
                    </Text>
                  </View>
                </View>
                <ChevronRight size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
              </View>
            </Pressable>
          </Animated.View>

          {/* Storage & Cache Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {language === 'ru' ? 'Хранилище' : 'Storage'}
            </Text>

            <View className="rounded-2xl overflow-hidden" style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}>
              {/* Cache Size Info - now clickable */}
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  setShowCacheModal(true);
                }}
                style={{ borderBottomWidth: 1, borderBottomColor: `${theme.colors.text}0D`, paddingVertical: 16, paddingHorizontal: 16 }}
                className="active:opacity-80"
              >
                <View className="flex-row items-center justify-between">
                  <View className="flex-row items-center flex-1">
                    <HardDrive size={20} color={theme.colors.accent} strokeWidth={1.5} />
                    <View className="ml-3 flex-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {language === 'ru' ? 'Размер кэша' : 'Cache Size'}
                      </Text>
                      <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                        {language === 'ru' ? 'Нажмите для подробностей' : 'Tap for detailed breakdown'}
                      </Text>
                    </View>
                  </View>
                  <View className="flex-row items-center">
                    {isCalculating ? (
                      <ActivityIndicator size="small" color={theme.colors.accent} />
                    ) : (
                      <Text style={{ color: theme.colors.accent, fontSize: 16, fontWeight: '600', marginRight: 8 }}>
                        {cacheSize}
                      </Text>
                    )}
                    <ChevronRight size={18} color={theme.colors.textSecondary} strokeWidth={1.5} />
                  </View>
                </View>
              </Pressable>
            </View>
          </Animated.View>

          {/* Premium Section */}
          <Animated.View
            entering={FadeIn.duration(300)}
            className="mx-5 mb-6"
          >
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {language === 'ru' ? 'Подписка' : 'Subscription'}
            </Text>

            <Pressable
              onPress={() => {
                triggerHaptic();
                router.push('/premium');
              }}
              className="rounded-2xl overflow-hidden active:opacity-80"
              style={{
                backgroundColor: isPremium ? `${theme.colors.accent}20` : 'rgba(255, 255, 255, 0.05)',
                borderWidth: isPremium ? 1 : 0,
                borderColor: `${theme.colors.accent}40`,
              }}
            >
              <View className="flex-row items-center justify-between px-4 py-4">
                <View className="flex-row items-center flex-1">
                  <View
                    className="w-10 h-10 rounded-full items-center justify-center"
                    style={{ backgroundColor: `${theme.colors.accent}30` }}
                  >
                    <Sparkles size={20} color={theme.colors.accent} />
                  </View>
                  <View className="ml-3 flex-1">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '600' }}>
                      {language === 'ru' ? 'Memories Premium' : 'Memories Premium'}
                    </Text>
                    <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginTop: 2 }}>
                      {isPremium
                        ? (language === 'ru' ? 'Активна' : 'Active')
                        : (language === 'ru' ? 'Автоперевод и без рекламы' : 'Auto-translate & ad-free')
                      }
                    </Text>
                  </View>
                </View>
                {isPremium ? (
                  <View
                    className="px-3 py-1 rounded-full"
                    style={{ backgroundColor: theme.colors.accent }}
                  >
                    <Text style={{ color: '#FFFFFF', fontSize: 12, fontWeight: '600' }}>
                      PRO
                    </Text>
                  </View>
                ) : (
                  <ChevronRight size={20} color={theme.colors.accent} strokeWidth={1.5} />
                )}
              </View>
            </Pressable>
          </Animated.View>

        </ScrollView>
      </LinearGradient>

      {/* Settings Modals */}
      <SettingsAudioModal
        visible={showAudioModal}
        onClose={() => setShowAudioModal(false)}
      />

      <SettingsAppearanceModal
        visible={showAppearanceModal}
        onClose={() => setShowAppearanceModal(false)}
      />

      <SelectThemeModal
        visible={showThemeModal}
        onClose={() => setShowThemeModal(false)}
      />

      <SelectLanguageModal
        visible={showLanguageModal}
        onClose={() => setShowLanguageModal(false)}
      />

      <CacheUsageModal
        visible={showCacheModal}
        onClose={() => setShowCacheModal(false)}
      />

      <PrivacyModal
        visible={showPrivacyModal}
        onClose={() => setShowPrivacyModal(false)}
      />
    </View>
  );
}
