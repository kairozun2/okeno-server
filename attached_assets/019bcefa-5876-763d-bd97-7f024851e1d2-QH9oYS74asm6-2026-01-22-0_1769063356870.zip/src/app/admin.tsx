import React, { useState } from 'react';
import { View, Text, FlatList, Pressable, TextInput, Alert, ActivityIndicator, Modal, KeyboardAvoidingView, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { X, Search, CheckCircle, XCircle, Shield, ShieldOff, Ban, ShieldAlert, Activity } from 'lucide-react-native';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useAllUsers, useVerifyUser, useSetAdmin, useBanUser, useAuth, useIsSuperAdmin } from '@/lib/supabase-hooks';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import * as Haptics from 'expo-haptics';

// Define error/success colors since theme doesn't have them
const ERROR_COLOR = '#EF4444';
const SUCCESS_COLOR = '#22C55E';

export default function AdminPanel() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const theme = getTheme(themeKey);

  const [searchQuery, setSearchQuery] = useState('');
  const [banModalVisible, setBanModalVisible] = useState(false);
  const [banReason, setBanReason] = useState('');
  const [userToBan, setUserToBan] = useState<{ id: string; username: string } | null>(null);

  const { data: auth } = useAuth();
  const isSuperAdmin = useIsSuperAdmin();
  const { data: users = [], isLoading } = useAllUsers();
  const verifyMutation = useVerifyUser();
  const setAdminMutation = useSetAdmin();
  const banMutation = useBanUser();

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
  };

  // Filter users by search query
  const filteredUsers = users.filter(user =>
    user.username.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleVerifyToggle = (userId: string, currentStatus: boolean, isBanned: boolean) => {
    if (isBanned) {
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Нельзя верифицировать забаненного пользователя' : 'Cannot verify a banned user'
      );
      return;
    }

    Alert.alert(
      currentStatus
        ? (language === 'ru' ? 'Снять верификацию?' : 'Remove Verification?')
        : (language === 'ru' ? 'Верифицировать?' : 'Verify User?'),
      currentStatus
        ? (language === 'ru' ? 'Вы уверены, что хотите снять верификацию с этого пользователя?' : 'Are you sure you want to remove verification from this user?')
        : (language === 'ru' ? 'Вы уверены, что хотите верифицировать этого пользователя?' : 'Are you sure you want to verify this user?'),
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
        },
        {
          text: language === 'ru' ? 'Подтвердить' : 'Confirm',
          onPress: () => {
            triggerHaptic();
            verifyMutation.mutate({ userId, verified: !currentStatus });
          },
        },
      ]
    );
  };

  const handleAdminToggle = (userId: string, currentStatus: boolean, username: string, isUserSuperAdmin: boolean, isBanned: boolean) => {
    if (isUserSuperAdmin) {
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Нельзя снять права у главного администратора' : 'Cannot remove super admin privileges'
      );
      return;
    }

    if (isBanned) {
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Нельзя назначить админом забаненного пользователя' : 'Cannot grant admin rights to a banned user'
      );
      return;
    }

    Alert.alert(
      currentStatus
        ? (language === 'ru' ? 'Снять права админа?' : 'Remove Admin Rights?')
        : (language === 'ru' ? 'Назначить админом?' : 'Make Admin?'),
      currentStatus
        ? (language === 'ru' ? `Вы уверены, что хотите снять права администратора с ${username}?` : `Are you sure you want to remove admin rights from ${username}?`)
        : (language === 'ru' ? `Вы уверены, что хотите назначить ${username} младшим администратором?` : `Are you sure you want to make ${username} a junior admin?`),
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
        },
        {
          text: language === 'ru' ? 'Подтвердить' : 'Confirm',
          style: currentStatus ? 'destructive' : 'default',
          onPress: () => {
            triggerHaptic();
            setAdminMutation.mutate({ userId, isAdmin: !currentStatus });
          },
        },
      ]
    );
  };

  const handleBanToggle = (userId: string, currentStatus: boolean, username: string, isUserSuperAdmin: boolean, isUserAdmin: boolean) => {
    if (isUserSuperAdmin) {
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Нельзя забанить главного администратора' : 'Cannot ban super admin'
      );
      return;
    }

    // Only super admin can ban other admins
    if (isUserAdmin && !isSuperAdmin) {
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Только главный администратор может банить других админов' : 'Only super admin can ban other admins'
      );
      return;
    }

    if (currentStatus) {
      // Unban - simple confirmation
      Alert.alert(
        language === 'ru' ? 'Разбанить пользователя?' : 'Unban User?',
        language === 'ru' ? `Вы уверены, что хотите разбанить ${username}?` : `Are you sure you want to unban ${username}?`,
        [
          {
            text: language === 'ru' ? 'Отмена' : 'Cancel',
            style: 'cancel',
          },
          {
            text: language === 'ru' ? 'Разбанить' : 'Unban',
            onPress: () => {
              triggerHaptic();
              banMutation.mutate({ userId, banned: false });
            },
          },
        ]
      );
    } else {
      // Ban - show custom modal for reason input
      setUserToBan({ id: userId, username });
      setBanReason('');
      setBanModalVisible(true);
    }
  };

  const confirmBan = () => {
    if (userToBan) {
      triggerHaptic();
      banMutation.mutate({
        userId: userToBan.id,
        banned: true,
        reason: banReason.trim() || 'No reason provided'
      });
      setBanModalVisible(false);
      setUserToBan(null);
      setBanReason('');
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.background]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 12,
            paddingHorizontal: 16,
            paddingBottom: 16,
            borderBottomWidth: 1,
            borderBottomColor: `${theme.colors.text}20`,
          }}
        >
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
              <ShieldAlert size={24} color={theme.colors.accent} />
              <Text style={{ fontSize: 24, fontWeight: '700', color: theme.colors.text }}>
                {language === 'ru' ? 'Админ-Панель' : 'Admin Panel'}
              </Text>
            </View>
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.push('/admin-monitor');
                }}
                style={{
                  padding: 8,
                  borderRadius: 12,
                  backgroundColor: `${theme.colors.accent}20`,
                }}
              >
                <Activity size={20} color={theme.colors.accent} />
              </Pressable>
              <Pressable onPress={() => { triggerHaptic(); router.back(); }}>
                <X size={28} color={theme.colors.text} />
              </Pressable>
            </View>
          </View>

          {/* Super Admin Badge */}
          {isSuperAdmin && (
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 16, backgroundColor: `${theme.colors.accent}20`, paddingVertical: 8, paddingHorizontal: 12, borderRadius: 12 }}>
              <ShieldAlert size={18} color={theme.colors.accent} fill={theme.colors.accent} />
              <Text style={{ fontSize: 14, fontWeight: '600', color: theme.colors.accent }}>
                {language === 'ru' ? 'Вы - Главный Администратор' : 'You are Super Admin'}
              </Text>
            </View>
          )}

          {/* Search */}
          <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: `${theme.colors.text}10`, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10 }}>
            <Search size={20} color={`${theme.colors.text}60`} />
            <TextInput
              value={searchQuery}
              onChangeText={setSearchQuery}
              placeholder={language === 'ru' ? 'Поиск пользователей...' : 'Search users...'}
              placeholderTextColor={`${theme.colors.text}60`}
              style={{ flex: 1, marginLeft: 8, fontSize: 16, color: theme.colors.text }}
            />
          </View>
        </View>

        {/* Users List */}
        {isLoading ? (
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
            <ActivityIndicator size="large" color={theme.colors.accent} />
          </View>
        ) : (
          <FlatList
            data={filteredUsers}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ paddingHorizontal: 16, paddingTop: 16, paddingBottom: insets.bottom + 16 }}
            renderItem={({ item }) => {
              const isCurrentUser = item.id === auth?.profile?.id;
              const isBanned = item.is_banned || false;
              const isUserSuperAdmin = item.is_super_admin || false;
              const isUserAdmin = item.is_admin || false;

              return (
                <View
                  style={{
                    backgroundColor: isBanned ? `${ERROR_COLOR}20` : (isUserSuperAdmin ? `${theme.colors.accent}10` : `${theme.colors.primaryLight}80`),
                    borderRadius: 16,
                    padding: 16,
                    marginBottom: 12,
                    borderWidth: isUserSuperAdmin ? 2 : (isUserAdmin ? 1 : 0),
                    borderColor: isUserSuperAdmin ? theme.colors.accent : (isUserAdmin ? `${theme.colors.accent}40` : 'transparent'),
                  }}
                >
                  {/* User Info */}
                  <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: isCurrentUser ? 0 : 12 }}>
                    <Text style={{ fontSize: 32, marginRight: 12 }}>{item.avatar_emoji}</Text>
                    <View style={{ flex: 1 }}>
                      <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                        <Text style={{ fontSize: 18, fontWeight: '600', color: theme.colors.text }}>
                          {item.username}
                        </Text>
                        <VerifiedBadge isVerified={item.is_verified || false} size={16} checkColor={theme.colors.primary} />
                        {isUserSuperAdmin && (
                          <ShieldAlert size={18} color={theme.colors.accent} fill={theme.colors.accent} />
                        )}
                        {isUserAdmin && !isUserSuperAdmin && (
                          <Shield size={18} color={theme.colors.accent} fill={theme.colors.accent} />
                        )}
                      </View>
                      <Text style={{ fontSize: 12, color: `${theme.colors.text}60`, marginTop: 2 }}>
                        {new Date(item.created_at).toLocaleDateString()}
                      </Text>
                      {isBanned && (
                        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 }}>
                          <Ban size={14} color={ERROR_COLOR} />
                          <Text style={{ fontSize: 12, color: ERROR_COLOR, fontWeight: '600' }}>
                            {language === 'ru' ? 'ЗАБАНЕН' : 'BANNED'}
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>

                  {/* Action Buttons - Show for ALL users including current user (super admin can verify themselves) */}
                  <View style={{ flexDirection: 'row', gap: 8, flexWrap: 'wrap' }}>
                    {/* Verify/Unverify Button */}
                    <Pressable
                      onPress={() => handleVerifyToggle(item.id, item.is_verified || false, isBanned)}
                      style={{
                        backgroundColor: (item.is_verified && !isBanned) ? `${SUCCESS_COLOR}20` : `${theme.colors.text}10`,
                        paddingVertical: 8,
                        paddingHorizontal: 12,
                        borderRadius: 8,
                        flexDirection: 'row',
                        alignItems: 'center',
                        gap: 6,
                      }}
                      disabled={verifyMutation.isPending}
                    >
                        {(item.is_verified && !isBanned) ? (
                          <>
                            <XCircle size={16} color={SUCCESS_COLOR} />
                            <Text style={{ fontSize: 14, fontWeight: '600', color: SUCCESS_COLOR }}>
                              {language === 'ru' ? 'Снять ✓' : 'Unverify'}
                            </Text>
                          </>
                        ) : (
                          <>
                            <CheckCircle size={16} color={theme.colors.text} />
                            <Text style={{ fontSize: 14, fontWeight: '600', color: theme.colors.text }}>
                              {language === 'ru' ? 'Верифицировать' : 'Verify'}
                            </Text>
                          </>
                        )}
                      </Pressable>

                      {/* Grant/Remove Admin Button */}
                      <Pressable
                        onPress={() => handleAdminToggle(item.id, item.is_admin || false, item.username, isUserSuperAdmin, isBanned)}
                        style={{
                          backgroundColor: (item.is_admin && !isUserSuperAdmin) ? `${theme.colors.accent}20` : `${theme.colors.text}10`,
                          paddingVertical: 8,
                          paddingHorizontal: 12,
                          borderRadius: 8,
                          flexDirection: 'row',
                          alignItems: 'center',
                          gap: 6,
                        }}
                        disabled={setAdminMutation.isPending || isUserSuperAdmin}
                      >
                        {(item.is_admin && !isUserSuperAdmin) ? (
                          <>
                            <ShieldOff size={16} color={theme.colors.accent} />
                            <Text style={{ fontSize: 14, fontWeight: '600', color: theme.colors.accent }}>
                              {language === 'ru' ? 'Снять админа' : 'Remove Admin'}
                            </Text>
                          </>
                        ) : (
                          <>
                            <Shield size={16} color={theme.colors.text} />
                            <Text style={{ fontSize: 14, fontWeight: '600', color: theme.colors.text }}>
                              {language === 'ru' ? 'Сделать админом' : 'Make Admin'}
                            </Text>
                          </>
                        )}
                      </Pressable>

                      {/* Ban/Unban Button */}
                      <Pressable
                        onPress={() => handleBanToggle(item.id, isBanned, item.username, isUserSuperAdmin, isUserAdmin)}
                        style={{
                          backgroundColor: isBanned ? `${ERROR_COLOR}20` : `${theme.colors.text}10`,
                          paddingVertical: 8,
                          paddingHorizontal: 12,
                          borderRadius: 8,
                          flexDirection: 'row',
                          alignItems: 'center',
                          gap: 6,
                        }}
                        disabled={banMutation.isPending || isUserSuperAdmin}
                      >
                        <Ban size={16} color={isBanned ? ERROR_COLOR : theme.colors.text} />
                        <Text style={{ fontSize: 14, fontWeight: '600', color: isBanned ? ERROR_COLOR : theme.colors.text }}>
                          {isBanned
                            ? (language === 'ru' ? 'Разбанить' : 'Unban')
                            : (language === 'ru' ? 'Забанить' : 'Ban')
                          }
                        </Text>
                      </Pressable>
                    </View>

                  {/* Current User Indicator */}
                  {isCurrentUser && (
                    <View style={{ marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: `${theme.colors.text}20` }}>
                      <Text style={{ fontSize: 12, color: `${theme.colors.text}60`, textAlign: 'center' }}>
                        {language === 'ru' ? 'Это вы (нельзя изменить)' : 'This is you (cannot modify)'}
                      </Text>
                    </View>
                  )}
                </View>
              );
            }}
          />
        )}

        {/* Ban Reason Modal */}
        <Modal
          visible={banModalVisible}
          transparent
          animationType="fade"
          onRequestClose={() => setBanModalVisible(false)}
        >
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={{ flex: 1 }}
          >
            <Pressable
              style={{ flex: 1, backgroundColor: 'rgba(0,0,0,0.6)', justifyContent: 'center', alignItems: 'center', padding: 20 }}
              onPress={() => setBanModalVisible(false)}
            >
              <Pressable
                style={{
                  backgroundColor: theme.colors.primaryLight,
                  borderRadius: 20,
                  padding: 24,
                  width: '100%',
                  maxWidth: 360
                }}
                onPress={(e) => e.stopPropagation()}
              >
                <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
                  <Ban size={24} color={ERROR_COLOR} />
                  <Text style={{ fontSize: 20, fontWeight: '700', color: theme.colors.text, marginLeft: 10 }}>
                    {language === 'ru' ? 'Забанить пользователя' : 'Ban User'}
                  </Text>
                </View>

                <Text style={{ fontSize: 14, color: `${theme.colors.text}80`, marginBottom: 16 }}>
                  {language === 'ru'
                    ? `Вы собираетесь забанить ${userToBan?.username}. Укажите причину (необязательно):`
                    : `You are about to ban ${userToBan?.username}. Enter a reason (optional):`
                  }
                </Text>

                <TextInput
                  value={banReason}
                  onChangeText={setBanReason}
                  placeholder={language === 'ru' ? 'Причина бана...' : 'Ban reason...'}
                  placeholderTextColor={`${theme.colors.text}40`}
                  multiline
                  numberOfLines={3}
                  style={{
                    backgroundColor: `${theme.colors.text}10`,
                    borderRadius: 12,
                    padding: 12,
                    fontSize: 16,
                    color: theme.colors.text,
                    minHeight: 80,
                    textAlignVertical: 'top',
                    marginBottom: 20,
                  }}
                />

                <View style={{ flexDirection: 'row', gap: 12 }}>
                  <Pressable
                    onPress={() => {
                      setBanModalVisible(false);
                      setUserToBan(null);
                      setBanReason('');
                    }}
                    style={{
                      flex: 1,
                      backgroundColor: `${theme.colors.text}20`,
                      paddingVertical: 14,
                      borderRadius: 12,
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ fontSize: 16, fontWeight: '600', color: theme.colors.text }}>
                      {language === 'ru' ? 'Отмена' : 'Cancel'}
                    </Text>
                  </Pressable>

                  <Pressable
                    onPress={confirmBan}
                    style={{
                      flex: 1,
                      backgroundColor: ERROR_COLOR,
                      paddingVertical: 14,
                      borderRadius: 12,
                      alignItems: 'center',
                    }}
                  >
                    <Text style={{ fontSize: 16, fontWeight: '600', color: '#FFF' }}>
                      {language === 'ru' ? 'Забанить' : 'Ban'}
                    </Text>
                  </Pressable>
                </View>
              </Pressable>
            </Pressable>
          </KeyboardAvoidingView>
        </Modal>
      </LinearGradient>
    </View>
  );
}
