import React, { useState, useRef, useEffect } from 'react';
import { View, Text, FlatList, Pressable, TextInput, Platform, Alert, KeyboardAvoidingView, ActivityIndicator, Linking } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Send, Reply, Edit3, Trash2 } from 'lucide-react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useMessages, useSendMessage, useMarkMessagesAsRead, useCreateConversation, useAuth, useUserProfile } from '@/lib/supabase-hooks';
import { generateAvatar } from '@/lib/avatar';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ColoredUsername } from '@/components/ColoredUsername';
import { SocialLinkPreview, extractUrls, isMediaUrl } from '@/components/SocialLinkPreview';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, FadeInDown, FadeOut } from 'react-native-reanimated';
import { useQueryClient } from '@tanstack/react-query';

// Component to render text with clickable links and social media previews
function LinkableText({ text, style, isMe }: { text: string; style: any; isMe: boolean }) {
  const urls = extractUrls(text);

  // Filter out media URLs (images/videos) - we don't want to show them as links
  const clickableUrls = urls.filter(url => !isMediaUrl(url));

  // If no clickable URLs, just render plain text
  if (clickableUrls.length === 0) {
    return <Text style={style}>{text}</Text>;
  }

  // Split text into parts (text and URLs)
  const parts: Array<{ type: 'text' | 'url'; content: string }> = [];
  let lastIndex = 0;

  clickableUrls.forEach(url => {
    const urlIndex = text.indexOf(url, lastIndex);

    // Add text before URL
    if (urlIndex > lastIndex) {
      parts.push({
        type: 'text',
        content: text.substring(lastIndex, urlIndex),
      });
    }

    // Add URL
    parts.push({
      type: 'url',
      content: url,
    });

    lastIndex = urlIndex + url.length;
  });

  // Add remaining text after last URL
  if (lastIndex < text.length) {
    parts.push({
      type: 'text',
      content: text.substring(lastIndex),
    });
  }

  return (
    <View>
      {/* Render text parts */}
      <Text style={style}>
        {parts.map((part, index) => {
          if (part.type === 'text') {
            return <Text key={index}>{part.content}</Text>;
          }
          return null;
        })}
      </Text>

      {/* Render social link previews below text */}
      {clickableUrls.map((url, index) => (
        <SocialLinkPreview key={index} url={url} />
      ))}
    </View>
  );
}

// Simple Message Component - no swipe, just long press
function MessageItem({
  item,
  isMe,
  messages,
  theme,
  language,
  onLongPress,
}: any) {
  return (
    <Pressable
      onLongPress={() => onLongPress(item)}
      delayLongPress={300}
      style={{
        paddingHorizontal: 16,
        paddingVertical: 4,
        alignItems: isMe ? 'flex-end' : 'flex-start',
      }}
    >
      <View style={{ maxWidth: '75%' }}>
        {/* Reply preview */}
        {item.reply_to_id && (
          <View
            style={{
              backgroundColor: `${theme.colors.text}08`,
              borderRadius: 10,
              padding: 10,
              marginBottom: 6,
              borderLeftWidth: 2,
              borderLeftColor: isMe ? theme.colors.accent : theme.colors.text,
            }}
          >
            <Text
              style={{
                color: theme.colors.textSecondary,
                fontSize: 11,
                fontWeight: '600',
                marginBottom: 3,
                opacity: 0.7,
              }}
            >
              {language === 'ru' ? 'Ответ' : 'Reply'}
            </Text>
            <Text
              style={{
                color: theme.colors.textSecondary,
                fontSize: 13,
                opacity: 0.8,
              }}
              numberOfLines={2}
            >
              {messages.find((m: any) => m.id === item.reply_to_id)?.text || '...'}
            </Text>
          </View>
        )}

        {/* Message bubble */}
        <View
          style={{
            padding: 12,
            borderRadius: 16,
            backgroundColor: isMe ? theme.colors.accent : theme.colors.primaryLight,
          }}
        >
          <LinkableText
            text={item.text}
            isMe={isMe}
            style={{
              color: isMe ? theme.colors.primary : theme.colors.text,
              fontSize: 15,
              lineHeight: 20,
            }}
          />

          {/* Edited indicator */}
          {item.edited_at && (
            <Text
              style={{
                color: isMe ? `${theme.colors.primary}80` : `${theme.colors.text}60`,
                fontSize: 11,
                marginTop: 4,
                fontStyle: 'italic',
              }}
            >
              {language === 'ru' ? 'изменено' : 'edited'}
            </Text>
          )}
        </View>
      </View>
    </Pressable>
  );
}

// Component ends here
export default function ChatScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  const { id: conversationId, userId, username } = useLocalSearchParams<{
    id: string;
    userId: string;
    username?: string;
  }>();

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const flatListRef = useRef<FlatList>(null);

  // Get current user
  const { data: auth } = useAuth();
  const currentUserId = auth?.session?.user?.id;

  // Load other user's profile
  const { data: otherUserProfile } = useUserProfile(userId);

  // Check if user is trying to message themselves
  const isSelfChat = userId && currentUserId && userId === currentUserId && conversationId !== 'demo';

  const [messageText, setMessageText] = useState('');
  const [replyingTo, setReplyingTo] = useState<any | null>(null);
  const [editingMessage, setEditingMessage] = useState<any | null>(null);
  const [longPressedMessage, setLongPressedMessage] = useState<any | null>(null);

  // Start with null - we'll check if conversation exists and is valid
  const [realConversationId, setRealConversationId] = useState<string | null>(null);
  const [isCheckingConversation, setIsCheckingConversation] = useState(true);
  const [isOtherUserTyping, setIsOtherUserTyping] = useState(false);

  const { data: messages = [], isLoading: isLoadingMessages, isFetching } = useMessages(realConversationId || undefined);
  const sendMessage = useSendMessage();
  const markAsRead = useMarkMessagesAsRead();
  const createConversation = useCreateConversation();

  // CRITICAL: Only show skeleton on FIRST load when there's no data in cache
  // This prevents skeleton flashes when navigating between chats
  const shouldShowSkeleton = isLoadingMessages && Array.isArray(messages) && messages.length === 0;

  // Check if conversation from URL params exists and find existing conversation with user
  useEffect(() => {
    const checkAndFindConversation = async () => {
      if (!userId || !currentUserId) {
        setIsCheckingConversation(false);
        return;
      }

      try {
        // Import supabase here to avoid circular dependency
        const { supabase } = await import('@/lib/supabase');

        // Try to find existing conversation between these two users
        const { data: existingConv } = await supabase
          .from('conversations')
          .select('id')
          .or(
            `and(user1_id.eq.${currentUserId},user2_id.eq.${userId}),` +
            `and(user1_id.eq.${userId},user2_id.eq.${currentUserId})`
          )
          .maybeSingle();

        if (existingConv) {
          console.log('[Chat] Found existing conversation:', existingConv.id);
          setRealConversationId(existingConv.id);
        } else {
          console.log('[Chat] No existing conversation found, will create new one on first message');
          setRealConversationId(null);
        }
      } catch (error) {
        console.error('[Chat] Error checking conversation:', error);
        setRealConversationId(null);
      } finally {
        setIsCheckingConversation(false);
      }
    };

    checkAndFindConversation();
  }, [userId, currentUserId]);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Mark messages as read when screen is opened
  useEffect(() => {
    if (realConversationId && !isCheckingConversation) {
      markAsRead.mutate({ conversationId: realConversationId });
    }
  }, [realConversationId, isCheckingConversation]);

  // Typing indicator via Realtime Broadcast
  useEffect(() => {
    if (!realConversationId || !currentUserId) return;

    const setupTypingIndicator = async () => {
      const { supabase } = await import('@/lib/supabase');

      const channel = supabase.channel(`typing:${realConversationId}`)
        .on('broadcast', { event: 'typing' }, (payload: any) => {
          // Only show typing if it's the other user
          if (payload.payload.userId !== currentUserId) {
            setIsOtherUserTyping(true);
            // Auto-hide after 3 seconds
            setTimeout(() => setIsOtherUserTyping(false), 3000);
          }
        })
        .subscribe();

      return () => {
        channel.unsubscribe();
      };
    };

    setupTypingIndicator();
  }, [realConversationId, currentUserId]);

  // Send typing indicator when user types
  const handleTextChange = async (text: string) => {
    setMessageText(text);

    if (realConversationId && currentUserId && text.length > 0) {
      try {
        const { supabase } = await import('@/lib/supabase');
        await supabase.channel(`typing:${realConversationId}`).send({
          type: 'broadcast',
          event: 'typing',
          payload: { userId: currentUserId },
        });
      } catch (error) {
        // Ignore typing indicator errors
      }
    }
  };

  const handleSend = async () => {
    if (!messageText.trim() || isCheckingConversation) {
      return;
    }

    try {
      // If editing an existing message
      if (editingMessage) {
        const { supabase } = await import('@/lib/supabase');
        const { error } = await supabase
          .from('messages')
          .update({
            text: messageText.trim(),
            edited_at: new Date().toISOString()
          })
          .eq('id', editingMessage.id);

        if (!error) {
          queryClient.invalidateQueries({ queryKey: ['messages', realConversationId] });
        }

        setMessageText('');
        setEditingMessage(null);
        triggerHaptic();
        return;
      }

      // If no conversation exists, create one first
      if (!realConversationId && userId) {
        const newConv = await createConversation.mutateAsync({ otherUserId: userId });
        setRealConversationId(newConv.id);

        // Send message to new conversation
        await sendMessage.mutateAsync({
          conversationId: newConv.id,
          text: messageText.trim(),
          replyToId: replyingTo?.id,
        });
      } else if (realConversationId) {
        // Send message to existing conversation
        await sendMessage.mutateAsync({
          conversationId: realConversationId,
          text: messageText.trim(),
          replyToId: replyingTo?.id,
        });
      }

      setMessageText('');
      setReplyingTo(null);
      triggerHaptic();
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };

  const handleReply = (message: any) => {
    setReplyingTo(message);
    setLongPressedMessage(null);
    triggerHaptic();
  };

  const handleEdit = (message: any) => {
    setEditingMessage(message);
    setMessageText(message.text);
    setLongPressedMessage(null);
    triggerHaptic();
  };

  const handleDelete = async (message: any) => {
    setLongPressedMessage(null);

    Alert.alert(
      language === 'ru' ? 'Удалить сообщение?' : 'Delete message?',
      language === 'ru' ? 'Это действие нельзя отменить' : 'This action cannot be undone',
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
        },
        {
          text: language === 'ru' ? 'Удалить' : 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { supabase } = await import('@/lib/supabase');
              const { error } = await supabase
                .from('messages')
                .delete()
                .eq('id', message.id);

              if (error) throw error;

              triggerHaptic();

              // CRITICAL: Update cache immediately by removing message from list
              queryClient.setQueryData(['messages', realConversationId], (oldData: any[] | undefined) => {
                if (!oldData) return oldData;
                return oldData.filter((msg: any) => msg.id !== message.id);
              });

              // Also invalidate to sync with server
              queryClient.invalidateQueries({ queryKey: ['messages', realConversationId] });
              queryClient.invalidateQueries({ queryKey: ['conversations'] });
            } catch (error) {
              console.error('Failed to delete message:', error);
              Alert.alert(
                language === 'ru' ? 'Ошибка' : 'Error',
                language === 'ru' ? 'Не удалось удалить сообщение' : 'Failed to delete message'
              );
            }
          },
        },
      ]
    );
  };

  const handleEmojiReaction = async (message: any, emoji: string) => {
    setLongPressedMessage(null);
    triggerHaptic();

    try {
      const { supabase } = await import('@/lib/supabase');

      // Check if user already reacted with this emoji
      const { data: existing } = await supabase
        .from('message_reactions')
        .select('*')
        .eq('message_id', message.id)
        .eq('user_id', currentUserId)
        .eq('emoji', emoji)
        .maybeSingle();

      if (existing) {
        // Remove reaction
        await supabase
          .from('message_reactions')
          .delete()
          .eq('id', existing.id);
      } else {
        // Add reaction
        await supabase
          .from('message_reactions')
          .insert({
            message_id: message.id,
            user_id: currentUserId,
            emoji,
          });
      }
    } catch (error) {
      console.error('Failed to add reaction:', error);
    }
  };

  const otherUserAvatar = username ? generateAvatar(username) : '💬';

  // Open user profile
  const openProfile = () => {
    if (userId) {
      triggerHaptic();
      router.push(`/user/${userId}`);
    }
  };

  // If trying to chat with self, show error screen
  if (isSelfChat) {
    return (
      <View style={{ flex: 1, backgroundColor: theme.colors.background, alignItems: 'center', justifyContent: 'center', padding: 20 }}>
        <Text style={{ color: theme.colors.text, fontSize: 18, textAlign: 'center', marginBottom: 20 }}>
          {language === 'ru' ? 'Нельзя отправлять сообщения самому себе' : 'Cannot send messages to yourself'}
        </Text>
        <Pressable
          onPress={() => router.back()}
          style={{
            paddingHorizontal: 24,
            paddingVertical: 12,
            backgroundColor: theme.colors.accent,
            borderRadius: 20,
          }}
        >
          <Text style={{ color: theme.colors.primary, fontWeight: '600' }}>
            {language === 'ru' ? 'Назад' : 'Go Back'}
          </Text>
        </Pressable>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      {/* Top Gradient Overlay - BIGGER for messages to scroll behind */}
      <LinearGradient
        colors={['rgba(0,0,0,0.6)', 'rgba(0,0,0,0.4)', 'rgba(0,0,0,0.2)', 'transparent']}
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          height: insets.top + 120, // Increased from 80 to 120
          zIndex: 99,
          pointerEvents: 'none',
        }}
      />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 40 : 20}
      >
        {/* Floating glass buttons - MAXIMALLY RAISED (iOS 26 compatible) */}
        <View style={{
          position: 'absolute',
          top: insets.top - 20,
          left: 0,
          right: 0,
          zIndex: 100,
          paddingHorizontal: 16,
          minHeight: 44,
        }}>
          {/* Container for buttons */}
          <View style={{
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            {/* Avatar and Username - Rounded Glass Container - CLICKABLE */}
            <Pressable
              onPress={openProfile}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: 8,
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 20,
                backgroundColor: `${theme.colors.primaryLight}E0`,
                borderWidth: 1,
                borderColor: `${theme.colors.text}10`,
              }}
            >
            {Platform.OS === 'ios' ? (
              <BlurView
                intensity={30}
                tint="dark"
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  borderRadius: 20,
                  overflow: 'hidden',
                }}
              />
            ) : null}
            <Text style={{ fontSize: 22, lineHeight: 26 }}>{otherUserAvatar}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <ColoredUsername
                username={username || (language === 'ru' ? 'Чат' : 'Chat')}
                color={otherUserProfile?.username_color || null}
                size={14}
                weight="600"
                defaultColor={theme.colors.text}
              />
              <VerifiedBadge isVerified={otherUserProfile?.is_verified === true} size={14} checkColor={theme.colors.primary} />
            </View>
          </Pressable>

          {/* Loading/Typing Indicator - Centered between buttons */}
          {(isCheckingConversation || isLoadingMessages || isOtherUserTyping) && (
            <View style={{
              position: 'absolute',
              left: 0,
              right: 0,
              alignItems: 'center',
              pointerEvents: 'none',
            }}>
              <View style={{
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 20,
                backgroundColor: `${theme.colors.primaryLight}E0`,
                borderWidth: 1,
                borderColor: `${theme.colors.text}10`,
              }}>
                {Platform.OS === 'ios' ? (
                  <BlurView
                    intensity={30}
                    tint="dark"
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      borderRadius: 20,
                      overflow: 'hidden',
                    }}
                  />
                ) : null}
                {isOtherUserTyping ? (
                  <Text style={{
                    color: theme.colors.text,
                    fontSize: 12,
                    fontWeight: '500',
                  }}>
                    {language === 'ru' ? 'печатает' : 'typing'}
                  </Text>
                ) : (
                  <ActivityIndicator size="small" color={theme.colors.accent} />
                )}
              </View>
            </View>
          )}

          {/* Close Button - Rounded Glass */}
          <Pressable
            onPress={() => {
              triggerHaptic();
              router.back();
            }}
            style={{
              width: 36,
              height: 36,
              alignItems: 'center',
              justifyContent: 'center',
              borderRadius: 18,
              backgroundColor: `${theme.colors.primaryLight}E0`,
              borderWidth: 1,
              borderColor: `${theme.colors.text}10`,
            }}
          >
            {Platform.OS === 'ios' ? (
              <BlurView
                intensity={30}
                tint="dark"
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 0,
                  right: 0,
                  bottom: 0,
                  borderRadius: 18,
                  overflow: 'hidden',
                }}
              />
            ) : null}
            <X size={18} color={theme.colors.text} strokeWidth={2.5} />
          </Pressable>
          </View>
        </View>

        {/* Messages List */}
        <FlatList
          ref={flatListRef}
          data={Array.isArray(messages) ? messages : []}
          keyExtractor={(item) => item.id}
          inverted
          renderItem={({ item }) => (
            <MessageItem
              item={item}
              isMe={item.sender_id === currentUserId}
              messages={messages}
              theme={theme}
              language={language}
              onLongPress={(msg: any) => {
                setLongPressedMessage(msg);
                triggerHaptic();
              }}
            />
          )}
          contentContainerStyle={{ paddingTop: 8, paddingBottom: insets.top + 100 }} // Increased bottom padding for header
          showsVerticalScrollIndicator={false}
          keyboardDismissMode="interactive"
          removeClippedSubviews={true}
          maxToRenderPerBatch={10}
          windowSize={21}
          initialNumToRender={15}
          ListEmptyComponent={
            <View style={{ padding: 40, alignItems: 'center' }}>
              <Text style={{ color: `${theme.colors.text}60`, fontSize: 16, textAlign: 'center' }}>
                {language === 'ru'
                  ? 'Нет сообщений. Начните разговор!'
                  : 'No messages yet. Start the conversation!'}
              </Text>
            </View>
          }
        />

        {/* Long Press Menu - Compact with Message */}
        {longPressedMessage && (
          <>
            {/* Backdrop */}
            <Pressable
              onPress={() => setLongPressedMessage(null)}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: 'rgba(0,0,0,0.6)',
                zIndex: 1000,
              }}
            />

            {/* Compact Menu */}
            <Animated.View
              entering={FadeInDown.duration(200).springify()}
              exiting={FadeOut.duration(150)}
              style={{
                position: 'absolute',
                bottom: insets.bottom + 120,
                left: 20,
                right: 20,
                zIndex: 1001,
                alignItems: 'center',
              }}
            >
              <View
                style={{
                  backgroundColor: theme.colors.primaryLight,
                  borderRadius: 16,
                  padding: 8,
                  width: '100%',
                  maxWidth: 280,
                  borderWidth: 1,
                  borderColor: `${theme.colors.text}20`,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 8 },
                  shadowOpacity: 0.3,
                  shadowRadius: 16,
                  elevation: 12,
                }}
              >
                {Platform.OS === 'ios' ? (
                  <BlurView
                    intensity={40}
                    tint="dark"
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      right: 0,
                      bottom: 0,
                      borderRadius: 16,
                      overflow: 'hidden',
                    }}
                  />
                ) : null}

                {/* Action buttons - compact */}
                <View style={{ gap: 4 }}>
                  {/* Reply */}
                  <Pressable
                    onPress={() => handleReply(longPressedMessage)}
                    style={{
                      flexDirection: 'row',
                      alignItems: 'center',
                      paddingVertical: 12,
                      paddingHorizontal: 16,
                      borderRadius: 12,
                      gap: 12,
                    }}
                  >
                    <Reply size={20} color={theme.colors.accent} strokeWidth={2} />
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                      {language === 'ru' ? 'Ответить' : 'Reply'}
                    </Text>
                  </Pressable>

                  {/* Edit (only for own messages) */}
                  {longPressedMessage.sender_id === currentUserId && (
                    <Pressable
                      onPress={() => handleEdit(longPressedMessage)}
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        paddingVertical: 12,
                        paddingHorizontal: 16,
                        borderRadius: 12,
                        gap: 12,
                      }}
                    >
                      <Edit3 size={20} color={theme.colors.accent} strokeWidth={2} />
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {language === 'ru' ? 'Редактировать' : 'Edit'}
                      </Text>
                    </Pressable>
                  )}

                  {/* Delete (only for own messages) */}
                  {longPressedMessage.sender_id === currentUserId && (
                    <Pressable
                      onPress={() => handleDelete(longPressedMessage)}
                      style={{
                        flexDirection: 'row',
                        alignItems: 'center',
                        paddingVertical: 12,
                        paddingHorizontal: 16,
                        borderRadius: 12,
                        gap: 12,
                      }}
                    >
                      <Trash2 size={20} color="#FF4444" strokeWidth={2} />
                      <Text style={{ color: '#FF4444', fontSize: 16, fontWeight: '500' }}>
                        {language === 'ru' ? 'Удалить' : 'Delete'}
                      </Text>
                    </Pressable>
                  )}
                </View>
              </View>
            </Animated.View>
          </>
        )}

        {/* Input Field */}
        <View style={{ backgroundColor: theme.colors.background }}>
          {/* Reply/Edit indicator */}
          {(replyingTo || editingMessage) && (
            <Animated.View
              entering={FadeInDown.duration(200)}
              style={{
                paddingHorizontal: 16,
                paddingVertical: 8,
                backgroundColor: `${theme.colors.accent}20`,
                borderTopWidth: 1,
                borderTopColor: `${theme.colors.accent}40`,
                flexDirection: 'row',
                alignItems: 'center',
                justifyContent: 'space-between',
              }}
            >
              <View style={{ flex: 1 }}>
                <Text style={{ color: theme.colors.accent, fontSize: 12, fontWeight: '600', marginBottom: 2 }}>
                  {editingMessage
                    ? (language === 'ru' ? 'Редактирование' : 'Editing')
                    : (language === 'ru' ? 'Ответ на' : 'Replying to')}
                </Text>
                <Text style={{ color: theme.colors.text, fontSize: 14 }} numberOfLines={1}>
                  {(replyingTo || editingMessage)?.text}
                </Text>
              </View>
              <Pressable
                onPress={() => {
                  setReplyingTo(null);
                  setEditingMessage(null);
                  setMessageText('');
                }}
                style={{ padding: 4 }}
              >
                <X size={20} color={theme.colors.textSecondary} />
              </Pressable>
            </Animated.View>
          )}

          <View
            style={{
              paddingHorizontal: 16,
              paddingTop: 12,
              paddingBottom: Math.max(insets.bottom, 12),
              flexDirection: 'row',
              alignItems: 'flex-end',
              gap: 8,
            }}
          >
            <TextInput
              value={messageText}
              onChangeText={handleTextChange}
              placeholder={
                editingMessage
                  ? (language === 'ru' ? 'Редактировать...' : 'Edit...')
                  : (language === 'ru' ? 'Сообщение...' : 'Message...')
              }
              placeholderTextColor={`${theme.colors.text}40`}
              style={{
                flex: 1,
                backgroundColor: theme.colors.primaryLight,
                borderRadius: 20,
                paddingHorizontal: 16,
                paddingVertical: 10,
                color: theme.colors.text,
                fontSize: 16,
                maxHeight: 100,
              }}
              multiline
              maxLength={500}
            />
            <Pressable
              onPress={handleSend}
              disabled={!messageText.trim() || sendMessage.isPending || createConversation.isPending}
              style={{
                width: 40,
                height: 40,
                borderRadius: 20,
                backgroundColor: messageText.trim() ? theme.colors.accent : theme.colors.primaryLight,
                alignItems: 'center',
                justifyContent: 'center',
                marginBottom: 2,
              }}
            >
              <Send
                size={18}
                color={messageText.trim() ? theme.colors.primary : `${theme.colors.text}40`}
                strokeWidth={2.5}
              />
            </Pressable>
          </View>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
