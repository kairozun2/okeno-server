import React from 'react';
import { View, Text, FlatList, Pressable, Dimensions } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Search, Bell } from 'lucide-react-native';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useMemories } from '@/lib/supabase-hooks';
import { MemoryCard } from '@/components/MemoryCard';
import { FloatingActionButton } from '@/components/FloatingActionButton';
import * as Haptics from 'expo-haptics';

const { width: SCREEN_WIDTH } = Dimensions.get('window');

export default function ExploreScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const { data: memories = [] } = useMemories();

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Approximate card height for getItemLayout optimization
  const CARD_HEIGHT = SCREEN_WIDTH + 100;

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={{ paddingTop: insets.top + 16, paddingHorizontal: 20, paddingBottom: 16 }}>
          <Animated.View
            entering={FadeIn.duration(300)}
            style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
          >
            <Text style={{ color: theme.colors.text, fontSize: 28, fontWeight: '700' }}>
              {language === 'ru' ? 'Поиск' : 'Explore'}
            </Text>
            <View style={{ flexDirection: 'row', gap: 12 }}>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.push('/search-users');
                }}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: `${theme.colors.accent}20`,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Search size={20} color={theme.colors.accent} strokeWidth={2} />
              </Pressable>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.push('/notifications');
                }}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: `${theme.colors.accent}20`,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Bell size={20} color={theme.colors.accent} strokeWidth={2} />
              </Pressable>
            </View>
          </Animated.View>
        </View>

        {/* Feed */}
        <FlatList
          data={memories}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <MemoryCard memory={item} />}
          contentContainerStyle={{ paddingBottom: insets.bottom + 100, paddingTop: 8 }}
          showsVerticalScrollIndicator={false}
          removeClippedSubviews={true}
          maxToRenderPerBatch={3}
          updateCellsBatchingPeriod={100}
          initialNumToRender={5}
          windowSize={7}
          getItemLayout={(data, index) => ({
            length: CARD_HEIGHT,
            offset: CARD_HEIGHT * index,
            index,
          })}
          ListEmptyComponent={
            <View style={{ padding: 40, alignItems: 'center' }}>
              <Text style={{ color: `${theme.colors.text}60`, fontSize: 16, textAlign: 'center' }}>
                {language === 'ru'
                  ? 'Пока нет воспоминаний для изучения'
                  : 'No memories to explore yet'}
              </Text>
            </View>
          }
        />

        {/* Floating Action Button */}
        <FloatingActionButton />
      </LinearGradient>
    </View>
  );
}
