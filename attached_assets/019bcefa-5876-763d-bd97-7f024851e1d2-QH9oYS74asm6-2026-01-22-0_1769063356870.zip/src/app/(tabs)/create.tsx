import { View } from 'react-native';

// This is a placeholder - navigation handled by listener
export default function CreateScreen() {
  return <View />;
}
