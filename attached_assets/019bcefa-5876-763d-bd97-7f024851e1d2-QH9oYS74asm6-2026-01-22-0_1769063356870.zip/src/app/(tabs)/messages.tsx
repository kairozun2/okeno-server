import React, { useEffect } from 'react';
import { View, Text, FlatList, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Search, MessageCircle, Edit3 } from 'lucide-react-native';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { useQueryClient } from '@tanstack/react-query';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useConversations, useAuth } from '@/lib/supabase-hooks';
import { generateAvatar } from '@/lib/avatar';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ColoredUsername } from '@/components/ColoredUsername';
import * as Haptics from 'expo-haptics';
import { ChatActionsModal } from '@/components/ChatActionsModal';
import { supabase } from '@/lib/supabase';

export default function MessagesScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const queryClient = useQueryClient();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const { data: conversations = [] } = useConversations();
  const { data: auth } = useAuth();
  const currentUserId = auth?.session?.user?.id;

  const [showChatActions, setShowChatActions] = React.useState(false);

  // 🚀 PREFETCH: Automatically prefetch messages for the first conversation
  // With Pro plan (250 GB bandwidth), we can afford aggressive prefetching!
  useEffect(() => {
    if (conversations.length > 0) {
      const firstConversation = conversations[0];
      console.log('[Messages] Prefetching messages for first conversation:', firstConversation.id);

      // Prefetch messages in background (won't trigger loading state)
      queryClient.prefetchQuery({
        queryKey: ['messages', firstConversation.id],
        queryFn: async () => {
          const { data, error } = await supabase
            .from('messages')
            .select('*')
            .eq('conversation_id', firstConversation.id)
            .order('created_at', { ascending: false })
            .limit(50);

          if (error) throw error;
          return data || [];
        },
        staleTime: 30 * 60 * 1000, // 30 minutes (Pro plan!)
      });
    }
  }, [conversations, queryClient]);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  return (
    <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={{ paddingTop: insets.top + 16, paddingHorizontal: 20, paddingBottom: 16 }}>
          <Animated.View
            entering={FadeIn.duration(300)}
            style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}
          >
            <Text style={{ color: theme.colors.text, fontSize: 28, fontWeight: '700' }}>
              {language === 'ru' ? 'Сообщения' : 'Messages'}
            </Text>
            <View style={{ flexDirection: 'row', gap: 12 }}>
              {/* Edit/Manage Button */}
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  setShowChatActions(true);
                }}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: `${theme.colors.accent}20`,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Edit3 size={20} color={theme.colors.accent} strokeWidth={2} />
              </Pressable>
              {/* Search Button */}
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  router.push('/search-users');
                }}
                style={{
                  width: 40,
                  height: 40,
                  borderRadius: 20,
                  backgroundColor: `${theme.colors.accent}20`,
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                <Search size={20} color={theme.colors.accent} strokeWidth={2} />
              </Pressable>
            </View>
          </Animated.View>
        </View>

        {/* Conversations List or Empty State */}
        {conversations.length === 0 ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 40 }}>
            <MessageCircle size={64} color={`${theme.colors.text}40`} strokeWidth={1.5} />
            <Text style={{ color: `${theme.colors.text}60`, fontSize: 18, fontWeight: '600', marginTop: 16, textAlign: 'center' }}>
              {language === 'ru' ? 'Нет сообщений' : 'No messages'}
            </Text>
            <Text style={{ color: `${theme.colors.text}40`, fontSize: 14, marginTop: 8, textAlign: 'center' }}>
              {language === 'ru' ? 'Начните общаться с друзьями' : 'Start chatting with friends'}
            </Text>
          </View>
        ) : (
          <FlatList
            data={conversations}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => {
              // Determine which user is the "other" user in the conversation
              const otherUser = item.user1_id === currentUserId ? item.user2 : item.user1;
              const avatarEmoji = otherUser?.avatar_emoji || generateAvatar(otherUser?.username || '');
              const username = otherUser?.username || 'Unknown';
              const unreadCount = (item as any).unread_count || 0;

              return (
                <Pressable
                  onPress={() => {
                    triggerHaptic();
                    router.push({
                      pathname: '/chat',
                      params: {
                        id: item.id,
                        userId: otherUser?.id,
                        username,
                      },
                    });
                  }}
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: 16,
                    marginHorizontal: 16,
                    marginBottom: 8,
                    borderRadius: 16,
                    backgroundColor: unreadCount > 0 ? `${theme.colors.accent}15` : `${theme.colors.primaryLight}80`,
                  }}
                >
                  {/* Avatar with Badge */}
                  <View style={{ position: 'relative', marginRight: 12 }}>
                    <Text style={{ fontSize: 28 }}>{avatarEmoji}</Text>
                    {unreadCount > 0 && (
                      <View
                        style={{
                          position: 'absolute',
                          top: -2,
                          right: -2,
                          backgroundColor: '#FF3B30',
                          borderRadius: 8,
                          minWidth: 16,
                          height: 16,
                          alignItems: 'center',
                          justifyContent: 'center',
                          paddingHorizontal: 4,
                        }}
                      >
                        <Text style={{ color: '#FFFFFF', fontSize: 10, fontWeight: '700' }}>
                          {unreadCount > 9 ? '9+' : unreadCount}
                        </Text>
                      </View>
                    )}
                  </View>

                  {/* Info */}
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4, marginBottom: 4 }}>
                      <ColoredUsername
                        username={username}
                        color={otherUser?.username_color}
                        size={17}
                        weight={unreadCount > 0 ? '700' : '600'}
                        defaultColor={theme.colors.text}
                      />
                      <VerifiedBadge isVerified={otherUser?.is_verified === true} size={14} checkColor={theme.colors.primary} />
                    </View>
                    <Text
                      style={{
                        color: unreadCount > 0 ? `${theme.colors.text}90` : `${theme.colors.text}70`,
                        fontSize: 14,
                        fontWeight: unreadCount > 0 ? '600' : '400',
                      }}
                      numberOfLines={1}
                    >
                      {item.last_message || (language === 'ru' ? 'Нажмите для чата' : 'Tap to chat')}
                    </Text>
                  </View>

                  {/* Icon or Unread Badge */}
                  {unreadCount > 0 ? (
                    <View
                      style={{
                        backgroundColor: '#FF3B30',
                        borderRadius: 12,
                        minWidth: 24,
                        height: 24,
                        alignItems: 'center',
                        justifyContent: 'center',
                        paddingHorizontal: 6,
                      }}
                    >
                      <Text style={{ color: '#FFFFFF', fontSize: 12, fontWeight: '700' }}>
                        {unreadCount > 9 ? '9+' : unreadCount}
                      </Text>
                    </View>
                  ) : (
                    <MessageCircle size={20} color={`${theme.colors.text}40`} strokeWidth={1.5} />
                  )}
                </Pressable>
              );
            }}
            contentContainerStyle={{ paddingBottom: insets.bottom + 100, paddingTop: 8 }}
            showsVerticalScrollIndicator={false}
          />
        )}
      </LinearGradient>

      {/* Chat Actions Modal */}
      <ChatActionsModal visible={showChatActions} onClose={() => setShowChatActions(false)} />
    </View>
  );
}
