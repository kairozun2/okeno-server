import React, { useState, useCallback, useRef, useEffect, useMemo } from 'react';
import { View, Text, FlatList, RefreshControl, Pressable, ViewToken, Platform } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import Animated, {
  FadeIn,
  FadeOut,
  useAnimatedScrollHandler,
  useSharedValue,
  useAnimatedStyle,
  interpolate,
  Extrapolate,
  withTiming,
  withSpring,
} from 'react-native-reanimated';
import { Search, Bell, Plus } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { MemoryCard } from '@/components/MemoryCard';
import { CreateMemoryModal } from '@/components/CreateMemoryModal';
import { NotificationsModal } from '@/components/NotificationsModal';
import { SearchUsersModal } from '@/components/SearchUsersModal';
import { MemoryDetailModal } from '@/components/MemoryDetailModal';
import { CommentsModal } from '@/components/CommentsModal';
import * as Haptics from 'expo-haptics';
import { useMemories, useNotifications, useAuth } from '@/lib/supabase-hooks';

const AnimatedFlatList = Animated.createAnimatedComponent(FlatList);

export default function HomeScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [refreshing, setRefreshing] = useState(false);
  const [visibleMemoryId, setVisibleMemoryId] = useState<string | null>(null);
  const [showStatusIndicator, setShowStatusIndicator] = useState(false);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showNotificationsModal, setShowNotificationsModal] = useState(false);
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [showMemoryDetailModal, setShowMemoryDetailModal] = useState(false);
  const [showCommentsModal, setShowCommentsModal] = useState(false);
  const [selectedMemoryId, setSelectedMemoryId] = useState<string | null>(null);
  const scrollY = useSharedValue(0);
  const greetingOpacity = useSharedValue(1);
  const plusButtonOpacity = useSharedValue(0);

  // Use Supabase hook for memories
  const { data: memories = [], isLoading, refetch, isFetching } = useMemories();
  const { data: notifications = [] } = useNotifications();
  const { data: auth } = useAuth();
  const unreadCount = notifications.filter(n => !n.read).length;
  const isOnline = true; // Supabase is always "online"

  const userName = useAppStore(s => s.userName);
  const currentUserId = auth?.session?.user?.id;

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  // CRITICAL: Show skeleton when loading OR when fetching with no data
  // This prevents "No memories" flash for new users
  const shouldShowSkeleton = (isLoading || isFetching) && memories.length === 0;

  // Local haptic function that checks settings
  const triggerHaptic = (style: Haptics.ImpactFeedbackStyle = Haptics.ImpactFeedbackStyle.Light) => {
    if (hapticsEnabled) {
      Haptics.impactAsync(style);
    }
  };

  // Show status indicator for 3 seconds when loading or refreshing
  React.useEffect(() => {
    if (shouldShowSkeleton || refreshing) {
      setShowStatusIndicator(true);
      const timer = setTimeout(() => {
        setShowStatusIndicator(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [shouldShowSkeleton, refreshing]);

  // Handle initial load - show indicator for first 3 seconds
  React.useEffect(() => {
    if (isInitialLoad && !shouldShowSkeleton) {
      const timer = setTimeout(() => {
        setIsInitialLoad(false);
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [isInitialLoad, shouldShowSkeleton]);

  // Greeting animation - simultaneous fade after 3 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      greetingOpacity.value = withTiming(0, { duration: 500 });
      plusButtonOpacity.value = withTiming(1, { duration: 500 });
    }, 3000);
    return () => clearTimeout(timer);
  }, []);

  const onRefresh = () => {
    setRefreshing(true);
    // Refetch from API if online
    if (refetch) {
      refetch().finally(() => setRefreshing(false));
    } else {
      setTimeout(() => setRefreshing(false), 1000);
    }
  };

  // Track viewability changes - Instagram-like behavior
  const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    // Find the most visible video (closest to center, >70% visible)
    const visibleVideo = viewableItems.find(
      (item) => item.isViewable && item.item.imageUrl &&
      (item.item.imageUrl.endsWith('.mp4') ||
       item.item.imageUrl.endsWith('.mov') ||
       item.item.imageUrl.endsWith('.m4v') ||
       item.item.imageUrl.includes('video'))
    );

    if (visibleVideo) {
      setVisibleMemoryId(visibleVideo.item.id);
    } else {
      setVisibleMemoryId(null);
    }
  }).current;

  const viewabilityConfig = useRef({
    itemVisiblePercentThreshold: 70, // 70% visible
    minimumViewTime: 100, // 100ms
  }).current;

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  // Animated blur header opacity
  const headerBlurStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 60],
      [0, 1],
      Extrapolate.CLAMP
    );
    return { opacity };
  });

  // Animated title in header
  const headerTitleStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [60, 100],
      [0, 1],
      Extrapolate.CLAMP
    );
    const translateY = interpolate(
      scrollY.value,
      [60, 100],
      [10, 0],
      Extrapolate.CLAMP
    );
    return { opacity, transform: [{ translateY }] };
  });

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return t('greeting.morning');
    if (hour < 17) return t('greeting.afternoon');
    return t('greeting.evening');
  };

  // Animated styles for simultaneous fade
  const greetingAnimatedStyle = useAnimatedStyle(() => ({
    opacity: greetingOpacity.value,
  }));

  const plusButtonAnimatedStyle = useAnimatedStyle(() => ({
    opacity: plusButtonOpacity.value,
  }));

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        <AnimatedFlatList
          data={memories}
          keyExtractor={(item: any) => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 100, paddingTop: insets.top + 60 }}
          onScroll={scrollHandler}
          scrollEventThrottle={16}
          onViewableItemsChanged={onViewableItemsChanged}
          viewabilityConfig={viewabilityConfig}
          // Performance optimizations
          removeClippedSubviews={true}
          maxToRenderPerBatch={5}
          windowSize={7}
          initialNumToRender={3}
          updateCellsBatchingPeriod={50}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              tintColor={theme.colors.accent}
              progressViewOffset={insets.top + 60}
            />
          }
          ListHeaderComponent={
            <View className="px-5 mb-4">
              <Text style={{ color: theme.colors.textSecondary, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2 }}>
                {t('home.memories').split(' ').slice(-1).join(' ')}
              </Text>
            </View>
          }
          renderItem={({ item }: any) => (
            <MemoryCard
              memory={item}
              enableAutoplay={item.id === visibleMemoryId}
              onPress={() => {
                // Pause all videos before opening detail
                setVisibleMemoryId(null);
                triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                setSelectedMemoryId(item.id);
                setShowMemoryDetailModal(true);
              }}
            />
          )}
          ListEmptyComponent={
            !shouldShowSkeleton ? (
              <Animated.View
                entering={FadeIn.duration(300)}
                className="items-center py-20 px-8"
              >
                <Text style={{ color: theme.colors.textSecondary, textAlign: 'center', fontSize: 16, lineHeight: 24 }}>
                  {t('home.empty')}
                </Text>
              </Animated.View>
            ) : (
              <View className="px-5">
                {[1, 2, 3].map((i) => (
                  <Animated.View
                    key={i}
                    entering={FadeIn.duration(300).delay(i * 100)}
                    className="mb-6 rounded-3xl overflow-hidden"
                    style={{ backgroundColor: `${theme.colors.primaryLight}80` }}
                  >
                    {/* Skeleton Card */}
                    <View>
                      {/* Header Skeleton */}
                      <View className="flex-row items-center p-4">
                        <View
                          className="w-10 h-10 rounded-full"
                          style={{ backgroundColor: `${theme.colors.text}20` }}
                        />
                        <View className="ml-3 flex-1">
                          <View
                            className="h-4 rounded"
                            style={{ backgroundColor: `${theme.colors.text}20`, width: '40%', marginBottom: 6 }}
                          />
                          <View
                            className="h-3 rounded"
                            style={{ backgroundColor: `${theme.colors.text}15`, width: '25%' }}
                          />
                        </View>
                      </View>

                      {/* Image Skeleton */}
                      <View
                        className="w-full"
                        style={{ height: 300, backgroundColor: `${theme.colors.text}15` }}
                      />

                      {/* Caption Skeleton */}
                      <View className="p-4">
                        <View
                          className="h-3 rounded mb-2"
                          style={{ backgroundColor: `${theme.colors.text}20`, width: '90%' }}
                        />
                        <View
                          className="h-3 rounded"
                          style={{ backgroundColor: `${theme.colors.text}15`, width: '60%' }}
                        />
                      </View>
                    </View>
                  </Animated.View>
                ))}
              </View>
            )
          }
        />

        {/* Fixed Header with Blur */}
        <Animated.View
          style={[
            {
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              zIndex: 100,
            },
            headerBlurStyle,
          ]}
          pointerEvents="none"
        >
          {Platform.OS === 'ios' ? (
            <BlurView
              intensity={40}
              tint="dark"
              style={{
                paddingTop: insets.top + 8,
                paddingBottom: 12,
                paddingHorizontal: 20,
                backgroundColor: `${theme.colors.primary}CC`,
              }}
            >
              <View style={{ height: 40 }} />
            </BlurView>
          ) : (
            <View
              style={{
                paddingTop: insets.top + 8,
                paddingBottom: 12,
                paddingHorizontal: 20,
                backgroundColor: `${theme.colors.primary}F0`,
              }}
            >
              <View style={{ height: 40 }} />
            </View>
          )}
        </Animated.View>

        {/* Animated Title in Header with Connection Indicator */}
        <Animated.View
          style={[
            {
              position: 'absolute',
              top: insets.top + 8,
              left: 0,
              right: 0,
              zIndex: 102,
              alignItems: 'center',
              justifyContent: 'center',
              height: 40,
            },
            headerTitleStyle,
          ]}
          pointerEvents="none"
        >
          {!isOnline ? (
            <View
              className="flex-row items-center px-3 py-1.5 rounded-full"
              style={{ backgroundColor: `${theme.colors.accent}30` }}
            >
              <View
                style={{
                  width: 6,
                  height: 6,
                  borderRadius: 3,
                  backgroundColor: theme.colors.accent,
                  marginRight: 6
                }}
              />
              <Text style={{ color: theme.colors.accent, fontSize: 12, fontWeight: '600' }}>
                {language === 'ru' ? 'Подключение...' : 'Connecting...'}
              </Text>
            </View>
          ) : (
            <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '600' }}>
              {t('home.memories').split(' ').slice(-1).join(' ')}
            </Text>
          )}
        </Animated.View>

        {/* Fixed Top Buttons */}
        <View
          style={{
            position: 'absolute',
            top: insets.top + 8,
            left: 0,
            right: 0,
            zIndex: 101,
            paddingHorizontal: 20,
          }}
        >
          <Animated.View entering={FadeIn.duration(300)} className="flex-row items-center justify-between">
            {/* Greeting and + Button - simultaneous fade */}
            <View style={{ position: 'relative', width: 40, height: 40 }}>
              {/* Greeting - CLICKABLE */}
              <Animated.View style={[{ position: 'absolute', left: 0, top: 0, width: 200 }, greetingAnimatedStyle]}>
                <Pressable
                  onPress={() => {
                    if (currentUserId) {
                      triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                      router.push(`/user/${currentUserId}`);
                    }
                  }}
                  className="active:opacity-70"
                >
                  <Text style={{ color: theme.colors.textSecondary, fontSize: 12 }}>
                    {getGreeting()}
                  </Text>
                  <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '500', marginTop: 2 }}>
                    {userName || t('home.friend')}
                  </Text>
                </Pressable>
              </Animated.View>

              {/* Plus Button */}
              <Animated.View style={[{ position: 'absolute', left: 0, top: 0 }, plusButtonAnimatedStyle]}>
                <Pressable
                  onPress={() => {
                    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                    setShowCreateModal(true);
                  }}
                  className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                  style={{
                    backgroundColor: `${theme.colors.accent}20`,
                    shadowColor: '#000',
                    shadowOffset: { width: 0, height: 2 },
                    shadowOpacity: 0.1,
                    shadowRadius: 4,
                  }}
                >
                  <Plus size={20} color={theme.colors.accent} strokeWidth={1.5} />
                </Pressable>
              </Animated.View>
            </View>

            <View className="flex-row items-center" style={{ gap: 12 }}>
              <Pressable
                onPress={() => {
                  triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                  setShowNotificationsModal(true);
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{
                  backgroundColor: `${theme.colors.accent}20`,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                }}
              >
                <Bell size={20} color={theme.colors.accent} strokeWidth={1.5} />
                {unreadCount > 0 && (
                  <View
                    className="absolute -top-1 -right-1 rounded-full items-center justify-center"
                    style={{
                      backgroundColor: '#FF3B30',
                      minWidth: 16,
                      height: 16,
                      paddingHorizontal: 4,
                    }}
                  >
                    <Text
                      style={{
                        color: '#FFFFFF',
                        fontSize: 10,
                        fontWeight: '700',
                        lineHeight: 16,
                      }}
                    >
                      {unreadCount > 99 ? '99' : unreadCount}
                    </Text>
                  </View>
                )}
              </Pressable>
              <Pressable
                onPress={() => {
                  triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                  setShowSearchModal(true);
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{
                  backgroundColor: `${theme.colors.accent}20`,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 4,
                }}
              >
                <Search size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </View>
          </Animated.View>
        </View>
      </LinearGradient>

      {/* Create Memory Modal */}
      <CreateMemoryModal
        visible={showCreateModal}
        onClose={() => setShowCreateModal(false)}
      />

      {/* Notifications Modal */}
      <NotificationsModal
        visible={showNotificationsModal}
        onClose={() => setShowNotificationsModal(false)}
        onNotificationPress={(memoryId) => {
          router.push(`/memory-detail?id=${memoryId}`);
        }}
      />

      {/* Search Users Modal */}
      <SearchUsersModal
        visible={showSearchModal}
        onClose={() => setShowSearchModal(false)}
        onUserPress={(userId) => {
          router.push(`/user/${userId}`);
        }}
      />

      {/* Memory Detail Modal */}
      {selectedMemoryId && (
        <MemoryDetailModal
          visible={showMemoryDetailModal}
          onClose={() => setShowMemoryDetailModal(false)}
          memoryId={selectedMemoryId}
          onCommentsPress={(memoryId) => {
            setShowMemoryDetailModal(false);
            setTimeout(() => {
              setSelectedMemoryId(memoryId);
              setShowCommentsModal(true);
            }, 300);
          }}
          onPremiumPress={() => {
            router.push('/premium');
          }}
        />
      )}

      {/* Comments Modal */}
      {selectedMemoryId && (
        <CommentsModal
          visible={showCommentsModal}
          onClose={() => setShowCommentsModal(false)}
          memoryId={selectedMemoryId}
          onPremiumPress={() => {
            router.push('/premium');
          }}
        />
      )}
    </View>
  );
}
