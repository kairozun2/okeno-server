import React from 'react';
import { View, Text } from 'react-native';
import { Tabs, useRouter } from 'expo-router';
import { Home, MessageCircle, User } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { useConversations } from '@/lib/supabase-hooks';

export default function TabLayout() {
  const router = useRouter();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  // Get total unread count
  const { data: conversations = [] } = useConversations();
  const totalUnread = conversations.reduce((sum, conv: any) => sum + (conv.unread_count || 0), 0);

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: theme.colors.primaryDark,
          borderTopColor: `${theme.colors.text}10`,
          borderTopWidth: 1,
          height: 82,
          paddingBottom: 26,
          paddingTop: 8,
        },
        tabBarActiveTintColor: theme.colors.accent,
        tabBarInactiveTintColor: `${theme.colors.text}40`,
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: '500',
          marginTop: 2,
        },
        tabBarIconStyle: {
          marginTop: 2,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: language === 'ru' ? 'Главная' : 'Home',
          tabBarIcon: ({ color, focused }) => (
            <Home size={24} color={color} strokeWidth={focused ? 2 : 1.5} />
          ),
        }}
      />
      <Tabs.Screen
        name="messages"
        options={{
          title: language === 'ru' ? 'Чаты' : 'Chats',
          tabBarIcon: ({ color, focused }) => (
            <View style={{ position: 'relative' }}>
              <MessageCircle size={24} color={color} strokeWidth={focused ? 2 : 1.5} />
              {totalUnread > 0 && (
                <View
                  style={{
                    position: 'absolute',
                    top: -4,
                    right: -8,
                    backgroundColor: '#FF3B30',
                    borderRadius: 10,
                    minWidth: 18,
                    height: 18,
                    alignItems: 'center',
                    justifyContent: 'center',
                    paddingHorizontal: 4,
                  }}
                >
                  <Text
                    style={{
                      color: '#FFFFFF',
                      fontSize: 11,
                      fontWeight: '700',
                    }}
                  >
                    {totalUnread > 99 ? '99+' : totalUnread}
                  </Text>
                </View>
              )}
            </View>
          ),
        }}
      />
      <Tabs.Screen
        name="profile-tab"
        options={{
          title: language === 'ru' ? 'Профиль' : 'Profile',
          tabBarIcon: ({ color, focused }) => (
            <User size={24} color={color} strokeWidth={focused ? 2 : 1.5} />
          ),
        }}
        listeners={{
          tabPress: (e) => {
            e.preventDefault();
            Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            router.push('/profile');
          },
        }}
      />
      {/* Hidden tabs */}
      <Tabs.Screen name="explore" options={{ href: null }} />
      <Tabs.Screen name="saved" options={{ href: null }} />
      <Tabs.Screen name="create" options={{ href: null }} />
    </Tabs>
  );
}
