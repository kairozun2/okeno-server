import React, { useState, useRef } from 'react';
import { View, Text, FlatList, ViewToken } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { Bookmark } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { MemoryCard } from '@/components/MemoryCard';
import { useSavedMemories } from '@/lib/supabase-hooks';

export default function SavedScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [visibleMemoryId, setVisibleMemoryId] = useState<string | null>(null);

  // Use Supabase hook for saved memories
  const { data: savedMemories = [], isLoading } = useSavedMemories();

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Track viewability changes - Instagram-like behavior
  const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    const visibleVideo = viewableItems.find(
      (item) => item.isViewable && item.item.imageUrl &&
      (item.item.imageUrl.endsWith('.mp4') ||
       item.item.imageUrl.endsWith('.mov') ||
       item.item.imageUrl.endsWith('.m4v') ||
       item.item.imageUrl.includes('video'))
    );

    if (visibleVideo) {
      setVisibleMemoryId(visibleVideo.item.id);
    } else {
      setVisibleMemoryId(null);
    }
  }).current;

  const viewabilityConfig = useRef({
    itemVisiblePercentThreshold: 70,
    minimumViewTime: 100,
  }).current;

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
        style={{ flex: 1 }}
      >
        <FlatList
          data={savedMemories}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: 100 }}
          onViewableItemsChanged={onViewableItemsChanged}
          viewabilityConfig={viewabilityConfig}
          ListHeaderComponent={
            <View
              style={{ paddingTop: insets.top + 8 }}
              className="px-5 pb-4"
            >
              <Animated.View
                entering={FadeIn.duration(300)}
              >
                <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: '300' }}>
                  {t('saved.title')}
                </Text>
                <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 14, marginTop: 4 }}>
                  {savedMemories.length} {savedMemories.length === 1 ? t('saved.memory') : t('saved.memories')}
                </Text>
              </Animated.View>
            </View>
          }
          renderItem={({ item }) => (
            <MemoryCard
              memory={item}
              enableAutoplay={item.id === visibleMemoryId}
              onPress={() => {
                triggerHaptic();
                router.push(`/memory-detail?id=${item.id}`);
              }}
            />
          )}
          ListEmptyComponent={
            <Animated.View
              entering={FadeIn.duration(400)}
              className="items-center py-20 px-8"
            >
              <View
                className="w-20 h-20 rounded-3xl items-center justify-center mb-6"
                style={{ backgroundColor: `${theme.colors.accent}0D` }}
              >
                <Bookmark size={36} color={`${theme.colors.accent}4D`} strokeWidth={1.5} />
              </View>
              <Text style={{ color: `${theme.colors.textSecondary}80`, textAlign: 'center', fontSize: 16, lineHeight: 24 }}>
                {t('saved.empty')}{'\n'}
                {t('saved.emptyDesc')}
              </Text>
            </Animated.View>
          }
        />
      </LinearGradient>
    </View>
  );
}
