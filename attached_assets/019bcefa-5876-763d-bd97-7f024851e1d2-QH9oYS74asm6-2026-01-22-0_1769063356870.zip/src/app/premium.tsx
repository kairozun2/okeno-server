import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, ActivityIndicator, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import Animated, { FadeIn, FadeInDown, FadeInUp } from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Check, Sparkles, Languages, Ban, Zap } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { useAppStore } from '@/lib/store';
import { getTheme } from '@/lib/themes';
import {
  getOfferings,
  purchasePackage,
  restorePurchases,
  hasEntitlement,
  isRevenueCatEnabled,
} from '@/lib/revenuecatClient';
import type { PurchasesPackage } from 'react-native-purchases';

export default function PremiumScreen() {
  const router = useRouter();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const setPremium = useAppStore(s => s.setPremium);
  const theme = getTheme(themeKey);

  const [isLoading, setIsLoading] = useState(true);
  const [isPurchasing, setIsPurchasing] = useState(false);
  const [monthlyPackage, setMonthlyPackage] = useState<PurchasesPackage | null>(null);
  const [alreadyPremium, setAlreadyPremium] = useState(false);

  const triggerHaptic = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  useEffect(() => {
    loadOfferings();
  }, []);

  const loadOfferings = async () => {
    setIsLoading(true);

    // Check if already premium
    const premiumResult = await hasEntitlement('premium');
    if (premiumResult.ok && premiumResult.data) {
      setAlreadyPremium(true);
      setPremium(true);
      setIsLoading(false);
      return;
    }

    // Load offerings
    const offeringsResult = await getOfferings();
    if (offeringsResult.ok && offeringsResult.data.current) {
      const monthly = offeringsResult.data.current.availablePackages.find(
        pkg => pkg.identifier === '$rc_monthly'
      );
      setMonthlyPackage(monthly || null);
    }

    setIsLoading(false);
  };

  const handlePurchase = async () => {
    if (!monthlyPackage) return;

    triggerHaptic();
    setIsPurchasing(true);

    try {
      const result = await purchasePackage(monthlyPackage);
      if (result.ok) {
        // Check if premium entitlement is now active
        const premiumResult = await hasEntitlement('premium');
        if (premiumResult.ok && premiumResult.data) {
          setPremium(true);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          Alert.alert(
            language === 'ru' ? 'Успешно!' : 'Success!',
            language === 'ru'
              ? 'Добро пожаловать в Premium! Теперь у вас есть доступ к автопереводу и приложение без рекламы.'
              : 'Welcome to Premium! You now have access to auto-translation and ad-free experience.',
            [{ text: 'OK', onPress: () => router.back() }]
          );
        }
      } else {
        if (result.reason !== 'sdk_error') {
          // User cancelled or other non-error
          console.log('[Premium] Purchase not completed:', result.reason);
        }
      }
    } catch (error) {
      console.error('[Premium] Purchase error:', error);
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Не удалось завершить покупку' : 'Failed to complete purchase'
      );
    } finally {
      setIsPurchasing(false);
    }
  };

  const handleRestore = async () => {
    triggerHaptic();
    setIsPurchasing(true);

    try {
      const result = await restorePurchases();
      if (result.ok) {
        const premiumResult = await hasEntitlement('premium');
        if (premiumResult.ok && premiumResult.data) {
          setPremium(true);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          Alert.alert(
            language === 'ru' ? 'Восстановлено!' : 'Restored!',
            language === 'ru'
              ? 'Ваша подписка Premium восстановлена.'
              : 'Your Premium subscription has been restored.',
            [{ text: 'OK', onPress: () => router.back() }]
          );
        } else {
          Alert.alert(
            language === 'ru' ? 'Не найдено' : 'Not Found',
            language === 'ru'
              ? 'Активных подписок не найдено.'
              : 'No active subscriptions found.'
          );
        }
      }
    } catch (error) {
      console.error('[Premium] Restore error:', error);
    } finally {
      setIsPurchasing(false);
    }
  };

  const features = [
    {
      icon: Languages,
      title: language === 'ru' ? 'Автоперевод постов' : 'Auto-translate posts',
      description: language === 'ru'
        ? 'Посты автоматически переводятся на ваш язык'
        : 'Posts are automatically translated to your language',
    },
    {
      icon: Zap,
      title: language === 'ru' ? 'Мгновенный перевод' : 'Instant translation',
      description: language === 'ru'
        ? 'Кнопка перевода в деталях каждого поста'
        : 'Translate button in every post detail',
    },
    {
      icon: Ban,
      title: language === 'ru' ? 'Без рекламы' : 'Ad-free experience',
      description: language === 'ru'
        ? 'Наслаждайтесь приложением без рекламы'
        : 'Enjoy the app without any advertisements',
    },
  ];

  if (!isRevenueCatEnabled()) {
    return (
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <SafeAreaView className="flex-1 px-6 items-center justify-center">
          <Text style={{ color: theme.colors.textSecondary, textAlign: 'center' }}>
            {language === 'ru'
              ? 'Подписки недоступны в веб-версии. Пожалуйста, используйте мобильное приложение.'
              : 'Subscriptions are not available on web. Please use the mobile app.'}
          </Text>
          <Pressable
            onPress={() => router.back()}
            className="mt-6 px-6 py-3 rounded-full"
            style={{ backgroundColor: theme.colors.accent }}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>
              {language === 'ru' ? 'Назад' : 'Go Back'}
            </Text>
          </Pressable>
        </SafeAreaView>
      </View>
    );
  }

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[`${theme.colors.accent}30`, 'transparent']}
        style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 300 }}
      />

      <SafeAreaView className="flex-1">
        {/* Header */}
        <View className="flex-row items-center justify-between px-5 py-3">
          <Pressable
            onPress={() => {
              triggerHaptic();
              router.back();
            }}
            className="w-10 h-10 rounded-full items-center justify-center"
            style={{ backgroundColor: `${theme.colors.text}10` }}
          >
            <X size={20} color={theme.colors.text} strokeWidth={2} />
          </Pressable>
          <View className="w-10" />
        </View>

        {isLoading ? (
          <View className="flex-1 items-center justify-center">
            <ActivityIndicator size="large" color={theme.colors.accent} />
          </View>
        ) : alreadyPremium ? (
          <View className="flex-1 items-center justify-center px-6">
            <Animated.View entering={FadeIn.duration(500)}>
              <View
                className="w-24 h-24 rounded-full items-center justify-center mb-6"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <Sparkles size={48} color={theme.colors.accent} />
              </View>
            </Animated.View>
            <Text
              style={{
                color: theme.colors.text,
                fontSize: 28,
                fontWeight: '700',
                textAlign: 'center',
                marginBottom: 12,
              }}
            >
              {language === 'ru' ? 'Вы уже Premium!' : "You're already Premium!"}
            </Text>
            <Text
              style={{
                color: theme.colors.textSecondary,
                fontSize: 16,
                textAlign: 'center',
              }}
            >
              {language === 'ru'
                ? 'У вас есть доступ ко всем премиум функциям.'
                : 'You have access to all premium features.'}
            </Text>
          </View>
        ) : (
          <>
            {/* Premium Icon */}
            <Animated.View
              entering={FadeInDown.duration(500).delay(100)}
              className="items-center mt-4"
            >
              <View
                className="w-20 h-20 rounded-full items-center justify-center"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <Sparkles size={40} color={theme.colors.accent} />
              </View>
            </Animated.View>

            {/* Title */}
            <Animated.View
              entering={FadeInDown.duration(500).delay(200)}
              className="px-6 mt-6"
            >
              <Text
                style={{
                  color: theme.colors.text,
                  fontSize: 32,
                  fontWeight: '700',
                  textAlign: 'center',
                }}
              >
                {language === 'ru' ? 'Memories Premium' : 'Memories Premium'}
              </Text>
              <Text
                style={{
                  color: theme.colors.textSecondary,
                  fontSize: 16,
                  textAlign: 'center',
                  marginTop: 8,
                }}
              >
                {language === 'ru'
                  ? 'Разблокируйте все возможности'
                  : 'Unlock all features'}
              </Text>
            </Animated.View>

            {/* Features */}
            <Animated.View
              entering={FadeInDown.duration(500).delay(300)}
              className="px-6 mt-8"
            >
              {features.map((feature, index) => (
                <View
                  key={index}
                  className="flex-row items-center mb-5"
                >
                  <View
                    className="w-12 h-12 rounded-full items-center justify-center mr-4"
                    style={{ backgroundColor: `${theme.colors.accent}15` }}
                  >
                    <feature.icon size={24} color={theme.colors.accent} />
                  </View>
                  <View className="flex-1">
                    <Text
                      style={{
                        color: theme.colors.text,
                        fontSize: 16,
                        fontWeight: '600',
                      }}
                    >
                      {feature.title}
                    </Text>
                    <Text
                      style={{
                        color: theme.colors.textSecondary,
                        fontSize: 14,
                        marginTop: 2,
                      }}
                    >
                      {feature.description}
                    </Text>
                  </View>
                  <Check size={20} color={theme.colors.accent} />
                </View>
              ))}
            </Animated.View>

            {/* Spacer */}
            <View className="flex-1" />

            {/* Price and CTA */}
            <Animated.View
              entering={FadeInUp.duration(500).delay(400)}
              className="px-6 pb-6"
            >
              {/* Price */}
              <View className="items-center mb-6">
                <Text
                  style={{
                    color: theme.colors.text,
                    fontSize: 48,
                    fontWeight: '700',
                  }}
                >
                  $4.99
                </Text>
                <Text
                  style={{
                    color: theme.colors.textSecondary,
                    fontSize: 16,
                  }}
                >
                  {language === 'ru' ? '/ месяц' : '/ month'}
                </Text>
              </View>

              {/* Subscribe Button */}
              <Pressable
                onPress={handlePurchase}
                disabled={isPurchasing || !monthlyPackage}
                className="py-4 rounded-2xl items-center mb-4"
                style={{
                  backgroundColor: theme.colors.accent,
                  opacity: isPurchasing || !monthlyPackage ? 0.7 : 1,
                }}
              >
                {isPurchasing ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text
                    style={{
                      color: '#FFFFFF',
                      fontSize: 18,
                      fontWeight: '700',
                    }}
                  >
                    {language === 'ru' ? 'Подписаться' : 'Subscribe'}
                  </Text>
                )}
              </Pressable>

              {/* Restore */}
              <Pressable
                onPress={handleRestore}
                disabled={isPurchasing}
                className="py-3 items-center"
              >
                <Text
                  style={{
                    color: theme.colors.textSecondary,
                    fontSize: 14,
                    textDecorationLine: 'underline',
                  }}
                >
                  {language === 'ru' ? 'Восстановить покупки' : 'Restore purchases'}
                </Text>
              </Pressable>

              {/* Terms */}
              <Text
                style={{
                  color: theme.colors.textSecondary,
                  fontSize: 11,
                  textAlign: 'center',
                  marginTop: 16,
                  lineHeight: 16,
                }}
              >
                {language === 'ru'
                  ? 'Подписка автоматически продлевается. Вы можете отменить в любое время в настройках App Store.'
                  : 'Subscription auto-renews. Cancel anytime in App Store settings.'}
              </Text>
            </Animated.View>
          </>
        )}
      </SafeAreaView>
    </View>
  );
}
