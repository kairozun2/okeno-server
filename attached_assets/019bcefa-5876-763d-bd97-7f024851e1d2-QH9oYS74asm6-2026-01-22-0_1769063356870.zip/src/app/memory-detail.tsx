import React, { useState, useRef } from 'react';
import { View, Text, ScrollView, Pressable, Image, Alert, TextInput, Keyboard, Platform, Share, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { X, Bookmark, Waves, MoreHorizontal, Edit2, Trash2, Archive, Check, MessageCircle, Share2, Languages } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, useAnimatedStyle, useSharedValue, withTiming } from 'react-native-reanimated';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';
import type { KeyboardAwareScrollViewRef } from 'react-native-keyboard-controller';
import { useAppStore, EMOTIONS } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { CustomVideoPlayer } from '@/components/CustomVideoPlayer';
import { ResizeMode } from 'expo-av';
import { translateText } from '@/lib/translation';
import { generateMemoryLink } from '@/lib/deep-linking';
import {
  useToggleEcho,
  useToggleSave,
  useDeleteMemory,
  useUpdateMemory,
  useToggleArchive,
  useMemories,
  useAuth,
} from '@/lib/supabase-hooks';

export default function MemoryDetailScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();

  const scrollViewRef = useRef<KeyboardAwareScrollViewRef>(null);
  const textInputRef = useRef<TextInput>(null);

  const [showActions, setShowActions] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [editedText, setEditedText] = useState('');
  const [editedEmotion, setEditedEmotion] = useState('');
  const [videoError, setVideoError] = useState(false);
  const [imageAspectRatio, setImageAspectRatio] = useState<number | undefined>(undefined);
  const [isTranslating, setIsTranslating] = useState(false);
  const [translatedText, setTranslatedText] = useState<string | null>(null);
  const [showTranslation, setShowTranslation] = useState(false);

  // Use Supabase hooks
  const { data: auth } = useAuth();
  const toggleEchoMutation = useToggleEcho();
  const toggleSaveMutation = useToggleSave();
  const deleteMemoryMutation = useDeleteMemory();
  const updateMemoryMutation = useUpdateMemory();
  const toggleArchiveMutation = useToggleArchive();

  const { data: memories = [] } = useMemories();
  const userName = useAppStore(s => s.userName);
  const isPremium = useAppStore(s => s.isPremium);

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  const memory = memories.find((m: any) => m.id === id);

  // Check if current user is the author of this memory
  const isOwner = memory?.authorId === auth?.profile?.id;

  const emotion = memory ? EMOTIONS.find(e => e.key === memory.emotion) : undefined;
  const isVideo = memory?.imageUrl && (
    memory.imageUrl.endsWith('.mp4') ||
    memory.imageUrl.endsWith('.mov') ||
    memory.imageUrl.endsWith('.m4v') ||
    memory.imageUrl.includes('video')
  );

  // Use 1:1 aspect ratio for consistent display
  React.useEffect(() => {
    setImageAspectRatio(1);
  }, [memory?.imageUrl]);

  // Navigate back if memory not found
  React.useEffect(() => {
    if (!memory && memories.length > 0) {
      // Only navigate back if memories are loaded but this one isn't found
      router.back();
    }
  }, [memory, memories.length, router]);

  // Show loading state while memories are being fetched or if memory not found
  if (!memory) {
    return (
      <View className="flex-1 items-center justify-center" style={{ backgroundColor: theme.colors.background }}>
        <ActivityIndicator size="large" color={theme.colors.accent} />
      </View>
    );
  }

  // Check if this is user's own post (in production, check by userId)
  const isOwnPost = true; // For now, all posts are considered user's own

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleEcho = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    toggleEchoMutation.mutate(memory.id);
  };

  const handleSave = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    toggleSaveMutation.mutate(memory.id);
  };

  const handleTranslate = async () => {
    triggerHaptic();

    // Check if user has premium
    if (!isPremium) {
      router.push('/premium');
      return;
    }

    // Toggle translation view if already translated
    if (translatedText) {
      setShowTranslation(!showTranslation);
      return;
    }

    // Translate the text
    setIsTranslating(true);
    try {
      const result = await translateText(memory.text, language);
      if (result.success) {
        setTranslatedText(result.translatedText);
        setShowTranslation(true);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      } else {
        Alert.alert(
          language === 'ru' ? 'Ошибка' : 'Error',
          language === 'ru' ? 'Не удалось перевести текст' : 'Failed to translate text'
        );
      }
    } catch (error) {
      console.error('[Translation] Error:', error);
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Не удалось перевести текст' : 'Failed to translate text'
      );
    } finally {
      setIsTranslating(false);
    }
  };

  const handleShare = async () => {
    triggerHaptic();
    try {
      // Generate deep link for this memory
      const deepLink = generateMemoryLink(memory.id);

      const shareContent: any = {
        title: language === 'ru' ? 'Поделиться воспоминанием' : 'Share Memory',
        message: `${memory.text || (language === 'ru' ? 'Посмотрите это воспоминание!' : 'Check out this memory!')}\n\n${deepLink}`,
      };

      // Add media URL if available
      if (memory.imageUrl) {
        shareContent.url = memory.imageUrl;
      }

      const result = await Share.share(shareContent);

      if (result.action === Share.sharedAction) {
        // Shared successfully
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      console.error('Error sharing:', error);
    }
  };

  const handleEdit = () => {
    triggerHaptic();
    setEditedText(memory.text);
    setEditedEmotion(memory.emotion);
    setIsEditing(true);
    setShowActions(false);

    // Focus text input after state updates
    setTimeout(() => {
      textInputRef.current?.focus();
    }, 100);
  };

  const handleSaveEdit = () => {
    triggerHaptic();

    // Validate input
    if (!editedText.trim()) {
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Текст не может быть пустым' : 'Text cannot be empty'
      );
      return;
    }

    // Save changes via Supabase
    updateMemoryMutation.mutate(
      {
        memoryId: memory.id,
        text: editedText.trim(),
        emotion: editedEmotion as any,
      },
      {
        onSuccess: () => {
          setIsEditing(false);
          Keyboard.dismiss();
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        },
        onError: (error) => {
          console.error('[MemoryDetail] Failed to update:', error);
          Alert.alert(
            language === 'ru' ? 'Ошибка' : 'Error',
            language === 'ru' ? 'Не удалось сохранить изменения' : 'Failed to save changes'
          );
        },
      }
    );
  };

  const handleCancelEdit = () => {
    triggerHaptic();
    setIsEditing(false);
    setEditedText('');
    Keyboard.dismiss();
  };

  const handleDelete = () => {
    triggerHaptic();
    setShowActions(false);

    Alert.alert(
      language === 'ru' ? 'Удалить воспоминание?' : 'Delete Memory?',
      language === 'ru'
        ? 'Это действие нельзя отменить.'
        : 'This action cannot be undone.',
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
          onPress: () => triggerHaptic(),
        },
        {
          text: language === 'ru' ? 'Удалить' : 'Delete',
          style: 'destructive',
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            deleteMemoryMutation.mutate(memory.id);
            router.back();
          },
        },
      ]
    );
  };

  const handleArchive = () => {
    triggerHaptic();
    setShowActions(false);

    Alert.alert(
      language === 'ru' ? 'Архивировать воспоминание?' : 'Archive Memory?',
      language === 'ru'
        ? 'Воспоминание будет скрыто из профиля, но останется доступным в архиве.'
        : 'Memory will be hidden from profile but remain accessible in archive.',
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
          onPress: () => triggerHaptic(),
        },
        {
          text: language === 'ru' ? 'Архивировать' : 'Archive',
          onPress: () => {
            Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
            toggleArchiveMutation.mutate({ memoryId: memory.id, isArchived: memory.isArchived || false });
            router.back();
          },
        },
      ]
    );
  };

  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    return date.toLocaleDateString(language === 'ru' ? 'ru-RU' : 'en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  // Show edit modal as full screen
  if (isEditing) {
    const selectedEmotion = EMOTIONS.find(e => e.key === editedEmotion);

    return (
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]} locations={[0, 0.7, 1]}
          style={{ flex: 1 }}
        >
          {/* Header with media preview between buttons */}
          <View
            style={{
              paddingTop: insets.top + 8,
              paddingHorizontal: 20,
              paddingBottom: 12,
            }}
          >
            {/* Top row: Close, Media Preview, Save */}
            <View className="flex-row items-center justify-between">
              {/* Close button */}
              <Pressable
                onPress={handleCancelEdit}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>

              {/* Media preview in center - LARGER */}
              {memory.imageUrl && (
                <View className="flex-1 mx-3">
                  <View className="rounded-3xl overflow-hidden" style={{ height: 100, alignItems: 'center' }}>
                    {isVideo && !videoError ? (
                      <CustomVideoPlayer
                        uri={memory.imageUrl}
                        width={120}
                        height={100}
                        resizeMode={ResizeMode.COVER}
                        onError={() => setVideoError(true)}
                        hideControls={true}
                        borderRadius={24}
                      />
                    ) : (
                      <Image
                        source={{ uri: memory.imageUrl }}
                        style={{ width: 120, height: 100, borderRadius: 24 }}
                        resizeMode="cover"
                      />
                    )}
                  </View>
                </View>
              )}

              {/* Save button */}
              <Pressable
                onPress={handleSaveEdit}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: theme.colors.accent }}
              >
                <Check size={20} color={theme.colors.primary} strokeWidth={2} />
              </Pressable>
            </View>
          </View>

          {/* Keyboard-aware content */}
          <KeyboardAwareScrollView
            bottomOffset={20}
            contentContainerStyle={{ flexGrow: 1, paddingHorizontal: 20 }}
            className="flex-1"
          >
            <View className="flex-1">
              {/* Emotion Selector */}
              <Text style={{
                color: theme.colors.textSecondary,
                fontSize: 13,
                fontWeight: '500',
                marginBottom: 8,
              }}>
                {language === 'ru' ? 'Эмоция' : 'Emotion'}
              </Text>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                className="mb-4"
                style={{ flexGrow: 0 }}
              >
                {EMOTIONS.map((emotion) => (
                  <Pressable
                    key={emotion.key}
                    onPress={() => {
                      triggerHaptic();
                      setEditedEmotion(emotion.key);
                    }}
                    className="mr-2 px-3 py-2 rounded-full active:opacity-70"
                    style={{
                      backgroundColor: editedEmotion === emotion.key
                        ? theme.colors.accent
                        : `${theme.colors.accent}15`,
                    }}
                  >
                    <View className="flex-row items-center">
                      <Text className="text-base">{emotion.icon}</Text>
                      <Text style={{
                        color: editedEmotion === emotion.key
                          ? theme.colors.primary
                          : theme.colors.text,
                        fontSize: 13,
                        fontWeight: '500',
                        marginLeft: 6,
                      }}>
                        {emotion.label}
                      </Text>
                    </View>
                  </Pressable>
                ))}
              </ScrollView>

              {/* Description Field - SMALLER */}
              <Text style={{
                color: theme.colors.textSecondary,
                fontSize: 13,
                fontWeight: '500',
                marginBottom: 8,
              }}>
                {language === 'ru' ? 'Описание' : 'Description'}
              </Text>

              <TextInput
                ref={textInputRef}
                value={editedText}
                onChangeText={setEditedText}
                multiline
                style={{
                  color: theme.colors.text,
                  fontSize: 16,
                  lineHeight: 24,
                  fontWeight: '400',
                  minHeight: 120,
                  maxHeight: 280,
                  padding: 16,
                  borderRadius: 16,
                  backgroundColor: `${theme.colors.accent}15`,
                  textAlignVertical: 'top',
                }}
                placeholderTextColor={`${theme.colors.textSecondary}66`}
                placeholder={language === 'ru' ? 'Напишите описание...' : 'Write a description...'}
              />
            </View>
          </KeyboardAwareScrollView>
        </LinearGradient>
      </View>
    );
  }

  // Regular view mode
  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]} locations={[0, 0.7, 1]}
        style={{ flex: 1 }}
      >
        <KeyboardAwareScrollView
          ref={scrollViewRef}
          className="flex-1"
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
          bottomOffset={20}
          keyboardShouldPersistTaps="handled"
        >
          {/* Media */}
          {memory.imageUrl && (
            <Animated.View entering={FadeIn.duration(300)} className="relative">
              {isVideo && !videoError ? (
                <CustomVideoPlayer
                  uri={memory.imageUrl}
                  aspectRatio={4 / 5}
                  resizeMode={ResizeMode.COVER}
                  onError={() => setVideoError(true)}
                  isVisible={true}
                />
              ) : (
                <Image
                  source={{ uri: memory.imageUrl }}
                  style={{
                    width: '100%',
                    aspectRatio: 4 / 5,
                  }}
                  resizeMode="cover"
                />
              )}

              {/* Floating Header Buttons */}
              <View
                style={{
                  position: 'absolute',
                  top: insets.top + 8,
                  left: 0,
                  right: 0,
                  paddingHorizontal: 20,
                }}
              >
                <View className="flex-row items-center justify-between">
                  <Pressable
                    onPress={() => {
                      triggerHaptic();
                      router.back();
                    }}
                    className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                    style={{
                      backgroundColor: 'rgba(0, 0, 0, 0.5)',
                      backdropFilter: 'blur(10px)',
                    }}
                  >
                    <X size={20} color="#fff" strokeWidth={1.5} />
                  </Pressable>

                  {isOwner && (
                    <Pressable
                      onPress={() => {
                        triggerHaptic();
                        setShowActions(!showActions);
                      }}
                      className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                      style={{
                        backgroundColor: 'rgba(0, 0, 0, 0.5)',
                        backdropFilter: 'blur(10px)',
                      }}
                    >
                      <MoreHorizontal size={20} color="#fff" strokeWidth={1.5} />
                    </Pressable>
                  )}
                </View>
              </View>
            </Animated.View>
          )}

          {/* If no media, show simple header */}
          {!memory.imageUrl && (
            <View
              style={{
                paddingTop: insets.top + 8,
                paddingHorizontal: 20,
                paddingBottom: 12,
              }}
            >
              <View className="flex-row items-center justify-between">
                <Pressable
                  onPress={() => {
                    triggerHaptic();
                    router.back();
                  }}
                  className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                  style={{ backgroundColor: `${theme.colors.accent}20` }}
                >
                  <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
                </Pressable>

                {isOwner && (
                  <Pressable
                    onPress={() => {
                      triggerHaptic();
                      setShowActions(!showActions);
                    }}
                    className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                    style={{ backgroundColor: `${theme.colors.accent}20` }}
                  >
                    <MoreHorizontal size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  </Pressable>
                )}
              </View>
            </View>
          )}

          {/* Content */}
          <View className="px-5" style={{ paddingTop: 24 }}>
            {/* Emotion & Date */}
            <Animated.View
              entering={FadeIn.duration(300)}
              className="flex-row items-center justify-between mb-4"
            >
              <View className="flex-row items-center">
                <Text className="mr-2 text-2xl">{emotion?.icon}</Text>
                <Text style={{ color: theme.colors.accent, fontSize: 16, fontWeight: '500' }}>
                  {emotion?.label}
                </Text>
              </View>
              <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 14 }}>
                {formatDate(memory.createdAt)}
              </Text>
            </Animated.View>

            {/* Text */}
            <Animated.View entering={FadeIn.duration(300)} className="mb-4">
              <Text
                style={{
                  color: theme.colors.text,
                  fontSize: 18,
                  lineHeight: 28,
                  fontWeight: '300',
                }}
              >
                {showTranslation && translatedText ? translatedText : memory.text}
              </Text>
            </Animated.View>

            {/* Translate Button */}
            <Animated.View entering={FadeIn.duration(300)} className="mb-6">
              <Pressable
                onPress={handleTranslate}
                disabled={isTranslating}
                className="flex-row items-center active:opacity-60"
                style={{
                  alignSelf: 'flex-start',
                  paddingVertical: 6,
                  paddingHorizontal: 12,
                  borderRadius: 16,
                  backgroundColor: isPremium ? `${theme.colors.accent}15` : `${theme.colors.textSecondary}10`,
                }}
              >
                {isTranslating ? (
                  <ActivityIndicator size="small" color={theme.colors.accent} />
                ) : (
                  <Languages size={16} color={isPremium ? theme.colors.accent : theme.colors.textSecondary} strokeWidth={2} />
                )}
                <Text
                  style={{
                    color: isPremium ? theme.colors.accent : theme.colors.textSecondary,
                    fontSize: 13,
                    fontWeight: '500',
                    marginLeft: 6,
                  }}
                >
                  {isTranslating
                    ? (language === 'ru' ? 'Перевод...' : 'Translating...')
                    : showTranslation
                      ? (language === 'ru' ? 'Показать оригинал' : 'Show original')
                      : (language === 'ru' ? 'Перевести' : 'Translate')
                  }
                </Text>
                {!isPremium && (
                  <Text
                    style={{
                      color: theme.colors.accent,
                      fontSize: 11,
                      fontWeight: '600',
                      marginLeft: 6,
                    }}
                  >
                    PRO
                  </Text>
                )}
              </Pressable>
            </Animated.View>

            {/* Actions Menu */}
            {showActions && isOwner && (
              <Animated.View
                entering={FadeIn.duration(200)}
                className="mb-6 rounded-2xl overflow-hidden"
                style={{ backgroundColor: `${theme.colors.accent}10` }}
              >
                <Pressable
                  onPress={handleEdit}
                  className="flex-row items-center px-4 py-4 active:opacity-60"
                  style={{ borderBottomWidth: 1, borderBottomColor: `${theme.colors.text}0D` }}
                >
                  <Edit2 size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  <Text style={{ color: theme.colors.text, fontSize: 16, marginLeft: 12, fontWeight: '500' }}>
                    {language === 'ru' ? 'Редактировать' : 'Edit'}
                  </Text>
                </Pressable>

                <Pressable
                  onPress={handleArchive}
                  className="flex-row items-center px-4 py-4 active:opacity-60"
                  style={{ borderBottomWidth: 1, borderBottomColor: `${theme.colors.text}0D` }}
                >
                  <Archive size={20} color={theme.colors.accent} strokeWidth={1.5} />
                  <Text style={{ color: theme.colors.text, fontSize: 16, marginLeft: 12, fontWeight: '500' }}>
                    {language === 'ru' ? 'Архивировать' : 'Archive'}
                  </Text>
                </Pressable>

                <Pressable
                  onPress={handleDelete}
                  className="flex-row items-center px-4 py-4 active:opacity-60"
                >
                  <Trash2 size={20} color="rgba(255, 59, 48, 0.9)" strokeWidth={1.5} />
                  <Text style={{ color: 'rgba(255, 59, 48, 0.9)', fontSize: 16, marginLeft: 12, fontWeight: '500' }}>
                    {language === 'ru' ? 'Удалить' : 'Delete'}
                  </Text>
                </Pressable>
              </Animated.View>
            )}

            {/* Stats */}
            <Animated.View
              entering={FadeIn.duration(300)}
              className="flex-row items-center pt-4"
              style={{ borderTopWidth: 1, borderTopColor: `${theme.colors.text}0D` }}
            >
              <Pressable
                onPress={handleEcho}
                className="flex-row items-center active:opacity-60 mr-6"
              >
                <Waves size={22} color={theme.colors.accent} strokeWidth={1.5} />
                {memory.echoCount > 0 && (
                  <Text style={{ color: theme.colors.accent, fontSize: 16, marginLeft: 8, fontWeight: '500' }}>
                    {memory.echoCount}
                  </Text>
                )}
              </Pressable>

              <View className="flex-row items-center ml-auto">
                <Pressable
                  onPress={handleShare}
                  className="active:opacity-60 mr-4"
                >
                  <Share2
                    size={22}
                    color={theme.colors.accent}
                    strokeWidth={1.5}
                  />
                </Pressable>

                <Pressable
                  onPress={handleSave}
                  className="active:opacity-60"
                >
                  <Bookmark
                    size={22}
                    color={theme.colors.accent}
                    strokeWidth={1.5}
                    fill={memory.isSaved ? theme.colors.accent : 'transparent'}
                  />
                </Pressable>
              </View>
            </Animated.View>

            {/* View Comments Button */}
            <Animated.View
              entering={FadeIn.duration(300).delay(100)}
              className="mt-6"
            >
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  // TODO: Open comments modal
                  router.push(`/comments?memoryId=${memory.id}`);
                }}
                className="flex-row items-center justify-center py-4 rounded-2xl active:opacity-70"
                style={{ backgroundColor: `${theme.colors.accent}15` }}
              >
                <MessageCircle size={20} color={theme.colors.accent} strokeWidth={2} />
                <Text style={{
                  color: theme.colors.accent,
                  fontSize: 15,
                  fontWeight: '600',
                  marginLeft: 8,
                }}>
                  {language === 'ru' ? 'Посмотреть комментарии' : 'View Comments'}
                </Text>
              </Pressable>
            </Animated.View>
          </View>
        </KeyboardAwareScrollView>
      </LinearGradient>
    </View>
  );
}
