import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { View, Text, TextInput, Pressable, FlatList, ActivityIndicator } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { X, Search as SearchIcon, Clock, Trash2 } from 'lucide-react-native';
import { useRouter } from 'expo-router';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import * as Haptics from 'expo-haptics';
import { useSearchUsers } from '@/lib/supabase-hooks';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ColoredUsername } from '@/components/ColoredUsername';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface SearchResult {
  id: string;
  userName: string;
  avatar: string;
  isVerified?: boolean;
  usernameColor?: string | null;
  socialLinks?: Array<{ platform: string; url: string }>;
}

export default function SearchUsersScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const [searchQuery, setSearchQuery] = useState('');
  const [searchHistory, setSearchHistory] = useState<SearchResult[]>([]);

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  // Use Supabase search hook
  const { data: results = [], isLoading: isSearching } = useSearchUsers(searchQuery);

  // Load search history on mount
  useEffect(() => {
    loadSearchHistory();
  }, []);

  const loadSearchHistory = async () => {
    try {
      const history = await AsyncStorage.getItem('search_history');
      if (history) {
        setSearchHistory(JSON.parse(history));
      }
    } catch (error) {
      console.error('Failed to load search history:', error);
    }
  };

  const saveToHistory = async (user: SearchResult) => {
    try {
      // Remove duplicates and add to beginning
      const newHistory = [user, ...searchHistory.filter(u => u.id !== user.id)].slice(0, 10); // Keep last 10
      setSearchHistory(newHistory);
      await AsyncStorage.setItem('search_history', JSON.stringify(newHistory));
    } catch (error) {
      console.error('Failed to save search history:', error);
    }
  };

  const clearHistory = async () => {
    try {
      setSearchHistory([]);
      await AsyncStorage.removeItem('search_history');
      triggerHaptic();
    } catch (error) {
      console.error('Failed to clear search history:', error);
    }
  };

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query);
  }, []);

  const handleUserPress = useCallback((user: SearchResult) => {
    triggerHaptic();
    saveToHistory(user);
    router.push(`/user/${user.id}`);
  }, [triggerHaptic, router]);

  const renderItem = useCallback(({ item, index }: { item: SearchResult; index: number }) => (
    <Animated.View
      entering={FadeInDown.duration(200).delay(index * 30)}
      style={{ marginBottom: 12 }}
    >
      <Pressable
        onPress={() => handleUserPress(item)}
        className="rounded-2xl overflow-hidden active:opacity-80"
        style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}
      >
        <View className="flex-row items-center p-4">
          <Text style={{ fontSize: 48, lineHeight: 52, marginRight: 16 }}>
            {item.avatar}
          </Text>
          <View style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <ColoredUsername
              username={item.userName}
              color={item.usernameColor}
              size={18}
              weight="500"
              defaultColor={theme.colors.text}
            />
            <VerifiedBadge isVerified={item.isVerified === true} size={16} checkColor={theme.colors.primary} />
          </View>
        </View>
      </Pressable>
    </Animated.View>
  ), [handleUserPress, theme.colors.text]);

  const ListEmptyComponent = useMemo(() => {
    if (searchQuery.trim().length === 0 || isSearching) return null;
    return (
      <View className="items-center py-12">
        <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 14, textAlign: 'center' }}>
          {language === 'ru' ? 'Пользователи не найдены' : 'No users found'}
        </Text>
      </View>
    );
  }, [searchQuery, isSearching, theme.colors.textSecondary, language]);

  return (
    <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
      <LinearGradient
        colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
        locations={[0, 0.7, 1]}
        style={{ flex: 1 }}
      >
        {/* Header */}
        <View style={{ paddingTop: insets.top + 12 }} className="px-5 pb-4">
          <Animated.View
            entering={FadeIn.duration(200)}
            className="flex-row items-center justify-between mb-4"
          >
            <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: '300' }}>
              {language === 'ru' ? 'Поиск пользователей' : 'Search Users'}
            </Text>
            <Pressable
              onPress={() => {
                triggerHaptic();
                router.back();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{ backgroundColor: `${theme.colors.accent}20` }}
            >
              <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>
          </Animated.View>

          {/* Search Input */}
          <Animated.View
            entering={FadeIn.duration(200)}
            className="rounded-2xl overflow-hidden flex-row items-center px-4"
            style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
          >
            <SearchIcon size={20} color={`${theme.colors.textSecondary}66`} strokeWidth={1.5} />
            <TextInput
              value={searchQuery}
              onChangeText={handleSearch}
              placeholder={language === 'ru' ? 'Поиск по имени пользователя...' : 'Search by username...'}
              placeholderTextColor={`${theme.colors.textSecondary}66`}
              style={{
                flex: 1,
                color: theme.colors.text,
                fontSize: 16,
                paddingVertical: 14,
                paddingHorizontal: 12,
              }}
              autoFocus
              autoCapitalize="none"
              autoCorrect={false}
            />
            {isSearching && (
              <ActivityIndicator size="small" color={theme.colors.accent} />
            )}
          </Animated.View>
        </View>

        {/* Results or History */}
        {searchQuery.trim().length === 0 && searchHistory.length > 0 ? (
          <View className="flex-1 px-5">
            <View className="flex-row items-center justify-between mb-4">
              <View className="flex-row items-center">
                <Clock size={16} color={theme.colors.textSecondary} strokeWidth={2} />
                <Text style={{ color: theme.colors.textSecondary, fontSize: 14, marginLeft: 8 }}>
                  {language === 'ru' ? 'Недавние' : 'Recent'}
                </Text>
              </View>
              <Pressable onPress={clearHistory}>
                <Text style={{ color: theme.colors.accent, fontSize: 14 }}>
                  {language === 'ru' ? 'Очистить' : 'Clear'}
                </Text>
              </Pressable>
            </View>
            <FlatList
              data={searchHistory}
              keyExtractor={(item) => item.id}
              showsVerticalScrollIndicator={false}
              contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
              renderItem={renderItem}
            />
          </View>
        ) : (
          <FlatList
            data={results}
            keyExtractor={(item) => item.id}
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 40 }}
            ListEmptyComponent={ListEmptyComponent}
            renderItem={renderItem}
            removeClippedSubviews={true}
            maxToRenderPerBatch={10}
            windowSize={5}
          />
        )}
      </LinearGradient>
    </View>
  );
}
