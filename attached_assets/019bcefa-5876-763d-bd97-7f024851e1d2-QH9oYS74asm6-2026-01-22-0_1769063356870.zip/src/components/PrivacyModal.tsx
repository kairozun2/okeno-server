import React from 'react';
import { View, Text, ScrollView, Pressable, Modal, Linking } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { X, Shield, Camera, MapPin, Image as ImageIcon, Bell, Database, Lock, Eye, Globe, FileText } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn } from 'react-native-reanimated';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';

interface PrivacyModalProps {
  visible: boolean;
  onClose: () => void;
}

export function PrivacyModal({ visible, onClose }: PrivacyModalProps) {
  const insets = useSafeAreaInsets();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  const triggerHaptic = () => {
    if (hapticsEnabled) { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }
  };

  const permissions = [
    {
      icon: Camera,
      title: language === 'ru' ? 'Камера' : 'Camera',
      description: language === 'ru'
        ? 'Для создания фотографий и видео воспоминаний'
        : 'To capture photos and videos for your memories',
      required: true,
    },
    {
      icon: ImageIcon,
      title: language === 'ru' ? 'Фотографии' : 'Photos',
      description: language === 'ru'
        ? 'Для выбора фото и видео из галереи'
        : 'To select photos and videos from your library',
      required: true,
    },
    {
      icon: MapPin,
      title: language === 'ru' ? 'Геолокация' : 'Location',
      description: language === 'ru'
        ? 'Для добавления места к воспоминаниям (по желанию)'
        : 'To tag locations in your memories (optional)',
      required: false,
    },
    {
      icon: Bell,
      title: language === 'ru' ? 'Уведомления' : 'Notifications',
      description: language === 'ru'
        ? 'Для получения уведомлений о лайках и комментариях'
        : 'To receive notifications about likes and comments',
      required: false,
    },
  ];

  const privacyPrinciples = [
    {
      icon: Lock,
      title: language === 'ru' ? 'Шифрование' : 'Encryption',
      description: language === 'ru'
        ? 'Данные защищены стандартными технологиями безопасности Apple'
        : 'Data is protected using standard Apple-provided security technologies',
    },
    {
      icon: Shield,
      title: language === 'ru' ? 'Безопасное хранилище' : 'Secure Storage',
      description: language === 'ru'
        ? 'Данные хранятся на защищённых серверах Supabase'
        : 'Data stored on secure Supabase servers',
    },
    {
      icon: Eye,
      title: language === 'ru' ? 'Без трекинга' : 'No Tracking',
      description: language === 'ru'
        ? 'Никаких сторонних трекеров или аналитики'
        : 'No third-party trackers or analytics',
    },
    {
      icon: Database,
      title: language === 'ru' ? 'Контроль данных' : 'Data Control',
      description: language === 'ru'
        ? 'Вы владеете своими данными. Удаление в любой момент.'
        : 'You own your data. Delete anytime.',
    },
  ];

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 12,
            paddingBottom: 12,
            paddingHorizontal: 20,
            borderBottomWidth: 1,
            borderBottomColor: `${theme.colors.text}10`,
          }}
        >
          <View className="flex-row items-center justify-between">
            <Pressable
              onPress={() => {
                triggerHaptic();
                onClose();
              }}
              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
            >
              <X size={24} color={theme.colors.text} strokeWidth={2} />
            </Pressable>
            <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '600' }}>
              {language === 'ru' ? 'Конфиденциальность' : 'Privacy'}
            </Text>
            <View style={{ width: 24 }} />
          </View>
        </View>

        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
        >
          {/* App Permissions Section */}
          <View className="mx-5 mt-6 mb-6">
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {language === 'ru' ? 'РАЗРЕШЕНИЯ ПРИЛОЖЕНИЯ' : 'APP PERMISSIONS'}
            </Text>

            {permissions.map((perm, index) => (
              <Animated.View
                key={perm.title}
                entering={FadeIn.duration(300).delay(index * 50)}
                style={{
                  backgroundColor: `${theme.colors.text}05`,
                  borderRadius: 16,
                  marginBottom: 12,
                  padding: 16,
                }}
              >
                <View className="flex-row items-start">
                  <View
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 12,
                      backgroundColor: `${theme.colors.accent}20`,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <perm.icon size={20} color={theme.colors.accent} strokeWidth={2} />
                  </View>
                  <View className="flex-1 ml-3">
                    <View className="flex-row items-center justify-between mb-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '600' }}>
                        {perm.title}
                      </Text>
                      {!perm.required && (
                        <Text style={{ color: theme.colors.textSecondary, fontSize: 11, fontWeight: '500' }}>
                          {language === 'ru' ? 'Опционально' : 'Optional'}
                        </Text>
                      )}
                    </View>
                    <Text style={{ color: theme.colors.textSecondary, fontSize: 14, lineHeight: 20 }}>
                      {perm.description}
                    </Text>
                  </View>
                </View>
              </Animated.View>
            ))}
          </View>

          {/* Privacy Principles Section */}
          <View className="mx-5 mb-6">
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {language === 'ru' ? 'ЗАЩИТА ДАННЫХ' : 'DATA PROTECTION'}
            </Text>

            {privacyPrinciples.map((principle, index) => (
              <Animated.View
                key={principle.title}
                entering={FadeIn.duration(300).delay(200 + index * 50)}
                style={{
                  backgroundColor: `${theme.colors.text}05`,
                  borderRadius: 16,
                  marginBottom: 12,
                  padding: 16,
                }}
              >
                <View className="flex-row items-start">
                  <View
                    style={{
                      width: 40,
                      height: 40,
                      borderRadius: 12,
                      backgroundColor: `${theme.colors.primary}20`,
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    <principle.icon size={20} color={theme.colors.primary} strokeWidth={2} />
                  </View>
                  <View className="flex-1 ml-3">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '600', marginBottom: 4 }}>
                      {principle.title}
                    </Text>
                    <Text style={{ color: theme.colors.textSecondary, fontSize: 14, lineHeight: 20 }}>
                      {principle.description}
                    </Text>
                  </View>
                </View>
              </Animated.View>
            ))}
          </View>

          {/* Privacy Policy Link */}
          <View className="mx-5 mb-6">
            <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
              {language === 'ru' ? 'ДОКУМЕНТЫ' : 'DOCUMENTS'}
            </Text>

            <Pressable
              onPress={() => {
                triggerHaptic();
                Linking.openURL('https://skaisay.github.io/App-Privacy/');
              }}
              style={{
                backgroundColor: `${theme.colors.text}05`,
                borderRadius: 16,
                padding: 16,
              }}
              className="active:opacity-70"
            >
              <View className="flex-row items-center justify-between">
                <View className="flex-row items-center flex-1">
                  <FileText size={20} color={theme.colors.accent} strokeWidth={2} />
                  <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500', marginLeft: 12 }}>
                    {language === 'ru' ? 'Политика конфиденциальности' : 'Privacy Policy'}
                  </Text>
                </View>
                <Globe size={18} color={theme.colors.textSecondary} strokeWidth={2} />
              </View>
            </Pressable>
          </View>

          {/* Info Footer */}
          <View className="mx-5 mb-4">
            <Text style={{ color: theme.colors.textSecondary, fontSize: 13, lineHeight: 20, textAlign: 'center' }}>
              {language === 'ru'
                ? 'Мы серьёзно относимся к вашей конфиденциальности. Ваши данные никогда не продаются третьим лицам.'
                : 'We take your privacy seriously. Your data is never sold to third parties.'}
            </Text>
          </View>
        </ScrollView>
      </View>
    </Modal>
  );
}
