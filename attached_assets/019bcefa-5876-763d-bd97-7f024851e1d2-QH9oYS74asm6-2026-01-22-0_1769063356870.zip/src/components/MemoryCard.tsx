import React, { useState, useCallback, memo } from 'react';
import { View, Text, Pressable, Dimensions, Share } from 'react-native';
import { Image } from 'expo-image'; // Use expo-image for better caching!
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withSequence,
  withTiming,
  runOnJS,
} from 'react-native-reanimated';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import { LinearGradient } from 'expo-linear-gradient';
import { Bookmark, Waves, Share2, EyeOff, MapPin, ArchiveRestore } from 'lucide-react-native';
import { ResizeMode } from 'expo-av';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { Memory, EMOTIONS, useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { generateAvatarFromPattern } from '@/lib/avatar';
import { CustomVideoPlayer } from './CustomVideoPlayer';
import { ImageSkeleton } from './ImageSkeleton';
import { LocationMapModal } from './LocationMapModal';
import { MediaViewerModal } from './MediaViewerModal';
import { UserProfileModal } from './UserProfileModal';
import { useToggleEcho, useToggleSave, useHideUser } from '@/lib/supabase-hooks';
import { VerifiedBadge } from './VerifiedBadge';
import { ColoredUsername } from './ColoredUsername';
import { generateMemoryLink } from '@/lib/deep-linking';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

interface MemoryCardProps {
  memory: Memory;
  onPress?: () => void;
  enableAutoplay?: boolean; // Add prop to control autoplay
  showRestoreButton?: boolean; // Show restore button instead of hide button (for archive)
  onRestore?: () => void; // Callback for restore action
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function formatTimeAgo(dateString: string): string {
  const now = new Date();
  const date = new Date(dateString);
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'now';
  if (diffMins < 60) return `${diffMins}m`;
  if (diffHours < 24) return `${diffHours}h`;
  if (diffDays === 1) return '1d';
  if (diffDays < 7) return `${diffDays}d`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

function MemoryCardComponent({ memory, onPress, enableAutoplay = false, showRestoreButton = false, onRestore }: MemoryCardProps) {
  const router = useRouter();

  // Use Supabase hooks
  const toggleEchoMutation = useToggleEcho();
  const toggleSaveMutation = useToggleSave();
  const hideUserMutation = useHideUser();

  const userName = useAppStore(s => s.userName);
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const [videoError, setVideoError] = useState(false);
  const [isHolding, setIsHolding] = useState(false);
  const [wasHolding, setWasHolding] = useState(false);
  const [showMapModal, setShowMapModal] = useState(false);
  const [showMediaViewer, setShowMediaViewer] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const [showProfileModal, setShowProfileModal] = useState(false);

  const theme = getTheme(themeKey);
  const echoScale = useSharedValue(1);
  const saveScale = useSharedValue(1);
  const uiOpacity = useSharedValue(1);

  // Local haptic function that checks settings (memoized)
  const triggerHaptic = useCallback((style: Haptics.ImpactFeedbackStyle = Haptics.ImpactFeedbackStyle.Light) => {
    if (hapticsEnabled) {
      Haptics.impactAsync(style);
    }
  }, [hapticsEnabled]);

  // Swipe gesture values
  const translateX = useSharedValue(0);
  const swipeStartX = useSharedValue(0);

  const emotion = EMOTIONS.find(e => e.key === memory.emotion);
  // Use avatar from memory (from server), not from local store
  const avatar = memory.authorAvatar || '👤';

  // Detect if media is video - use videoUrl field
  const isVideo = !!memory.videoUrl;

  // Always use 1:1 aspect ratio for consistent Instagram-like feed
  // This avoids CORS/permission issues with Image.getSize() on Supabase Storage
  const imageAspectRatio = 1;

  const handleEcho = useCallback(() => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
    echoScale.value = withSpring(1.3, { damping: 10 }, () => {
      echoScale.value = withSpring(1);
    });
    toggleEchoMutation.mutate(memory.id);
  }, [memory.id, triggerHaptic]);

  const handleSave = useCallback(() => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    saveScale.value = withSpring(1.2, { damping: 10 }, () => {
      saveScale.value = withSpring(1);
    });
    toggleSaveMutation.mutate(memory.id);
  }, [memory.id, triggerHaptic]);

  const handleSavePressIn = useCallback(() => {
    saveScale.value = withSpring(0.9, { damping: 15 });
  }, []);

  const handleSavePressOut = useCallback(() => {
    saveScale.value = withSpring(1, { damping: 15 });
  }, []);

  const echoAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: echoScale.value }],
  }));

  const saveAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: saveScale.value }],
  }));

  const uiAnimatedStyle = useAnimatedStyle(() => ({
    opacity: uiOpacity.value,
  }));

  const handleHoldStart = () => {
    setIsHolding(true);
    setWasHolding(true);
    uiOpacity.value = withSpring(0, { damping: 20 });
  };

  const handleHoldEnd = () => {
    setIsHolding(false);
    uiOpacity.value = withSpring(1, { damping: 20 });
    // Reset after delay to allow press to register
    setTimeout(() => setWasHolding(false), 500);
  };

  const handleAvatarPress = () => {
    if (memory.authorId) {
      triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
      setShowProfileModal(true);
    }
  };

  // Swipe handlers
  const handleShare = async () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
    translateX.value = withSpring(0);
    try {
      // Share deep link to post using helper function
      const link = generateMemoryLink(memory.id);
      await Share.share({
        title: language === 'ru' ? 'Поделиться воспоминанием' : 'Share Memory',
        message: `${memory.text || (language === 'ru' ? 'Посмотрите это воспоминание!' : 'Check out this memory!')}\n\n${link}`,
      });
    } catch (error) {
      console.error('Share error:', error);
    }
  };

  const handleHide = () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
    translateX.value = withSpring(0);
    // Hide all posts from this user via Supabase
    if (memory.authorId) {
      hideUserMutation.mutate(memory.authorId);
    }
  };

  // Swipe gesture - optimized to not conflict with scroll
  const panGesture = Gesture.Pan()
    .activeOffsetX([-10, 10]) // Need 10px horizontal movement to activate
    .failOffsetY([-15, 15]) // Cancel if vertical scroll detected
    .onStart(() => {
      swipeStartX.value = translateX.value;
    })
    .onUpdate((event) => {
      // Only allow swipe left (negative values)
      const newValue = swipeStartX.value + event.translationX;
      if (newValue <= 0 && newValue >= -140) {
        translateX.value = newValue;
      }
    })
    .onEnd(() => {
      // If swiped more than 60px, snap to -120 (show actions)
      // Otherwise snap back to 0
      if (translateX.value < -60) {
        translateX.value = withSpring(-120);
        runOnJS(triggerHaptic)(Haptics.ImpactFeedbackStyle.Light);
      } else {
        translateX.value = withSpring(0);
      }
    });

  const cardAnimatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }],
  }));

  const actionsAnimatedStyle = useAnimatedStyle(() => ({
    opacity: translateX.value < -40 ? 1 : 0,
  }));

  return (
    <View className="mb-6">
      {/* User Header */}
      <View className="flex-row items-center mb-3 mx-4">
        <Pressable onPress={handleAvatarPress} className="active:opacity-70">
          <Text style={{ fontSize: 40, lineHeight: 44 }}>{avatar}</Text>
        </Pressable>
        <View className="ml-3 flex-1">
          <View className="flex-row items-center" style={{ gap: 4 }}>
            <ColoredUsername
              username={memory.authorName || 'User'}
              color={memory.authorUsernameColor}
              size={15}
              weight="600"
              defaultColor={theme.colors.text}
            />
            <VerifiedBadge isVerified={memory.isVerified === true} size={14} checkColor={theme.colors.primary} />
          </View>
          <View className="flex-row items-center">
            <Text style={{ color: theme.colors.textSecondary, fontSize: 12 }}>
              {formatTimeAgo(memory.createdAt)}
            </Text>
            {memory.location && (
              <>
                <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginHorizontal: 4 }}>
                  •
                </Text>
                <Pressable
                  onPress={() => {
                    if (memory.latitude && memory.longitude) {
                      triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                      setShowMapModal(true);
                    }
                  }}
                  className="flex-row items-center active:opacity-60"
                  style={{ maxWidth: 120 }}
                >
                  <MapPin size={12} color={theme.colors.textSecondary} strokeWidth={2} />
                  <Text
                    style={{ color: theme.colors.textSecondary, fontSize: 12, marginLeft: 2 }}
                    numberOfLines={1}
                  >
                    {memory.location}
                  </Text>
                </Pressable>
              </>
            )}
          </View>
        </View>

        {/* Emotion badge */}
        <View
          className="ml-auto rounded-full px-3 py-1.5"
          style={{ backgroundColor: `${theme.colors.accent}20` }}
        >
          <View className="flex-row items-center">
            <Text className="text-sm mr-1">{emotion?.icon}</Text>
            <Text style={{ color: theme.colors.accent, fontSize: 11, fontWeight: '600' }}>
              {emotion?.label}
            </Text>
          </View>
        </View>
      </View>

      {/* Swipeable Container */}
      <View style={{ position: 'relative' }}>
        {/* Action Buttons (behind the card) */}
        <Animated.View
          style={[
            {
              position: 'absolute',
              right: 16,
              top: 0,
              bottom: 0,
              flexDirection: 'row',
              alignItems: 'center',
              gap: 12,
            },
            actionsAnimatedStyle,
          ]}
        >
          {/* Share Button */}
          <Pressable
            onPress={handleShare}
            className="w-12 h-12 rounded-full items-center justify-center active:opacity-70"
            style={{ backgroundColor: `${theme.colors.accent}40` }}
          >
            <Share2 size={22} color={theme.colors.accent} strokeWidth={2} />
          </Pressable>

          {/* Hide Button */}
          <Pressable
            onPress={handleHide}
            className="w-12 h-12 rounded-full items-center justify-center active:opacity-70"
            style={{ backgroundColor: `${theme.colors.accent}40` }}
          >
            <EyeOff size={22} color={theme.colors.accent} strokeWidth={2} />
          </Pressable>
        </Animated.View>

        {/* Main Card with Swipe Gesture */}
        <GestureDetector gesture={panGesture}>
          <Animated.View style={[{ paddingHorizontal: 16 }, cardAnimatedStyle]}>
            {/* Media Container - Beautiful rounded card */}
            <Pressable
              onPress={() => {
                // Don't open modal if user was just holding or if card is swiped
                if (!wasHolding && Math.abs(translateX.value) < 10 && onPress) {
                  onPress();
                }
              }}
              onLongPress={() => {
                // Long press opens fullscreen media viewer
                if (memory.imageUrl || memory.videoUrl) {
                  triggerHaptic(Haptics.ImpactFeedbackStyle.Medium);
                  setShowMediaViewer(true);
                }
              }}
              className="overflow-hidden"
              style={{
                borderRadius: 24,
                backgroundColor: theme.colors.background,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 4 },
                shadowOpacity: 0.15,
                shadowRadius: 12,
                elevation: 8,
              }}
            >
        {memory.imageUrl || memory.videoUrl ? (
          isVideo && !videoError ? (
            <CustomVideoPlayer
              uri={memory.videoUrl!}
              aspectRatio={imageAspectRatio || 1}
              resizeMode={ResizeMode.COVER}
              onError={() => setVideoError(true)}
              onHoldStart={handleHoldStart}
              onHoldEnd={handleHoldEnd}
              isVisible={enableAutoplay}
              borderRadius={24}
            />
          ) : (
            <>
              {!imageLoaded && (
                <View style={{ position: 'absolute', width: '100%', height: '100%', zIndex: 1 }}>
                  <ImageSkeleton aspectRatio={1} borderRadius={24} />
                </View>
              )}
              <Image
                source={{ uri: memory.imageUrl }}
                style={{
                  width: '100%',
                  aspectRatio: imageAspectRatio || 1,
                }}
                contentFit="cover"
                transition={0}
                cachePolicy="disk"
                onLoadStart={() => setImageLoaded(false)}
                onLoad={() => {
                  setImageLoaded(true);
                }}
                onError={(error) => {
                  console.log('[MemoryCard] Image load error:', error);
                  setImageLoaded(true);
                }}
              />
            </>
          )
        ) : (
          <View
            style={{
              width: '100%',
              aspectRatio: 1,
              justifyContent: 'center',
              alignItems: 'center',
              padding: 24,
            }}
          >
            <LinearGradient
              colors={[`${theme.colors.accent}20`, `${theme.colors.accent}10`]}
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
              }}
            />
            <Text style={{ color: theme.colors.text, fontSize: 16, lineHeight: 24, textAlign: 'center' }}>
              {memory.text}
            </Text>
          </View>
        )}

        {/* Overlay UI - minimal, only visible when not holding */}
        <Animated.View
          style={[
            {
              position: 'absolute',
              bottom: 12,
              left: 12,
              right: 12,
            },
            uiAnimatedStyle,
          ]}
        >
          {/* Empty - buttons moved below card */}
        </Animated.View>
      </Pressable>

      {/* Actions and Caption on same line */}
      <View className="flex-row items-center justify-between mt-3">
        {/* Caption/Description - left side, flex-1 */}
        {memory.text && (
          <Pressable onPress={onPress} className="flex-1 mr-3">
            <Text
              style={{ color: theme.colors.text, fontSize: 15, lineHeight: 22 }}
              numberOfLines={2}
            >
              {memory.text}
            </Text>
          </Pressable>
        )}

        {/* Actions - right side */}
        <View className="flex-row items-center" style={{ gap: 12 }}>
          {/* Restore button (only in archive) */}
          {showRestoreButton && onRestore && (
            <Pressable
              onPress={onRestore}
              className="flex-row items-center active:opacity-60"
              style={{
                backgroundColor: `${theme.colors.accent}15`,
                borderRadius: 20,
                paddingHorizontal: 12,
                paddingVertical: 8,
              }}
            >
              <Animated.View>
                <ArchiveRestore
                  size={20}
                  color={theme.colors.accent}
                  strokeWidth={2}
                />
              </Animated.View>
            </Pressable>
          )}

          {/* Echo button */}
          <Pressable
            onPress={handleEcho}
            className="flex-row items-center active:opacity-60"
            style={{
              backgroundColor: `${theme.colors.accent}15`,
              borderRadius: 20,
              paddingHorizontal: 12,
              paddingVertical: 8,
            }}
          >
            <Animated.View style={echoAnimatedStyle}>
              <Waves
                size={20}
                color={theme.colors.accent}
                strokeWidth={2}
                fill={memory.hasEchoed ? theme.colors.accent : 'transparent'}
              />
            </Animated.View>
            {memory.echoCount > 0 && (
              <Text style={{ color: theme.colors.accent, fontSize: 14, marginLeft: 6, fontWeight: '600' }}>
                {memory.echoCount}
              </Text>
            )}
          </Pressable>

          {/* Save button */}
          <Pressable
            onPress={handleSave}
            onPressIn={handleSavePressIn}
            onPressOut={handleSavePressOut}
            style={{
              backgroundColor: `${theme.colors.accent}15`,
              borderRadius: 20,
              padding: 8,
            }}
          >
            <Animated.View style={saveAnimatedStyle}>
              <Bookmark
                size={20}
                color={theme.colors.accent}
                strokeWidth={2}
                fill={memory.isSaved ? theme.colors.accent : 'transparent'}
              />
            </Animated.View>
          </Pressable>
        </View>
      </View>
          </Animated.View>
        </GestureDetector>
      </View>

      {/* Location Map Modal */}
      {memory.location && memory.latitude && memory.longitude && (
        <LocationMapModal
          visible={showMapModal}
          onClose={() => setShowMapModal(false)}
          location={memory.location}
          latitude={memory.latitude}
          longitude={memory.longitude}
        />
      )}

      {/* Media Viewer Modal */}
      {(memory.imageUrl || memory.videoUrl) && (
        <MediaViewerModal
          visible={showMediaViewer}
          onClose={() => setShowMediaViewer(false)}
          mediaUrl={(memory.videoUrl || memory.imageUrl)!}
          isVideo={isVideo}
        />
      )}

      {/* User Profile Modal */}
      {memory.authorId && (
        <UserProfileModal
          visible={showProfileModal}
          onClose={() => setShowProfileModal(false)}
          userId={memory.authorId}
          onMemoryPress={(memoryId) => {
            setShowProfileModal(false);
            setTimeout(() => {
              if (onPress) {
                onPress();
              }
            }, 300);
          }}
        />
      )}
    </View>
  );
}

// Memoize to prevent unnecessary re-renders when parent updates
export const MemoryCard = memo(MemoryCardComponent, (prevProps, nextProps) => {
  // Only re-render if memory data or key props changed
  return (
    prevProps.memory.id === nextProps.memory.id &&
    prevProps.memory.hasEchoed === nextProps.memory.hasEchoed &&
    prevProps.memory.isSaved === nextProps.memory.isSaved &&
    prevProps.memory.echoCount === nextProps.memory.echoCount &&
    prevProps.enableAutoplay === nextProps.enableAutoplay
  );
});
