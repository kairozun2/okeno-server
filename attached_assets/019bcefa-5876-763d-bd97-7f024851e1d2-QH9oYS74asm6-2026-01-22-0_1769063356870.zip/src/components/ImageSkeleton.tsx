import React, { useEffect } from 'react';
import { View, StyleSheet, DimensionValue } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';

interface ImageSkeletonProps {
  width?: DimensionValue;
  height?: number;
  aspectRatio?: number;
  borderRadius?: number;
}

export function ImageSkeleton({
  width = '100%',
  height,
  aspectRatio,
  borderRadius = 0,
}: ImageSkeletonProps) {
  const shimmerTranslate = useSharedValue(-1);

  useEffect(() => {
    shimmerTranslate.value = withRepeat(
      withTiming(1, { duration: 1500, easing: Easing.linear }),
      -1,
      false
    );
  }, []);

  const shimmerStyle = useAnimatedStyle(() => {
    return {
      transform: [{ translateX: shimmerTranslate.value * 400 }],
    };
  });

  return (
    <View
      style={{
        width,
        height,
        aspectRatio: height ? undefined : aspectRatio,
        borderRadius,
        overflow: 'hidden',
        backgroundColor: 'rgba(200, 200, 200, 0.3)',
      }}
    >
      <View style={StyleSheet.absoluteFillObject}>
        <LinearGradient
          colors={['rgba(200, 200, 200, 0.2)', 'rgba(200, 200, 200, 0.4)', 'rgba(200, 200, 200, 0.2)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={StyleSheet.absoluteFillObject}
        />
      </View>
      <Animated.View style={[styles.shimmer, shimmerStyle]}>
        <LinearGradient
          colors={['transparent', 'rgba(255, 255, 255, 0.5)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={StyleSheet.absoluteFillObject}
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  shimmer: {
    width: '100%',
    height: '100%',
  },
});

