import React, { useEffect, useState } from 'react';
import { View, Text, Modal, Pressable, ActivityIndicator, ScrollView, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { ChevronLeft, Trash2 } from 'lucide-react-native';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useQueryClient } from '@tanstack/react-query';

interface CacheUsageModalProps {
  visible: boolean;
  onClose: () => void;
}

interface CacheBreakdown {
  messages: number;
  memories: number;
  profiles: number;
  notifications: number;
  other: number;
  total: number;
}

export function CacheUsageModal({ visible, onClose }: CacheUsageModalProps) {
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const [cacheData, setCacheData] = useState<CacheBreakdown | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isClearing, setIsClearing] = useState(false);

  const themeKey = useSettingsStore(s => s.theme);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const language = useSettingsStore(s => s.language);
  const theme = getTheme(themeKey);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  useEffect(() => {
    if (visible) {
      calculateCacheSize();
    }
  }, [visible]);

  const calculateCacheSize = async () => {
    setIsLoading(true);
    try {
      const keys = await AsyncStorage.getAllKeys();
      const appKeys = keys.filter(k => k.startsWith('@app_cache:'));

      let breakdown: CacheBreakdown = {
        messages: 0,
        memories: 0,
        profiles: 0,
        notifications: 0,
        other: 0,
        total: 0,
      };

      // Get all values and calculate sizes
      for (const key of appKeys) {
        const value = await AsyncStorage.getItem(key);
        if (value) {
          const sizeInBytes = new Blob([value]).size;
          const sizeInKB = sizeInBytes / 1024;

          breakdown.total += sizeInKB;

          if (key.includes('messages:')) {
            breakdown.messages += sizeInKB;
          } else if (key.includes('memories') || key.includes('my-memories') || key.includes('saved-memories') || key.includes('archived-memories')) {
            breakdown.memories += sizeInKB;
          } else if (key.includes('profile:') || key.includes('conversations')) {
            breakdown.profiles += sizeInKB;
          } else if (key.includes('notifications:')) {
            breakdown.notifications += sizeInKB;
          } else {
            breakdown.other += sizeInKB;
          }
        }
      }

      setCacheData(breakdown);
    } catch (error) {
      console.error('[CacheUsage] Error calculating cache size:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const clearCache = async () => {
    triggerHaptic();

    Alert.alert(
      language === 'ru' ? 'Очистить кэш?' : 'Clear Cache?',
      language === 'ru'
        ? 'Это удалит все локально сохранённые данные. Настройки приложения останутся.'
        : 'This will remove all locally cached data. App settings will remain.',
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
        },
        {
          text: language === 'ru' ? 'Очистить' : 'Clear',
          style: 'destructive',
          onPress: async () => {
            setIsClearing(true);
            try {
              // Clear AsyncStorage cache
              const keys = await AsyncStorage.getAllKeys();
              const cacheKeys = keys.filter(k => k.startsWith('@app_cache:'));
              await AsyncStorage.multiRemove(cacheKeys);

              // Clear React Query cache
              queryClient.clear();

              Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

              // Recalculate after clearing
              await calculateCacheSize();
            } catch (error) {
              console.error('[CacheUsage] Error clearing cache:', error);
              Alert.alert(
                language === 'ru' ? 'Ошибка' : 'Error',
                language === 'ru' ? 'Не удалось очистить кэш' : 'Failed to clear cache'
              );
            } finally {
              setIsClearing(false);
            }
          },
        },
      ]
    );
  };

  const formatSize = (kb: number) => {
    if (kb < 1024) {
      return `${kb.toFixed(1)} KB`;
    } else {
      return `${(kb / 1024).toFixed(2)} MB`;
    }
  };

  const getPercentage = (value: number, total: number) => {
    if (total === 0) return 0;
    return Math.round((value / total) * 100);
  };

  const categories = cacheData ? [
    { label: language === 'ru' ? 'Сообщения' : 'Messages', value: cacheData.messages, color: theme.colors.accent },
    { label: language === 'ru' ? 'Публикации' : 'Memories', value: cacheData.memories, color: '#FF6B6B' },
    { label: language === 'ru' ? 'Профили' : 'Profiles', value: cacheData.profiles, color: '#4ECDC4' },
    { label: language === 'ru' ? 'Уведомления' : 'Notifications', value: cacheData.notifications, color: '#FFD93D' },
    { label: language === 'ru' ? 'Другое' : 'Other', value: cacheData.other, color: '#95E1D3' },
  ] : [];

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
          style={{ flex: 1 }}
        >
          {/* Header */}
          <View style={{ paddingTop: insets.top + 8 }} className="px-5 pb-6">
            <Animated.View
              entering={FadeIn.duration(300)}
              className="flex-row items-center justify-between"
            >
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <ChevronLeft size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>

              <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500', position: 'absolute', left: 0, right: 0, textAlign: 'center', zIndex: -1 }}>
                {language === 'ru' ? 'Использование кэша' : 'Cache Usage'}
              </Text>

              <View className="w-10" />
            </Animated.View>
          </View>

          <ScrollView
            className="flex-1"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 40 }}
          >
            {isLoading ? (
              <View className="items-center py-20">
                <ActivityIndicator size="large" color={theme.colors.accent} />
                <Text style={{ color: theme.colors.textSecondary, fontSize: 14, marginTop: 12 }}>
                  {language === 'ru' ? 'Подсчёт размера кэша...' : 'Calculating cache size...'}
                </Text>
              </View>
            ) : cacheData ? (
              <>
                {/* Total Size Circle */}
                <Animated.View
                  entering={FadeIn.duration(400).delay(200)}
                  className="items-center mb-12 mt-8"
                >
                  <View
                    className="items-center justify-center"
                    style={{
                      width: 180,
                      height: 180,
                      borderRadius: 90,
                      backgroundColor: `${theme.colors.accent}15`,
                      borderWidth: 10,
                      borderColor: theme.colors.accent,
                    }}
                  >
                    <Text style={{ color: theme.colors.accent, fontSize: 36, fontWeight: '700' }}>
                      {formatSize(cacheData.total)}
                    </Text>
                    <Text style={{ color: theme.colors.textSecondary, fontSize: 15, marginTop: 4 }}>
                      {language === 'ru' ? 'Всего кэш' : 'Total Cache'}
                    </Text>
                  </View>
                </Animated.View>

                {/* Breakdown */}
                <View className="mb-8">
                  {categories.map((category, index) => {
                    const percentage = getPercentage(category.value, cacheData.total);
                    if (percentage === 0) return null;

                    return (
                      <Animated.View
                        key={category.label}
                        entering={FadeInDown.duration(300).delay(300 + index * 50)}
                        className="mb-6"
                      >
                        <View className="flex-row items-center justify-between mb-3">
                          <View className="flex-row items-center">
                            <View
                              style={{
                                width: 14,
                                height: 14,
                                borderRadius: 7,
                                backgroundColor: category.color,
                                marginRight: 10,
                              }}
                            />
                            <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                              {category.label}
                            </Text>
                          </View>
                          <Text style={{ color: theme.colors.textSecondary, fontSize: 15 }}>
                            {formatSize(category.value)} ({percentage}%)
                          </Text>
                        </View>
                        {/* Progress bar */}
                        <View
                          className="h-3 rounded-full overflow-hidden"
                          style={{ backgroundColor: `${theme.colors.text}10` }}
                        >
                          <Animated.View
                            entering={FadeIn.duration(600).delay(400 + index * 50)}
                            className="h-full rounded-full"
                            style={{
                              backgroundColor: category.color,
                              width: `${percentage}%`,
                            }}
                          />
                        </View>
                      </Animated.View>
                    );
                  })}
                </View>

                {/* Device Storage Note */}
                <Animated.View
                  entering={FadeIn.duration(400).delay(600)}
                  className="mb-6 p-4 rounded-2xl"
                  style={{ backgroundColor: `${theme.colors.accent}10` }}
                >
                  <Text style={{ color: theme.colors.textSecondary, fontSize: 14, lineHeight: 20, textAlign: 'center' }}>
                    {language === 'ru'
                      ? 'Показан только кэш приложения. Для полной информации о хранилище устройства проверьте Настройки iOS → Основные → Хранилище iPhone'
                      : 'This shows app cache only. For full device storage info, check iOS Settings → General → iPhone Storage'}
                  </Text>
                </Animated.View>

                {/* Clear Cache Button */}
                <Animated.View entering={FadeInDown.duration(400).delay(700)}>
                  <Pressable
                    onPress={clearCache}
                    disabled={isClearing || cacheData.total === 0}
                    className="rounded-2xl overflow-hidden active:opacity-80"
                    style={{
                      backgroundColor: isClearing || cacheData.total === 0 ? `#FF3B3040` : '#FF3B30',
                    }}
                  >
                    <View className="py-5 flex-row items-center justify-center">
                      {isClearing ? (
                        <ActivityIndicator size="small" color="#FFFFFF" />
                      ) : (
                        <>
                          <Trash2 size={20} color="#FFFFFF" strokeWidth={1.5} />
                          <Text style={{ color: '#FFFFFF', fontSize: 17, fontWeight: '600', marginLeft: 10 }}>
                            {language === 'ru' ? 'Очистить кэш' : 'Clear Cache'}
                          </Text>
                        </>
                      )}
                    </View>
                  </Pressable>
                </Animated.View>
              </>
            ) : null}
          </ScrollView>
        </LinearGradient>
      </View>
    </Modal>
  );
}
