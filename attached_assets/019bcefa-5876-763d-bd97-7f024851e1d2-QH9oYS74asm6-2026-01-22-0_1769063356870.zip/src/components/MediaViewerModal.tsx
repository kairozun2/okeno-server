import React, { useState } from 'react';
import { View, Modal, Pressable, Dimensions, Platform, Text } from 'react-native';
import { Image } from 'expo-image';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { X, ZoomIn, ZoomOut } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { CustomVideoPlayer } from '@/components/CustomVideoPlayer';
import { ResizeMode } from 'expo-av';
import { GestureDetector, Gesture } from 'react-native-gesture-handler';
import Animated, { useSharedValue, useAnimatedStyle, withSpring, withTiming } from 'react-native-reanimated';

const { width: SCREEN_WIDTH, height: SCREEN_HEIGHT } = Dimensions.get('window');

interface MediaViewerModalProps {
  visible: boolean;
  onClose: () => void;
  mediaUrl: string;
  isVideo?: boolean;
}

export function MediaViewerModal({ visible, onClose, mediaUrl, isVideo = false }: MediaViewerModalProps) {
  const insets = useSafeAreaInsets();
  const [isZoomed, setIsZoomed] = useState(false);
  const [imageLoaded, setImageLoaded] = useState(false);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  // Prefetch image when modal becomes visible
  React.useEffect(() => {
    if (visible && !isVideo && mediaUrl) {
      // Preload image
      Image.prefetch(mediaUrl).then(() => {
        setImageLoaded(true);
      }).catch((error) => {
        console.log('[MediaViewer] Prefetch error:', error);
        setImageLoaded(true);
      });
    }
  }, [visible, mediaUrl, isVideo]);

  // Local wrapper for haptic feedback
  const triggerHaptic = () => {
    if (hapticsEnabled) { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }
  };

  const scale = useSharedValue(1);
  const savedScale = useSharedValue(1);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);


  const handleDoubleTap = () => {
    triggerHaptic();
    if (isZoomed) {
      scale.value = withSpring(1);
      savedScale.value = 1;
      translateX.value = withSpring(0);
      translateY.value = withSpring(0);
      setIsZoomed(false);
    } else {
      scale.value = withSpring(2);
      savedScale.value = 2;
      setIsZoomed(true);
    }
  };

  const doubleTap = Gesture.Tap()
    .numberOfTaps(2)
    .onEnd(() => {
      handleDoubleTap();
    });

  const pinch = Gesture.Pinch()
    .onUpdate((e) => {
      scale.value = savedScale.value * e.scale;
    })
    .onEnd(() => {
      savedScale.value = scale.value;
      if (scale.value < 1) {
        scale.value = withSpring(1);
        savedScale.value = 1;
        translateX.value = withSpring(0);
        translateY.value = withSpring(0);
        setIsZoomed(false);
      } else if (scale.value > 1) {
        setIsZoomed(true);
      }
    });

  const pan = Gesture.Pan()
    .enabled(isZoomed)
    .onUpdate((e) => {
      translateX.value = e.translationX;
      translateY.value = e.translationY;
    })
    .onEnd(() => {
      translateX.value = withSpring(0);
      translateY.value = withSpring(0);
    });

  const composed = Gesture.Simultaneous(doubleTap, pinch, pan);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: scale.value },
      { translateX: translateX.value },
      { translateY: translateY.value },
    ],
  }));

  const handleClose = () => {
    triggerHaptic();
    // Reset zoom instantly for smooth close
    scale.value = 1;
    savedScale.value = 1;
    translateX.value = 0;
    translateY.value = 0;
    setIsZoomed(false);
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={handleClose}
    >
      <View className="flex-1 bg-black">
        {/* Media Content */}
        <View className="flex-1 items-center justify-center">
          {isVideo ? (
            <CustomVideoPlayer
              uri={mediaUrl}
              width={SCREEN_WIDTH}
              height={SCREEN_HEIGHT}
              resizeMode={ResizeMode.CONTAIN}
              isVisible={visible}
            />
          ) : (
            <GestureDetector gesture={composed}>
              <Animated.View style={[{ width: SCREEN_WIDTH, height: SCREEN_HEIGHT }, animatedStyle]}>
                {!imageLoaded && (
                  <View className="flex-1 items-center justify-center">
                    <View
                      className="w-12 h-12 rounded-full"
                      style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
                    />
                  </View>
                )}
                <Image
                  source={{ uri: mediaUrl }}
                  style={{ width: '100%', height: '100%' }}
                  contentFit="contain"
                  transition={200}
                  cachePolicy="memory-disk"
                  priority="high"
                  onLoad={() => setImageLoaded(true)}
                />
              </Animated.View>
            </GestureDetector>
          )}
        </View>

        {/* Close Button */}
        <View
          style={{
            position: 'absolute',
            top: insets.top + 8,
            right: 20,
            zIndex: 100,
          }}
        >
          <Pressable
            onPress={handleClose}
            className="w-12 h-12 rounded-full items-center justify-center active:opacity-60"
            style={{
              backgroundColor: 'rgba(0, 0, 0, 0.6)',
            }}
          >
            <X size={24} color="#FFFFFF" strokeWidth={1.5} />
          </Pressable>
        </View>

        {/* Zoom Indicator (only for images) */}
        {!isVideo && (
          <View
            style={{
              position: 'absolute',
              bottom: insets.bottom + 20,
              left: 0,
              right: 0,
              alignItems: 'center',
              zIndex: 100,
            }}
          >
            <View
              className="flex-row items-center px-4 py-2 rounded-full"
              style={{
                backgroundColor: 'rgba(0, 0, 0, 0.6)',
              }}
            >
              {isZoomed ? (
                <ZoomOut size={16} color="#FFFFFF" strokeWidth={1.5} />
              ) : (
                <ZoomIn size={16} color="#FFFFFF" strokeWidth={1.5} />
              )}
              <Text style={{ fontSize: 12, color: '#FFFFFF', opacity: 0.8, marginLeft: 8 }}>
                {isZoomed ? 'Pinch to zoom out' : 'Double tap to zoom'}
              </Text>
            </View>
          </View>
        )}
      </View>
    </Modal>
  );
}
