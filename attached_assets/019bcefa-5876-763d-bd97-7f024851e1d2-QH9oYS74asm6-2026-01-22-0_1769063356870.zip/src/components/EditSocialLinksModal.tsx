import React, { useState } from 'react';
import { View, Text, Modal, Pressable, TextInput, ScrollView, Alert, Clipboard } from 'react-native';
import { BlurView } from 'expo-blur';
import { X, Plus, Trash2, Clipboard as ClipboardIcon } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { supabase } from '@/lib/supabase';
import { useQueryClient } from '@tanstack/react-query';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';
import { useSettingsStore } from '@/lib/settings-store';
import { useTranslation } from '@/lib/i18n';

interface SocialLink {
  platform: string;
  url: string;
}

interface EditSocialLinksModalProps {
  visible: boolean;
  onClose: () => void;
  currentLinks: SocialLink[];
  userId: string;
}

// Allowed social media platforms (no porn/banned sites)
const ALLOWED_PLATFORMS = [
  'instagram.com',
  'instagr.am',
  't.me',
  'telegram.me',
  'youtube.com',
  'youtu.be',
  'twitter.com',
  'x.com',
  'facebook.com',
  'fb.com',
  'tiktok.com',
  'linkedin.com',
  'github.com',
  'reddit.com',
  'pinterest.com',
  'snapchat.com',
  'twitch.tv',
  'discord.gg',
  'discord.com',
  'spotify.com',
  'soundcloud.com',
  'vk.com',
  'ok.ru',
];

// Validate if URL is from an allowed platform
function isAllowedUrl(url: string): boolean {
  const lowerUrl = url.toLowerCase();

  // Must start with http:// or https://
  if (!lowerUrl.startsWith('http://') && !lowerUrl.startsWith('https://')) {
    return false;
  }

  // Check if URL contains any allowed platform
  return ALLOWED_PLATFORMS.some(platform => lowerUrl.includes(platform));
}

export function EditSocialLinksModal({ visible, onClose, currentLinks, userId }: EditSocialLinksModalProps) {
  const [links, setLinks] = useState<SocialLink[]>(
    currentLinks.length > 0
      ? currentLinks
      : [{ platform: '', url: '' }, { platform: '', url: '' }] // Минимум 2 поля
  );
  const [isSaving, setIsSaving] = useState(false);
  const queryClient = useQueryClient();
  const language = useSettingsStore(s => s.language);
  const t = useTranslation(language);

  // Update links when modal opens or currentLinks changes
  React.useEffect(() => {
    if (visible) {
      // Всегда ровно 2 поля (не больше, не меньше)
      if (currentLinks.length === 0) {
        setLinks([{ platform: '', url: '' }, { platform: '', url: '' }]);
      } else if (currentLinks.length === 1) {
        setLinks([...currentLinks, { platform: '', url: '' }]);
      } else {
        // Берём только первые 2 ссылки
        setLinks(currentLinks.slice(0, 2));
      }
    }
  }, [visible, currentLinks]);

  const removeLink = (index: number) => {
    // Очистить URL вместо удаления поля
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const newLinks = [...links];
    newLinks[index].url = '';
    setLinks(newLinks);
  };

  const updateLink = (index: number, url: string) => {
    const newLinks = [...links];
    newLinks[index].url = url;
    setLinks(newLinks);
  };

  const pasteFromClipboard = async (index: number) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const text = await Clipboard.getString();
    if (text) {
      updateLink(index, text);
    }
  };

  const handleSave = async () => {
    // Filter out empty links
    const validLinks = links.filter(link => link.url.trim() !== '');

    // Validate all URLs
    for (const link of validLinks) {
      if (!isAllowedUrl(link.url)) {
        Alert.alert(
          t('socialLinks.invalidUrlTitle'),
          t('socialLinks.invalidUrlMessage'),
          [{ text: 'OK' }]
        );
        return;
      }
    }

    setIsSaving(true);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);

    try {
      const { error } = await supabase
        .from('profiles')
        .update({ social_links: validLinks })
        .eq('id', userId);

      if (error) throw error;

      // Invalidate ALL related queries to ensure UI updates everywhere
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['auth'] }),
        queryClient.invalidateQueries({ queryKey: ['user-profile'] }),
        queryClient.invalidateQueries({ queryKey: ['memories'] }),
        queryClient.invalidateQueries({ queryKey: ['my-memories'] }),
        queryClient.invalidateQueries({ queryKey: ['user-memories'] }),
      ]);

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onClose();
    } catch (error) {
      console.error('Error saving social links:', error);
      Alert.alert(t('socialLinks.errorTitle'), t('socialLinks.errorMessage'));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <Modal visible={visible} animationType="slide" transparent>
      <BlurView intensity={40} tint="dark" style={{ flex: 1 }}>
        <KeyboardAwareScrollView
          style={{ flex: 1 }}
          contentContainerStyle={{ flex: 1 }}
          bottomOffset={40}
        >
          <View
            style={{
              flex: 1,
              backgroundColor: 'rgba(0,0,0,0.7)',
              justifyContent: 'flex-end',
            }}
          >
            <View
              style={{
                backgroundColor: '#1C1C1E',
                borderTopLeftRadius: 24,
                borderTopRightRadius: 24,
                paddingTop: 24,
                paddingBottom: 40,
                paddingHorizontal: 20,
                maxHeight: '80%',
              }}
            >
              {/* Header */}
              <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 }}>
                <Text style={{ color: '#FFFFFF', fontSize: 20, fontWeight: '700' }}>{t('socialLinks.title')}</Text>
                <Pressable
                  onPress={onClose}
                  style={{
                    width: 32,
                    height: 32,
                    borderRadius: 16,
                    backgroundColor: 'rgba(255,255,255,0.1)',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <X size={20} color="#FFFFFF" strokeWidth={2} />
                </Pressable>
              </View>

              {/* Info Text */}
              <Text style={{ color: 'rgba(255,255,255,0.6)', fontSize: 14, marginBottom: 16 }}>
                {t('socialLinks.description')}
              </Text>

              {/* Links List */}
              <ScrollView style={{ maxHeight: 300, marginBottom: 20 }} showsVerticalScrollIndicator={false}>
                {links.map((link, index) => (
                  <View
                    key={index}
                    style={{
                      marginBottom: 12,
                      backgroundColor: 'rgba(255,255,255,0.05)',
                      borderRadius: 12,
                      padding: 12,
                    }}
                  >
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      {/* Paste Button */}
                      <Pressable
                        onPress={() => pasteFromClipboard(index)}
                        style={{
                          width: 36,
                          height: 36,
                          borderRadius: 18,
                          backgroundColor: 'rgba(0,122,255,0.2)',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        <ClipboardIcon size={18} color="#007AFF" strokeWidth={2} />
                      </Pressable>

                      {/* Input Field */}
                      <TextInput
                        value={link.url}
                        onChangeText={(text) => updateLink(index, text)}
                        placeholder={t('socialLinks.placeholder')}
                        placeholderTextColor="rgba(255,255,255,0.3)"
                        style={{
                          flex: 1,
                          color: '#FFFFFF',
                          fontSize: 15,
                          paddingVertical: 8,
                          paddingHorizontal: 12,
                          backgroundColor: 'rgba(255,255,255,0.08)',
                          borderRadius: 8,
                        }}
                        autoCapitalize="none"
                        autoCorrect={false}
                        keyboardType="url"
                      />

                      {/* Delete Button */}
                      <Pressable
                        onPress={() => removeLink(index)}
                        style={{
                          width: 36,
                          height: 36,
                          borderRadius: 18,
                          backgroundColor: 'rgba(255,59,48,0.2)',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        <Trash2 size={18} color="#FF3B30" strokeWidth={2} />
                      </Pressable>
                    </View>
                  </View>
                ))}
              </ScrollView>

              {/* Save Button */}
              <Pressable
                onPress={handleSave}
                disabled={isSaving}
                style={{
                  backgroundColor: '#007AFF',
                  paddingVertical: 16,
                  borderRadius: 12,
                  alignItems: 'center',
                  opacity: isSaving ? 0.6 : 1,
                }}
              >
                <Text style={{ color: '#FFFFFF', fontSize: 16, fontWeight: '600' }}>
                  {isSaving ? t('socialLinks.saving') : t('socialLinks.save')}
                </Text>
              </Pressable>
            </View>
          </View>
        </KeyboardAwareScrollView>
      </BlurView>
    </Modal>
  );
}
