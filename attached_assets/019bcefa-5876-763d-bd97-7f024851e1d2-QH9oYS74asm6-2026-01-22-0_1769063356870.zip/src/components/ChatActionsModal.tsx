import React from 'react';
import { View, Text, Modal, Pressable, FlatList, Alert } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { X, UserX, Trash2, BellOff } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useConversations, useAuth, useBlockUser, useDeleteConversation, useMuteUser } from '@/lib/supabase-hooks';
import { generateAvatar } from '@/lib/avatar';

interface ChatActionsModalProps {
  visible: boolean;
  onClose: () => void;
}

export function ChatActionsModal({ visible, onClose }: ChatActionsModalProps) {
  const insets = useSafeAreaInsets();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const { data: conversations = [] } = useConversations();
  const { data: auth } = useAuth();
  const currentUserId = auth?.session?.user?.id;

  const blockUserMutation = useBlockUser();
  const deleteConversationMutation = useDeleteConversation();
  const muteUserMutation = useMuteUser();

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleBlockUser = (userId: string, username: string) => {
    triggerHaptic();
    Alert.alert(
      language === 'ru' ? 'Заблокировать пользователя?' : 'Block User?',
      language === 'ru'
        ? `Вы больше не будете видеть посты от @${username}`
        : `You will no longer see posts from @${username}`,
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
        },
        {
          text: language === 'ru' ? 'Заблокировать' : 'Block',
          style: 'destructive',
          onPress: () => {
            blockUserMutation.mutate(userId);
            onClose();
          },
        },
      ]
    );
  };

  const handleDeleteConversation = (conversationId: string, username: string) => {
    triggerHaptic();
    Alert.alert(
      language === 'ru' ? 'Удалить переписку?' : 'Delete Conversation?',
      language === 'ru'
        ? `Переписка с @${username} будет удалена`
        : `Conversation with @${username} will be deleted`,
      [
        {
          text: language === 'ru' ? 'Отмена' : 'Cancel',
          style: 'cancel',
        },
        {
          text: language === 'ru' ? 'Удалить' : 'Delete',
          style: 'destructive',
          onPress: () => {
            deleteConversationMutation.mutate(conversationId);
          },
        },
      ]
    );
  };

  const handleMuteUser = (userId: string, username: string, isMuted: boolean) => {
    triggerHaptic();
    if (isMuted) {
      // Unmute
      muteUserMutation.mutate({ userId, muted: false });
    } else {
      // Mute
      Alert.alert(
        language === 'ru' ? 'Отключить уведомления?' : 'Mute Notifications?',
        language === 'ru'
          ? `Вы не будете получать уведомления от @${username}`
          : `You will not receive notifications from @${username}`,
        [
          {
            text: language === 'ru' ? 'Отмена' : 'Cancel',
            style: 'cancel',
          },
          {
            text: language === 'ru' ? 'Отключить' : 'Mute',
            onPress: () => {
              muteUserMutation.mutate({ userId, muted: true });
            },
          },
        ]
      );
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
        {/* Header */}
        <View
          style={{
            paddingTop: insets.top + 16,
            paddingHorizontal: 20,
            paddingBottom: 16,
            borderBottomWidth: 1,
            borderBottomColor: `${theme.colors.text}10`,
          }}
        >
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: '700' }}>
              {language === 'ru' ? 'Управление чатами' : 'Manage Chats'}
            </Text>
            <Pressable
              onPress={() => {
                triggerHaptic();
                onClose();
              }}
              style={{
                width: 32,
                height: 32,
                borderRadius: 16,
                backgroundColor: `${theme.colors.accent}20`,
                alignItems: 'center',
                justifyContent: 'center',
              }}
            >
              <X size={18} color={theme.colors.accent} strokeWidth={2} />
            </Pressable>
          </View>
        </View>

        {/* Conversations List */}
        {conversations.length === 0 ? (
          <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 40 }}>
            <Text style={{ color: `${theme.colors.text}60`, fontSize: 16, textAlign: 'center' }}>
              {language === 'ru' ? 'Нет чатов' : 'No chats'}
            </Text>
          </View>
        ) : (
          <FlatList
            data={conversations}
            keyExtractor={(item) => item.id}
            renderItem={({ item }) => {
              // Determine which user is the "other" user
              const otherUser = item.user1_id === currentUserId ? item.user2 : item.user1;
              const avatarEmoji = otherUser?.avatar_emoji || generateAvatar(otherUser?.username || '');
              const username = otherUser?.username || 'Unknown';
              const userId = otherUser?.id || '';
              // TODO: Get muted status from database
              const isMuted = false;

              return (
                <View
                  style={{
                    flexDirection: 'row',
                    alignItems: 'center',
                    padding: 16,
                    marginHorizontal: 16,
                    marginBottom: 8,
                    borderRadius: 16,
                    backgroundColor: `${theme.colors.primaryLight}40`,
                  }}
                >
                  {/* Avatar */}
                  <Text style={{ fontSize: 32, marginRight: 12 }}>{avatarEmoji}</Text>

                  {/* Username */}
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: theme.colors.text, fontSize: 17, fontWeight: '600' }}>
                      {username}
                    </Text>
                    {isMuted && (
                      <Text style={{ color: `${theme.colors.text}60`, fontSize: 13, marginTop: 2 }}>
                        {language === 'ru' ? 'Уведомления отключены' : 'Notifications muted'}
                      </Text>
                    )}
                  </View>

                  {/* Action Buttons */}
                  <View style={{ flexDirection: 'row', gap: 8 }}>
                    {/* Mute/Unmute */}
                    <Pressable
                      onPress={() => handleMuteUser(userId, username, isMuted)}
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 20,
                        backgroundColor: isMuted ? `${theme.colors.accent}20` : `${theme.colors.text}10`,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <BellOff
                        size={18}
                        color={isMuted ? theme.colors.accent : `${theme.colors.text}60`}
                        strokeWidth={2}
                      />
                    </Pressable>

                    {/* Delete Conversation */}
                    <Pressable
                      onPress={() => handleDeleteConversation(item.id, username)}
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 20,
                        backgroundColor: `${theme.colors.text}10`,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <Trash2 size={18} color="#FF3B30" strokeWidth={2} />
                    </Pressable>

                    {/* Block User */}
                    <Pressable
                      onPress={() => handleBlockUser(userId, username)}
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: 20,
                        backgroundColor: `${theme.colors.text}10`,
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      <UserX size={18} color="#FF3B30" strokeWidth={2} />
                    </Pressable>
                  </View>
                </View>
              );
            }}
            contentContainerStyle={{ paddingTop: 8, paddingBottom: insets.bottom + 20 }}
            showsVerticalScrollIndicator={false}
          />
        )}
      </View>
    </Modal>
  );
}
