import React, { useState, useRef, useEffect } from 'react';
import { View, StyleSheet, DimensionValue } from 'react-native';
import { Video, ResizeMode, AVPlaybackStatus, Audio } from 'expo-av';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, { useAnimatedStyle, useSharedValue, withTiming, runOnJS } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';

interface CustomVideoPlayerProps {
  uri: string;
  width?: DimensionValue;
  height?: number;
  aspectRatio?: number;
  resizeMode?: ResizeMode;
  onError?: () => void;
  autoPlay?: boolean;
  isVisible?: boolean; // For autoplay when visible
  hideControls?: boolean; // For edit mode
  onHoldStart?: () => void; // Callback when user starts holding
  onHoldEnd?: () => void; // Callback when user stops holding
  borderRadius?: number; // Add border radius support
}

export function CustomVideoPlayer({
  uri,
  width = '100%',
  height,
  aspectRatio = 4 / 3,
  resizeMode = ResizeMode.CONTAIN,
  onError,
  autoPlay = false,
  isVisible = false, // Changed default to false
  hideControls = false,
  onHoldStart,
  onHoldEnd,
  borderRadius = 0, // Default no border radius
}: CustomVideoPlayerProps) {
  const videoRef = useRef<Video>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [position, setPosition] = useState(0);
  const [isLoaded, setIsLoaded] = useState(false);
  const [isHolding, setIsHolding] = useState(false);

  const controlsOpacity = useSharedValue(1);

  // Set audio mode to play sound
  useEffect(() => {
    if (!hideControls) {
      Audio.setAudioModeAsync({
        playsInSilentModeIOS: true,
        staysActiveInBackground: false,
        shouldDuckAndroid: true,
      });
    }
  }, [hideControls]);

  // Autoplay when visible AND loaded - Instagram-like behavior
  useEffect(() => {
    if (!isLoaded || hideControls) return;

    // If not visible, always pause
    if (!isVisible) {
      videoRef.current?.pauseAsync();
      return;
    }

    // If visible and not holding, play
    if (isVisible && !isHolding) {
      videoRef.current?.playAsync();
    }
  }, [isVisible, hideControls, isLoaded, isHolding]);

  const onPlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (status.isLoaded) {
      setIsPlaying(status.isPlaying);
      setDuration(status.durationMillis || 0);
      setPosition(status.positionMillis || 0);

      // Set loaded flag
      if (!isLoaded) {
        setIsLoaded(true);
      }
    }
  };

  const hideControlsUI = () => {
    controlsOpacity.value = withTiming(0, { duration: 200 });
  };

  const showControlsUI = () => {
    controlsOpacity.value = withTiming(1, { duration: 200 });
  };

  const pauseVideo = async () => {
    await videoRef.current?.pauseAsync();
    setIsHolding(true);
  };

  const playVideo = async () => {
    setIsHolding(false);
    // Only play if still visible
    if (isVisible && !hideControls) {
      await videoRef.current?.playAsync();
    }
  };

  // Long press gesture - pause video and hide UI
  const longPress = Gesture.LongPress()
    .minDuration(200)
    .onStart(() => {
      runOnJS(Haptics.impactAsync)(Haptics.ImpactFeedbackStyle.Medium);
      runOnJS(hideControlsUI)();
      runOnJS(pauseVideo)();
      if (onHoldStart) runOnJS(onHoldStart)();
    })
    .onEnd(() => {
      runOnJS(showControlsUI)();
      runOnJS(playVideo)();
      if (onHoldEnd) runOnJS(onHoldEnd)();
    });

  const controlsAnimatedStyle = useAnimatedStyle(() => ({
    opacity: controlsOpacity.value,
  }));

  return (
    <View
      style={[
        styles.container,
        {
          width,
          height,
          aspectRatio: height ? undefined : aspectRatio,
          borderRadius,
          overflow: 'hidden',
        },
      ]}
    >
      <Video
        ref={videoRef}
        source={{ uri }}
        style={StyleSheet.absoluteFillObject}
        resizeMode={resizeMode}
        isMuted={hideControls} // Mute in edit mode, unmute in feed
        onPlaybackStatusUpdate={onPlaybackStatusUpdate}
        onError={onError}
        shouldPlay={false}
      />

      {!hideControls && (
        <GestureDetector gesture={longPress}>
          <Animated.View style={[StyleSheet.absoluteFillObject, controlsAnimatedStyle]} />
        </GestureDetector>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'relative',
    backgroundColor: '#000',
  },
});
