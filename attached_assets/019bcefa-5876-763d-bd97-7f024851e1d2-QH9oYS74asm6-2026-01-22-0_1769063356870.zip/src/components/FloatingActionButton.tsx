import React from 'react';
import { Pressable } from 'react-native';
import { Plus } from 'lucide-react-native';
import Animated, { useAnimatedStyle, withSpring, withSequence } from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Haptics from 'expo-haptics';
import { useRouter } from 'expo-router';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

export function FloatingActionButton() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const themeKey = useSettingsStore(s => s.theme);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const performanceMode = useSettingsStore(s => s.performanceMode);

  const theme = getTheme(themeKey);
  const [isPressed, setIsPressed] = React.useState(false);

  const animatedStyle = useAnimatedStyle(() => {
    if (performanceMode === 'high-performance') {
      // Minimal animation for performance
      return {
        transform: [{ scale: isPressed ? 0.9 : 1 }],
      };
    }

    // Full animations for balanced and quality modes
    return {
      transform: [
        {
          scale: withSpring(isPressed ? 0.85 : 1, {
            damping: 15,
            stiffness: 200,
          }),
        },
        {
          rotate: isPressed ? '-10deg' : '0deg',
        },
      ],
    };
  }, [isPressed, performanceMode]);

  const handlePress = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    router.push('/create-memory');
  };

  return (
    <AnimatedPressable
      onPress={handlePress}
      onPressIn={() => setIsPressed(true)}
      onPressOut={() => setIsPressed(false)}
      style={[
        {
          position: 'absolute',
          right: 20,
          bottom: insets.bottom + 80, // Above tab bar
          width: 60,
          height: 60,
          borderRadius: 30,
          backgroundColor: theme.colors.accent,
          alignItems: 'center',
          justifyContent: 'center',
          shadowColor: '#000',
          shadowOffset: { width: 0, height: 4 },
          shadowOpacity: 0.3,
          shadowRadius: 8,
          elevation: 8,
        },
        animatedStyle,
      ]}
    >
      <Plus size={28} color={theme.colors.primary} strokeWidth={2.5} />
    </AnimatedPressable>
  );
}
