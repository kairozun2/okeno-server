import React, { useEffect } from 'react';
import { View, Dimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withSequence,
  withTiming,
  FadeIn,
} from 'react-native-reanimated';

const { width } = Dimensions.get('window');
const GRID_ITEM_SIZE = (width - 6) / 3;

interface ProfileGridSkeletonProps {
  count?: number;
  backgroundColor?: string;
}

export function ProfileGridSkeleton({ count = 9, backgroundColor = 'rgba(255, 255, 255, 0.1)' }: ProfileGridSkeletonProps) {
  const opacity = useSharedValue(0.3);

  useEffect(() => {
    opacity.value = withRepeat(
      withSequence(
        withTiming(0.6, { duration: 1000 }),
        withTiming(0.3, { duration: 1000 })
      ),
      -1,
      false
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  return (
    <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 2 }}>
      {Array.from({ length: count }).map((_, index) => (
        <Animated.View
          key={index}
          entering={FadeIn.duration(300).delay(index * 50)}
          style={[
            {
              width: GRID_ITEM_SIZE,
              height: GRID_ITEM_SIZE,
              backgroundColor,
            },
            animatedStyle,
          ]}
        />
      ))}
    </View>
  );
}
