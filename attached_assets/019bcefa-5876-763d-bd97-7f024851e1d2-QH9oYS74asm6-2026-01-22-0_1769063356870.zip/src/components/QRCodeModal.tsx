import React from 'react';
import { View, Text, Pressable, Modal, Share } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Share2, ScanLine } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn } from 'react-native-reanimated';
import QRCode from 'react-native-qrcode-svg';
import { useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { generateAvatarFromPattern } from '@/lib/avatar';
import { useAuth } from '@/lib/supabase-hooks';
import { generateUserLink } from '@/lib/deep-linking';

interface QRCodeModalProps {
  visible: boolean;
  onClose: () => void;
  onScan: () => void;
}

export function QRCodeModal({ visible, onClose, onScan }: QRCodeModalProps) {
  const insets = useSafeAreaInsets();

  const { data: auth } = useAuth();
  const localUserName = useAppStore(s => s.userName);

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  // Local wrapper for haptic feedback
  const triggerHaptic = () => {
    if (hapticsEnabled) { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }
  };

  // Use real data from Supabase
  const userName = auth?.profile?.username || localUserName;
  const userId = auth?.profile?.id || '';
  const avatar = auth?.profile?.avatar_emoji || '👤';


  const handleShare = async () => {
    triggerHaptic();
    try {
      // Generate deep link for user profile
      const deepLink = generateUserLink(userId);

      const message = `${language === 'ru' ? 'Добавь меня в Memories!' : 'Add me on Memories!'}\n\n${language === 'ru' ? 'Пользователь' : 'Username'}: ${userName}\n\n${deepLink}`;

      await Share.share({
        title: language === 'ru' ? 'Поделиться профилем' : 'Share Profile',
        message: message,
      });

      if (hapticsEnabled) {
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      }
    } catch (error) {
      console.error('Error sharing QR code:', error);
    }
  };

  const handleScan = () => {
    triggerHaptic();
    onScan();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
          style={{ flex: 1 }}
        >
          {/* Header */}
          <View
            style={{
              paddingTop: insets.top + 8,
              paddingHorizontal: 20,
              paddingBottom: 12,
            }}
          >
            <View className="flex-row items-center justify-between">
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>

              <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '600' }}>
                {language === 'ru' ? 'Мой QR-код' : 'My QR Code'}
              </Text>

              <Pressable
                onPress={handleShare}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <Share2 size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </View>
          </View>

          {/* Content */}
          <View className="flex-1 items-center justify-center px-8">
            <Animated.View entering={FadeIn.duration(300)} className="items-center">
              {/* Avatar */}
              <Text style={{ fontSize: 72, lineHeight: 80, marginBottom: 16 }}>{avatar}</Text>

              {/* User Name */}
              <Text style={{
                color: theme.colors.text,
                fontSize: 24,
                fontWeight: '600',
                marginBottom: 32,
                textAlign: 'center',
              }}>
                {userName || (language === 'ru' ? 'Пользователь' : 'User')}
              </Text>

              {/* QR Code */}
              <View
                style={{
                  backgroundColor: '#FFFFFF',
                  padding: 24,
                  borderRadius: 24,
                  marginBottom: 24,
                  alignItems: 'center',
                  justifyContent: 'center',
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 4 },
                  shadowOpacity: 0.15,
                  shadowRadius: 12,
                }}
              >
                {userId ? (
                  <QRCode
                    value={JSON.stringify({ userId, userName })}
                    size={200}
                    backgroundColor="white"
                    color="black"
                  />
                ) : (
                  <Text style={{ color: '#666', fontSize: 14 }}>
                    {language === 'ru' ? 'Загрузка...' : 'Loading...'}
                  </Text>
                )}
              </View>

              {/* User ID */}
              <Text style={{
                color: theme.colors.textSecondary,
                fontSize: 13,
                marginBottom: 8,
                fontFamily: 'monospace',
              }}>
                {language === 'ru' ? 'ID' : 'ID'}
              </Text>
              <View
                style={{
                  backgroundColor: `${theme.colors.accent}15`,
                  paddingHorizontal: 16,
                  paddingVertical: 8,
                  borderRadius: 12,
                  marginBottom: 48,
                }}
              >
                <Text style={{
                  color: theme.colors.text,
                  fontSize: 12,
                  fontFamily: 'monospace',
                }}>
                  {userId}
                </Text>
              </View>

              {/* Scan Button */}
              <Pressable
                onPress={handleScan}
                className="active:opacity-80"
                style={{
                  backgroundColor: theme.colors.accent,
                  paddingVertical: 16,
                  paddingHorizontal: 32,
                  borderRadius: 16,
                  flexDirection: 'row',
                  alignItems: 'center',
                  gap: 12,
                  shadowColor: '#000',
                  shadowOffset: { width: 0, height: 2 },
                  shadowOpacity: 0.1,
                  shadowRadius: 8,
                }}
              >
                <ScanLine size={20} color={theme.colors.primary} strokeWidth={2} />
                <Text style={{
                  color: theme.colors.primary,
                  fontSize: 16,
                  fontWeight: '600',
                }}>
                  {language === 'ru' ? 'Сканировать QR-код' : 'Scan QR Code'}
                </Text>
              </Pressable>
            </Animated.View>
          </View>
        </LinearGradient>
      </View>
    </Modal>
  );
}
