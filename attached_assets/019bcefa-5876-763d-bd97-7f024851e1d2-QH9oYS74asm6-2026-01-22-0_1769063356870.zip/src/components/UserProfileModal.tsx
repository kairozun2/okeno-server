import React, { useState, useEffect } from 'react';
import { View, Text, Pressable, Image, Dimensions, Modal, FlatList } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { X, MessageCircle, Play } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, useAnimatedScrollHandler, useSharedValue, useAnimatedStyle, interpolate, Extrapolate } from 'react-native-reanimated';
import { useRouter } from 'expo-router';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/supabase-hooks';
import { EMOTIONS } from '@/lib/store';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ColoredUsername } from '@/components/ColoredUsername';

const { width } = Dimensions.get('window');
const GRID_ITEM_SIZE = (width - 6) / 3;

const AnimatedScrollView = Animated.createAnimatedComponent(Animated.ScrollView);

interface UserProfileModalProps {
  visible: boolean;
  onClose: () => void;
  userId: string;
  onMemoryPress?: (memoryId: string) => void;
}

export function UserProfileModal({ visible, onClose, userId, onMemoryPress }: UserProfileModalProps) {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const scrollY = useSharedValue(0);

  // Get current user
  const { data: auth } = useAuth();
  const currentUserId = auth?.session?.user?.id;
  const isOwnProfile = currentUserId === userId;

  // Fetch user profile with prefetching
  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['user-profile', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('id, username, avatar_emoji, is_verified, is_admin, username_color')
        .eq('id', userId)
        .single();
      if (error) throw error;
      return data;
    },
    staleTime: 5 * 60 * 1000, // Cache for 5 minutes
    enabled: !!userId,
  });

  // Fetch user memories with aggressive caching
  const { data: memories = [], isLoading: isLoadingMemories } = useQuery({
    queryKey: ['user-memories', userId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('memories')
        .select('*')
        .eq('user_id', userId)
        .eq('is_archived', false)
        .order('created_at', { ascending: false })
        .limit(50); // Limit to 50 for performance
      if (error) throw error;
      return data;
    },
    staleTime: 2 * 60 * 1000, // Cache for 2 minutes
    enabled: !!userId && visible,
  });

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  // Animated blur header opacity
  const headerBlurStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 60],
      [0, 1],
      Extrapolate.CLAMP
    );
    return { opacity };
  });

  // Animated avatar in header
  const headerAvatarStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [60, 100],
      [0, 1],
      Extrapolate.CLAMP
    );
    const scale = interpolate(
      scrollY.value,
      [60, 100],
      [0.5, 1],
      Extrapolate.CLAMP
    );
    return { opacity, transform: [{ scale }] };
  });

  // Hide main avatar on scroll
  const mainAvatarStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 80],
      [1, 0],
      Extrapolate.CLAMP
    );
    return { opacity };
  });

  const totalEchoes = memories.reduce((sum, m) => sum + (m.echo_count || 0), 0);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
          style={{ flex: 1 }}
        >
          <AnimatedScrollView
            className="flex-1"
            showsVerticalScrollIndicator={false}
            onScroll={scrollHandler}
            scrollEventThrottle={16}
            contentContainerStyle={{ paddingBottom: insets.bottom + 40 }}
          >
            {/* Content starts with top padding */}
            <View style={{ paddingTop: insets.top + 60 }}>
              {/* Avatar + Name + Stats */}
              <Animated.View
                entering={FadeIn.duration(300)}
                style={mainAvatarStyle}
                className="items-center px-5 mb-8"
              >
                <Text style={{ fontSize: 80, lineHeight: 88, marginBottom: 12 }}>
                  {profile?.avatar_emoji || '👤'}
                </Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <ColoredUsername
                    username={profile?.username || 'User'}
                    color={profile?.username_color}
                    size={24}
                    weight="600"
                    defaultColor={theme.colors.text}
                  />
                  <VerifiedBadge isVerified={profile?.is_verified === true} size={20} checkColor={theme.colors.primary} />
                </View>

                {/* Stats */}
                <View className="flex-row justify-center mt-6" style={{ gap: 40 }}>
                  <View className="items-center">
                    <Text style={{ color: theme.colors.text, fontSize: 20, fontWeight: '300' }}>
                      {memories.length}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 4 }}>
                      {language === 'ru'
                        ? (memories.length === 1 ? 'пост' : memories.length < 5 ? 'поста' : 'постов')
                        : (memories.length === 1 ? 'post' : 'posts')}
                    </Text>
                  </View>
                  <View className="items-center">
                    <Text style={{ color: theme.colors.text, fontSize: 20, fontWeight: '300' }}>
                      {totalEchoes}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 4 }}>
                      {language === 'ru' ? 'эхо' : 'echoes'}
                    </Text>
                  </View>
                </View>

                {/* Message Button */}
                {!isOwnProfile && (
                  <Pressable
                    onPress={() => {
                      triggerHaptic();
                      onClose();
                      setTimeout(() => {
                        router.push(`/chat?id=${userId}&userId=${userId}&username=${profile?.username}`);
                      }, 300);
                    }}
                    className="active:opacity-70"
                    style={{
                      marginTop: 20,
                      paddingHorizontal: 24,
                      paddingVertical: 12,
                      borderRadius: 24,
                      backgroundColor: theme.colors.accent,
                      flexDirection: 'row',
                      alignItems: 'center',
                      gap: 8,
                    }}
                  >
                    <MessageCircle size={18} color={theme.colors.primary} strokeWidth={2} />
                    <Text style={{ color: theme.colors.primary, fontSize: 15, fontWeight: '600' }}>
                      {language === 'ru' ? 'Написать сообщение' : 'Send Message'}
                    </Text>
                  </Pressable>
                )}
              </Animated.View>

              {/* Memories Grid - with skeleton if loading */}
              <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 2 }}>
                {isLoadingMemories ? (
                  // Skeleton grid
                  [1, 2, 3, 4, 5, 6].map((i) => (
                    <Animated.View
                      key={i}
                      entering={FadeIn.duration(300).delay(i * 50)}
                      style={{
                        width: GRID_ITEM_SIZE,
                        height: GRID_ITEM_SIZE,
                        backgroundColor: `${theme.colors.accent}15`,
                      }}
                    />
                  ))
                ) : memories.length > 0 ? (
                  memories.map((memory) => {
                    const emotion = EMOTIONS.find(e => e.key === memory.emotion);
                    const isVideo = memory.video_url || (memory.image_url && (
                      memory.image_url.endsWith('.mp4') ||
                      memory.image_url.endsWith('.mov') ||
                      memory.image_url.includes('video')
                    ));

                    return (
                      <Pressable
                        key={memory.id}
                        onPress={() => {
                          triggerHaptic();
                          if (onMemoryPress) {
                            onMemoryPress(memory.id);
                          }
                        }}
                        style={{ width: GRID_ITEM_SIZE, height: GRID_ITEM_SIZE }}
                        className="active:opacity-80 relative"
                      >
                        {memory.image_url || memory.video_url ? (
                          <>
                            <Image
                              source={{
                                uri: memory.video_url || memory.image_url,
                                cache: 'force-cache',
                              }}
                              style={{ width: '100%', height: '100%' }}
                              resizeMode="cover"
                              progressiveRenderingEnabled={true}
                              fadeDuration={0}
                            />
                            {isVideo && (
                              <View
                                className="absolute inset-0 items-center justify-center"
                                style={{ backgroundColor: 'rgba(0, 0, 0, 0.2)' }}
                              >
                                <View
                                  className="w-10 h-10 rounded-full items-center justify-center"
                                  style={{ backgroundColor: 'rgba(255, 255, 255, 0.9)' }}
                                >
                                  <Play size={20} color="#000" fill="#000" />
                                </View>
                              </View>
                            )}
                          </>
                        ) : (
                          <LinearGradient
                            colors={[`${theme.colors.accent}30`, `${theme.colors.accent}15`]}
                            style={{
                              width: '100%',
                              height: '100%',
                              justifyContent: 'center',
                              alignItems: 'center',
                              padding: 8,
                            }}
                          >
                            <Text
                              style={{
                                color: theme.colors.text,
                                fontSize: 11,
                                lineHeight: 14,
                                textAlign: 'center',
                              }}
                              numberOfLines={6}
                            >
                              {memory.text}
                            </Text>
                          </LinearGradient>
                        )}

                        {/* Emotion indicator */}
                        <View
                          className="absolute bottom-1 right-1 rounded-full px-1.5 py-0.5"
                          style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)' }}
                        >
                          <Text style={{ fontSize: 10 }}>{emotion?.icon}</Text>
                        </View>
                      </Pressable>
                    );
                  })
                ) : (
                  <Animated.View
                    entering={FadeIn.duration(300)}
                    className="items-center py-12 px-8"
                    style={{ width: '100%' }}
                  >
                    <Text style={{ color: `${theme.colors.textSecondary}66`, textAlign: 'center', fontSize: 14 }}>
                      {language === 'ru' ? 'Нет воспоминаний' : 'No memories yet'}
                    </Text>
                  </Animated.View>
                )}
              </View>
            </View>
          </AnimatedScrollView>

          {/* Close Button - Always visible */}
          <View
            style={{
              position: 'absolute',
              top: insets.top + 8,
              right: 20,
              zIndex: 102,
            }}
          >
            <Pressable
              onPress={() => {
                triggerHaptic();
                onClose();
              }}
              className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
              style={{
                backgroundColor: `${theme.colors.accent}20`,
                shadowColor: '#000',
                shadowOffset: { width: 0, height: 2 },
                shadowOpacity: 0.1,
                shadowRadius: 4,
              }}
            >
              <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
            </Pressable>
          </View>

          {/* Animated Avatar in Header */}
          <Animated.View
            style={[
              {
                position: 'absolute',
                top: insets.top + 8,
                left: 0,
                right: 0,
                zIndex: 101,
                alignItems: 'center',
                justifyContent: 'center',
                height: 40,
              },
              headerAvatarStyle,
            ]}
            pointerEvents="none"
          >
            <View className="flex-row items-center" style={{ gap: 8 }}>
              <Text style={{ fontSize: 24, lineHeight: 28 }}>{profile?.avatar_emoji || '👤'}</Text>
              <ColoredUsername
                username={profile?.username || 'User'}
                color={profile?.username_color}
                size={16}
                weight="600"
                defaultColor={theme.colors.text}
              />
              <VerifiedBadge isVerified={profile?.is_verified === true} size={16} checkColor={theme.colors.primary} />
            </View>
          </Animated.View>
        </LinearGradient>
      </View>
    </Modal>
  );
}
