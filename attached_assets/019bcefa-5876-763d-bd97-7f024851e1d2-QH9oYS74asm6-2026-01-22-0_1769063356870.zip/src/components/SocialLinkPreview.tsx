import React from 'react';
import { View, Text, Pressable, Linking } from 'react-native';
import { Instagram, Send, Youtube, Twitter, Facebook, MessageCircle, Music, Globe } from 'lucide-react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as Haptics from 'expo-haptics';

interface SocialLink {
  platform: string;
  url: string;
  icon: React.ReactElement;
  gradient: string[];
  username?: string;
}

// Detect social media platform from URL
function detectSocialPlatform(url: string): SocialLink | null {
  const lowerUrl = url.toLowerCase();

  // Telegram
  if (lowerUrl.includes('t.me/') || lowerUrl.includes('telegram.me/')) {
    const username = url.split('/').pop()?.replace('@', '') || '';
    return {
      platform: 'Telegram',
      url,
      username,
      icon: <Send size={18} color="#FFFFFF" strokeWidth={2} />,
      gradient: ['#0088cc', '#229ED9'],
    };
  }

  // Instagram
  if (lowerUrl.includes('instagram.com/') || lowerUrl.includes('instagr.am/')) {
    const username = url.split('/').filter(Boolean).pop()?.replace('@', '') || '';
    return {
      platform: 'Instagram',
      url,
      username,
      icon: <Instagram size={18} color="#FFFFFF" strokeWidth={2} />,
      gradient: ['#833AB4', '#FD1D1D'],
    };
  }

  // YouTube
  if (lowerUrl.includes('youtube.com/') || lowerUrl.includes('youtu.be/')) {
    return {
      platform: 'YouTube',
      url,
      icon: <Youtube size={18} color="#FFFFFF" strokeWidth={2} />,
      gradient: ['#FF0000', '#CC0000'],
    };
  }

  // Twitter / X
  if (lowerUrl.includes('twitter.com/') || lowerUrl.includes('x.com/')) {
    const username = url.split('/').filter(Boolean).pop()?.replace('@', '') || '';
    return {
      platform: 'X',
      url,
      username,
      icon: <Twitter size={18} color="#FFFFFF" strokeWidth={2} />,
      gradient: ['#000000', '#14171A'],
    };
  }

  // Facebook
  if (lowerUrl.includes('facebook.com/') || lowerUrl.includes('fb.com/')) {
    return {
      platform: 'Facebook',
      url,
      icon: <Facebook size={18} color="#FFFFFF" strokeWidth={2} />,
      gradient: ['#1877F2', '#165DBB'],
    };
  }

  // WhatsApp
  if (lowerUrl.includes('wa.me/') || lowerUrl.includes('whatsapp.com/')) {
    return {
      platform: 'WhatsApp',
      url,
      icon: <MessageCircle size={18} color="#FFFFFF" strokeWidth={2} />,
      gradient: ['#25D366', '#128C7E'],
    };
  }

  // TikTok
  if (lowerUrl.includes('tiktok.com/')) {
    const username = url.split('/').filter(Boolean).pop()?.replace('@', '') || '';
    return {
      platform: 'TikTok',
      url,
      username,
      icon: <Music size={18} color="#FFFFFF" strokeWidth={2} />,
      gradient: ['#000000', '#EE1D52'],
    };
  }

  // Generic link (not a social media)
  return null;
}

interface SocialLinkPreviewProps {
  url: string;
}

export function SocialLinkPreview({ url }: SocialLinkPreviewProps) {
  const socialLink = detectSocialPlatform(url);

  if (!socialLink) {
    // Not a social media link - return regular clickable link
    return (
      <Pressable
        onPress={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          Linking.openURL(url).catch(err => {
            console.error('Failed to open URL:', err);
          });
        }}
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 6,
          paddingVertical: 8,
          paddingHorizontal: 12,
          borderRadius: 12,
          backgroundColor: 'rgba(255,255,255,0.1)',
          borderWidth: 1,
          borderColor: 'rgba(255,255,255,0.2)',
          marginVertical: 4,
        }}
      >
        <Globe size={18} color="#FFFFFF" strokeWidth={2} />
        <Text
          style={{
            color: '#FFFFFF',
            fontSize: 14,
            fontWeight: '500',
            flex: 1,
          }}
          numberOfLines={1}
        >
          {url.replace(/^https?:\/\/(www\.)?/, '').split('/')[0]}
        </Text>
      </Pressable>
    );
  }

  // Render social media link with branded icon - COMPACT VERSION
  return (
    <Pressable
      onPress={() => {
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        Linking.openURL(socialLink.url).catch(err => {
          console.error('Failed to open URL:', err);
        });
      }}
      style={{
        marginVertical: 4,
        borderRadius: 10,
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.15,
        shadowRadius: 2,
        elevation: 2,
      }}
    >
      <LinearGradient
        colors={socialLink.gradient as [string, string, ...string[]]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={{
          flexDirection: 'row',
          alignItems: 'center',
          gap: 8,
          paddingVertical: 8,
          paddingHorizontal: 10,
        }}
      >
        {/* Icon - smaller */}
        <View
          style={{
            width: 32,
            height: 32,
            borderRadius: 16,
            backgroundColor: 'rgba(255,255,255,0.25)',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {socialLink.icon}
        </View>

        {/* Platform and Username - more compact */}
        <View style={{ flex: 1 }}>
          <Text
            style={{
              color: '#FFFFFF',
              fontSize: 14,
              fontWeight: '700',
            }}
          >
            {socialLink.platform}
            {socialLink.username && (
              <Text
                style={{
                  color: 'rgba(255,255,255,0.85)',
                  fontSize: 13,
                  fontWeight: '500',
                }}
              >
                {' '}@{socialLink.username}
              </Text>
            )}
          </Text>
        </View>

        {/* Arrow indicator - smaller */}
        <View
          style={{
            width: 24,
            height: 24,
            borderRadius: 12,
            backgroundColor: 'rgba(255,255,255,0.3)',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <Text style={{ color: '#FFFFFF', fontSize: 14, fontWeight: '700' }}>→</Text>
        </View>
      </LinearGradient>
    </Pressable>
  );
}

// Extract all URLs from text
export function extractUrls(text: string): string[] {
  const urlRegex = /(https?:\/\/[^\s]+)/gi;
  return text.match(urlRegex) || [];
}

// Helper function to check if URL is a media file (image/video)
export function isMediaUrl(url: string): boolean {
  const mediaExtensions = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.mp4', '.mov', '.avi', '.mkv', '.svg', '.bmp', '.tiff', '.wav', '.mp3'];
  const lowerUrl = url.toLowerCase();

  for (const ext of mediaExtensions) {
    if (lowerUrl.endsWith(ext) || lowerUrl.includes(ext + '?') || lowerUrl.includes(ext + '#')) {
      return true;
    }
  }

  return false;
}
