import React, { useState } from 'react';
import { View, Text, Modal, Pressable, ScrollView, Alert, TouchableOpacity } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Check } from 'lucide-react-native';
import Animated, {
  FadeIn,
  FadeInDown,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withSequence,
  interpolate,
  Extrapolate,
  useAnimatedScrollHandler
} from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useAuth, useIsAdmin } from '@/lib/supabase-hooks';
import { supabase } from '@/lib/supabase';
import { BlurView } from 'expo-blur';
import { useQueryClient } from '@tanstack/react-query';

interface EditUsernameColorModalProps {
  visible: boolean;
  onClose: () => void;
  currentColor: string;
  lastChanged?: string | null;
}

const COLOR_PALETTE = [
  // Solid colors
  { name: 'Default', color: '#FFFFFF', type: 'solid' },
  { name: 'Red', color: '#FF3B30', type: 'solid' },
  { name: 'Orange', color: '#FF9500', type: 'solid' },
  { name: 'Yellow', color: '#FFCC00', type: 'solid' },
  { name: 'Lime', color: '#32CD32', type: 'solid' },
  { name: 'Green', color: '#34C759', type: 'solid' },
  { name: 'Mint', color: '#00C7BE', type: 'solid' },
  { name: 'Teal', color: '#30B0C7', type: 'solid' },
  { name: 'Cyan', color: '#32ADE6', type: 'solid' },
  { name: 'Blue', color: '#007AFF', type: 'solid' },
  { name: 'Indigo', color: '#5856D6', type: 'solid' },
  { name: 'Purple', color: '#AF52DE', type: 'solid' },
  { name: 'Pink', color: '#FF2D55', type: 'solid' },
  { name: 'Magenta', color: '#FF00FF', type: 'solid' },
  { name: 'Brown', color: '#A2845E', type: 'solid' },
  { name: 'Gold', color: '#FFD700', type: 'solid' },
  { name: 'Silver', color: '#C0C0C0', type: 'solid' },
  { name: 'Rose Gold', color: '#B76E79', type: 'solid' },
  { name: 'Crimson', color: '#DC143C', type: 'solid' },
  { name: 'Coral', color: '#FF7F50', type: 'solid' },
  { name: 'Peach', color: '#FFDAB9', type: 'solid' },
  { name: 'Lavender', color: '#E6E6FA', type: 'solid' },
  { name: 'Sky', color: '#87CEEB', type: 'solid' },
  { name: 'Ocean', color: '#006994', type: 'solid' },

  // Gradients (stored as "color1,color2" format)
  { name: 'Sunset', color: '#FF512F,#F09819', type: 'gradient' },
  { name: 'Ocean Blue', color: '#2E3192,#1BFFFF', type: 'gradient' },
  { name: 'Purple Dream', color: '#C471F5,#FA71CD', type: 'gradient' },
  { name: 'Mint Green', color: '#00F260,#0575E6', type: 'gradient' },
  { name: 'Fire', color: '#FF0000,#FFA500', type: 'gradient' },
  { name: 'Cool Sky', color: '#667EEA,#764BA2', type: 'gradient' },
  { name: 'Peach Glow', color: '#FFB88C,#DE6262', type: 'gradient' },
  { name: 'Rainbow', color: '#FF0080,#FF8C00,#FFD700', type: 'gradient' },
];

export function EditUsernameColorModal({ visible, onClose, currentColor, lastChanged }: EditUsernameColorModalProps) {
  const insets = useSafeAreaInsets();
  const [selectedColor, setSelectedColor] = useState(currentColor);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const scrollY = useSharedValue(0);
  const glowScale = useSharedValue(1);

  const themeKey = useSettingsStore(s => s.theme);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const language = useSettingsStore(s => s.language);
  const theme = getTheme(themeKey);
  const { data: auth } = useAuth();
  const isAdmin = useIsAdmin();
  const queryClient = useQueryClient();

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Animated scroll handler
  const scrollHandler = useAnimatedScrollHandler({
    onScroll: (event) => {
      scrollY.value = event.contentOffset.y;
    },
  });

  // Animated username in header (appears on scroll)
  const headerUsernameStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [60, 100],
      [0, 1],
      Extrapolate.CLAMP
    );

    const scale = interpolate(
      scrollY.value,
      [60, 100],
      [0.5, 1],
      Extrapolate.CLAMP
    );

    return {
      opacity,
      transform: [{ scale }],
    };
  });

  // Preview animation style (fades out on scroll)
  const previewStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      scrollY.value,
      [0, 100],
      [1, 0],
      Extrapolate.CLAMP
    );

    const translateY = interpolate(
      scrollY.value,
      [0, 100],
      [0, -20],
      Extrapolate.CLAMP
    );

    return {
      opacity,
      transform: [{ translateY }],
    };
  });

  // Glow animation for selected color
  const glowStyle = useAnimatedStyle(() => {
    return {
      transform: [{ scale: glowScale.value }],
      opacity: interpolate(glowScale.value, [1, 1.15], [0.5, 1], Extrapolate.CLAMP),
    };
  });

  // Trigger glow animation when color is selected
  const triggerGlow = () => {
    glowScale.value = withSequence(
      withSpring(1.15, { damping: 10, stiffness: 100 }),
      withSpring(1, { damping: 10, stiffness: 100 })
    );
  };

  // Check if user can change color (15 days cooldown, admins bypass)
  const canChangeColor = () => {
    if (isAdmin) return true;
    if (!lastChanged) return true;
    const daysSinceLastChange = (Date.now() - new Date(lastChanged).getTime()) / (1000 * 60 * 60 * 24);
    return daysSinceLastChange >= 15;
  };

  const getDaysUntilNextChange = () => {
    if (!lastChanged) return 0;
    const daysSinceLastChange = (Date.now() - new Date(lastChanged).getTime()) / (1000 * 60 * 60 * 24);
    return Math.ceil(15 - daysSinceLastChange);
  };

  const handleSave = async () => {
    triggerHaptic();

    if (!isAdmin && !canChangeColor()) {
      Alert.alert(
        language === 'ru' ? 'Слишком рано' : 'Too Soon',
        language === 'ru'
          ? `Вы сможете изменить цвет через ${getDaysUntilNextChange()} дней`
          : `You can change your color in ${getDaysUntilNextChange()} days`,
        [{ text: 'OK' }]
      );
      return;
    }

    if (selectedColor === currentColor) {
      onClose();
      return;
    }

    setIsSubmitting(true);

    try {
      // Update color in database
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          username_color: selectedColor,
          color_last_changed: new Date().toISOString(),
        })
        .eq('id', auth?.profile?.id);

      if (updateError) throw updateError;

      console.log('[UsernameColor] ✅ Color updated in database, clearing all caches...');

      // CRITICAL: Clear BOTH memory AND disk cache (AsyncStorage)
      // React Query has staleTime: Infinity, so we must clear disk cache too!

      // Step 1: Clear memory cache
      queryClient.clear();

      console.log('[UsernameColor] ✅ Memory cache cleared, fetching fresh data...');

      // Step 2: Fetch fresh data from server with new color
      // Do this in parallel for maximum speed
      await Promise.all([
        queryClient.refetchQueries({ queryKey: ['auth'] }),
        queryClient.refetchQueries({ queryKey: ['memories'] }),
        queryClient.refetchQueries({ queryKey: ['my-memories'] }),
        queryClient.refetchQueries({ queryKey: ['saved-memories'] }),
        queryClient.refetchQueries({ queryKey: ['user-memories'] }),
        queryClient.refetchQueries({ queryKey: ['user-profile'] }),
        queryClient.refetchQueries({ queryKey: ['conversations'] }),
        queryClient.refetchQueries({ queryKey: ['notifications'] }),
        queryClient.refetchQueries({ queryKey: ['search-users'] }),
        queryClient.refetchQueries({ queryKey: ['all-users'] }),
      ]);

      console.log('[UsernameColor] ✅ All data refreshed with new color!');

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

      // Close modal after success
      setTimeout(() => {
        onClose();
      }, 300);
    } catch (err: any) {
      console.log('[EditColor] Error:', err);
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        err.message || 'Failed to update color'
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  // Render username with color/gradient
  const renderUsername = (size: number = 16) => {
    const username = auth?.profile?.username || 'Username';

    if (selectedColor.includes(',')) {
      return (
        <LinearGradient
          colors={selectedColor.split(',') as [string, string, ...string[]]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          style={{
            borderRadius: 6,
            paddingVertical: 2,
            paddingHorizontal: 6,
          }}
        >
          <Text style={{ fontSize: size, fontWeight: '700', color: '#FFFFFF' }}>
            {username}
          </Text>
        </LinearGradient>
      );
    } else {
      return (
        <Text style={{ color: selectedColor, fontSize: size, fontWeight: '700' }}>
          {username}
        </Text>
      );
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primaryLight, theme.colors.primaryDark]}
          style={{ flex: 1 }}
        >
          {/* Static Header */}
          <View style={{ paddingTop: insets.top + 8, paddingBottom: 12 }} className="px-5">
            <View className="flex-row items-center justify-between">
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>

              {/* Static title (fades out on scroll) */}
              <Animated.View
                style={[
                  {
                    position: 'absolute',
                    left: 0,
                    right: 0,
                    alignItems: 'center',
                  },
                  useAnimatedStyle(() => ({
                    opacity: interpolate(
                      scrollY.value,
                      [60, 100],
                      [1, 0],
                      Extrapolate.CLAMP
                    ),
                  }))
                ]}
                pointerEvents="none"
              >
                <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                  {language === 'ru' ? 'Цвет имени' : 'Username Color'}
                </Text>
              </Animated.View>

              {/* Animated username in header (appears on scroll) */}
              <Animated.View
                style={[
                  {
                    position: 'absolute',
                    left: 0,
                    right: 0,
                    alignItems: 'center',
                  },
                  headerUsernameStyle,
                ]}
                pointerEvents="none"
              >
                {renderUsername(16)}
              </Animated.View>

              <Pressable
                onPress={handleSave}
                disabled={isSubmitting || (!isAdmin && !canChangeColor()) || selectedColor === currentColor}
                className="px-4 py-2 rounded-full active:opacity-70"
                style={{
                  backgroundColor: isSubmitting || (!isAdmin && !canChangeColor()) || selectedColor === currentColor
                    ? `${theme.colors.accent}40`
                    : theme.colors.accent,
                }}
              >
                <Text style={{ color: theme.colors.primary, fontSize: 15, fontWeight: '600' }}>
                  {isSubmitting ? '...' : (language === 'ru' ? 'Готово' : 'Done')}
                </Text>
              </Pressable>
            </View>
          </View>

          <Animated.ScrollView
            className="flex-1"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingHorizontal: 20, paddingBottom: insets.bottom + 40 }}
            onScroll={scrollHandler}
            scrollEventThrottle={16}
          >
            {/* Preview (fades out on scroll) */}
            <Animated.View
              entering={FadeIn.duration(400).delay(100)}
              style={[{ alignItems: 'center', marginBottom: 32 }, previewStyle]}
            >
              <Text style={{ color: theme.colors.textSecondary, fontSize: 14, marginBottom: 12 }}>
                {language === 'ru' ? 'Предпросмотр' : 'Preview'}
              </Text>
              {renderUsername(36)}
            </Animated.View>

            {/* Color Grid - Redesigned with square containers */}
            <View className="flex-row flex-wrap justify-center mb-6" style={{ gap: 16 }}>
              {COLOR_PALETTE.map((item, index) => {
                const isSelected = selectedColor === item.color;

                return (
                  <Animated.View
                    key={item.color}
                    entering={FadeInDown.duration(300).delay(150 + index * 20)}
                    style={{ width: 80, alignItems: 'center' }}
                  >
                    <View
                      onTouchEnd={() => {
                        triggerHaptic();
                        setSelectedColor(item.color);
                        triggerGlow();
                      }}
                      style={{ width: 80, alignItems: 'center' }}
                    >
                      {/* Glow effect for selected item */}
                      {isSelected && (
                        <Animated.View
                          style={[
                            {
                              position: 'absolute',
                              width: 72,
                              height: 72,
                              borderRadius: 12,
                              backgroundColor: theme.colors.accent,
                              top: 0,
                            },
                            glowStyle,
                          ]}
                        />
                      )}

                      {/* Square color container */}
                      <View
                        style={{
                          width: 72,
                          height: 72,
                          borderRadius: 12,
                          borderWidth: isSelected ? 3 : 2,
                          borderColor: isSelected ? '#FFFFFF' : 'rgba(255,255,255,0.2)',
                          overflow: 'hidden',
                          alignItems: 'center',
                          justifyContent: 'center',
                        }}
                      >
                        {item.type === 'gradient' ? (
                          <LinearGradient
                            colors={item.color.split(',') as [string, string, ...string[]]}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 0 }}
                            style={{
                              width: '100%',
                              height: '100%',
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            {isSelected && (
                              <Check size={32} color="#FFFFFF" strokeWidth={3} />
                            )}
                          </LinearGradient>
                        ) : (
                          <View
                            style={{
                              width: '100%',
                              height: '100%',
                              backgroundColor: item.color,
                              alignItems: 'center',
                              justifyContent: 'center',
                            }}
                          >
                            {isSelected && (
                              <Check size={32} color={item.color === '#FFFFFF' ? theme.colors.accent : '#FFFFFF'} strokeWidth={3} />
                            )}
                          </View>
                        )}
                      </View>

                      <Text style={{ color: theme.colors.textSecondary, fontSize: 11, marginTop: 8, textAlign: 'center' }}>
                        {item.name}
                      </Text>
                    </View>
                  </Animated.View>
                );
              })}
            </View>

            {/* Cooldown Warning */}
            {!isAdmin && !canChangeColor() && (
              <Animated.View
                entering={FadeIn.duration(400).delay(200)}
                className="p-4 rounded-2xl mb-4"
                style={{ backgroundColor: `${theme.colors.accent}15` }}
              >
                <Text style={{ color: theme.colors.text, fontSize: 14, lineHeight: 20, textAlign: 'center' }}>
                  {language === 'ru'
                    ? `Вы сможете изменить цвет через ${getDaysUntilNextChange()} дней`
                    : `You can change your color in ${getDaysUntilNextChange()} days`}
                </Text>
              </Animated.View>
            )}
          </Animated.ScrollView>
        </LinearGradient>
      </View>
    </Modal>
  );
}
