import React, { useEffect } from 'react';
import { View, Text, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, {
  FadeIn,
  FadeOut,
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withSequence,
  withTiming,
  Easing,
  interpolate,
} from 'react-native-reanimated';
import { useSettingsStore } from '@/lib/settings-store';
import { useAppStore } from '@/lib/store';
import { getTheme } from '@/lib/themes';
import { useAuth } from '@/lib/supabase-hooks';

interface LoadingScreenProps {
  onFinish?: () => void;
}

const { width, height } = Dimensions.get('window');

export function LoadingScreen({ onFinish }: LoadingScreenProps) {
  const themeKey = useSettingsStore(s => s.theme);
  const localUserName = useAppStore(s => s.userName);

  // Use Supabase auth data
  const { data: auth } = useAuth();
  const avatar = auth?.profile?.avatar_emoji || '👤';

  const theme = getTheme(themeKey);

  // iOS app opening animation - scale from small card to full screen
  const progress = useSharedValue(0);
  const scale = useSharedValue(0.1);
  const borderRadius = useSharedValue(40);
  const opacity = useSharedValue(0);

  useEffect(() => {
    // Start animation sequence like iOS app opening from app switcher
    opacity.value = withTiming(1, { duration: 100 });

    progress.value = withSequence(
      withSpring(1, {
        damping: 20,
        stiffness: 120,
        mass: 1,
      })
    );

    scale.value = withSpring(1, {
      damping: 20,
      stiffness: 120,
      mass: 1,
    });

    borderRadius.value = withSpring(0, {
      damping: 20,
      stiffness: 120,
      mass: 1,
    });

    // Auto-dismiss after animation
    const timer = setTimeout(() => {
      if (onFinish) onFinish();
    }, 1200);

    return () => clearTimeout(timer);
  }, []);

  const animatedContainerStyle = useAnimatedStyle(() => ({
    transform: [
      { scale: scale.value },
    ],
    borderRadius: borderRadius.value,
    opacity: opacity.value,
  }));

  const animatedContentStyle = useAnimatedStyle(() => ({
    transform: [
      {
        scale: interpolate(
          progress.value,
          [0, 1],
          [0.5, 1]
        )
      },
    ],
    opacity: interpolate(
      progress.value,
      [0, 0.5, 1],
      [0, 0.8, 1]
    ),
  }));

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#000' }}>
      <Animated.View
        style={[
          {
            width: width,
            height: height,
            overflow: 'hidden',
          },
          animatedContainerStyle,
        ]}
      >
        <LinearGradient
          colors={[theme.colors.primary, theme.colors.primaryLight, theme.colors.primaryDark]}
          style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}
        >
          <Animated.View style={[{ alignItems: 'center' }, animatedContentStyle]}>
            <Text style={{ fontSize: 80, lineHeight: 88 }}>{avatar}</Text>
          </Animated.View>
        </LinearGradient>
      </Animated.View>
    </View>
  );
}
