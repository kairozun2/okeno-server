import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Platform, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import { Key, Clipboard } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import * as ClipboardAPI from 'expo-clipboard';
import { VisualKeyPattern } from './VisualKeyPattern';
import { useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { useSignIn } from '@/lib/supabase-hooks';
import { supabase } from '@/lib/supabase';

type LoginStep = 'username' | 'pattern';

interface LoginFlowProps {
  onSuccess: () => void;
  onBack: () => void;
}

export function LoginFlow({ onSuccess, onBack }: LoginFlowProps) {
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState<LoginStep>('username');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');

  const setAuthenticated = useAppStore(s => s.setAuthenticated);
  const setUserName = useAppStore(s => s.setUserName);
  const setUserId = useAppStore(s => s.setUserId);
  const setVisualKeyPattern = useAppStore(s => s.setVisualKeyPattern);
  const setOnboarded = useAppStore(s => s.setOnboarded);
  const savedUserName = useAppStore(s => s.userName); // Get saved userName from store
  const savedUserId = useAppStore(s => s.userId); // Get saved userId from store
  const language = useSettingsStore(s => s.language);

  const signInMutation = useSignIn();

  const handleUsernameSubmit = () => {
    if (!username.trim()) {
      setError(language === 'ru' ? 'Введите имя пользователя' : 'Enter username');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setStep('pattern');
  };

  const handlePatternSubmit = async (pattern: number[]) => {
    const inputText = username.trim();

    try {
      console.log('[Login] Attempting login with:', inputText);

      // Sign in with Supabase using the username as-is
      // If user entered UUID (Recovery ID), Supabase will handle it
      const result = await signInMutation.mutateAsync({
        username: inputText,
        pattern,
      });

      console.log('[Login] Success!', result);

      // Fetch user profile to get username
      const { data: profile } = await supabase
        .from('profiles')
        .select('username')
        .eq('id', result.user.id)
        .single();

      // Update local store
      setUserName(profile?.username || inputText);
      setUserId(result.session.user.id);
      setVisualKeyPattern(pattern);
      setOnboarded(true);
      setAuthenticated(true);

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTimeout(onSuccess, 500);
    } catch (err: any) {
      // Log detailed error for debugging
      console.log('[Login] Authentication failed - invalid credentials');
      console.log('[Login] Error details:', {
        message: err?.message,
        code: err?.code,
        status: err?.status,
        username: inputText,
      });
      setError(language === 'ru' ? 'Неверное имя пользователя или узор' : 'Invalid username or pattern');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setStep('username');
    }
  };

  const handlePasteFromClipboard = async () => {
    try {
      const text = await ClipboardAPI.getStringAsync();
      if (text) {
        setUsername(text);
        setError('');
        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      }
    } catch (error) {
      console.error('[Login] Paste error:', error);
    }
  };

  return (
    <View className="flex-1 bg-forest">
      <LinearGradient
        colors={['#064734', '#043325', '#021a13']}
        style={{ flex: 1 }}
      >
        <KeyboardAwareScrollView
          contentContainerStyle={{ flex: 1 }}
          bottomOffset={40}
          keyboardShouldPersistTaps="handled"
        >
          <View
            style={{ paddingTop: insets.top + 20, paddingBottom: insets.bottom + 20 }}
            className="flex-1 px-6"
          >

            {/* Content */}
            <View className="flex-1 justify-center">
              {step === 'username' && (
                <Animated.View
                  entering={FadeIn.duration(400)}
                  exiting={FadeOut.duration(300)}
                  className="items-center px-4"
                >
                  <View className="w-20 h-20 rounded-full bg-sand/10 items-center justify-center mb-8">
                    <Key size={40} color="#E8D5B7" strokeWidth={1.5} />
                  </View>

                  <Text className="text-cream/90 text-2xl font-light mb-2 text-center">
                    {language === 'ru' ? 'Вход' : 'Sign In'}
                  </Text>
                  <Text className="text-cream/60 text-base mb-12 text-center">
                    {language === 'ru' ? 'Введите ваше имя пользователя' : 'Enter your username'}
                  </Text>

                  <View className="w-full max-w-sm">
                    <View className="flex-row items-center gap-3 mb-3">
                      <TextInput
                        value={username}
                        onChangeText={(text) => {
                          setUsername(text);
                          setError('');
                        }}
                        placeholder={language === 'ru' ? 'Имя или ID' : 'Username or ID'}
                        placeholderTextColor="rgba(232, 213, 183, 0.3)"
                        className="flex-1 bg-cream/5 border border-cream/20 rounded-2xl px-6 py-4 text-cream text-lg"
                        autoCapitalize="none"
                        autoCorrect={false}
                        autoFocus
                      />
                      <Pressable
                        onPress={handlePasteFromClipboard}
                        className="w-14 h-14 bg-cream/5 border border-cream/20 rounded-2xl items-center justify-center active:opacity-60"
                      >
                        <Clipboard size={22} color="#E8D5B7" strokeWidth={1.5} />
                      </Pressable>
                    </View>

                    {error ? (
                      <Text className="text-red-400/90 text-sm mb-6 text-center">{error}</Text>
                    ) : null}

                    <Pressable
                      onPress={handleUsernameSubmit}
                      disabled={signInMutation.isPending}
                      className="w-full bg-sand/90 rounded-2xl py-4 items-center mt-4 active:opacity-70"
                    >
                      {signInMutation.isPending ? (
                        <ActivityIndicator color="#064734" />
                      ) : (
                        <Text className="text-forest text-lg font-medium">
                          {language === 'ru' ? 'Далее' : 'Continue'}
                        </Text>
                      )}
                    </Pressable>

                    <Pressable
                      onPress={onBack}
                      className="mt-8 items-center active:opacity-60"
                    >
                      <Text className="text-cream/70 text-sm" style={{ textDecorationLine: 'underline' }}>
                        {language === 'ru' ? '← Назад' : '← Back'}
                      </Text>
                    </Pressable>
                  </View>
                </Animated.View>
              )}

              {step === 'pattern' && (
                <Animated.View
                  entering={FadeIn.duration(400)}
                  exiting={FadeOut.duration(300)}
                  className="items-center"
                >
                  <Text className="text-cream/90 text-xl font-light text-center mb-2 px-8">
                    {language === 'ru' ? 'Введите ваш узор' : 'Enter your pattern'}
                  </Text>
                  <Text className="text-cream/40 text-sm text-center mb-8 px-8">
                    {language === 'ru' ? 'Нарисуйте тот же узор, который вы создали' : 'Draw the same pattern you created'}
                  </Text>

                  {error ? (
                    <Animated.View entering={FadeIn.duration(200)} className="mb-4">
                      <Text className="text-red-400 text-sm text-center">
                        {error}
                      </Text>
                    </Animated.View>
                  ) : null}

                  {signInMutation.isPending ? (
                    <View className="my-16">
                      <ActivityIndicator size="large" color="#E8D5B7" />
                    </View>
                  ) : (
                    <VisualKeyPattern onPatternComplete={handlePatternSubmit} />
                  )}

                  <Pressable
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setStep('username');
                      setError('');
                    }}
                    className="mt-8 active:opacity-60"
                  >
                    <Text className="text-cream/70 text-sm" style={{ textDecorationLine: 'underline' }}>
                      {language === 'ru' ? '← Назад' : '← Back'}
                    </Text>
                  </Pressable>
                </Animated.View>
              )}
            </View>
          </View>
        </KeyboardAwareScrollView>
      </LinearGradient>
    </View>
  );
}
