import React, { useState, useRef, useEffect } from 'react';
import { View, Text, Pressable, TextInput, FlatList, Keyboard, Platform, ActivityIndicator, Modal, KeyboardAvoidingView } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Send, Languages } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { generateAvatarFromPattern } from '@/lib/avatar';
import { useComments, useCreateComment } from '@/lib/supabase-hooks';
import { translateText } from '@/lib/translation';
import { VerifiedBadge } from '@/components/VerifiedBadge';
import { ColoredUsername } from '@/components/ColoredUsername';

interface CommentsModalProps {
  visible: boolean;
  onClose: () => void;
  memoryId: string;
  onPremiumPress: () => void;
}

function formatTimeAgo(dateString: string): string {
  const now = new Date();
  const date = new Date(dateString);
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'now';
  if (diffMins < 60) return `${diffMins}m`;
  if (diffHours < 24) return `${diffHours}h`;
  if (diffDays === 1) return '1d';
  if (diffDays < 7) return `${diffDays}d`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function CommentsModal({ visible, onClose, memoryId, onPremiumPress }: CommentsModalProps) {
  const insets = useSafeAreaInsets();
  const flatListRef = useRef<FlatList>(null);

  const [commentText, setCommentText] = useState('');
  const [translatedComments, setTranslatedComments] = useState<Record<string, string>>({});
  const [translatingComments, setTranslatingComments] = useState<Set<string>>(new Set());

  // Use Supabase hooks
  const { data: comments = [], isLoading } = useComments(memoryId);
  const createCommentMutation = useCreateComment();

  const userName = useAppStore(s => s.userName);
  const visualKeyPattern = useAppStore(s => s.visualKeyPattern);
  const isPremium = useAppStore(s => s.isPremium);
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  // Local wrapper for haptic feedback
  const triggerHaptic = () => {
    if (hapticsEnabled) { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }
  };

  const userAvatar = generateAvatarFromPattern(visualKeyPattern);

  // Scroll to bottom when new comment is added
  useEffect(() => {
    if (comments.length > 0 && flatListRef.current) {
      setTimeout(() => {
        flatListRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  }, [comments.length]);

  const handleSendComment = async () => {
    if (commentText.trim().length === 0) return;
    if (!memoryId) return;

    triggerHaptic();

    try {
      await createCommentMutation.mutateAsync({
        memoryId,
        text: commentText.trim(),
      });
      setCommentText('');
      Keyboard.dismiss();
    } catch (error) {
      console.error('Failed to post comment:', error);
    }
  };

  const handleTranslateComment = async (commentId: string, text: string) => {
    triggerHaptic();

    // Check if user has premium
    if (!isPremium) {
      onClose();
      setTimeout(() => {
        onPremiumPress();
      }, 300);
      return;
    }

    // Toggle translation if already translated
    if (translatedComments[commentId]) {
      const newTranslations = { ...translatedComments };
      delete newTranslations[commentId];
      setTranslatedComments(newTranslations);
      return;
    }

    // Translate
    setTranslatingComments(prev => new Set(prev).add(commentId));
    try {
      const result = await translateText(text, language);
      if (result.success) {
        setTranslatedComments(prev => ({ ...prev, [commentId]: result.translatedText }));
      }
    } catch (error) {
      console.error('[Translation] Error:', error);
    } finally {
      setTranslatingComments(prev => {
        const newSet = new Set(prev);
        newSet.delete(commentId);
        return newSet;
      });
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View style={{ flex: 1, backgroundColor: theme.colors.background }}>
        <KeyboardAvoidingView
          style={{ flex: 1 }}
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          keyboardVerticalOffset={Platform.OS === 'ios' ? 45 : 20}
        >
          <LinearGradient
            colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
            locations={[0, 0.7, 1]}
            style={{ flex: 1 }}
          >
            {/* Header */}
            <View
              style={{
                paddingTop: insets.top + 8,
                paddingHorizontal: 20,
                paddingBottom: 12,
                borderBottomWidth: 1,
                borderBottomColor: `${theme.colors.text}10`,
              }}
            >
              <Animated.View entering={FadeIn.duration(200)} className="flex-row items-center justify-between">
                <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '600' }}>
                  {language === 'ru' ? 'Комментарии' : 'Comments'}
                </Text>
                <Pressable
                  onPress={() => {
                    triggerHaptic();
                    onClose();
                  }}
                  className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                  style={{ backgroundColor: `${theme.colors.accent}20` }}
                >
                  <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
                </Pressable>
              </Animated.View>
            </View>

            {/* Comments List */}
            <FlatList
              ref={flatListRef}
              data={comments}
              keyExtractor={(item) => item.id}
              contentContainerStyle={{
                paddingHorizontal: 20,
                paddingTop: 16,
                paddingBottom: 20,
              }}
              showsVerticalScrollIndicator={false}
              keyboardDismissMode="on-drag"
              renderItem={({ item, index }) => {
                const isTranslating = translatingComments.has(item.id);
                const translated = translatedComments[item.id];

                return (
                  <Animated.View
                    entering={FadeInDown.duration(300).delay(index * 50)}
                    className="mb-4"
                  >
                    <View className="flex-row">
                      <Text className="text-3xl mr-3">{item.userAvatar}</Text>
                      <View className="flex-1">
                        <View className="flex-row items-center mb-1 gap-1">
                          <ColoredUsername
                            username={item.userName}
                            color={item.usernameColor}
                            size={14}
                            weight="600"
                            defaultColor={theme.colors.text}
                          />
                          <VerifiedBadge isVerified={item.isVerified === true} size={12} checkColor={theme.colors.primary} />
                          <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginLeft: 6 }}>
                            {formatTimeAgo(item.createdAt)}
                          </Text>
                        </View>
                        <Text style={{ color: theme.colors.text, fontSize: 15, lineHeight: 22, marginBottom: 6 }}>
                          {translated || item.text}
                        </Text>
                        {/* Translate button */}
                        <Pressable
                          onPress={() => handleTranslateComment(item.id, item.text)}
                          disabled={isTranslating}
                          className="flex-row items-center active:opacity-60"
                          style={{
                            alignSelf: 'flex-start',
                            paddingVertical: 4,
                            paddingHorizontal: 8,
                            borderRadius: 12,
                            backgroundColor: isPremium ? `${theme.colors.accent}10` : `${theme.colors.textSecondary}08`,
                          }}
                        >
                          {isTranslating ? (
                            <ActivityIndicator size="small" color={theme.colors.accent} />
                          ) : (
                            <Languages size={12} color={isPremium ? theme.colors.accent : theme.colors.textSecondary} strokeWidth={2} />
                          )}
                          <Text
                            style={{
                              color: isPremium ? theme.colors.accent : theme.colors.textSecondary,
                              fontSize: 11,
                              fontWeight: '500',
                              marginLeft: 4,
                            }}
                          >
                            {isTranslating
                              ? (language === 'ru' ? 'Перевод...' : 'Translating...')
                              : translated
                                ? (language === 'ru' ? 'Оригинал' : 'Original')
                                : (language === 'ru' ? 'Перевести' : 'Translate')
                            }
                          </Text>
                          {!isPremium && (
                            <Text
                              style={{
                                color: theme.colors.accent,
                                fontSize: 9,
                                fontWeight: '600',
                                marginLeft: 4,
                              }}
                            >
                              PRO
                            </Text>
                          )}
                        </Pressable>
                      </View>
                    </View>
                  </Animated.View>
                );
              }}
              ListEmptyComponent={
                <Animated.View
                  entering={FadeIn.duration(300)}
                  className="items-center py-20"
                >
                  <Text style={{ color: theme.colors.textSecondary, fontSize: 15 }}>
                    {language === 'ru' ? 'Пока нет комментариев' : 'No comments yet'}
                  </Text>
                </Animated.View>
              }
            />

            {/* Input Bar - Fixed at bottom */}
            <View style={{ backgroundColor: theme.colors.background }}>
              <View
                style={{
                  paddingHorizontal: 16,
                  paddingTop: 12,
                  paddingBottom: Math.max(insets.bottom, 12),
                  flexDirection: 'row',
                  alignItems: 'flex-end',
                  gap: 8,
                }}
              >
                <TextInput
                  value={commentText}
                  onChangeText={setCommentText}
                  placeholder={language === 'ru' ? 'Добавить комментарий...' : 'Add a comment...'}
                  placeholderTextColor={`${theme.colors.text}40`}
                  style={{
                    flex: 1,
                    backgroundColor: theme.colors.primaryLight,
                    borderRadius: 20,
                    paddingHorizontal: 16,
                    paddingVertical: 10,
                    color: theme.colors.text,
                    fontSize: 16,
                    maxHeight: 100,
                  }}
                  multiline
                  maxLength={500}
                />
                <Pressable
                  onPress={handleSendComment}
                  disabled={commentText.trim().length === 0}
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 20,
                    backgroundColor: commentText.trim().length > 0 ? theme.colors.accent : theme.colors.primaryLight,
                    alignItems: 'center',
                    justifyContent: 'center',
                    marginBottom: 2,
                  }}
                >
                  <Send
                    size={18}
                    color={commentText.trim().length > 0 ? theme.colors.primary : `${theme.colors.text}40`}
                    strokeWidth={2.5}
                  />
                </Pressable>
              </View>
            </View>
          </LinearGradient>
        </KeyboardAvoidingView>
      </View>
    </Modal>
  );
}
