import React, { useState } from 'react';
import { View, Text, Pressable, TextInput, Platform, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { KeyboardAwareScrollView } from 'react-native-keyboard-controller';
import Animated, { FadeIn, FadeOut } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { VisualKeyPattern } from './VisualKeyPattern';
import { useAppStore } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { validateUsername } from '@/lib/validation';
import { useSignUp } from '@/lib/supabase-hooks';

type OnboardingStep = 'welcome' | 'name' | 'create-key' | 'confirm-key';

interface OnboardingFlowProps {
  onComplete: () => void;
  onSwitchToLogin?: () => void;
}

export function OnboardingFlow({ onComplete, onSwitchToLogin }: OnboardingFlowProps) {
  const insets = useSafeAreaInsets();
  const [step, setStep] = useState<OnboardingStep>('welcome');
  const [name, setName] = useState('');
  const [nameError, setNameError] = useState('');
  const [tempPattern, setTempPattern] = useState<number[]>([]);

  const language = useSettingsStore(s => s.language);
  const setUserName = useAppStore(s => s.setUserName);
  const setUserId = useAppStore(s => s.setUserId);
  const setVisualKeyPattern = useAppStore(s => s.setVisualKeyPattern);
  const setOnboarded = useAppStore(s => s.setOnboarded);
  const setAuthenticated = useAppStore(s => s.setAuthenticated);

  const signUpMutation = useSignUp();

  const handleNameSubmit = () => {
    const validation = validateUsername(name);

    if (!validation.valid) {
      setNameError(validation.error || 'Invalid username');
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      return;
    }

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setUserName(name.trim());
    setStep('create-key');
  };

  const handlePatternCreated = (pattern: number[]) => {
    setTempPattern(pattern);
    setTimeout(() => setStep('confirm-key'), 500);
  };

  const handlePatternConfirmed = async (pattern: number[]) => {
    try {
      console.log('[Signup] Starting registration for:', name.trim());

      // Sign up with Supabase
      const result = await signUpMutation.mutateAsync({
        username: name.trim(),
        pattern,
      });

      console.log('[Signup] Success! User ID:', result.user.id);

      // Update local store
      setVisualKeyPattern(pattern);
      setUserName(result.username);
      setUserId(result.user.id);
      setOnboarded(true);
      setAuthenticated(true);

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setTimeout(onComplete, 500);
    } catch (error: any) {
      console.error('[Signup] Error:', error);
      console.error('[Signup] Error message:', error.message);
      console.error('[Signup] Error details:', JSON.stringify(error, null, 2));

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
      setNameError(error.message || 'Failed to create account');
      setStep('name');
    }
  };

  return (
    <View className="flex-1 bg-forest">
      <LinearGradient
        colors={['#064734', '#043325', '#021a13']}
        style={{ flex: 1 }}
      >
        <KeyboardAwareScrollView
          contentContainerStyle={{ flex: 1 }}
          bottomOffset={40}
          keyboardShouldPersistTaps="handled"
        >
          <View
            style={{ paddingTop: insets.top + 20, paddingBottom: insets.bottom + 20 }}
            className="flex-1 px-6"
          >

            {/* Content */}
            <View className="flex-1 justify-center">
              {step === 'welcome' && (
                <Animated.View
                  entering={FadeIn.delay(400).duration(600)}
                  exiting={FadeOut.duration(300)}
                  className="items-center"
                >
                  <Text className="text-cream/90 text-xl font-light text-center mb-4">
                    {language === 'ru' ? 'Ваше личное пространство' : 'Your private space'}
                  </Text>
                  <Text className="text-cream/50 text-base text-center mb-12 leading-6 px-4">
                    {language === 'ru'
                      ? 'Тихое место для сохранения моментов,{"\n"}чувств и важных воспоминаний.'
                      : 'A quiet place to capture moments,{"\n"}feelings, and memories that matter.'
                    }
                  </Text>
                  <Pressable
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                      setStep('name');
                    }}
                    className="bg-sand px-10 py-4 rounded-full active:bg-sand-dark"
                  >
                    <Text className="text-forest font-semibold text-base">
                      {language === 'ru' ? 'Начать' : 'Begin'}
                    </Text>
                  </Pressable>
                  {onSwitchToLogin && (
                    <Animated.View entering={FadeIn.delay(200).duration(600)} className="mt-4">
                      <Pressable
                        onPress={() => {
                          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                          onSwitchToLogin();
                        }}
                        className="px-10 py-4"
                      >
                        <Text className="text-cream/60 font-medium text-sm">
                          {language === 'ru' ? 'Уже есть аккаунт? Войти' : 'Already have an account? Login'}
                        </Text>
                      </Pressable>
                    </Animated.View>
                  )}
                </Animated.View>
              )}

              {step === 'name' && (
                <Animated.View
                  entering={FadeIn.duration(400)}
                  exiting={FadeOut.duration(300)}
                  className="items-center px-4"
                >
                  <Text className="text-cream/90 text-xl font-light text-center mb-2">
                    {language === 'ru' ? 'Как вас называть?' : 'What should we call you?'}
                  </Text>
                  <Text className="text-cream/40 text-sm text-center mb-2">
                    {language === 'ru' ? 'Только латинские буквы, минимум 4 символа.' : 'Only Latin letters, numbers. Min 4 characters.'}
                  </Text>
                  <TextInput
                    value={name}
                    onChangeText={(text) => {
                      setName(text);
                      setNameError(''); // Clear error on change
                    }}
                    placeholder={language === 'ru' ? 'имя пользователя' : 'username'}
                    placeholderTextColor="rgba(245, 242, 237, 0.3)"
                    autoFocus
                    autoCapitalize="none"
                    autoCorrect={false}
                    className="text-cream text-2xl text-center font-light w-full py-4 border-b border-cream/20 mb-2"
                  />
                  {nameError ? (
                    <Animated.View entering={FadeIn.duration(200)} className="mb-6">
                      <Text className="text-red-400 text-sm text-center">
                        {nameError}
                      </Text>
                    </Animated.View>
                  ) : null}
                  {name.trim().length >= 4 && !nameError && (
                    <Animated.View entering={FadeIn.duration(300)} className="mt-6">
                      <Pressable
                        onPress={handleNameSubmit}
                        className="bg-sand px-10 py-4 rounded-full active:bg-sand-dark"
                      >
                        <Text className="text-forest font-semibold text-base">
                          {language === 'ru' ? 'Продолжить' : 'Continue'}
                        </Text>
                      </Pressable>
                    </Animated.View>
                  )}
                  <Pressable
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setStep('welcome');
                      setNameError('');
                    }}
                    className="mt-8 items-center active:opacity-60"
                  >
                    <Text className="text-cream/70 text-sm" style={{ textDecorationLine: 'underline' }}>
                      {language === 'ru' ? '← Назад' : '← Back'}
                    </Text>
                  </Pressable>
                </Animated.View>
              )}

              {step === 'create-key' && (
                <Animated.View
                  entering={FadeIn.duration(400)}
                  exiting={FadeOut.duration(300)}
                  className="items-center"
                >
                  <Text className="text-cream/90 text-xl font-light text-center mb-2">
                    {language === 'ru' ? 'Создайте ваш визуальный ключ' : 'Create your Visual Key'}
                  </Text>
                  <Text className="text-cream/40 text-sm text-center mb-10 px-8">
                    {language === 'ru'
                      ? 'Соедините минимум 4 точки в узор.{"\n"}Это ваш уникальный способ доступа к воспоминаниям.'
                      : 'Connect at least 4 dots in a pattern.{"\n"}This is your unique way to access memories.'
                    }
                  </Text>
                  <VisualKeyPattern onPatternComplete={handlePatternCreated} />
                  <Pressable
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setStep('name');
                    }}
                    className="mt-8 active:opacity-60"
                  >
                    <Text className="text-cream/70 text-sm" style={{ textDecorationLine: 'underline' }}>
                      {language === 'ru' ? '← Назад' : '← Back'}
                    </Text>
                  </Pressable>
                </Animated.View>
              )}

              {step === 'confirm-key' && (
                <Animated.View
                  entering={FadeIn.duration(400)}
                  exiting={FadeOut.duration(300)}
                  className="items-center"
                >
                  <Text className="text-cream/90 text-xl font-light text-center mb-2">
                    {language === 'ru' ? 'Подтвердите ваш узор' : 'Confirm your pattern'}
                  </Text>
                  <Text className="text-cream/40 text-sm text-center mb-10 px-8">
                    {language === 'ru' ? 'Нарисуйте его снова, чтобы убедиться что запомнили.' : 'Draw it again to make sure you remember.'}
                  </Text>
                  <VisualKeyPattern
                    onPatternComplete={handlePatternConfirmed}
                    existingPattern={tempPattern}
                    isVerifying
                  />
                  <Pressable
                    onPress={() => {
                      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      setStep('create-key');
                    }}
                    className="mt-8 active:opacity-60"
                  >
                    <Text className="text-cream/70 text-sm" style={{ textDecorationLine: 'underline' }}>
                      {language === 'ru' ? '← Назад' : '← Back'}
                    </Text>
                  </Pressable>
                </Animated.View>
              )}
            </View>
          </View>
        </KeyboardAwareScrollView>
      </LinearGradient>
    </View>
  );
}
