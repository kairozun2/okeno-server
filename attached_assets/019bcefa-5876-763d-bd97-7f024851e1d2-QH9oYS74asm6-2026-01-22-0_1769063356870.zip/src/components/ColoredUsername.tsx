import React from 'react';
import { Text, View } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

interface ColoredUsernameProps {
  username: string;
  color: string | null | undefined;
  size?: number;
  weight?: '400' | '500' | '600' | '700';
  defaultColor?: string;
}

/**
 * Displays username with custom color or gradient.
 * Supports both solid colors (#FFFFFF) and gradients (#FF0000,#FFA500).
 * Used throughout the app: feed, profile, chat, comments, search, notifications.
 *
 * OPTIMIZED: Uses React.memo to prevent unnecessary re-renders
 */
export const ColoredUsername = React.memo(function ColoredUsername({
  username,
  color,
  size = 16,
  weight = '600',
  defaultColor = '#FFFFFF',
}: ColoredUsernameProps) {
  // Use default color if no custom color is set
  const displayColor = color || defaultColor;

  // Check if it's a gradient (contains comma)
  const isGradient = displayColor.includes(',');

  if (isGradient) {
    const colors = displayColor.split(',') as [string, string, ...string[]];

    return (
      <LinearGradient
        colors={colors}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={{
          borderRadius: 6,
          paddingVertical: 2,
          paddingHorizontal: 6,
        }}
      >
        <Text
          style={{
            fontSize: size,
            fontWeight: weight,
            color: '#FFFFFF',
          }}
          numberOfLines={1}
        >
          {username}
        </Text>
      </LinearGradient>
    );
  }

  // Solid color
  return (
    <Text
      style={{
        fontSize: size,
        fontWeight: weight,
        color: displayColor,
      }}
      numberOfLines={1}
    >
      {username}
    </Text>
  );
});
