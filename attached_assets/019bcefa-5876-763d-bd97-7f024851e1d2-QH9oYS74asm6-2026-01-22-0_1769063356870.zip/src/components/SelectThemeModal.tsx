import React from 'react';
import { View, Text, Pressable, ScrollView, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X } from 'lucide-react-native';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme, themeList, ThemeKey } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import * as Haptics from 'expo-haptics';

interface SelectThemeModalProps {
  visible: boolean;
  onClose: () => void;
}

export function SelectThemeModal({ visible, onClose }: SelectThemeModalProps) {
  const insets = useSafeAreaInsets();

  const currentTheme = useSettingsStore(s => s.theme);
  const setTheme = useSettingsStore(s => s.setTheme);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const language = useSettingsStore(s => s.language);

  const theme = getTheme(currentTheme);
  const t = useTranslation(language);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleSelectTheme = (themeKey: ThemeKey) => {
    triggerHaptic();
    setTheme(themeKey);
    setTimeout(() => onClose(), 150);
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
          locations={[0, 0.7, 1]}
          style={{ flex: 1 }}
        >
          {/* Header */}
          <View style={{ paddingTop: insets.top + 12 }} className="px-5 pb-4">
            <Animated.View
              entering={FadeIn.duration(200)}
              className="flex-row items-center justify-between"
            >
              <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: '300' }}>
                {t('settings.theme')}
              </Text>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </Animated.View>
          </View>

          <ScrollView
            className="flex-1"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: insets.bottom + 40, paddingHorizontal: 20 }}
          >
            {themeList.map((themeItem, index) => {
              const isSelected = currentTheme === themeItem.key;

              return (
                <Animated.View
                  key={themeItem.key}
                  entering={FadeIn.duration(200)}
                  className="mb-4"
                >
                  <Pressable
                    onPress={() => handleSelectTheme(themeItem.key)}
                    className="rounded-2xl overflow-hidden active:opacity-80"
                    style={{
                      borderWidth: isSelected ? 2 : 0,
                      borderColor: isSelected ? theme.colors.accent : 'transparent',
                    }}
                  >
                    <LinearGradient
                      colors={[
                        themeItem.colors.primary,
                        themeItem.colors.primaryLight,
                        themeItem.colors.primaryDark,
                      ]}
                      style={{ padding: 20 }}
                    >
                      <View className="flex-row items-center justify-between mb-3">
                        <Text style={{ color: themeItem.colors.text, fontSize: 20, fontWeight: '500' }}>
                          {t(`theme.${themeItem.key}` as any)}
                        </Text>
                        {isSelected && (
                          <View
                            className="w-6 h-6 rounded-full items-center justify-center"
                            style={{ backgroundColor: theme.colors.accent }}
                          >
                            <Text style={{ color: theme.colors.primary, fontSize: 16 }}>✓</Text>
                          </View>
                        )}
                      </View>

                      {/* Color Preview */}
                      <View className="flex-row" style={{ gap: 8 }}>
                        <View
                          className="w-10 h-10 rounded-lg"
                          style={{ backgroundColor: themeItem.colors.primary }}
                        />
                        <View
                          className="w-10 h-10 rounded-lg"
                          style={{ backgroundColor: themeItem.colors.accent }}
                        />
                        <View
                          className="w-10 h-10 rounded-lg"
                          style={{ backgroundColor: themeItem.colors.accentDark }}
                        />
                      </View>
                    </LinearGradient>
                  </Pressable>
                </Animated.View>
              );
            })}
          </ScrollView>
        </LinearGradient>
      </View>
    </Modal>
  );
}
