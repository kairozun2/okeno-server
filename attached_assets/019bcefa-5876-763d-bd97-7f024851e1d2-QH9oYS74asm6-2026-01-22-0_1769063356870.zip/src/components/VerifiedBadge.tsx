import React from 'react';
import { View } from 'react-native';
import { BadgeCheck, Check } from 'lucide-react-native';

interface VerifiedBadgeProps {
  isVerified: boolean;
  size?: number;
  color?: string;
  checkColor?: string; // Color for the checkmark inside
}

export function VerifiedBadge({
  isVerified,
  size = 14,
  color = '#1DA1F2', // Twitter-style blue
  checkColor = '#FFFFFF', // White checkmark inside
}: VerifiedBadgeProps) {
  if (!isVerified) return null;

  return (
    <View style={{ marginLeft: 3, marginTop: 1, position: 'relative' }}>
      {/* Blue badge background */}
      <BadgeCheck
        size={size}
        color={color}
        fill={color}
        strokeWidth={0}
      />
      {/* White checkmark on top */}
      <View
        style={{
          position: 'absolute',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <Check
          size={size * 0.5}
          color={checkColor}
          strokeWidth={2.5}
        />
      </View>
    </View>
  );
}
