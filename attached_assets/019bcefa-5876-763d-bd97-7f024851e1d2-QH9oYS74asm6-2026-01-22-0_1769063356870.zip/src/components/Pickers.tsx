import React from 'react';
import { View, Text, Pressable } from 'react-native';
import { useSettingsStore } from '@/lib/settings-store';
import { themeList, Theme } from '@/lib/themes';
import { TranslationKey } from '@/lib/i18n';
import * as Haptics from 'expo-haptics';

interface ThemePickerProps {
  t: (key: TranslationKey) => string;
}

export function ThemePicker({ t }: ThemePickerProps) {
  const currentTheme = useSettingsStore(s => s.theme);
  const setTheme = useSettingsStore(s => s.setTheme);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  return (
    <View style={{ gap: 12 }}>
      {themeList.map((theme) => (
        <Pressable
          key={theme.key}
          onPress={() => {
            if (hapticsEnabled) {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }
            setTheme(theme.key);
          }}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            padding: 14,
            borderRadius: 12,
            backgroundColor: 'rgba(255, 255, 255, 0.05)',
            borderWidth: currentTheme === theme.key ? 2 : 0,
            borderColor: '#E8D5B7',
          }}
        >
          <View
            style={{
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: theme.colors.primary,
              marginRight: 12,
            }}
          />
          <Text
            style={{
              color: currentTheme === theme.key ? '#E8D5B7' : 'rgba(245, 242, 237, 0.8)',
              fontSize: 16,
              fontWeight: currentTheme === theme.key ? '600' : '400',
            }}
          >
            {t(`theme.${theme.key}`)}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}

export function LanguagePicker({ t }: { t: (key: TranslationKey) => string }) {
  const currentLanguage = useSettingsStore(s => s.language);
  const setLanguage = useSettingsStore(s => s.setLanguage);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const languages = [
    { code: 'en' as const, name: t('language.en'), flag: '🇺🇸' },
    { code: 'ru' as const, name: t('language.ru'), flag: '🇷🇺' },
  ];

  return (
    <View style={{ gap: 12 }}>
      {languages.map((lang) => (
        <Pressable
          key={lang.code}
          onPress={() => {
            if (hapticsEnabled) {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
            }
            setLanguage(lang.code);
          }}
          style={{
            flexDirection: 'row',
            alignItems: 'center',
            padding: 14,
            borderRadius: 12,
            backgroundColor: 'rgba(255, 255, 255, 0.05)',
            borderWidth: currentLanguage === lang.code ? 2 : 0,
            borderColor: '#E8D5B7',
          }}
        >
          <Text style={{ fontSize: 28, marginRight: 12 }}>{lang.flag}</Text>
          <Text
            style={{
              color: currentLanguage === lang.code ? '#E8D5B7' : 'rgba(245, 242, 237, 0.8)',
              fontSize: 16,
              fontWeight: currentLanguage === lang.code ? '600' : '400',
            }}
          >
            {lang.name}
          </Text>
        </Pressable>
      ))}
    </View>
  );
}
