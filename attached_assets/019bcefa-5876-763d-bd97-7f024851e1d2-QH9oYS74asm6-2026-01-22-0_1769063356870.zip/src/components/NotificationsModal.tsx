import React, { useCallback, useMemo } from 'react';
import { View, Text, Pressable, FlatList, Image, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { X, Heart, MessageCircle } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import Animated, { FadeIn, FadeInDown } from 'react-native-reanimated';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useNotifications, useMarkNotificationRead } from '@/lib/supabase-hooks';

interface NotificationsModalProps {
  visible: boolean;
  onClose: () => void;
  onNotificationPress: (memoryId: string) => void;
}

function formatTimeAgo(dateString: string): string {
  const now = new Date();
  const date = new Date(dateString);
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return 'now';
  if (diffMins < 60) return `${diffMins}m`;
  if (diffHours < 24) return `${diffHours}h`;
  if (diffDays === 1) return '1d';
  if (diffDays < 7) return `${diffDays}d`;
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}

export function NotificationsModal({ visible, onClose, onNotificationPress }: NotificationsModalProps) {
  const insets = useSafeAreaInsets();

  // Use Supabase hook instead of local store
  const { data: notifications = [], isLoading } = useNotifications();
  const markAsReadMutation = useMarkNotificationRead();

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);

  // Local wrapper for haptic feedback
  const triggerHaptic = () => {
    if (hapticsEnabled) { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); }
  };


  const handleNotificationPress = useCallback((notificationId: string, memoryId: string) => {
    triggerHaptic();

    // Mark notification as read
    markAsReadMutation.mutate(notificationId);

    // Close modal
    onClose();

    // Navigate to the specific memory after closing the modal
    setTimeout(() => {
      onNotificationPress(memoryId);
    }, 300);
  }, [onClose, onNotificationPress, triggerHaptic, markAsReadMutation]);

  const renderItem = useCallback(({ item, index }: { item: any; index: number }) => (
    <Animated.View
      entering={FadeInDown.duration(200).delay(index * 30)}
      className="mb-4"
    >
      <Pressable
        onPress={() => handleNotificationPress(item.id, item.memoryId)}
        className="flex-row items-start active:opacity-70"
      >
        {/* User Avatar */}
        <Text style={{ fontSize: 40, lineHeight: 44, marginRight: 12 }}>{item.userAvatar}</Text>

        {/* Content */}
        <View className="flex-1 flex-row items-start">
          <View className="flex-1 mr-3">
            {/* Icon + Text */}
            <View className="flex-row items-center mb-1">
              {item.type === 'like' ? (
                <Heart size={14} color={theme.colors.accent} fill={theme.colors.accent} strokeWidth={0} />
              ) : (
                <MessageCircle size={14} color={theme.colors.accent} strokeWidth={1.5} />
              )}
              <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginLeft: 6 }}>
                {formatTimeAgo(item.createdAt)}
              </Text>
            </View>

            {/* Message */}
            <Text style={{ color: theme.colors.text, fontSize: 15, lineHeight: 21 }}>
              <Text style={{ fontWeight: '600' }}>{item.userName}</Text>
              {item.type === 'like' ? (
                <Text>
                  {' '}
                  {language === 'ru'
                    ? 'отметил ваше воспоминание'
                    : 'liked your memory'}
                </Text>
              ) : (
                <>
                  <Text>
                    {' '}
                    {language === 'ru'
                      ? 'прокомментировал: '
                      : 'commented: '}
                  </Text>
                  <Text style={{ color: theme.colors.textSecondary }}>
                    "{item.commentText}"
                  </Text>
                </>
              )}
            </Text>
          </View>

          {/* Memory Thumbnail */}
          <Image
            source={{ uri: item.memoryThumbnail }}
            style={{
              width: 50,
              height: 50,
              borderRadius: 8,
              backgroundColor: `${theme.colors.accent}20`,
            }}
            resizeMode="cover"
          />
        </View>
      </Pressable>
    </Animated.View>
  ), [handleNotificationPress, language, theme.colors.accent, theme.colors.text, theme.colors.textSecondary]);

  const ListEmptyComponent = useMemo(() => (
    <Animated.View
      entering={FadeIn.duration(300)}
      className="items-center py-20"
    >
      <Text style={{ color: theme.colors.textSecondary, fontSize: 15 }}>
        {language === 'ru' ? 'Нет уведомлений' : 'No notifications'}
      </Text>
    </Animated.View>
  ), [theme.colors.textSecondary, language]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
          locations={[0, 0.7, 1]}
          style={{ flex: 1 }}
        >
          {/* Header */}
          <View
            style={{
              paddingTop: insets.top + 8,
              paddingHorizontal: 20,
              paddingBottom: 12,
              borderBottomWidth: 1,
              borderBottomColor: `${theme.colors.text}10`,
            }}
          >
            <Animated.View entering={FadeIn.duration(200)} className="flex-row items-center justify-between">
              <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '600' }}>
                {language === 'ru' ? 'Уведомления' : 'Notifications'}
              </Text>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </Animated.View>
          </View>

          {/* Notifications List */}
          <FlatList
            data={notifications}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{
              paddingHorizontal: 20,
              paddingTop: 16,
              paddingBottom: insets.bottom + 20,
            }}
            showsVerticalScrollIndicator={false}
            renderItem={renderItem}
            ListEmptyComponent={ListEmptyComponent}
            removeClippedSubviews={true}
            maxToRenderPerBatch={10}
            windowSize={5}
          />
        </LinearGradient>
      </View>
    </Modal>
  );
}
