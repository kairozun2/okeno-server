import React from 'react';
import { View, Text, ScrollView, Pressable, Switch, Platform, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X, Eye, Sparkles } from 'lucide-react-native';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { BlurView } from 'expo-blur';
import * as Haptics from 'expo-haptics';

interface SettingsAppearanceModalProps {
  visible: boolean;
  onClose: () => void;
}

export function SettingsAppearanceModal({ visible, onClose }: SettingsAppearanceModalProps) {
  const insets = useSafeAreaInsets();

  const backgroundDimEnabled = useSettingsStore(s => s.backgroundDimEnabled);
  const glassEffectEnabled = useSettingsStore(s => s.glassEffectEnabled);
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const setBackgroundDimEnabled = useSettingsStore(s => s.setBackgroundDimEnabled);
  const setGlassEffectEnabled = useSettingsStore(s => s.setGlassEffectEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
          locations={[0, 0.7, 1]}
          style={{ flex: 1 }}
        >
          {/* Header */}
          <View
            style={{
              paddingTop: insets.top + 8,
              paddingHorizontal: 20,
              paddingBottom: 12,
              borderBottomWidth: 1,
              borderBottomColor: `${theme.colors.text}10`,
            }}
          >
            <Animated.View entering={FadeIn.duration(200)} className="flex-row items-center justify-between">
              <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '600' }}>
                {t('settings.appearance')}
              </Text>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </Animated.View>
          </View>

          <ScrollView
            className="flex-1"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingTop: 20, paddingBottom: insets.bottom + 40 }}
          >
            {/* Options */}
            <Animated.View
              entering={FadeIn.duration(300).delay(100)}
              className="mx-5"
            >
              <View className="rounded-2xl overflow-hidden" style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}>
                {/* Background Dim Toggle */}
                <View className="flex-row items-center justify-between px-4 py-4" style={{ borderBottomWidth: 1, borderBottomColor: `${theme.colors.text}0D` }}>
                  <View className="flex-row items-center flex-1">
                    <Eye
                      size={20}
                      color={backgroundDimEnabled ? theme.colors.accent : `${theme.colors.textSecondary}4D`}
                      strokeWidth={1.5}
                    />
                    <View className="ml-3 flex-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {t('settings.dimBackground')}
                      </Text>
                      <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                        {t('settings.dimDesc')}
                      </Text>
                    </View>
                  </View>
                  <Switch
                    value={backgroundDimEnabled}
                    onValueChange={(value) => {
                      triggerHaptic();
                      setBackgroundDimEnabled(value);
                    }}
                    trackColor={{ false: 'rgba(245, 242, 237, 0.1)', true: theme.colors.accent }}
                    thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : backgroundDimEnabled ? theme.colors.primary : '#f4f3f4'}
                    ios_backgroundColor="rgba(245, 242, 237, 0.1)"
                  />
                </View>

                {/* Glass Effect Toggle */}
                <View className="flex-row items-center justify-between px-4 py-4">
                  <View className="flex-row items-center flex-1">
                    <Sparkles
                      size={20}
                      color={glassEffectEnabled ? theme.colors.accent : `${theme.colors.textSecondary}4D`}
                      strokeWidth={1.5}
                    />
                    <View className="ml-3 flex-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {t('settings.glassEffect')}
                      </Text>
                      <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                        {t('settings.glassDesc')}
                      </Text>
                    </View>
                  </View>
                  <Switch
                    value={glassEffectEnabled}
                    onValueChange={(value) => {
                      triggerHaptic();
                      setGlassEffectEnabled(value);
                    }}
                    trackColor={{ false: 'rgba(245, 242, 237, 0.1)', true: theme.colors.accent }}
                    thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : glassEffectEnabled ? theme.colors.primary : '#f4f3f4'}
                    ios_backgroundColor="rgba(245, 242, 237, 0.1)"
                  />
                </View>
              </View>
            </Animated.View>

            {/* Preview Card */}
            <Animated.View
              entering={FadeIn.duration(300).delay(200)}
              className="mx-5 mt-6"
            >
              <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, textTransform: 'uppercase', letterSpacing: 2, marginBottom: 12, paddingLeft: 4 }}>
                {t('settings.preview')}
              </Text>

              <View
                className="rounded-2xl overflow-hidden"
                style={{
                  backgroundColor: backgroundDimEnabled
                    ? 'rgba(0, 0, 0, 0.3)'
                    : 'rgba(255, 255, 255, 0.05)',
                }}
              >
                {glassEffectEnabled && Platform.OS === 'ios' ? (
                  <BlurView intensity={20} tint="dark" style={{ padding: 16 }}>
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500', marginBottom: 4 }}>
                      {t('settings.previewText')}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}80`, fontSize: 14 }}>
                      {t('settings.previewDesc')}
                    </Text>
                  </BlurView>
                ) : (
                  <View className="p-4">
                    <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500', marginBottom: 4 }}>
                      {t('settings.previewText')}
                    </Text>
                    <Text style={{ color: `${theme.colors.textSecondary}80`, fontSize: 14 }}>
                      {t('settings.previewDesc')}
                    </Text>
                  </View>
                )}
              </View>
            </Animated.View>
          </ScrollView>
        </LinearGradient>
      </View>
    </Modal>
  );
}
