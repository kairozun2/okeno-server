import React, { useState } from 'react';
import { View, Text, Modal, Pressable, TextInput, ActivityIndicator, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { X, AlertCircle } from 'lucide-react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useAuth } from '@/lib/supabase-hooks';
import { supabase } from '@/lib/supabase';

interface EditUsernameModalProps {
  visible: boolean;
  onClose: () => void;
  currentUsername: string;
  lastChanged?: string | null; // ISO date string
}

export function EditUsernameModal({ visible, onClose, currentUsername, lastChanged }: EditUsernameModalProps) {
  const [username, setUsername] = useState(currentUsername);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const themeKey = useSettingsStore(s => s.theme);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const language = useSettingsStore(s => s.language);
  const theme = getTheme(themeKey);
  const { data: auth } = useAuth();

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  // Check if user can change username (15 days cooldown)
  const canChangeUsername = () => {
    if (!lastChanged) return true;
    const daysSinceLastChange = (Date.now() - new Date(lastChanged).getTime()) / (1000 * 60 * 60 * 24);
    return daysSinceLastChange >= 15;
  };

  const getDaysUntilNextChange = () => {
    if (!lastChanged) return 0;
    const daysSinceLastChange = (Date.now() - new Date(lastChanged).getTime()) / (1000 * 60 * 60 * 24);
    return Math.ceil(15 - daysSinceLastChange);
  };

  // Validate username with Gemini API for comprehensive content moderation
  const validateUsername = async (name: string): Promise<{ valid: boolean; error?: string }> => {
    // Basic validation
    if (name.length < 3) {
      return { valid: false, error: language === 'ru' ? 'Минимум 3 символа' : 'Minimum 3 characters' };
    }
    if (name.length > 20) {
      return { valid: false, error: language === 'ru' ? 'Максимум 20 символов' : 'Maximum 20 characters' };
    }
    if (!/^[a-zA-Z0-9_]+$/.test(name)) {
      return { valid: false, error: language === 'ru' ? 'Только буквы, цифры и _' : 'Only letters, numbers and _' };
    }

    try {
      // Check if username is already taken
      const { data: existing } = await supabase
        .from('profiles')
        .select('id')
        .eq('username', name)
        .single();

      if (existing && existing.id !== auth?.profile?.id) {
        return { valid: false, error: language === 'ru' ? 'Имя занято' : 'Username taken' };
      }

      // Check content moderation using Gemini API
      const geminiApiKey = process.env.EXPO_PUBLIC_GEMINI_API_KEY;

      if (!geminiApiKey) {
        console.warn('[EditUsername] Gemini API key not found, skipping content moderation');
        return { valid: true };
      }

      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${geminiApiKey}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{
              parts: [{
                text: `Analyze this username for inappropriate content: "${name}"\n\nCheck for:\n- Profanity and offensive language\n- Names of presidents, politicians, or political figures\n- Discriminatory terms (racism, sexism, homophobia, etc.)\n- Political ideology or party names\n- References to children or minors in inappropriate context\n- Country names or nationalism\n- Violence or harmful content\n- Sexual content\n\nRespond with ONLY "SAFE" if the username is appropriate, or "UNSAFE" if it contains any inappropriate content.`
              }]
            }],
            generationConfig: {
              temperature: 0.1,
              maxOutputTokens: 10,
            }
          })
        }
      );

      if (!response.ok) {
        console.error('[EditUsername] Gemini API error:', response.status);
        return { valid: true }; // Allow if API fails
      }

      const data = await response.json();
      const result = data?.candidates?.[0]?.content?.parts?.[0]?.text?.trim().toUpperCase();

      if (result === 'UNSAFE') {
        return { valid: false, error: language === 'ru' ? 'Недопустимое имя' : 'Inappropriate name' };
      }

      return { valid: true };
    } catch (error) {
      console.error('[EditUsername] Validation error:', error);
      return { valid: true }; // Allow if API fails
    }
  };

  const handleSave = async () => {
    triggerHaptic();

    if (!canChangeUsername()) {
      Alert.alert(
        language === 'ru' ? 'Слишком рано' : 'Too Soon',
        language === 'ru'
          ? `Вы сможете изменить имя через ${getDaysUntilNextChange()} дней`
          : `You can change your username in ${getDaysUntilNextChange()} days`,
        [{ text: 'OK' }]
      );
      return;
    }

    if (username === currentUsername) {
      onClose();
      return;
    }

    setIsSubmitting(true);
    setError(null);

    // Validate username
    const validation = await validateUsername(username);
    if (!validation.valid) {
      setError(validation.error || 'Invalid username');
      setIsSubmitting(false);
      return;
    }

    try {
      // Update username in database
      const { error: updateError } = await supabase
        .from('profiles')
        .update({
          username,
          username_last_changed: new Date().toISOString(),
        })
        .eq('id', auth?.profile?.id);

      if (updateError) throw updateError;

      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onClose();
    } catch (err: any) {
      console.error('[EditUsername] Error:', err);
      setError(err.message || 'Failed to update username');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="fade"
      transparent={true}
      onRequestClose={onClose}
    >
      <View
        className="flex-1 items-center justify-center"
        style={{ backgroundColor: 'rgba(0,0,0,0.7)' }}
      >
        <Animated.View
          entering={FadeInDown.duration(300)}
          className="w-11/12 max-w-md rounded-3xl overflow-hidden"
        >
          <LinearGradient
            colors={[theme.colors.primaryLight, theme.colors.primaryDark]}
            style={{ padding: 24 }}
          >
            {/* Header */}
            <View className="flex-row items-center justify-between mb-6">
              <Text style={{ color: theme.colors.text, fontSize: 20, fontWeight: '600' }}>
                {language === 'ru' ? 'Изменить имя' : 'Edit Username'}
              </Text>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </View>

            {/* Cooldown Warning */}
            {!canChangeUsername() && (
              <View
                className="flex-row items-start p-3 rounded-2xl mb-4"
                style={{ backgroundColor: `${theme.colors.accent}15` }}
              >
                <AlertCircle size={18} color={theme.colors.accent} strokeWidth={1.5} style={{ marginTop: 2, marginRight: 8 }} />
                <Text style={{ color: theme.colors.text, fontSize: 13, lineHeight: 18, flex: 1 }}>
                  {language === 'ru'
                    ? `Вы сможете изменить имя через ${getDaysUntilNextChange()} дней`
                    : `You can change your username in ${getDaysUntilNextChange()} days`}
                </Text>
              </View>
            )}

            {/* Username Input */}
            <View className="mb-6">
              <Text style={{ color: theme.colors.textSecondary, fontSize: 14, marginBottom: 8 }}>
                {language === 'ru' ? 'Новое имя пользователя' : 'New username'}
              </Text>
              <TextInput
                value={username}
                onChangeText={(text) => {
                  setUsername(text.toLowerCase().replace(/[^a-z0-9_]/g, ''));
                  setError(null);
                }}
                placeholder={currentUsername}
                placeholderTextColor={`${theme.colors.textSecondary}40`}
                maxLength={20}
                autoCapitalize="none"
                autoCorrect={false}
                editable={canChangeUsername() && !isSubmitting}
                style={{
                  backgroundColor: `${theme.colors.accent}15`,
                  borderRadius: 16,
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  color: theme.colors.text,
                  fontSize: 16,
                  fontWeight: '500',
                }}
              />
              {error && (
                <Text style={{ color: '#FF3B30', fontSize: 13, marginTop: 8 }}>
                  {error}
                </Text>
              )}
              <Text style={{ color: theme.colors.textSecondary, fontSize: 12, marginTop: 8 }}>
                {language === 'ru'
                  ? '3-20 символов, только буквы, цифры и _'
                  : '3-20 characters, letters, numbers and _ only'}
              </Text>
            </View>

            {/* Save Button */}
            <Pressable
              onPress={handleSave}
              disabled={isSubmitting || !canChangeUsername() || username === currentUsername}
              className="rounded-full overflow-hidden active:opacity-80"
              style={{
                backgroundColor: isSubmitting || !canChangeUsername() || username === currentUsername
                  ? `${theme.colors.accent}40`
                  : theme.colors.accent,
              }}
            >
              <View className="py-4 items-center">
                {isSubmitting ? (
                  <ActivityIndicator size="small" color={theme.colors.primary} />
                ) : (
                  <Text style={{ color: theme.colors.primary, fontSize: 16, fontWeight: '600' }}>
                    {language === 'ru' ? 'Сохранить' : 'Save'}
                  </Text>
                )}
              </View>
            </Pressable>
          </LinearGradient>
        </Animated.View>
      </View>
    </Modal>
  );
}
