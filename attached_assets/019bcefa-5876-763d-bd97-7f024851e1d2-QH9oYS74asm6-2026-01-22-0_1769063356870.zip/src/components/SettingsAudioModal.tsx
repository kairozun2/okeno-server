import React from 'react';
import { View, Text, ScrollView, Switch, Platform, Modal, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X, Vibrate } from 'lucide-react-native';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import * as Haptics from 'expo-haptics';

interface SettingsAudioModalProps {
  visible: boolean;
  onClose: () => void;
}

export function SettingsAudioModal({ visible, onClose }: SettingsAudioModalProps) {
  const insets = useSafeAreaInsets();

  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);

  const setHapticsEnabled = useSettingsStore(s => s.setHapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
          locations={[0, 0.7, 1]}
          style={{ flex: 1 }}
        >
          {/* Header */}
          <View
            style={{
              paddingTop: insets.top + 8,
              paddingHorizontal: 20,
              paddingBottom: 12,
              borderBottomWidth: 1,
              borderBottomColor: `${theme.colors.text}10`,
            }}
          >
            <Animated.View entering={FadeIn.duration(200)} className="flex-row items-center justify-between">
              <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '600' }}>
                {t('settings.audioFeedback')}
              </Text>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </Animated.View>
          </View>

          <ScrollView
            className="flex-1"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingTop: 20, paddingBottom: insets.bottom + 40 }}
          >
            {/* Options */}
            <Animated.View
              entering={FadeIn.duration(300).delay(100)}
              className="mx-5"
            >
              <View className="rounded-2xl overflow-hidden" style={{ backgroundColor: 'rgba(255, 255, 255, 0.05)' }}>
                {/* Haptics Toggle */}
                <View className="flex-row items-center justify-between px-4 py-4">
                  <View className="flex-row items-center flex-1">
                    <Vibrate
                      size={20}
                      color={hapticsEnabled ? theme.colors.accent : `${theme.colors.textSecondary}4D`}
                      strokeWidth={1.5}
                    />
                    <View className="ml-3 flex-1">
                      <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '500' }}>
                        {t('settings.haptics')}
                      </Text>
                      <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 12, marginTop: 2 }}>
                        {t('settings.hapticsDesc')}
                      </Text>
                    </View>
                  </View>
                  <Switch
                    value={hapticsEnabled}
                    onValueChange={(value) => {
                      // Only trigger haptic if turning ON (value = true)
                      if (value) {
                        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                      }
                      setHapticsEnabled(value);
                    }}
                    trackColor={{ false: 'rgba(245, 242, 237, 0.1)', true: theme.colors.accent }}
                    thumbColor={Platform.OS === 'ios' ? '#FFFFFF' : hapticsEnabled ? theme.colors.primary : '#f4f3f4'}
                    ios_backgroundColor="rgba(245, 242, 237, 0.1)"
                  />
                </View>
              </View>
            </Animated.View>
          </ScrollView>
        </LinearGradient>
      </View>
    </Modal>
  );
}
