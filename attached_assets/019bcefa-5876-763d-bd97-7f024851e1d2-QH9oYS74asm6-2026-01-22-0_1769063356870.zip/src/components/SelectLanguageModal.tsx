import React from 'react';
import { View, Text, Pressable, ScrollView, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X } from 'lucide-react-native';
import { useSettingsStore, Language } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import * as Haptics from 'expo-haptics';

const languages: Array<{ code: Language; nameKey: string; flag: string }> = [
  // European languages
  { code: 'en', nameKey: 'language.en', flag: '🇺🇸' },
  { code: 'ru', nameKey: 'language.ru', flag: '🇷🇺' },
  { code: 'es', nameKey: 'language.es', flag: '🇪🇸' },
  { code: 'fr', nameKey: 'language.fr', flag: '🇫🇷' },
  { code: 'de', nameKey: 'language.de', flag: '🇩🇪' },
  { code: 'it', nameKey: 'language.it', flag: '🇮🇹' },
  { code: 'pt', nameKey: 'language.pt', flag: '🇵🇹' },
  { code: 'pl', nameKey: 'language.pl', flag: '🇵🇱' },
  { code: 'nl', nameKey: 'language.nl', flag: '🇳🇱' },
  { code: 'tr', nameKey: 'language.tr', flag: '🇹🇷' },
  { code: 'sv', nameKey: 'language.sv', flag: '🇸🇪' },
  { code: 'no', nameKey: 'language.no', flag: '🇳🇴' },
  { code: 'da', nameKey: 'language.da', flag: '🇩🇰' },
  { code: 'fi', nameKey: 'language.fi', flag: '🇫🇮' },
  { code: 'cs', nameKey: 'language.cs', flag: '🇨🇿' },
  { code: 'sk', nameKey: 'language.sk', flag: '🇸🇰' },
  { code: 'hu', nameKey: 'language.hu', flag: '🇭🇺' },
  { code: 'ro', nameKey: 'language.ro', flag: '🇷🇴' },
  { code: 'el', nameKey: 'language.el', flag: '🇬🇷' },
  { code: 'bg', nameKey: 'language.bg', flag: '🇧🇬' },
  { code: 'uk', nameKey: 'language.uk', flag: '🇺🇦' },
  { code: 'sr', nameKey: 'language.sr', flag: '🇷🇸' },
  { code: 'hr', nameKey: 'language.hr', flag: '🇭🇷' },
  { code: 'sl', nameKey: 'language.sl', flag: '🇸🇮' },
  { code: 'et', nameKey: 'language.et', flag: '🇪🇪' },
  { code: 'lv', nameKey: 'language.lv', flag: '🇱🇻' },
  { code: 'lt', nameKey: 'language.lt', flag: '🇱🇹' },

  // Asian languages
  { code: 'zh', nameKey: 'language.zh', flag: '🇨🇳' },
  { code: 'ja', nameKey: 'language.ja', flag: '🇯🇵' },
  { code: 'ko', nameKey: 'language.ko', flag: '🇰🇷' },
  { code: 'th', nameKey: 'language.th', flag: '🇹🇭' },
  { code: 'vi', nameKey: 'language.vi', flag: '🇻🇳' },
  { code: 'id', nameKey: 'language.id', flag: '🇮🇩' },
  { code: 'ms', nameKey: 'language.ms', flag: '🇲🇾' },
  { code: 'tl', nameKey: 'language.tl', flag: '🇵🇭' },
  { code: 'hi', nameKey: 'language.hi', flag: '🇮🇳' },
  { code: 'bn', nameKey: 'language.bn', flag: '🇧🇩' },
  { code: 'ur', nameKey: 'language.ur', flag: '🇵🇰' },
  { code: 'km', nameKey: 'language.km', flag: '🇰🇭' },
  { code: 'lo', nameKey: 'language.lo', flag: '🇱🇦' },
  { code: 'my', nameKey: 'language.my', flag: '🇲🇲' },
  { code: 'mn', nameKey: 'language.mn', flag: '🇲🇳' },

  // Middle Eastern languages
  { code: 'ar', nameKey: 'language.ar', flag: '🇸🇦' },
  { code: 'he', nameKey: 'language.he', flag: '🇮🇱' },
  { code: 'fa', nameKey: 'language.fa', flag: '🇮🇷' },

  // Other languages
  { code: 'sw', nameKey: 'language.sw', flag: '🇰🇪' },
  { code: 'am', nameKey: 'language.am', flag: '🇪🇹' },
  { code: 'ka', nameKey: 'language.ka', flag: '🇬🇪' },
  { code: 'hy', nameKey: 'language.hy', flag: '🇦🇲' },
  { code: 'az', nameKey: 'language.az', flag: '🇦🇿' },
  { code: 'kk', nameKey: 'language.kk', flag: '🇰🇿' },
  { code: 'uz', nameKey: 'language.uz', flag: '🇺🇿' },
];

interface SelectLanguageModalProps {
  visible: boolean;
  onClose: () => void;
}

export function SelectLanguageModal({ visible, onClose }: SelectLanguageModalProps) {
  const insets = useSafeAreaInsets();

  const currentLanguage = useSettingsStore(s => s.language);
  const setLanguage = useSettingsStore(s => s.setLanguage);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const themeKey = useSettingsStore(s => s.theme);

  const theme = getTheme(themeKey);
  const t = useTranslation(currentLanguage);

  const triggerHaptic = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  };

  const handleSelectLanguage = (languageCode: Language) => {
    triggerHaptic();
    setLanguage(languageCode);
    setTimeout(() => onClose(), 150);
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
          locations={[0, 0.7, 1]}
          style={{ flex: 1 }}
        >
          {/* Header */}
          <View style={{ paddingTop: insets.top + 12 }} className="px-5 pb-4">
            <Animated.View
              entering={FadeIn.duration(200)}
              className="flex-row items-center justify-between"
            >
              <Text style={{ color: theme.colors.text, fontSize: 24, fontWeight: '300' }}>
                {t('settings.language')}
              </Text>
              <Pressable
                onPress={() => {
                  triggerHaptic();
                  onClose();
                }}
                className="w-10 h-10 rounded-full items-center justify-center active:opacity-60"
                style={{ backgroundColor: `${theme.colors.accent}20` }}
              >
                <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
              </Pressable>
            </Animated.View>
          </View>

          <ScrollView
            className="flex-1"
            showsVerticalScrollIndicator={false}
            contentContainerStyle={{ paddingBottom: insets.bottom + 40, paddingHorizontal: 20 }}
          >
            {languages.map((lang, index) => {
              const isSelected = currentLanguage === lang.code;

              return (
                <Animated.View
                  key={lang.code}
                  entering={FadeIn.duration(200)}
                  className="mb-4"
                >
                  <Pressable
                    onPress={() => handleSelectLanguage(lang.code)}
                    className="rounded-2xl overflow-hidden active:opacity-80"
                    style={{
                      backgroundColor: 'rgba(255, 255, 255, 0.05)',
                      borderWidth: isSelected ? 2 : 0,
                      borderColor: isSelected ? theme.colors.accent : 'transparent',
                    }}
                  >
                    <View className="flex-row items-center justify-between p-5">
                      <View className="flex-row items-center" style={{ gap: 16 }}>
                        <Text style={{ fontSize: 32 }}>{lang.flag}</Text>
                        <Text style={{ color: theme.colors.text, fontSize: 18, fontWeight: '500' }}>
                          {t(lang.nameKey as any)}
                        </Text>
                      </View>
                      {isSelected && (
                        <View
                          className="w-6 h-6 rounded-full items-center justify-center"
                          style={{ backgroundColor: theme.colors.accent }}
                        >
                          <Text style={{ color: theme.colors.primary, fontSize: 16 }}>✓</Text>
                        </View>
                      )}
                    </View>
                  </Pressable>
                </Animated.View>
              );
            })}
          </ScrollView>
        </LinearGradient>
      </View>
    </Modal>
  );
}
