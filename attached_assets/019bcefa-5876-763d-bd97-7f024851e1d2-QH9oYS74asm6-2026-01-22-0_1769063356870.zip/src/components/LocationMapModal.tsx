import React, { useRef } from 'react';
import { View, Text, Modal, Pressable } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { X, Navigation } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import { BlurView } from 'expo-blur';
import MapView, { Marker, PROVIDER_GOOGLE } from 'react-native-maps';
import { getTheme } from '@/lib/themes';
import { useSettingsStore } from '@/lib/settings-store';

interface LocationMapModalProps {
  visible: boolean;
  onClose: () => void;
  location: string;
  latitude: number;
  longitude: number;
}

export function LocationMapModal({
  visible,
  onClose,
  location,
  latitude,
  longitude,
}: LocationMapModalProps) {
  const insets = useSafeAreaInsets();
  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);
  const theme = getTheme(themeKey);

  const mapRef = useRef<MapView>(null);

  const handleClose = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    onClose();
  };

  const openInMaps = () => {
    if (hapticsEnabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    }
    // Would open native maps app
    // const scheme = Platform.select({ ios: 'maps:', android: 'geo:' });
    // Linking.openURL(...);
    onClose();
  };

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="fullScreen"
      onRequestClose={onClose}
    >
      <View className="flex-1">
        {/* Map - Full Screen */}
        <MapView
          ref={mapRef}
          style={{ flex: 1 }}
          provider={PROVIDER_GOOGLE}
          initialRegion={{
            latitude,
            longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          }}
          mapType="standard"
          scrollEnabled={true}
          zoomEnabled={true}
          pitchEnabled={true}
          rotateEnabled={true}
        >
          <Marker
            coordinate={{ latitude, longitude }}
            title={location}
            pinColor={theme.colors.accent}
          />
        </MapView>

        {/* Close Button - Top Right with dark blur background */}
        <View
          style={{
            position: 'absolute',
            top: insets.top + 12,
            right: 16,
          }}
        >
          <Pressable
            onPress={handleClose}
            className="w-11 h-11 rounded-full items-center justify-center active:opacity-70 overflow-hidden"
          >
            <BlurView intensity={80} tint="dark" style={{ position: 'absolute', top: 0, left: 0, right: 0, bottom: 0 }}>
              <View style={{ backgroundColor: 'rgba(0, 0, 0, 0.5)', flex: 1 }} />
            </BlurView>
            <X size={24} color="#FFFFFF" strokeWidth={2.5} />
          </Pressable>
        </View>

        {/* Bottom Button - Centered with Glass Effect (no container) */}
        <View
          style={{
            position: 'absolute',
            bottom: insets.bottom + 24,
            left: 0,
            right: 0,
            alignItems: 'center',
          }}
        >
          <Pressable
            onPress={openInMaps}
            className="flex-row items-center justify-center px-6 py-3.5 rounded-full active:scale-95 overflow-hidden shadow-lg"
            style={{
              minWidth: 180,
            }}
          >
            <BlurView
              intensity={80}
              tint="dark"
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
              }}
            >
              <View style={{ backgroundColor: 'rgba(0, 0, 0, 0.4)', flex: 1 }} />
            </BlurView>
            <Navigation size={18} color="#FFFFFF" strokeWidth={2.5} />
            <Text
              style={{
                color: '#FFFFFF',
                fontSize: 15,
                fontWeight: '600',
                marginLeft: 8,
              }}
            >
              {language === 'ru' ? 'Открыть в Картах' : 'Open in Maps'}
            </Text>
          </Pressable>
        </View>
      </View>
    </Modal>
  );
}
