import React, { useCallback, useState } from 'react';
import { View, Pressable, Text } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withSpring,
  withSequence,
  withTiming,
  interpolateColor,
  FadeIn,
} from 'react-native-reanimated';
import * as Haptics from 'expo-haptics';
import { cn } from '@/lib/cn';

const GRID_SIZE = 3;
const DOT_SIZE = 64;
const GAP = 24;

interface VisualKeyPatternProps {
  onPatternComplete: (pattern: number[]) => void;
  existingPattern?: number[];
  isVerifying?: boolean;
}

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

function DotItem({
  index,
  isSelected,
  orderNumber,
  onPress,
}: {
  index: number;
  isSelected: boolean;
  orderNumber: number;
  onPress: (index: number) => void;
}) {
  const colorProgress = useSharedValue(isSelected ? 1 : 0);

  React.useEffect(() => {
    if (isSelected) {
      // Removed zoom animation - just fade in color
      colorProgress.value = withTiming(1, { duration: 200 });
    } else {
      colorProgress.value = withTiming(0, { duration: 200 });
    }
  }, [isSelected]);

  const animatedStyle = useAnimatedStyle(() => ({
    backgroundColor: interpolateColor(
      colorProgress.value,
      [0, 1],
      ['rgba(232, 213, 183, 0.2)', '#E8D5B7']
    ),
    borderColor: interpolateColor(
      colorProgress.value,
      [0, 1],
      ['rgba(232, 213, 183, 0.4)', '#E8D5B7']
    ),
  }));

  return (
    <AnimatedPressable
      onPress={() => onPress(index)}
      style={[
        {
          width: DOT_SIZE,
          height: DOT_SIZE,
          borderRadius: DOT_SIZE / 2,
          borderWidth: 2,
          justifyContent: 'center',
          alignItems: 'center',
        },
        animatedStyle,
      ]}
    >
      {isSelected && (
        <Animated.Text
          entering={FadeIn}
          className="text-forest font-semibold text-lg"
        >
          {orderNumber}
        </Animated.Text>
      )}
    </AnimatedPressable>
  );
}

export function VisualKeyPattern({
  onPatternComplete,
  existingPattern,
  isVerifying = false,
}: VisualKeyPatternProps) {
  const [selectedDots, setSelectedDots] = useState<number[]>([]);
  const [isComplete, setIsComplete] = useState(false);

  const handleDotPress = useCallback((index: number) => {
    if (isComplete) return;
    if (selectedDots.includes(index)) return;

    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);

    const newPattern = [...selectedDots, index];
    setSelectedDots(newPattern);

    // Check for minimum pattern length (4 dots)
    if (newPattern.length >= 4) {
      if (isVerifying && existingPattern) {
        // Verify pattern
        const matches = JSON.stringify(newPattern) === JSON.stringify(existingPattern);
        if (matches) {
          setIsComplete(true);
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
          onPatternComplete(newPattern);
        } else if (newPattern.length === existingPattern.length) {
          // Wrong pattern - reset
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
          resetPattern();
        }
      }
    }
  }, [selectedDots, isComplete, existingPattern, isVerifying, onPatternComplete]);

  const confirmPattern = useCallback(() => {
    if (selectedDots.length >= 4 && !isVerifying) {
      setIsComplete(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      onPatternComplete(selectedDots);
    }
  }, [selectedDots, isVerifying, onPatternComplete]);

  const resetPattern = useCallback(() => {
    setSelectedDots([]);
    setIsComplete(false);
  }, []);

  return (
    <View className="items-center">
      <View
        style={{
          width: GRID_SIZE * DOT_SIZE + (GRID_SIZE - 1) * GAP,
          flexDirection: 'row',
          flexWrap: 'wrap',
          gap: GAP,
        }}
      >
        {Array.from({ length: 9 }, (_, i) => (
          <DotItem
            key={i}
            index={i}
            isSelected={selectedDots.includes(i)}
            orderNumber={selectedDots.indexOf(i) + 1}
            onPress={handleDotPress}
          />
        ))}
      </View>

      {/* Pattern indicator */}
      <View className="flex-row mt-8" style={{ gap: 8 }}>
        {Array.from({ length: Math.max(4, selectedDots.length) }, (_, i) => (
          <View
            key={i}
            className={cn(
              'w-3 h-3 rounded-full',
              i < selectedDots.length ? 'bg-sand' : 'bg-sand/20'
            )}
          />
        ))}
      </View>

      {/* Action buttons */}
      {!isVerifying && selectedDots.length >= 4 && !isComplete && (
        <View className="flex-row mt-8" style={{ gap: 16 }}>
          <Pressable
            onPress={resetPattern}
            className="px-6 py-3 rounded-full bg-white/10 active:bg-white/20"
          >
            <Text className="text-cream/70">Reset</Text>
          </Pressable>
          <Pressable
            onPress={confirmPattern}
            className="px-8 py-3 rounded-full bg-sand active:bg-sand-dark"
          >
            <Text className="text-forest font-semibold">Confirm</Text>
          </Pressable>
        </View>
      )}

      {isVerifying && selectedDots.length > 0 && !isComplete && (
        <Pressable
          onPress={resetPattern}
          className="mt-8 px-6 py-3 rounded-full bg-white/10 active:bg-white/20"
        >
          <Text className="text-cream/70">Try again</Text>
        </Pressable>
      )}
    </View>
  );
}
