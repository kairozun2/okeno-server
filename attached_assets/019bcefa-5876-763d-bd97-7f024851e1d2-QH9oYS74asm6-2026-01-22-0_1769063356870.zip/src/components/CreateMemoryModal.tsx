import React, { useState, useCallback } from 'react';
import { View, Text, Pressable, TextInput, ScrollView, KeyboardAvoidingView, Platform, Alert, Image, ActivityIndicator, Modal } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Animated, { FadeIn } from 'react-native-reanimated';
import { X, Send, Image as ImageIcon, Camera, MapPin, Trash2, Play } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { CustomVideoPlayer } from './CustomVideoPlayer';
import { ResizeMode } from 'expo-av';
import { Emotion, EMOTIONS } from '@/lib/store';
import { useSettingsStore } from '@/lib/settings-store';
import { getTheme } from '@/lib/themes';
import { useTranslation } from '@/lib/i18n';
import { LinearGradient } from 'expo-linear-gradient';
import { useCreateMemory, useUploadMedia } from '@/lib/supabase-hooks';

const AnimatedPressable = Animated.createAnimatedComponent(Pressable);

interface CreateMemoryModalProps {
  visible: boolean;
  onClose: () => void;
}

export function CreateMemoryModal({ visible, onClose }: CreateMemoryModalProps) {
  const insets = useSafeAreaInsets();
  const [text, setText] = useState('');
  const [selectedEmotion, setSelectedEmotion] = useState<Emotion | null>(null);
  const [mediaUri, setMediaUri] = useState<string | undefined>(undefined);
  const [mediaType, setMediaType] = useState<'image' | 'video' | undefined>(undefined);
  const [location, setLocation] = useState<string | undefined>(undefined);
  const [latitude, setLatitude] = useState<number | undefined>(undefined);
  const [longitude, setLongitude] = useState<number | undefined>(undefined);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [imageAspectRatio, setImageAspectRatio] = useState<number | undefined>(undefined);
  const [isPickingMedia, setIsPickingMedia] = useState(false);

  // Use Supabase hooks
  const createMemoryMutation = useCreateMemory();
  const uploadMediaMutation = useUploadMedia();

  const themeKey = useSettingsStore(s => s.theme);
  const language = useSettingsStore(s => s.language);
  const hapticsEnabled = useSettingsStore(s => s.hapticsEnabled);

  const theme = getTheme(themeKey);
  const t = useTranslation(language);

  // Local haptic function that checks settings
  const triggerHaptic = (style: Haptics.ImpactFeedbackStyle = Haptics.ImpactFeedbackStyle.Light) => {
    if (hapticsEnabled) {
      Haptics.impactAsync(style);
    }
  };

  const isVideo = mediaType === 'video';

  // Pre-request permissions on mount for faster picker response
  React.useEffect(() => {
    if (visible) {
      ImagePicker.requestMediaLibraryPermissionsAsync();
      ImagePicker.requestCameraPermissionsAsync();
    }
  }, [visible]);

  // Get image dimensions to calculate aspect ratio
  React.useEffect(() => {
    if (mediaUri && mediaType === 'image') {
      Image.getSize(
        mediaUri,
        (width, height) => {
          setImageAspectRatio(width / height);
        },
        (error) => {
          console.log('Failed to get image size:', error);
          setImageAspectRatio(4 / 5); // Fallback
        }
      );
    } else if (mediaType === 'video') {
      setImageAspectRatio(9 / 16); // Portrait video default
    }
  }, [mediaUri, mediaType]);

  const handleCreate = async () => {
    if (text.trim().length > 0 && selectedEmotion) {
      try {
        setIsUploading(true);
        setUploadProgress(0);

        let uploadedMediaUrl = mediaUri;

        // Upload media to Supabase if exists
        if (mediaUri && mediaType) {
          setUploadProgress(10);

          try {
            const result = await uploadMediaMutation.mutateAsync({
              uri: mediaUri,
              type: mediaType,
            });
            uploadedMediaUrl = result.url;
            setUploadProgress(100);
          } catch (error) {
            console.error('Media upload failed:', error);
            // Continue without media on error
            uploadedMediaUrl = undefined;
          }
        }

        // Create memory
        await createMemoryMutation.mutateAsync({
          text: text.trim(),
          emotion: selectedEmotion,
          imageUrl: mediaType === 'image' ? uploadedMediaUrl : undefined,
          videoUrl: mediaType === 'video' ? uploadedMediaUrl : undefined,
          location,
          latitude,
          longitude,
        });

        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);

        // Reset form
        setText('');
        setSelectedEmotion(null);
        setMediaUri(undefined);
        setMediaType(undefined);
        setLocation(undefined);
        setLatitude(undefined);
        setLongitude(undefined);
        setUploadProgress(0);
        setIsUploading(false);

        onClose();
      } catch (error) {
        console.error('Create memory failed:', error);
        setIsUploading(false);
        Alert.alert(
          language === 'ru' ? 'Ошибка' : 'Error',
          language === 'ru' ? 'Не удалось создать воспоминание' : 'Failed to create memory'
        );
      }
    }
  };

  const pickMedia = useCallback(async () => {
    if (isPickingMedia) return; // Prevent double-taps

    setIsPickingMedia(true);
    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);

    try {
      const { status } = await ImagePicker.getMediaLibraryPermissionsAsync();

      if (status !== 'granted') {
        const { status: newStatus } = await ImagePicker.requestMediaLibraryPermissionsAsync();
        if (newStatus !== 'granted') {
          Alert.alert(t('permission.library'), t('permission.library'));
          setIsPickingMedia(false);
          return;
        }
      }

      console.log('[MediaPicker] Opening picker...');

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images', 'videos'],
        allowsEditing: false,
        allowsMultipleSelection: false,
        quality: 0.9, // Higher quality for better images
        videoQuality: ImagePicker.UIImagePickerControllerQualityType.High,
        videoMaxDuration: 120, // 2 minutes max for videos
        exif: false, // Don't include EXIF data to reduce size
      });

      console.log('[MediaPicker] Result:', result);

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        console.log('[MediaPicker] Selected asset:', {
          type: asset.type,
          uri: asset.uri,
          width: asset.width,
          height: asset.height,
          fileSize: asset.fileSize,
        });

        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        setMediaUri(asset.uri);
        setMediaType(asset.type === 'video' ? 'video' : 'image');
      } else {
        console.log('[MediaPicker] User cancelled or no asset selected');
      }
    } catch (error) {
      console.error('[MediaPicker] Error picking media:', error);
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Не удалось выбрать медиа. Попробуйте еще раз.' : 'Failed to pick media. Please try again.'
      );
    } finally {
      setIsPickingMedia(false);
    }
  }, [isPickingMedia, triggerHaptic, t, language]);

  const takePhoto = useCallback(async () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);

    try {
      const { status } = await ImagePicker.getCameraPermissionsAsync();

      if (status !== 'granted') {
        const { status: newStatus } = await ImagePicker.requestCameraPermissionsAsync();
        if (newStatus !== 'granted') {
          Alert.alert(t('permission.camera'), t('permission.cameraDesc'));
          return;
        }
      }

      console.log('[Camera] Opening camera...');

      const result = await ImagePicker.launchCameraAsync({
        allowsEditing: false,
        quality: 0.9, // Higher quality
        exif: false,
      });

      console.log('[Camera] Result:', result);

      if (!result.canceled && result.assets[0]) {
        const asset = result.assets[0];
        console.log('[Camera] Photo taken:', {
          uri: asset.uri,
          width: asset.width,
          height: asset.height,
        });

        Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        setMediaUri(asset.uri);
        setMediaType('image');
      }
    } catch (error) {
      console.error('[Camera] Error taking photo:', error);
      Alert.alert(
        language === 'ru' ? 'Ошибка' : 'Error',
        language === 'ru' ? 'Не удалось сделать фото. Попробуйте еще раз.' : 'Failed to take photo. Please try again.'
      );
    }
  }, [triggerHaptic, t, language]);

  const removeMedia = () => {
    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
    setMediaUri(undefined);
    setMediaType(undefined);
  };

  const addLocationData = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert(t('permission.location'), t('permission.location'));
      return;
    }

    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
    const loc = await Location.getCurrentPositionAsync({});

    // Save coordinates
    setLatitude(loc.coords.latitude);
    setLongitude(loc.coords.longitude);

    const address = await Location.reverseGeocodeAsync({
      latitude: loc.coords.latitude,
      longitude: loc.coords.longitude,
    });

    if (address[0]) {
      const locationString = `${address[0].city || ''}, ${address[0].region || ''}`.trim();
      setLocation(locationString);
    }
  };

  const canSubmit = text.trim().length > 0 && selectedEmotion !== null;

  return (
    <Modal
      visible={visible}
      animationType="slide"
      presentationStyle="pageSheet"
      onRequestClose={onClose}
    >
      <View className="flex-1" style={{ backgroundColor: theme.colors.background }}>
        <LinearGradient
          colors={[theme.colors.primaryLight, theme.colors.primaryLight, theme.colors.primaryDark]}
          locations={[0, 0.7, 1]}
          style={{ flex: 1 }}
        >
          <Animated.View
            entering={FadeIn.duration(200)}
            style={{ flex: 1 }}
          >
            <View
              style={{ paddingTop: insets.top + 8, paddingBottom: insets.bottom }}
              className="flex-1"
            >
              {/* Header */}
              <View className="flex-row items-center justify-between px-4 pb-4">
                <Pressable
                  onPress={() => {
                    triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                    onClose();
                  }}
                  className="w-10 h-10 items-center justify-center rounded-full active:opacity-60"
                  style={{ backgroundColor: `${theme.colors.accent}20` }}
                >
                  <X size={20} color={theme.colors.accent} strokeWidth={1.5} />
                </Pressable>
                <Text style={{ color: theme.colors.text, fontSize: 16, fontWeight: '300' }}>
                  {t('create.title')}
                </Text>
                <Pressable
                  onPress={handleCreate}
                  disabled={!canSubmit || isUploading}
                  className="w-10 h-10 items-center justify-center rounded-full"
                  style={{
                    backgroundColor: canSubmit && !isUploading ? theme.colors.accent : 'rgba(255, 255, 255, 0.05)'
                  }}
                >
                  {isUploading ? (
                    <ActivityIndicator size="small" color={theme.colors.primary} />
                  ) : (
                    <Send
                      size={18}
                      color={canSubmit ? theme.colors.primary : `${theme.colors.textSecondary}4D`}
                      strokeWidth={1.5}
                    />
                  )}
                </Pressable>
              </View>

              {/* Content with KeyboardAvoidingView */}
              <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={{ flex: 1 }}
                keyboardVerticalOffset={insets.top + 60}
              >
                <ScrollView
                  className="flex-1 px-4"
                  keyboardDismissMode="interactive"
                  showsVerticalScrollIndicator={false}
                  contentContainerStyle={{ paddingBottom: 20 }}
                >
                  {/* 1. EMOTION PICKER - AT THE TOP */}
                  <Animated.View entering={FadeIn.duration(200)} className="mb-6">
                    <Text style={{ color: `${theme.colors.textSecondary}66`, fontSize: 14, marginBottom: 12 }}>
                      {t('create.emotion')}
                    </Text>
                    <ScrollView
                      horizontal
                      showsHorizontalScrollIndicator={false}
                      contentContainerStyle={{ paddingRight: 20 }}
                      style={{ flexGrow: 0 }}
                    >
                      {EMOTIONS.map((emotion) => (
                        <AnimatedPressable
                          key={emotion.key}
                          onPress={() => {
                            triggerHaptic(Haptics.ImpactFeedbackStyle.Light);
                            setSelectedEmotion(emotion.key);
                          }}
                          className="px-4 py-2.5 rounded-xl flex-row items-center mr-2"
                          style={{
                            backgroundColor: selectedEmotion === emotion.key
                              ? theme.colors.accent
                              : `${theme.colors.accent}20`
                          }}
                        >
                          <Text className="mr-1.5 text-base">{emotion.icon}</Text>
                          <Text
                            className="text-sm font-medium"
                            style={{
                              color: selectedEmotion === emotion.key
                                ? theme.colors.primary
                                : theme.colors.accent
                            }}
                          >
                            {emotion.label}
                          </Text>
                        </AnimatedPressable>
                      ))}
                    </ScrollView>
                  </Animated.View>

                  {/* 2. MEDIA BUTTONS - Gallery, Camera, Location */}
                  <Animated.View
                    entering={FadeIn.duration(200)}
                    className="flex-row mb-6"
                    style={{ gap: 10 }}
                  >
                    <Pressable
                      onPress={pickMedia}
                      disabled={isPickingMedia}
                      className="flex-1 rounded-xl py-3 flex-row items-center justify-center active:opacity-80"
                      style={{ backgroundColor: `${theme.colors.accent}20`, opacity: isPickingMedia ? 0.5 : 1 }}
                    >
                      {isPickingMedia ? (
                        <ActivityIndicator size="small" color={theme.colors.accent} />
                      ) : (
                        <>
                          <ImageIcon size={18} color={theme.colors.accent} strokeWidth={1.5} />
                          <Text style={{ color: theme.colors.accent, fontSize: 14, marginLeft: 8 }}>
                            {t('create.gallery')}
                          </Text>
                        </>
                      )}
                    </Pressable>
                    <Pressable
                      onPress={takePhoto}
                      className="flex-1 rounded-xl py-3 flex-row items-center justify-center active:opacity-80"
                      style={{ backgroundColor: `${theme.colors.accent}20` }}
                    >
                      <Camera size={18} color={theme.colors.accent} strokeWidth={1.5} />
                      <Text style={{ color: theme.colors.accent, fontSize: 14, marginLeft: 8 }}>
                        {t('create.camera')}
                      </Text>
                    </Pressable>
                    <Pressable
                      onPress={addLocationData}
                      className="flex-1 rounded-xl py-3 flex-row items-center justify-center active:opacity-80"
                      style={{ backgroundColor: `${theme.colors.accent}20` }}
                    >
                      <MapPin size={18} color={theme.colors.accent} strokeWidth={1.5} />
                      <Text style={{ color: theme.colors.accent, fontSize: 14, marginLeft: 8 }}>
                        {t('create.location')}
                      </Text>
                    </Pressable>
                  </Animated.View>

                  {/* 3. LOCATION INDICATOR (if added) */}
                  {location && (
                    <Animated.View entering={FadeIn.duration(300)} className="mb-4">
                      <Text className="text-sand/60 text-xs">📍 {location}</Text>
                    </Animated.View>
                  )}

                  {/* 4. MEDIA PREVIEW - Shows after adding photo/video */}
                  {mediaUri && (
                    <Animated.View
                      entering={FadeIn.duration(300)}
                      className="mb-6"
                    >
                      <View className="rounded-2xl overflow-hidden relative">
                        {mediaType === 'video' ? (
                          <View>
                            <CustomVideoPlayer
                              uri={mediaUri}
                              aspectRatio={imageAspectRatio || 9 / 16}
                              resizeMode={ResizeMode.COVER}
                            />
                            <View
                              className="absolute top-3 right-3 w-10 h-10 rounded-full bg-forest/80 items-center justify-center"
                            >
                              <Play size={20} color="#E8D5B7" fill="#E8D5B7" strokeWidth={0} />
                            </View>
                          </View>
                        ) : (
                          <Image
                            source={{ uri: mediaUri }}
                            style={{ width: '100%', aspectRatio: imageAspectRatio || 4 / 5, borderRadius: 16 }}
                            resizeMode="cover"
                          />
                        )}
                        {/* Remove button */}
                        <Pressable
                          onPress={removeMedia}
                          className="absolute top-3 left-3 w-10 h-10 rounded-full bg-forest/80 items-center justify-center active:bg-forest"
                        >
                          <Trash2 size={18} color="#E8D5B7" strokeWidth={1.5} />
                        </Pressable>
                      </View>

                      {/* Upload Progress */}
                      {isUploading && uploadProgress > 0 && (
                        <Animated.View entering={FadeIn.duration(200)} className="mt-2">
                          <View className="flex-row items-center justify-between mb-1">
                            <Text style={{ color: theme.colors.textSecondary, fontSize: 12 }}>
                              {language === 'ru' ? 'Загрузка...' : 'Uploading...'}
                            </Text>
                            <Text style={{ color: theme.colors.accent, fontSize: 12, fontWeight: '600' }}>
                              {uploadProgress}%
                            </Text>
                          </View>
                          <View
                            className="h-1 rounded-full overflow-hidden"
                            style={{ backgroundColor: `${theme.colors.accent}20` }}
                          >
                            <View
                              className="h-full rounded-full"
                              style={{
                                backgroundColor: theme.colors.accent,
                                width: `${uploadProgress}%`,
                              }}
                            />
                          </View>
                        </Animated.View>
                      )}
                    </Animated.View>
                  )}

                  {/* 5. TEXT INPUT - AT THE BOTTOM */}
                  <Animated.View entering={FadeIn.duration(200)}>
                    <TextInput
                      value={text}
                      onChangeText={setText}
                      placeholder={t('create.placeholder')}
                      placeholderTextColor="rgba(245, 242, 237, 0.25)"
                      multiline
                      autoFocus
                      className="text-lg font-light leading-7 min-h-[160px] py-4"
                      style={{ color: theme.colors.text }}
                      textAlignVertical="top"
                    />
                  </Animated.View>
                </ScrollView>
              </KeyboardAvoidingView>
            </View>
          </Animated.View>
        </LinearGradient>
      </View>
    </Modal>
  );
}
