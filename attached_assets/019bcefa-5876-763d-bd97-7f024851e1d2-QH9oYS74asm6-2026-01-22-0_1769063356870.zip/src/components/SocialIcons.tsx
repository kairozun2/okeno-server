import React from 'react';
import { View, Pressable, Linking } from 'react-native';
import { Instagram, Send, Youtube, Twitter, Facebook, Music, Linkedin, Github } from 'lucide-react-native';
import * as Haptics from 'expo-haptics';

interface SocialLink {
  platform: string;
  url: string;
}

interface SocialIconsProps {
  socialLinks: SocialLink[];
  size?: number;
  gap?: number;
}

// Detect platform from URL and return icon
function getPlatformIcon(url: string, size: number) {
  const lowerUrl = url.toLowerCase();

  if (lowerUrl.includes('instagram.com') || lowerUrl.includes('instagr.am')) {
    return <Instagram size={size} color="#E4405F" strokeWidth={2} />;
  }
  if (lowerUrl.includes('t.me') || lowerUrl.includes('telegram.me')) {
    return <Send size={size} color="#0088cc" strokeWidth={2} />;
  }
  if (lowerUrl.includes('youtube.com') || lowerUrl.includes('youtu.be')) {
    return <Youtube size={size} color="#FF0000" strokeWidth={2} />;
  }
  if (lowerUrl.includes('twitter.com') || lowerUrl.includes('x.com')) {
    return <Twitter size={size} color="#1DA1F2" strokeWidth={2} />;
  }
  if (lowerUrl.includes('facebook.com') || lowerUrl.includes('fb.com')) {
    return <Facebook size={size} color="#1877F2" strokeWidth={2} />;
  }
  if (lowerUrl.includes('tiktok.com')) {
    return <Music size={size} color="#000000" strokeWidth={2} />;
  }
  if (lowerUrl.includes('linkedin.com')) {
    return <Linkedin size={size} color="#0A66C2" strokeWidth={2} />;
  }
  if (lowerUrl.includes('github.com')) {
    return <Github size={size} color="#FFFFFF" strokeWidth={2} />;
  }

  return null;
}

/**
 * Displays small social media icons next to username.
 * Icons are borderless and minimal, clickable to open links.
 */
export function SocialIcons({ socialLinks, size = 16, gap = 6 }: SocialIconsProps) {
  // Debug log
  console.log('[SocialIcons] Rendering with links:', JSON.stringify(socialLinks));

  if (!socialLinks || socialLinks.length === 0) {
    console.log('[SocialIcons] No links to display');
    return null;
  }

  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap }}>
      {socialLinks.map((link, index) => {
        if (!link || !link.url) {
          console.log('[SocialIcons] Invalid link at index', index, link);
          return null;
        }

        const icon = getPlatformIcon(link.url, size);
        if (!icon) {
          console.log('[SocialIcons] No icon found for URL:', link.url);
          return null;
        }

        return (
          <Pressable
            key={index}
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              Linking.openURL(link.url).catch(err => {
                console.error('Failed to open URL:', err);
              });
            }}
            style={{ opacity: 1 }}
          >
            {icon}
          </Pressable>
        );
      })}
    </View>
  );
}
