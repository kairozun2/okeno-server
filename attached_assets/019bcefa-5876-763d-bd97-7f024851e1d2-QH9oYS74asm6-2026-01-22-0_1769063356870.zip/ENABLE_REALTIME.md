# Включение Realtime в Supabase

## Проблема
Сообщения не приходят в реальном времени на другое устройство.

## Решение
Нужно включить Realtime для таблиц в Supabase:

### Шаг 1: Откройте Supabase Dashboard
1. Перейдите на https://supabase.com
2. Откройте ваш проект
3. В левом меню выберите **Database** → **Replication**

### Шаг 2: Включите Realtime для таблиц
Включите Realtime для следующих таблиц:
- ✅ **messages** - для мгновенного получения сообщений
- ✅ **conversations** - для обновления списка чатов
- ✅ **notifications** (если есть) - для уведомлений
- ✅ **echoes** (лайки) - для обновления счётчика лайков
- ✅ **comments** - для комментариев в реальном времени

### Шаг 3: Проверьте настройки
1. В Supabase Dashboard → **Database** → **Replication**
2. Найдите таблицы `messages` и `conversations`
3. Убедитесь, что для них включен флажок **Enable Realtime**

### Шаг 4: Перезапустите приложение
После включения Realtime:
1. Полностью закройте приложение на обоих устройствах
2. Откройте снова
3. Проверьте, что сообщения приходят мгновенно

## Альтернативный способ (через SQL)
Если не находите настройки Realtime в Dashboard, выполните этот SQL:

```sql
-- Enable Realtime for messages table
ALTER PUBLICATION supabase_realtime ADD TABLE messages;

-- Enable Realtime for conversations table
ALTER PUBLICATION supabase_realtime ADD TABLE conversations;

-- Enable Realtime for notifications table (if exists)
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;

-- Enable Realtime for echoes table
ALTER PUBLICATION supabase_realtime ADD TABLE echoes;

-- Enable Realtime for comments table
ALTER PUBLICATION supabase_realtime ADD TABLE comments;
```

## Проверка
После включения Realtime вы должны видеть в логах:
```
[Conversations] Realtime subscription status: SUBSCRIBED
[Messages] Realtime subscription status: SUBSCRIBED
```

Если видите эти сообщения - Realtime работает правильно!
