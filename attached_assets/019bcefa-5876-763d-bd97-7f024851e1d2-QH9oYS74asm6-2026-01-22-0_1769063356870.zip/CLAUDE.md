<stack>
  Expo SDK 53, React Native 0.76.7, bun (not npm).
  React Query for server/async state.
  Supabase for backend (database, auth, storage, real-time).
  NativeWind + Tailwind v3 for styling.
  react-native-reanimated v3 for animations (preferred over Animated from react-native).
  react-native-gesture-handler for gestures.
  lucide-react-native for icons.
  All packages are pre-installed. DO NOT install new packages unless they are @expo-google-font packages or pure JavaScript helpers like lodash, dayjs, etc.
</stack>

<structure>
  src/app/          — Expo Router file-based routes (src/app/_layout.tsx is root). Add new screens to this folder.
  src/components/   — Reusable UI components. Add new components to this folder.
  src/lib/          — Utilities:
    - supabase.ts: Supabase client + TypeScript types
    - supabase-hooks.ts: React Query hooks for all Supabase operations (auth, CRUD, real-time)
    - store.ts: Local Zustand store (minimal, used for UI state only)
    - settings-store.ts: User settings (theme, language)
    - cn.ts: className merge helper
    - avatar.ts: Emoji avatar generation with improved FNV-1a hash algorithm for better uniqueness
</structure>

<backend>
  The app uses Supabase as the backend (BaaS - Backend as a Service).

  **IMPORTANT: User needs to set up Supabase before the app will work properly**

  When user gets their computer, they must:
  1. Create a Supabase account at https://supabase.com
  2. Create a new project
  3. Copy the SQL schema from /supabase-schema.sql and run it in Supabase SQL Editor
  4. Add environment variables in Vibecode ENV tab:
     - EXPO_PUBLIC_SUPABASE_URL (from Supabase project settings)
     - EXPO_PUBLIC_SUPABASE_ANON_KEY (from Supabase project settings)
  5. Set up Storage bucket named "memories" for images/videos

  **Authentication:**
  - Users sign up/in with username + Visual Key Pattern (3x3 grid)
  - Pattern is hashed with SHA-256 and used as Supabase auth password
  - useSignUp(), useSignIn(), useAuth() hooks handle all auth

  **Database:**
  - PostgreSQL hosted on Supabase
  - Schema defined in /supabase-schema.sql
  - Tables: profiles, memories, echoes, saves, comments, notifications, follows, hidden_users
  - Row Level Security (RLS) enabled - users can only access their own data

  **Data Fetching:**
  - Use React Query hooks from /src/lib/supabase-hooks.ts
  - Examples: useMemories(), useMyMemories(), useCreateMemory(), useToggleEcho()
  - All hooks have optimistic updates and automatic cache invalidation

  **File Storage:**
  - Supabase Storage bucket named "memories"
  - useUploadMedia() hook handles image/video uploads
  - Returns public CDN URL

  **Real-Time:**
  - Supabase Realtime subscriptions (coming soon)
  - Changes sync automatically across devices

  **Environment Variables (user must set in Vibecode ENV tab):**
  - EXPO_PUBLIC_SUPABASE_URL - Supabase project URL
  - EXPO_PUBLIC_SUPABASE_ANON_KEY - Supabase anon/public key

  **Setup Instructions:**
  - Full guide in /SUPABASE_SETUP.md
  - User must create Supabase account, run schema, and add ENV keys
</backend>

<recent_optimizations>
  **Performance improvements made (2026-01-19):**
  1. Modal screens (search, notifications) now use React.useCallback and useMemo for better performance
  2. FlatList optimization: removeClippedSubviews, maxToRenderPerBatch, windowSize for smooth scrolling
  3. Emoji generation uses improved FNV-1a hash algorithm with weighted patterns for better uniqueness
  4. Emoji rendering quality improved with proper fontSize and lineHeight for crisp display
  5. All modals have presentation: 'modal' and gestureEnabled: true for smooth swipe-to-close gestures
  6. App now works in offline mode without Supabase connection (will sync when backend is connected)
  7. Keyboard animations are smooth using react-native-keyboard-controller
  8. Back buttons are styled with underlines and arrow icons for better UX
</recent_optimizations>

<glass_design>
  **iOS Glass/Blur Design System:**
  - Use expo-blur's BlurView component for frosted glass effects
  - Use expo-glass-effect for advanced glass morphism
  - Intensity should be subtle: 20-40 for backgrounds, 60-80 for overlays
  - Combine with semi-transparent backgrounds (rgba with 0.7-0.9 alpha)
  - Use on modals, cards, headers, and bottom sheets
  - Example:
    <BlurView intensity={30} tint="dark" style={{ borderRadius: 16, overflow: 'hidden' }}>
      <View style={{ backgroundColor: 'rgba(0,0,0,0.3)' }}>
        {/* Content */}
      </View>
    </BlurView>
</glass_design>

<app_store_compliance>
  **Important for App Store submission:**
  1. Alert.alert is used for permission requests (camera, location, photos) - this is standard and approved by Apple
  2. Privacy: Make sure to add NSCameraUsageDescription, NSLocationWhenInUseUsageDescription, NSPhotoLibraryUsageDescription in app.json before submission
  3. No hardcoded API keys or secrets - all are in environment variables
  4. SafeArea is properly handled throughout the app with react-native-safe-area-context
  5. All gestures work smoothly on iOS with react-native-gesture-handler
</app_store_compliance>

<typescript>
  Explicit type annotations for useState: `useState<Type[]>([])` not `useState([])`
  Null/undefined handling: use optional chaining `?.` and nullish coalescing `??`
  Include ALL required properties when creating objects — TypeScript strict mode is enabled.
</typescript>

<environment>
  You are in Vibecode. The system manages git and the dev server (port 8081).
  DO NOT: manage git, touch the dev server, or check its state.
  The user views the app through Vibecode App.
  The user cannot see the code or interact with the terminal. Do not tell the user to do anything with the code or terminal.
  You can see logs in the expo.log file.
  The Vibecode App has tabs like ENV tab, API tab, LOGS tab. You can ask the user to use these tabs to view the logs, add enviroment variables, or give instructions for APIs like OpenAI, Nanobanana, Grok, Elevenlabs, etc. but first try to implement the functionality yourself.
  The user is likely non-technical, communicate with them in an easy to understand manner.
  If the user's request is vague or ambitious, scope down to specific functionality. Do everything for them.
  For images, use URLs from unsplash.com. You can also tell the user they can use the IMAGES tab to generate and uplooad images.
</environment>


<forbidden_files>
  Do not edit: patches/, babel.config.js, metro.config.js, app.json, tsconfig.json, nativewind-env.d.ts
</forbidden_files>

<routing>
  Expo Router for file-based routing. Every file in src/app/ becomes a route.
  Never delete or refactor RootLayoutNav from src/app/_layout.tsx.
  
  <stack_router>
    src/app/_layout.tsx (root layout), src/app/index.tsx (matches '/'), src/app/settings.tsx (matches '/settings')
    Use <Stack.Screen options={{ title, headerStyle, ... }} /> inside pages to customize headers.
  </stack_router>
  
  <tabs_router>
    Only files registered in src/app/(tabs)/_layout.tsx become actual tabs.
    Unregistered files in (tabs)/ are routes within tabs, not separate tabs.
    Nested stacks create double headers — remove header from tabs, add stack inside each tab.
    At least 2 tabs or don't use tabs at all — single tab looks bad.
  </tabs_router>
  
  <router_selection>
    Games should avoid tabs — use full-screen stacks instead.
    For full-screen overlays/modals outside tabs: create route in src/app/ (not src/app/(tabs)/), 
    then add `<Stack.Screen name="page" options={{ presentation: "modal" }} />` in src/app/_layout.tsx.
  </router_selection>
  
  <rules>
    Only ONE route can map to "/" — can't have both src/app/index.tsx and src/app/(tabs)/index.tsx.
    Dynamic params: use `const { id } = useLocalSearchParams()` from expo-router.
  </rules>
</routing>

<state>
  React Query for server/async state. Always use object API: `useQuery({ queryKey, queryFn })`.
  Never wrap RootLayoutNav directly.
  React Query provider must be outermost; nest other providers inside it.
  
  Use `useMutation` for async operations — no manual `setIsLoading` patterns.
  Wrap third-party lib calls (RevenueCat, etc.) in useQuery/useMutation for consistent loading states.
  Reuse query keys across components to share cached data — don't create duplicate providers.
  
  For local state, use Zustand. However, most state is server state, so use React Query for that.
  Always use a selector with Zustand to subscribe only to the specific slice of state you need (e.g., useStore(s => s.foo)) rather than the whole store to prevent unnecessary re-renders. Make sure that the value returned by the selector is a primitive. Do not execute store methods in selectors; select data/functions, then compute outside the selector.
  For persistence: use AsyncStorage inside context hook providers. Only persist necessary data.
  Split ephemeral from persisted state to avoid hydration bugs.
</state>

<safearea>
  Import from react-native-safe-area-context, NOT from react-native.
  Skip SafeAreaView inside tab stacks with navigation headers.
  Skip when using native headers from Stack/Tab navigator.
  Add when using custom/hidden headers.
  For games: use useSafeAreaInsets hook instead.
</safearea>

<data>
  Create realistic mock data when you lack access to real data.
  For image analysis: actually send to LLM don't mock.
</data>

<design>
  Don't hold back. This is mobile — design for touch, thumb zones, glanceability.
  Inspiration: iOS, Instagram, Airbnb, Coinbase, polished habit trackers.

  <avoid>
    Purple gradients on white, generic centered layouts, predictable patterns.
    Web-like designs on mobile. Overused fonts (Space Grotesk, Inter).
  </avoid>

  <do>
    Cohesive themes with dominant colors and sharp accents.
    High-impact animations: progress bars, button feedback, haptics.
    Depth via gradients and patterns, not flat solids.
    Install `@expo-google-fonts/{font-name}` for fonts (eg: `@expo-google-fonts/inter`)
    Use zeego for context menus and dropdowns (native feel). Lookup the documentation on zeego.dev to see how to use it.
  </do>
</design>

<mistakes>
  <styling>
    Use Nativewind for styling. Use cn() helper from src/lib/cn.ts to merge classNames when conditionally applying classNames or passing classNames via props.
    CameraView, LinearGradient, and Animated components DO NOT support className. Use inline style prop.
    Horizontal ScrollViews will expand vertically to fill flex containers. Add `style={{ flexGrow: 0 }}` to constrain height to content.
  </styling>

  <camera>
    Use CameraView from expo-camera, NOT the deprecated Camera import.
    import { CameraView, CameraType, useCameraPermissions } from 'expo-camera';
    Use style={{ flex: 1 }}, not className.
    Overlay UI must be absolute positioned inside CameraView.
  </camera>

  <react_native>
    No Node.js buffer in React Native — don't import from 'buffer'.
  </react_native>

  <ux>
    Use Pressable over TouchableOpacity.
    Use custom modals, not Alert.alert().
    Ensure keyboard is dismissable and doesn't obscure inputs. This is much harder to implement than it seems. You can use the react-native-keyboard-controller package to help with this. But, make sure to look up the documentation before implementing.
  </ux>

  <outdated_knowledge>
    Your react-native-reanimated and react-native-gesture-handler training may be outdated. Look up current docs before implementing.
  </outdated_knowledge>
</mistakes>

<appstore>
  Cannot assist with App Store or Google Play submission processes (app.json, eas.json, EAS CLI commands).
  For submission help, click "Share" on the top right corner on the Vibecode App and select "Submit to App Store".
</appstore> 

<skills>
You have access to a few skills in the `.claude/skills` folder. Use them to your advantage.
- ai-apis-like-chatgpt: Use this skill when the user asks you to make an app that requires an AI API.
- expo-docs: Use this skill when the user asks you to use an Expo SDK module or package that you might not know much about.
- frontend-app-design: Use this skill when the user asks you to design a frontend app component or screen.
</skills>