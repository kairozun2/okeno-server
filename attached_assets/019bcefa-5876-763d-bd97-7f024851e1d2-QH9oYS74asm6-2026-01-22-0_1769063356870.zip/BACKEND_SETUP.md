# Backend Infrastructure Setup Guide

## Overview
Complete backend setup for Memories app including authentication, database, API, file storage, and deployment.

---

## 🏗️ Architecture

```
┌─────────────┐
│ React Native│
│   Client    │
└──────┬──────┘
       │ HTTPS/WSS
       ↓
┌──────────────────┐
│   API Gateway    │
│   (Express.js)   │
└────────┬─────────┘
         │
    ┌────┴────┬──────────┬────────────┐
    ↓         ↓          ↓            ↓
┌────────┐ ┌─────┐  ┌────────┐  ┌──────────┐
│Postgres│ │Redis│  │  S3    │  │WebSocket │
│   DB   │ │Cache│  │Storage │  │ Server   │
└────────┘ └─────┘  └────────┘  └──────────┘
```

---

## 1. Database Schema (PostgreSQL)

### Users Table
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id VARCHAR(50) UNIQUE NOT NULL, -- Recovery ID (XXXX-XXXX-XXXX)
  username VARCHAR(50) UNIQUE,
  visual_key_hash TEXT NOT NULL, -- bcrypt hash of pattern array
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_users_user_id ON users(user_id);
CREATE INDEX idx_users_username ON users(username);
```

### Memories Table
```sql
CREATE TABLE memories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id UUID REFERENCES users(id) ON DELETE CASCADE,
  text TEXT,
  emotion VARCHAR(20) NOT NULL,
  image_url TEXT, -- S3 URL
  echo_count INTEGER DEFAULT 0,
  is_archived BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_memories_author ON memories(author_id);
CREATE INDEX idx_memories_created ON memories(created_at DESC);
```

### Saves Table (Many-to-Many)
```sql
CREATE TABLE saves (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  memory_id UUID REFERENCES memories(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, memory_id)
);

CREATE INDEX idx_saves_user ON saves(user_id);
CREATE INDEX idx_saves_memory ON saves(memory_id);
```

### Echoes Table
```sql
CREATE TABLE echoes (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  memory_id UUID REFERENCES memories(id) ON DELETE CASCADE,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, memory_id)
);

CREATE INDEX idx_echoes_memory ON echoes(memory_id);
```

### Comments Table
```sql
CREATE TABLE comments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  memory_id UUID REFERENCES memories(id) ON DELETE CASCADE,
  author_id UUID REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_comments_memory ON comments(memory_id);
```

### Notifications Table
```sql
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE, -- Recipient
  type VARCHAR(20) NOT NULL, -- 'like' | 'comment'
  actor_id UUID REFERENCES users(id) ON DELETE CASCADE, -- Who did the action
  memory_id UUID REFERENCES memories(id) ON DELETE CASCADE,
  comment_text TEXT, -- If type = 'comment'
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON notifications(user_id, created_at DESC);
```

---

## 2. API Endpoints

### Base URL: `https://api.memories.app/v1`

### Authentication
```typescript
POST /auth/register
Body: {
  username: string;
  visualKeyPattern: number[]; // Array of dot indices
}
Response: {
  userId: string; // Recovery ID
  token: string; // JWT
}

POST /auth/login
Body: {
  userId: string; // Recovery ID
  visualKeyPattern: number[];
}
Response: {
  token: string; // JWT
  user: User;
}

POST /auth/verify
Headers: { Authorization: 'Bearer <token>' }
Response: { valid: boolean; user: User; }
```

### Memories
```typescript
GET /memories/feed?page=1&limit=20
Headers: { Authorization: 'Bearer <token>' }
Response: {
  memories: Memory[];
  hasMore: boolean;
}

GET /memories/my?page=1&limit=20
Response: { memories: Memory[]; hasMore: boolean; }

GET /memories/saved?page=1&limit=20
Response: { memories: Memory[]; hasMore: boolean; }

GET /memories/archived
Response: { memories: Memory[]; }

GET /memories/:id
Response: { memory: Memory; }

POST /memories
Body: {
  text?: string;
  emotion: string;
  imageUrl?: string; // Upload first, get URL
}
Response: { memory: Memory; }

PATCH /memories/:id
Body: { text?: string; isArchived?: boolean; }
Response: { memory: Memory; }

DELETE /memories/:id
Response: { success: true; }
```

### Interactions
```typescript
POST /memories/:id/echo
Response: { echoCount: number; }

DELETE /memories/:id/echo
Response: { echoCount: number; }

POST /memories/:id/save
Response: { success: true; }

DELETE /memories/:id/save
Response: { success: true; }
```

### Comments
```typescript
GET /memories/:id/comments?page=1&limit=50
Response: { comments: Comment[]; hasMore: boolean; }

POST /memories/:id/comments
Body: { text: string; }
Response: { comment: Comment; }

DELETE /comments/:id
Response: { success: true; }
```

### Notifications
```typescript
GET /notifications?page=1&limit=50
Response: { notifications: Notification[]; hasMore: boolean; }

PATCH /notifications/:id/read
Response: { success: true; }

DELETE /notifications/:id
Response: { success: true; }
```

### Upload
```typescript
POST /upload/image
Body: FormData with 'file' field
Response: { url: string; }

POST /upload/video
Body: FormData with 'file' field (max 60s, 50MB)
Response: { url: string; }
```

### Users
```typescript
GET /users/search?q=username&page=1&limit=20
Response: { users: User[]; hasMore: boolean; }

GET /users/:id
Response: { user: User; memoriesCount: number; }
```

---

## 3. Tech Stack

### Backend
- **Runtime**: Node.js 20+ with TypeScript
- **Framework**: Express.js
- **Database**: PostgreSQL 15+ (Supabase or AWS RDS)
- **Cache**: Redis (for sessions, rate limiting)
- **Storage**: AWS S3 or Cloudflare R2
- **Auth**: JWT with bcrypt
- **Validation**: Zod
- **ORM**: Prisma or raw SQL with pg

### Recommended Services
- **Database**: Supabase (free tier: 500MB)
- **Storage**: Cloudflare R2 (free 10GB/month)
- **Hosting**: Railway.app or Fly.io
- **CDN**: Cloudflare
- **Monitoring**: Sentry

---

## 4. Environment Variables

```bash
# Server
PORT=3000
NODE_ENV=production

# Database
DATABASE_URL=postgresql://user:pass@host:5432/memories

# Redis (optional, for caching)
REDIS_URL=redis://user:pass@host:6379

# JWT
JWT_SECRET=your-super-secret-key-change-this
JWT_EXPIRES_IN=7d

# AWS S3 / Cloudflare R2
S3_ENDPOINT=https://s3.amazonaws.com
S3_BUCKET=memories-media
S3_ACCESS_KEY=AKIAIOSFODNN7EXAMPLE
S3_SECRET_KEY=wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY
S3_REGION=us-east-1

# CORS
ALLOWED_ORIGINS=exp://192.168.*.*:*,capacitor://localhost,http://localhost:*

# Rate Limiting
RATE_LIMIT_WINDOW_MS=900000
RATE_LIMIT_MAX_REQUESTS=100
```

---

## 5. Security

### Password/Pattern Security
```typescript
import bcrypt from 'bcrypt';

// Hash visual key pattern
async function hashPattern(pattern: number[]): Promise<string> {
  const patternString = pattern.sort().join('-');
  return bcrypt.hash(patternString, 12);
}

// Verify pattern
async function verifyPattern(
  pattern: number[],
  hash: string
): Promise<boolean> {
  const patternString = pattern.sort().join('-');
  return bcrypt.compare(patternString, hash);
}
```

### JWT Generation
```typescript
import jwt from 'jsonwebtoken';

function generateToken(userId: string): string {
  return jwt.sign(
    { userId, type: 'access' },
    process.env.JWT_SECRET!,
    { expiresIn: '7d' }
  );
}

function verifyToken(token: string): { userId: string } {
  return jwt.verify(token, process.env.JWT_SECRET!) as { userId: string };
}
```

### Middleware
```typescript
// Auth middleware
async function authenticate(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token' });

  try {
    const payload = verifyToken(token);
    req.userId = payload.userId;
    next();
  } catch (err) {
    res.status(401).json({ error: 'Invalid token' });
  }
}

// Rate limiting
import rateLimit from 'express-rate-limit';

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
});

app.use('/api', limiter);
```

---

## 6. File Upload (S3/R2)

### Setup
```typescript
import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import sharp from 'sharp'; // Image optimization

const s3 = new S3Client({
  region: process.env.S3_REGION,
  endpoint: process.env.S3_ENDPOINT,
  credentials: {
    accessKeyId: process.env.S3_ACCESS_KEY!,
    secretAccessKey: process.env.S3_SECRET_KEY!,
  },
});

async function uploadImage(
  file: Buffer,
  filename: string
): Promise<string> {
  // Optimize image
  const optimized = await sharp(file)
    .resize(1080, 1080, { fit: 'cover' })
    .jpeg({ quality: 85 })
    .toBuffer();

  const key = `memories/${Date.now()}-${filename}`;

  await s3.send(new PutObjectCommand({
    Bucket: process.env.S3_BUCKET,
    Key: key,
    Body: optimized,
    ContentType: 'image/jpeg',
    ACL: 'public-read',
  }));

  return `${process.env.S3_ENDPOINT}/${process.env.S3_BUCKET}/${key}`;
}
```

---

## 7. Real-time (WebSockets)

### Setup Socket.IO
```typescript
import { Server } from 'socket.io';

const io = new Server(server, {
  cors: { origin: process.env.ALLOWED_ORIGINS },
});

io.use(async (socket, next) => {
  const token = socket.handshake.auth.token;
  try {
    const payload = verifyToken(token);
    socket.userId = payload.userId;
    next();
  } catch (err) {
    next(new Error('Authentication error'));
  }
});

io.on('connection', (socket) => {
  console.log('User connected:', socket.userId);

  // Join user's notification room
  socket.join(`user:${socket.userId}`);

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.userId);
  });
});

// Send notification
function sendNotification(userId: string, notification: Notification) {
  io.to(`user:${userId}`).emit('notification', notification);
}
```

---

## 8. Deployment

### Railway.app (Recommended)
```bash
# Install Railway CLI
npm install -g @railway/cli

# Login
railway login

# Initialize project
railway init

# Add PostgreSQL
railway add --plugin postgresql

# Add Redis
railway add --plugin redis

# Deploy
railway up

# Set environment variables
railway variables set JWT_SECRET=your-secret
railway variables set S3_ACCESS_KEY=your-key
```

### Docker (Alternative)
```dockerfile
# Dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["node", "dist/index.js"]
```

```yaml
# docker-compose.yml
version: '3.8'
services:
  api:
    build: .
    ports:
      - "3000:3000"
    environment:
      DATABASE_URL: postgresql://postgres:password@db:5432/memories
      REDIS_URL: redis://redis:6379
    depends_on:
      - db
      - redis

  db:
    image: postgres:15
    environment:
      POSTGRES_DB: memories
      POSTGRES_PASSWORD: password
    volumes:
      - postgres_data:/var/lib/postgresql/data

  redis:
    image: redis:7-alpine

volumes:
  postgres_data:
```

---

## 9. Client Integration

### API Client Setup
```typescript
// src/lib/api.ts
import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

const api = axios.create({
  baseURL: 'https://api.memories.app/v1',
  timeout: 10000,
});

// Add auth token to requests
api.interceptors.request.use(async (config) => {
  const token = await AsyncStorage.getItem('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Handle errors
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    if (error.response?.status === 401) {
      await AsyncStorage.removeItem('auth_token');
      // Navigate to login
    }
    return Promise.reject(error);
  }
);

export default api;
```

### React Query Hooks
```typescript
// src/lib/queries/memories.ts
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import api from '@/lib/api';

export function useMemories() {
  return useQuery({
    queryKey: ['memories', 'feed'],
    queryFn: async () => {
      const { data } = await api.get('/memories/feed');
      return data.memories;
    },
  });
}

export function useCreateMemory() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: async (memory: CreateMemoryDto) => {
      const { data } = await api.post('/memories', memory);
      return data.memory;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['memories'] });
    },
  });
}
```

---

## 10. Testing

### API Tests (Jest + Supertest)
```typescript
import request from 'supertest';
import app from './app';

describe('POST /auth/register', () => {
  it('should create a new user', async () => {
    const res = await request(app)
      .post('/api/v1/auth/register')
      .send({
        username: 'testuser',
        visualKeyPattern: [0, 1, 2, 3],
      });

    expect(res.status).toBe(201);
    expect(res.body).toHaveProperty('userId');
    expect(res.body).toHaveProperty('token');
  });
});
```

---

## Next Steps

1. **Set up Supabase** - Create project, get DATABASE_URL
2. **Deploy to Railway** - One-click deploy with PostgreSQL
3. **Configure S3/R2** - Set up bucket for media storage
4. **Update frontend** - Replace mock data with API calls
5. **Test thoroughly** - Use Postman/Insomnia for API testing
6. **Monitor** - Add Sentry for error tracking

---

For questions or help: Check Railway/Supabase documentation or ask in Discord/Stack Overflow.
