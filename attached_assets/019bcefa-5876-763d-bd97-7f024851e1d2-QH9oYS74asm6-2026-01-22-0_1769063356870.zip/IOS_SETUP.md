# iOS Setup Instructions

## Required Permissions & Privacy Settings

For full iOS compatibility and App Store submission, add these to `app.json`:

```json
{
  "expo": {
    "name": "Memories",
    "slug": "memories-app",
    "version": "1.0.0",
    "orientation": "portrait",
    "icon": "./assets/icon.png",
    "userInterfaceStyle": "automatic",
    "splash": {
      "image": "./assets/splash.png",
      "resizeMode": "contain",
      "backgroundColor": "#043325"
    },
    "ios": {
      "supportsTablet": true,
      "bundleIdentifier": "com.yourcompany.memories",
      "infoPlist": {
        "NSPhotoLibraryUsageDescription": "Memories needs access to your photo library to add photos and videos to your memories.",
        "NSPhotoLibraryAddUsageDescription": "Memories needs permission to save photos to your library.",
        "NSCameraUsageDescription": "Memories needs access to your camera to take photos for your memories.",
        "NSLocationWhenInUseUsageDescription": "Memories can attach your location to memories if you choose.",
        "NSUserTrackingUsageDescription": "This identifier will be used to deliver personalized ads to you."
      },
      "privacyManifests": {
        "NSPrivacyAccessedAPITypes": [
          {
            "NSPrivacyAccessedAPIType": "NSPrivacyAccessedAPICategoryPhotoLibrary",
            "NSPrivacyAccessedAPITypeReasons": ["C7E8.1"]
          },
          {
            "NSPrivacyAccessedAPIType": "NSPrivacyAccessedAPICategoryCamera",
            "NSPrivacyAccessedAPITypeReasons": ["C7E8.1"]
          }
        ]
      }
    },
    "android": {
      "adaptiveIcon": {
        "foregroundImage": "./assets/adaptive-icon.png",
        "backgroundColor": "#043325"
      },
      "permissions": [
        "android.permission.CAMERA",
        "android.permission.READ_EXTERNAL_STORAGE",
        "android.permission.WRITE_EXTERNAL_STORAGE",
        "android.permission.ACCESS_FINE_LOCATION",
        "android.permission.ACCESS_COARSE_LOCATION"
      ],
      "package": "com.yourcompany.memories"
    },
    "plugins": [
      "expo-router",
      [
        "expo-image-picker",
        {
          "photosPermission": "Memories needs access to your photos to add them to your memories.",
          "cameraPermission": "Memories needs access to your camera to take photos."
        }
      ],
      [
        "expo-location",
        {
          "locationAlwaysAndWhenInUsePermission": "Memories can attach your location to memories if you choose."
        }
      ],
      [
        "expo-av",
        {
          "microphonePermission": "Allow Memories to record video with audio."
        }
      ]
    ]
  }
}
```

## Current Implementation

The app already uses:
- ✅ `expo-image-picker` for photo/video selection and camera access
- ✅ `expo-location` for location tagging
- ✅ Proper permission requests before accessing features
- ✅ iOS-native UI patterns (modals, animations, haptics)
- ✅ Dark mode support with `userInterfaceStyle: "automatic"`

## Photo Library Integration

The app fully integrates with iOS Photos:

### Features Implemented:
1. **Photo/Video Selection** - Users can pick any photo or video from their library
2. **Camera Access** - Users can take photos directly in the app
3. **Video Support** - Videos up to 60 seconds are supported
4. **Media Editing** - Users can crop/edit before adding to memories
5. **Permission Handling** - Proper iOS permission prompts with user-friendly messages

### Code Location:
- `/src/app/create-memory.tsx` - Main implementation
- Lines 55-75: Photo library picker
- Lines 77-95: Camera functionality

## App Store Requirements

### Privacy Policy
You'll need to create a privacy policy that covers:
- Photo/video access and usage
- Location data (optional feature)
- Data storage (local only, no cloud sync)
- Visual Key Pattern authentication method

### App Store Connect Setup
1. Create App ID with correct bundle identifier
2. Add App Store icon (1024x1024px)
3. Prepare screenshots for all iOS device sizes
4. Write app description highlighting privacy-first approach
5. Set age rating (likely 4+ or 9+)

### TestFlight
Before App Store submission, test via TestFlight to ensure:
- All permissions work correctly
- Visual Key Pattern auth is secure
- Photo/video playback works on all devices
- No crashes during photo selection

## Backend & Sync (Future)

Currently the app stores everything locally with AsyncStorage. For future server sync:

1. **Backend Options:**
   - Firebase (easiest, built-in auth)
   - Supabase (open source, PostgreSQL)
   - Custom Node.js/Express server

2. **What to Sync:**
   - User account (userId, userName, visualKeyPattern hash)
   - Memories metadata (text, emotion, timestamps)
   - Media files (photos/videos) - use cloud storage (S3, Cloudinary)
   - Notifications data

3. **Security:**
   - Store Visual Key Pattern as bcrypt hash
   - Encrypt media files before upload
   - Use HTTPS for all API calls
   - Implement rate limiting

## Next Steps

1. Update `app.json` with proper bundle ID and permissions (see above)
2. Create app icons and splash screen
3. Set up Apple Developer account
4. Test all features on physical iOS device
5. Submit for TestFlight beta testing
6. (Optional) Set up backend for sync between devices
