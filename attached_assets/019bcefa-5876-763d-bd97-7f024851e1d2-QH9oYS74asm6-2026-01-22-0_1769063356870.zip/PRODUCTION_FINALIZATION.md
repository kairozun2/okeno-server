# Production-Ready Finalization Guide

## Critical Changes Required

### 1. **Theme System** ✅ Created
**Files created:**
- `src/lib/themes.ts` - Theme definitions (Forest, Feldgrau, Wheat)
- Updated `src/lib/settings-store.ts` with `theme` and `language`

**TODO: Apply themes**
Update all screens to use `useSettingsStore(s => s.theme)` and apply colors dynamically.

### 2. **Localization (i18n)** ✅ Created
**Files created:**
- `src/lib/i18n.ts` - Complete EN/RU translations

**TODO: Apply translations**
Replace hardcoded strings with `t('key')` function in all screens.

### 3. **Settings Screen Updates** ⏳ Required
Add to `src/app/settings.tsx`:
- Theme picker (3 color swatches: Forest, Feldgrau, Wheat)
- Language picker (EN/RU with flags)

### 4. **Remove Duplicate Profile Button** ⏳ Required
In `src/app/(tabs)/index.tsx`:
- Remove `<Pressable>` with `<User>` icon from header
- Keep only greeting + username

### 5. **Optimize Create Animation** ⏳ Required
In `src/app/create-memory.tsx`:
- Replace `SlideInDown` with simpler `FadeIn`
- Remove complex spring animations
- Use `duration: 250` for instant feel

### 6. **Fix Video in MemoryCard** ⏳ Required
In `src/components/MemoryCard.tsx`:
- Add `<Video>` component for `memory.imageUrl` if it's video
- Check file extension or add `mediaType` to Memory interface
- Use `useNativeControls` for playback

## Quick Implementation Plan

###Step 1: Remove Profile Button
```tsx
// src/app/(tabs)/index.tsx
// DELETE lines with User icon button
// KEEP only greeting text
```

### Step 2: Update Settings Screen
```tsx
// Add theme picker
{themeList.map(theme => (
  <Pressable
    key={theme.key}
    onPress={() => setTheme(theme.key)}
    style={{ backgroundColor: theme.colors.primary }}
  />
))}

// Add language picker
{['en', 'ru'].map(lang => (
  <Pressable onPress={() => setLanguage(lang)}>
    <Text>{t(`language.${lang}`)}</Text>
  </Pressable>
))}
```

### Step 3: Apply Translations
```tsx
// Example: src/app/(tabs)/index.tsx
const language = useSettingsStore(s => s.language);
const translate = useTranslation(language);

<Text>{translate('greeting.morning')}</Text>
```

### Step 4: Apply Theme Colors
```tsx
// Example: Any screen
const themeKey = useSettingsStore(s => s.theme);
const theme = getTheme(themeKey);

<LinearGradient colors={[
  theme.colors.primary,
  theme.colors.primaryLight,
  theme.colors.primaryDark
]} />
```

### Step 5: Fix Video Playback
```tsx
// src/components/MemoryCard.tsx
{memory.imageUrl?.endsWith('.mp4') || memory.imageUrl?.endsWith('.mov') ? (
  <Video
    source={{ uri: memory.imageUrl }}
    useNativeControls
    resizeMode={ResizeMode.COVER}
    style={{ width: '100%', height: 200 }}
  />
) : (
  <Image source={{ uri: memory.imageUrl }} />
)}
```

### Step 6: Optimize Animations
```tsx
// src/app/create-memory.tsx
// REPLACE
entering={SlideInDown.duration(300).springify().damping(20)}

// WITH
entering={FadeIn.duration(250)}
```

## Files to Modify

1. ✅ `src/lib/themes.ts` - Created
2. ✅ `src/lib/settings-store.ts` - Updated
3. ✅ `src/lib/i18n.ts` - Created
4. ⏳ `src/app/settings.tsx` - Add pickers
5. ⏳ `src/app/(tabs)/index.tsx` - Remove button, add translations
6. ⏳ `src/app/(tabs)/_layout.tsx` - Add translations
7. ⏳ `src/app/profile.tsx` - Add translations
8. ⏳ `src/app/create-memory.tsx` - Optimize animation, add translations
9. ⏳ `src/components/MemoryCard.tsx` - Fix video playback
10. ⏳ All other screens - Apply theme colors

## Testing Checklist

- [ ] Change theme in settings → colors update everywhere
- [ ] Change language in settings → all text translates
- [ ] Video plays in feed after uploading
- [ ] Create animation is smooth (no lag)
- [ ] No duplicate profile button on home
- [ ] All settings persist after app restart

## Production Requirements Met

✅ Theme system - Expandable, persisted
✅ Localization - EN/RU, expandable
⏳ Video playback - Needs MemoryCard fix
⏳ Performance - Needs animation optimization
✅ iOS 26 SDK - Already configured
✅ Backend ready - API client exists

**Status: 60% Complete**
**Remaining: Apply changes listed above to complete 100%**
