-- Function to ban/unban users (admin only)
-- This function bypasses RLS and allows admins to ban any user
-- Run this in Supabase SQL Editor

CREATE OR REPLACE FUNCTION ban_user(
  target_user_id UUID,
  banned_status BOOLEAN,
  reason TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
  target_is_super_admin BOOLEAN;
BEGIN
  -- Check if current user is admin
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  -- If not admin, reject
  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can ban users';
  END IF;

  -- Check if target user is super admin
  SELECT is_super_admin INTO target_is_super_admin
  FROM profiles
  WHERE id = target_user_id;

  -- Cannot ban super admins
  IF target_is_super_admin THEN
    RAISE EXCEPTION 'Cannot ban super admin users';
  END IF;

  -- Update ban status
  UPDATE profiles
  SET
    is_banned = banned_status,
    ban_reason = CASE WHEN banned_status = TRUE THEN reason ELSE NULL END,
    banned_at = CASE WHEN banned_status = TRUE THEN NOW() ELSE NULL END,
    banned_by = CASE WHEN banned_status = TRUE THEN auth.uid() ELSE NULL END
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION ban_user TO authenticated;
