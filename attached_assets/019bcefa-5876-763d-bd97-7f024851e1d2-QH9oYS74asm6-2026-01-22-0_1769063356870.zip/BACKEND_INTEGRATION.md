# Backend Integration Guide

## Overview

The Memories app is architected with a clean separation between frontend and backend. The frontend uses:
- **React Query** for server state management
- **Zustand** for local UI state
- **AsyncStorage** for persistence

## Architecture

```
Frontend (React Native)
  ├── UI Components (src/components/)
  ├── Screens (src/app/)
  ├── State Management
  │   ├── Zustand (local state) - src/lib/store.ts
  │   ├── Settings Store - src/lib/settings-store.ts
  │   └── React Query (server state) - src/lib/hooks/use-api.ts
  └── API Client (src/lib/api.ts)
        ↓
Backend API (to be implemented)
  ├── Authentication (JWT tokens)
  ├── Memories CRUD
  ├── Media Upload (images)
  └── User Profile Sync
```

## API Endpoints

### Authentication

**POST /api/auth/register**
```json
{
  "username": "string",
  "visualKeyPattern": [1, 2, 5, 4, 7, 8, 9]
}
```

Response:
```json
{
  "success": true,
  "user": {
    "id": "uuid",
    "username": "string",
    "avatarEmoji": "🌿"
  },
  "token": "jwt_token"
}
```

**POST /api/auth/login**
Same as register

**POST /api/auth/logout**
Requires: Authorization header

---

### Memories

**GET /api/memories**
Query params: `limit`, `offset`, `saved`

Response:
```json
{
  "success": true,
  "memories": [
    {
      "id": "uuid",
      "text": "string",
      "emotion": "peaceful|grateful|nostalgic|hopeful|reflective|joyful",
      "createdAt": "ISO 8601",
      "imageUrl": "string?",
      "echoCount": 0,
      "isSaved": false
    }
  ],
  "total": 10
}
```

**POST /api/memories**
```json
{
  "text": "string",
  "emotion": "peaceful",
  "imageUrl": "string?",
  "locationText": "string?",
  "latitude": "number?",
  "longitude": "number?"
}
```

**PATCH /api/memories/:id/echo**
Increments echo count

**PATCH /api/memories/:id/save**
Toggles save status

**DELETE /api/memories/:id**
Deletes memory

---

### Media Upload

**POST /api/media/upload**
Content-Type: multipart/form-data
Body: file

Response:
```json
{
  "success": true,
  "url": "https://cdn.memories.app/uploads/..."
}
```

## Frontend Usage

### Using React Query Hooks

```tsx
import { useMemories, useCreateMemory } from '@/lib/hooks/use-api';

function MyComponent() {
  // Fetch memories
  const { data, isLoading, error } = useMemories();

  // Create memory
  const createMemory = useCreateMemory();

  const handleCreate = () => {
    createMemory.mutate({
      text: 'My memory',
      emotion: 'peaceful',
    });
  };
}
```

### Available Hooks

- `useMemories(params?)` - Fetch memories
- `useCreateMemory()` - Create new memory
- `useEchoMemory()` - Like a memory (optimistic update)
- `useToggleSaveMemory()` - Save/unsave (optimistic update)
- `useDeleteMemory()` - Delete memory
- `useUploadMedia()` - Upload image
- `useRegister()` - Register user
- `useLogin()` - Login user
- `useLogout()` - Logout user

## Backend Implementation Checklist

- [ ] Set up Node.js/Express or preferred backend
- [ ] Implement JWT authentication
- [ ] Create PostgreSQL/MongoDB database schema
- [ ] Implement CRUD endpoints for memories
- [ ] Set up S3/Cloudinary for image storage
- [ ] Implement media upload endpoint
- [ ] Add rate limiting and security headers
- [ ] Set up CORS for mobile app
- [ ] Implement user data sync
- [ ] Set up backup/restore system
- [ ] Deploy to production (Vercel, Railway, etc.)
- [ ] Configure environment variables in Vibecode ENV tab

## Environment Variables

Add these in the **ENV tab** of Vibecode:

```
API_BASE_URL=https://api.yourdomain.com/api
```

Or for local development, the app automatically uses `http://localhost:3000/api`.

## Data Sync Strategy

1. **On App Load**: Fetch all memories from backend
2. **On Create**: Optimistically add to UI, sync to backend
3. **On Echo/Save**: Optimistic update, sync in background
4. **On Delete**: Optimistic removal, sync to backend
5. **On Conflict**: Backend is source of truth

## Offline Support

- All mutations queue when offline
- React Query automatically retries failed requests
- AsyncStorage provides local cache
- Settings persist locally always

## Security Considerations

- Visual key pattern stored as hashed array on backend
- JWT tokens stored securely in AsyncStorage
- All API calls require authentication
- User data isolated per account
- Media uploads validated on backend
- Rate limiting on all endpoints

## Next Steps

1. Choose your backend stack (Node.js, Python, Go, etc.)
2. Set up database (PostgreSQL recommended)
3. Implement authentication flow
4. Create memories endpoints
5. Set up image storage (S3/Cloudinary)
6. Deploy backend
7. Update API_BASE_URL in Vibecode ENV tab
8. Test full integration

The frontend is production-ready and waiting for your backend!
