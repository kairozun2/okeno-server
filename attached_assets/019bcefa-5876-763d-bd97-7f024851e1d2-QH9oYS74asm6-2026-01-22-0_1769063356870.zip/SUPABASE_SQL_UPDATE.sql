-- ============================================================================
-- ОБНОВЛЕНИЕ СХЕМЫ SUPABASE ДЛЯ ГЕОЛОКАЦИИ И STORAGE
-- ============================================================================
-- Скопируйте весь этот код и вставьте в Supabase SQL Editor
-- Supabase Dashboard → SQL Editor → New Query → Вставить код → Run

-- Шаг 1: Добавить поля геолокации в таблицу memories
ALTER TABLE memories
ADD COLUMN IF NOT EXISTS location TEXT,
ADD COLUMN IF NOT EXISTS latitude DOUBLE PRECISION,
ADD COLUMN IF NOT EXISTS longitude DOUBLE PRECISION;

-- Шаг 2: Создать bucket для медиа (если еще не создан)
INSERT INTO storage.buckets (id, name, public)
VALUES ('memories', 'memories', true)
ON CONFLICT (id) DO NOTHING;

-- Шаг 3: Удалить старые политики если они существуют
DROP POLICY IF EXISTS "Users can upload their own media" ON storage.objects;
DROP POLICY IF EXISTS "Media is publicly accessible" ON storage.objects;
DROP POLICY IF EXISTS "Users can update their own media" ON storage.objects;
DROP POLICY IF EXISTS "Users can delete their own media" ON storage.objects;

-- Шаг 4: Создать новые политики для Storage
CREATE POLICY "Users can upload their own media"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'memories' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Media is publicly accessible"
ON storage.objects FOR SELECT
USING (bucket_id = 'memories');

CREATE POLICY "Users can update their own media"
ON storage.objects FOR UPDATE
USING (
  bucket_id = 'memories' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own media"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'memories' AND
  auth.uid()::text = (storage.foldername(name))[1]
);

-- ============================================================================
-- ГОТОВО! Теперь:
-- 1. Создание постов с геолокацией будет работать
-- 2. Загрузка изображений будет работать
-- 3. Геолокация будет отображаться в постах
-- ============================================================================
