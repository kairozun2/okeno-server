const pool = require('./database');

async function setupDatabase() {
  const client = await pool.connect();

  try {
    console.log('🗄️  Creating database tables...');

    // Users table
    await client.query(`
      CREATE TABLE IF NOT EXISTS users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_name VARCHAR(255) NOT NULL,
        user_id VARCHAR(255) UNIQUE NOT NULL,
        visual_key_hash TEXT NOT NULL,
        visual_key_pattern TEXT NOT NULL,
        avatar VARCHAR(10),
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);

    // Memories table
    await client.query(`
      CREATE TABLE IF NOT EXISTS memories (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        author_id UUID REFERENCES users(id) ON DELETE CASCADE,
        text TEXT,
        emotion VARCHAR(50),
        image_url TEXT,
        location TEXT,
        echo_count INT DEFAULT 0,
        comment_count INT DEFAULT 0,
        is_archived BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP DEFAULT NOW(),
        updated_at TIMESTAMP DEFAULT NOW()
      );
    `);

    // Echoes (likes) table
    await client.query(`
      CREATE TABLE IF NOT EXISTS echoes (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        memory_id UUID REFERENCES memories(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        created_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(memory_id, user_id)
      );
    `);

    // Saves table
    await client.query(`
      CREATE TABLE IF NOT EXISTS saves (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        memory_id UUID REFERENCES memories(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        created_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(memory_id, user_id)
      );
    `);

    // Comments table
    await client.query(`
      CREATE TABLE IF NOT EXISTS comments (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        memory_id UUID REFERENCES memories(id) ON DELETE CASCADE,
        author_id UUID REFERENCES users(id) ON DELETE CASCADE,
        text TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT NOW()
      );
    `);

    // Follows table
    await client.query(`
      CREATE TABLE IF NOT EXISTS follows (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        follower_id UUID REFERENCES users(id) ON DELETE CASCADE,
        following_id UUID REFERENCES users(id) ON DELETE CASCADE,
        created_at TIMESTAMP DEFAULT NOW(),
        UNIQUE(follower_id, following_id)
      );
    `);

    // Create indexes
    await client.query('CREATE INDEX IF NOT EXISTS idx_memories_author ON memories(author_id);');
    await client.query('CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at DESC);');
    await client.query('CREATE INDEX IF NOT EXISTS idx_echoes_memory ON echoes(memory_id);');
    await client.query('CREATE INDEX IF NOT EXISTS idx_echoes_user ON echoes(user_id);');
    await client.query('CREATE INDEX IF NOT EXISTS idx_comments_memory ON comments(memory_id);');
    await client.query('CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows(follower_id);');

    console.log('✅ Database tables created successfully!');
  } catch (err) {
    console.error('❌ Error creating tables:', err);
    throw err;
  } finally {
    client.release();
  }
}

if (require.main === module) {
  setupDatabase()
    .then(() => {
      console.log('✨ Database setup complete!');
      process.exit(0);
    })
    .catch((err) => {
      console.error('Failed to setup database:', err);
      process.exit(1);
    });
}

module.exports = setupDatabase;
