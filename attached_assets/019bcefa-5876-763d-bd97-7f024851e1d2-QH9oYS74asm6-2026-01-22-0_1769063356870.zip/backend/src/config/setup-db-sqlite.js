const db = require('./database-sqlite');

function setupDatabase() {
  try {
    console.log('🗄️  Creating database tables...');

    // Users table
    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        user_name TEXT NOT NULL,
        user_id TEXT UNIQUE NOT NULL,
        visual_key_hash TEXT NOT NULL,
        visual_key_pattern TEXT NOT NULL,
        avatar TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Memories table
    db.exec(`
      CREATE TABLE IF NOT EXISTS memories (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        author_id TEXT NOT NULL,
        text TEXT,
        emotion TEXT,
        image_url TEXT,
        location TEXT,
        echo_count INTEGER DEFAULT 0,
        comment_count INTEGER DEFAULT 0,
        is_archived INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `);

    // Echoes (likes) table
    db.exec(`
      CREATE TABLE IF NOT EXISTS echoes (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        memory_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE(memory_id, user_id)
      );
    `);

    // Saves table
    db.exec(`
      CREATE TABLE IF NOT EXISTS saves (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        memory_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE(memory_id, user_id)
      );
    `);

    // Comments table
    db.exec(`
      CREATE TABLE IF NOT EXISTS comments (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        memory_id TEXT NOT NULL,
        author_id TEXT NOT NULL,
        text TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE,
        FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
      );
    `);

    // Follows table
    db.exec(`
      CREATE TABLE IF NOT EXISTS follows (
        id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
        follower_id TEXT NOT NULL,
        following_id TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
        FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE,
        UNIQUE(follower_id, following_id)
      );
    `);

    // Create indexes
    db.exec(`
      CREATE INDEX IF NOT EXISTS idx_memories_author ON memories(author_id);
      CREATE INDEX IF NOT EXISTS idx_memories_created ON memories(created_at DESC);
      CREATE INDEX IF NOT EXISTS idx_echoes_memory ON echoes(memory_id);
      CREATE INDEX IF NOT EXISTS idx_echoes_user ON echoes(user_id);
      CREATE INDEX IF NOT EXISTS idx_comments_memory ON comments(memory_id);
      CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows(follower_id);
    `);

    console.log('✅ Database tables created successfully!');
    return true;
  } catch (err) {
    console.error('❌ Error creating tables:', err);
    throw err;
  }
}

if (require.main === module) {
  try {
    setupDatabase();
    console.log('✨ Database setup complete!');
    process.exit(0);
  } catch (err) {
    console.error('Failed to setup database:', err);
    process.exit(1);
  }
}

module.exports = setupDatabase;
