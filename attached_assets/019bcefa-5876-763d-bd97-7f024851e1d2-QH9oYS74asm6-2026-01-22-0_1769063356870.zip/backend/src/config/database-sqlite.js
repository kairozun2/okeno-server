const Database = require('better-sqlite3');
const path = require('path');
const { fileURLToPath } = require('url');

// Create database file in backend directory
const dbPath = path.join(process.cwd(), 'memories.db');
const db = new Database(dbPath, { verbose: console.log });

// Enable foreign keys
db.pragma('foreign_keys = ON');

console.log('✅ SQLite database connected:', dbPath);

module.exports = db;
