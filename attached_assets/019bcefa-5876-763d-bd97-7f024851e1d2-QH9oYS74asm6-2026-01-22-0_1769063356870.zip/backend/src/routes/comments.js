const express = require('express');
const db = require('../config/database-sqlite');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

// Get comments for a memory
router.get('/:memoryId', authMiddleware, async (req, res) => {
  const { memoryId } = req.params;

  try {
    const stmt = db.prepare(`
      SELECT c.*, u.user_name, u.avatar, u.user_id
      FROM comments c
      JOIN users u ON c.author_id = u.id
      WHERE c.memory_id = ?
      ORDER BY c.created_at DESC
    `);

    const rows = stmt.all(memoryId);

    const comments = rows.map(row => ({
      id: row.id,
      memoryId: row.memory_id,
      authorId: row.author_id,
      text: row.text,
      createdAt: row.created_at,
      userName: row.user_name,
      userAvatar: row.avatar,
      userId: row.user_id,
    }));

    res.json(comments);
  } catch (err) {
    console.error('Get comments error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create comment
router.post('/:memoryId', authMiddleware, async (req, res) => {
  const { memoryId } = req.params;
  const { text } = req.body;

  if (!text || text.trim().length === 0) {
    return res.status(400).json({ error: 'Comment text is required' });
  }

  try {
    // Create comment
    const insert = db.prepare('INSERT INTO comments (memory_id, author_id, text) VALUES (?, ?, ?)');
    const result = insert.run(memoryId, req.userId, text);

    // Increment comment count
    db.prepare('UPDATE memories SET comment_count = comment_count + 1 WHERE id = ?').run(memoryId);

    // Get created comment
    const comment = db.prepare('SELECT * FROM comments WHERE rowid = ?').get(result.lastInsertRowid);

    // Get user info
    const user = db.prepare('SELECT user_name, avatar, user_id FROM users WHERE id = ?').get(req.userId);

    res.json({
      id: comment.id,
      memoryId: comment.memory_id,
      authorId: comment.author_id,
      text: comment.text,
      createdAt: comment.created_at,
      userName: user.user_name,
      userAvatar: user.avatar,
      userId: user.user_id,
    });
  } catch (err) {
    console.error('Create comment error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete comment
router.delete('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;

  try {
    // Check ownership
    const comment = db.prepare('SELECT author_id, memory_id FROM comments WHERE id = ?').get(id);
    if (!comment) {
      return res.status(404).json({ error: 'Comment not found' });
    }
    if (comment.author_id !== req.userId) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const memoryId = comment.memory_id;

    // Delete comment
    db.prepare('DELETE FROM comments WHERE id = ?').run(id);

    // Decrement comment count
    db.prepare('UPDATE memories SET comment_count = comment_count - 1 WHERE id = ?').run(memoryId);

    res.json({ success: true });
  } catch (err) {
    console.error('Delete comment error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
