const express = require('express');
const db = require('../config/database-sqlite');
const authMiddleware = require('../middleware/auth');

const router = express.Router();

// Get all memories (with filter for current user)
router.get('/', authMiddleware, async (req, res) => {
  const { page = 1, limit = 20 } = req.query;
  const offset = (page - 1) * limit;

  try {
    const stmt = db.prepare(`
      SELECT m.*, u.user_name, u.avatar, u.user_id,
        (SELECT COUNT(*) FROM echoes WHERE memory_id = m.id AND user_id = ?) as is_echoed,
        (SELECT COUNT(*) FROM saves WHERE memory_id = m.id AND user_id = ?) as is_saved
      FROM memories m
      JOIN users u ON m.author_id = u.id
      WHERE m.is_archived = 0
      ORDER BY m.created_at DESC
      LIMIT ? OFFSET ?
    `);

    const rows = stmt.all(req.userId, req.userId, limit, offset);

    const memories = rows.map(row => ({
      id: row.id,
      authorId: row.author_id,
      text: row.text,
      emotion: row.emotion,
      imageUrl: row.image_url,
      location: row.location,
      echoCount: parseInt(row.echo_count),
      commentCount: parseInt(row.comment_count),
      isEchoed: row.is_echoed > 0,
      isSaved: row.is_saved > 0,
      isArchived: row.is_archived === 1,
      createdAt: row.created_at,
      userName: row.user_name,
      userAvatar: row.avatar,
      userId: row.user_id,
    }));

    res.json(memories);
  } catch (err) {
    console.error('Get memories error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Create memory
router.post('/', authMiddleware, async (req, res) => {
  const { text, emotion, imageUrl, location } = req.body;

  try {
    const insert = db.prepare(
      `INSERT INTO memories (author_id, text, emotion, image_url, location)
       VALUES (?, ?, ?, ?, ?)`
    );

    const result = insert.run(req.userId, text, emotion, imageUrl, location);

    // Get created memory
    const memory = db.prepare('SELECT * FROM memories WHERE rowid = ?').get(result.lastInsertRowid);

    // Get user info
    const user = db.prepare('SELECT user_name, avatar, user_id FROM users WHERE id = ?').get(req.userId);

    res.json({
      id: memory.id,
      authorId: memory.author_id,
      text: memory.text,
      emotion: memory.emotion,
      imageUrl: memory.image_url,
      location: memory.location,
      echoCount: 0,
      commentCount: 0,
      isEchoed: false,
      isSaved: false,
      isArchived: false,
      createdAt: memory.created_at,
      userName: user.user_name,
      userAvatar: user.avatar,
      userId: user.user_id,
    });
  } catch (err) {
    console.error('Create memory error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Update memory
router.patch('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;
  const { text, emotion } = req.body;

  try {
    // Check ownership
    const memory = db.prepare('SELECT author_id FROM memories WHERE id = ?').get(id);
    if (!memory) {
      return res.status(404).json({ error: 'Memory not found' });
    }
    if (memory.author_id !== req.userId) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    // Update
    db.prepare(
      `UPDATE memories SET text = ?, emotion = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).run(text, emotion, id);

    const updated = db.prepare('SELECT * FROM memories WHERE id = ?').get(id);
    res.json(updated);
  } catch (err) {
    console.error('Update memory error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Delete memory
router.delete('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;

  try {
    // Check ownership
    const memory = db.prepare('SELECT author_id FROM memories WHERE id = ?').get(id);
    if (!memory) {
      return res.status(404).json({ error: 'Memory not found' });
    }
    if (memory.author_id !== req.userId) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    db.prepare('DELETE FROM memories WHERE id = ?').run(id);
    res.json({ success: true });
  } catch (err) {
    console.error('Delete memory error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Toggle echo (like)
router.post('/:id/echo', authMiddleware, async (req, res) => {
  const { id } = req.params;

  try {
    // Check if already echoed
    const existing = db.prepare(
      'SELECT id FROM echoes WHERE memory_id = ? AND user_id = ?'
    ).get(id, req.userId);

    if (existing) {
      // Remove echo
      db.prepare('DELETE FROM echoes WHERE memory_id = ? AND user_id = ?').run(id, req.userId);
      db.prepare('UPDATE memories SET echo_count = echo_count - 1 WHERE id = ?').run(id);
    } else {
      // Add echo
      db.prepare('INSERT INTO echoes (memory_id, user_id) VALUES (?, ?)').run(id, req.userId);
      db.prepare('UPDATE memories SET echo_count = echo_count + 1 WHERE id = ?').run(id);
    }

    // Get updated count
    const memory = db.prepare('SELECT echo_count FROM memories WHERE id = ?').get(id);
    res.json({ echoCount: parseInt(memory.echo_count), isEchoed: !existing });
  } catch (err) {
    console.error('Echo error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Toggle save
router.post('/:id/save', authMiddleware, async (req, res) => {
  const { id } = req.params;

  try {
    const existing = db.prepare(
      'SELECT id FROM saves WHERE memory_id = ? AND user_id = ?'
    ).get(id, req.userId);

    if (existing) {
      db.prepare('DELETE FROM saves WHERE memory_id = ? AND user_id = ?').run(id, req.userId);
      res.json({ isSaved: false });
    } else {
      db.prepare('INSERT INTO saves (memory_id, user_id) VALUES (?, ?)').run(id, req.userId);
      res.json({ isSaved: true });
    }
  } catch (err) {
    console.error('Save error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Toggle archive
router.post('/:id/archive', authMiddleware, async (req, res) => {
  const { id } = req.params;

  try {
    // Check ownership
    const memory = db.prepare('SELECT author_id, is_archived FROM memories WHERE id = ?').get(id);
    if (!memory) {
      return res.status(404).json({ error: 'Memory not found' });
    }
    if (memory.author_id !== req.userId) {
      return res.status(403).json({ error: 'Not authorized' });
    }

    const newState = memory.is_archived === 1 ? 0 : 1;
    db.prepare('UPDATE memories SET is_archived = ? WHERE id = ?').run(newState, id);

    res.json({ isArchived: newState === 1 });
  } catch (err) {
    console.error('Archive error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
