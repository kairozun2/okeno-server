const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../config/database-sqlite');

const router = express.Router();

// Generate avatar from pattern (same logic as frontend)
function generateAvatar(pattern) {
  const emojis = ['🌸', '🎨', '🌊', '🔥', '⚡', '🌙', '☀️', '🍀', '💫'];
  const sum = pattern.reduce((a, b) => a + b, 0);
  return emojis[sum % emojis.length];
}

// Register
router.post('/register', async (req, res) => {
  const { userName, visualKeyPattern } = req.body;

  if (!userName || !visualKeyPattern || visualKeyPattern.length < 4) {
    return res.status(400).json({ error: 'Invalid input' });
  }

  try {
    // Hash the pattern
    const patternString = visualKeyPattern.join(',');
    const hash = await bcrypt.hash(patternString, 12);

    // Generate unique user ID
    const userId = `memories_user_${patternString.replace(/,/g, '')}`;
    const avatar = generateAvatar(visualKeyPattern);

    // Check if user exists
    const existing = db.prepare('SELECT id FROM users WHERE user_id = ?').get(userId);
    if (existing) {
      return res.status(400).json({ error: 'User already exists' });
    }

    // Create user
    const insert = db.prepare(
      `INSERT INTO users (user_name, user_id, visual_key_hash, visual_key_pattern, avatar)
       VALUES (?, ?, ?, ?, ?)`
    );

    const result = insert.run(userName, userId, hash, patternString, avatar);

    // Get the created user
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(result.lastInsertRowid);

    // Generate JWT
    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' });

    res.json({
      user: {
        id: user.id,
        userName: user.user_name,
        userId: user.user_id,
        avatar: user.avatar,
      },
      token,
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Login
router.post('/login', async (req, res) => {
  const { userId, visualKeyPattern } = req.body;

  if (!userId || !visualKeyPattern) {
    return res.status(400).json({ error: 'Invalid input' });
  }

  try {
    // Get user
    const user = db.prepare('SELECT * FROM users WHERE user_id = ?').get(userId);

    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const patternString = visualKeyPattern.join(',');

    // Verify pattern
    const match = await bcrypt.compare(patternString, user.visual_key_hash);

    if (!match) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    // Generate JWT
    const token = jwt.sign({ userId: user.id }, process.env.JWT_SECRET, { expiresIn: '30d' });

    res.json({
      user: {
        id: user.id,
        userName: user.user_name,
        userId: user.user_id,
        avatar: user.avatar,
      },
      token,
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
