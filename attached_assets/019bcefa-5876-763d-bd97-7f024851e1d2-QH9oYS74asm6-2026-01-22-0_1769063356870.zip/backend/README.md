# Memories Backend Server

Полный backend для приложения Memories с REST API, PostgreSQL и загрузкой файлов.

## 🚀 Быстрый старт

### 1. Установить PostgreSQL

**macOS:**
```bash
brew install postgresql
brew services start postgresql
```

**Ubuntu/Linux:**
```bash
sudo apt-get install postgresql postgresql-contrib
sudo systemctl start postgresql
```

**Windows:**
Скачать с https://www.postgresql.org/download/windows/

### 2. Создать базу данных

```bash
# Войти в PostgreSQL
psql postgres

# Создать базу данных
CREATE DATABASE memories;

# Создать пользователя (опционально)
CREATE USER memories_user WITH PASSWORD 'your_password';
GRANT ALL PRIVILEGES ON DATABASE memories TO memories_user;

# Выйти
\q
```

### 3. Установить зависимости

```bash
cd backend
npm install
```

### 4. Настроить .env файл

```bash
cp .env.example .env
```

Отредактировать `.env`:
```env
PORT=3000
NODE_ENV=development

# PostgreSQL
DB_HOST=localhost
DB_PORT=5432
DB_NAME=memories
DB_USER=postgres
DB_PASSWORD=your_password

# JWT
JWT_SECRET=your-super-secret-key-change-in-production

# CORS (добавить IP компьютера для Expo)
ALLOWED_ORIGINS=http://localhost:8081,exp://192.168.1.100:8081
```

### 5. Создать таблицы в базе

```bash
npm run db:setup
```

### 6. Запустить сервер

```bash
npm run dev
```

Сервер запустится на http://localhost:3000

## 📡 API Endpoints

### Авторизация

```
POST /api/auth/register
POST /api/auth/login
```

### Воспоминания

```
GET    /api/memories          - Получить все воспоминания
POST   /api/memories          - Создать воспоминание
PATCH  /api/memories/:id      - Обновить воспоминание
DELETE /api/memories/:id      - Удалить воспоминание
POST   /api/memories/:id/echo - Лайк/анлайк
POST   /api/memories/:id/save - Сохранить/убрать
POST   /api/memories/:id/archive - Архивировать/разархивировать
```

### Комментарии

```
GET    /api/comments/:memoryId - Получить комментарии
POST   /api/comments/:memoryId - Создать комментарий
DELETE /api/comments/:id       - Удалить комментарий
```

### Загрузка файлов

```
POST /api/media/upload - Загрузить фото/видео
```

## 🔧 Подключение к frontend

В файле `/src/lib/api-client.ts` изменить:

```typescript
const API_BASE_URL = 'http://YOUR_COMPUTER_IP:3000/api';
```

Чтобы узнать IP компьютера:

**macOS/Linux:**
```bash
ifconfig | grep "inet " | grep -v 127.0.0.1
```

**Windows:**
```bash
ipconfig
```

Пример: `http://192.168.1.100:3000/api`

## 📁 Структура

```
backend/
├── src/
│   ├── config/
│   │   ├── database.js    - Подключение к PostgreSQL
│   │   └── setup-db.js    - Создание таблиц
│   ├── middleware/
│   │   └── auth.js        - JWT авторизация
│   ├── routes/
│   │   ├── auth.js        - Регистрация/логин
│   │   ├── memories.js    - CRUD воспоминаний
│   │   ├── comments.js    - Комментарии
│   │   └── upload.js      - Загрузка файлов
│   └── index.js           - Главный файл сервера
├── uploads/               - Загруженные файлы
├── .env                   - Конфигурация
└── package.json
```

## 🗄️ База данных

Таблицы:
- `users` - Пользователи
- `memories` - Воспоминания
- `echoes` - Лайки
- `saves` - Сохраненные
- `comments` - Комментарии
- `follows` - Подписки

## ✅ Готово!

Backend готов к работе. Теперь запустите frontend приложение и всё будет синхронизироваться!
