-- Supabase Database Schema for Memories Social Network App
-- Copy and paste this entire file into Supabase SQL Editor

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles table (user accounts)
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  avatar_emoji TEXT NOT NULL,
  visual_key_hash TEXT NOT NULL, -- bcrypt hash of visual pattern
  is_verified BOOLEAN DEFAULT FALSE,
  is_admin BOOLEAN DEFAULT FALSE,
  is_super_admin BOOLEAN DEFAULT FALSE, -- Super admin cannot be banned or demoted
  is_banned BOOLEAN DEFAULT FALSE, -- Banned users cannot access the app
  banned_at TIMESTAMPTZ,
  banned_by UUID REFERENCES profiles(id),
  ban_reason TEXT,
  username_color TEXT, -- Hex color for username display (premium feature)
  username_last_changed TIMESTAMPTZ, -- Last time username was changed (15-day cooldown)
  color_last_changed TIMESTAMPTZ, -- Last time username color was changed (15-day cooldown)
  social_links JSONB DEFAULT '[]'::jsonb, -- Array of social media links
  is_private BOOLEAN DEFAULT FALSE, -- Private/closed profile (only followers can see posts)
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Memories table (posts)
CREATE TABLE IF NOT EXISTS memories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  emotion TEXT NOT NULL CHECK (emotion IN ('peaceful', 'grateful', 'nostalgic', 'hopeful', 'reflective', 'joyful')),
  image_url TEXT,
  video_url TEXT,
  location TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  echo_count INTEGER DEFAULT 0,
  is_archived BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Echoes table (likes)
CREATE TABLE IF NOT EXISTS echoes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  memory_id UUID NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, memory_id) -- One echo per user per memory
);

-- Saves table (bookmarks)
CREATE TABLE IF NOT EXISTS saves (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  memory_id UUID NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, memory_id) -- One save per user per memory
);

-- Comments table
CREATE TABLE IF NOT EXISTS comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  memory_id UUID NOT NULL REFERENCES memories(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, -- who receives the notification
  type TEXT NOT NULL CHECK (type IN ('like', 'comment', 'follow')),
  from_user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE, -- who triggered the notification
  memory_id UUID REFERENCES memories(id) ON DELETE CASCADE,
  comment_text TEXT,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Follows table (user relationships)
CREATE TABLE IF NOT EXISTS follows (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  follower_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id != following_id) -- Can't follow yourself
);

-- Hidden users table
CREATE TABLE IF NOT EXISTS hidden_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  hidden_user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, hidden_user_id)
);

-- Conversations table (chat threads between users)
CREATE TABLE IF NOT EXISTS conversations (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user1_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  user2_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  last_message_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user1_id, user2_id),
  CHECK (user1_id != user2_id)
);

-- Messages table (individual chat messages)
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX IF NOT EXISTS idx_memories_user_id ON memories(user_id);
CREATE INDEX IF NOT EXISTS idx_memories_created_at ON memories(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_echoes_memory_id ON echoes(memory_id);
CREATE INDEX IF NOT EXISTS idx_echoes_user_id ON echoes(user_id);
CREATE INDEX IF NOT EXISTS idx_saves_user_id ON saves(user_id);
CREATE INDEX IF NOT EXISTS idx_saves_memory_id ON saves(memory_id);
CREATE INDEX IF NOT EXISTS idx_comments_memory_id ON comments(memory_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_follows_follower_id ON follows(follower_id);
CREATE INDEX IF NOT EXISTS idx_follows_following_id ON follows(following_id);
CREATE INDEX IF NOT EXISTS idx_hidden_users_user_id ON hidden_users(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user1_id ON conversations(user1_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user2_id ON conversations(user2_id);
CREATE INDEX IF NOT EXISTS idx_conversations_last_message_at ON conversations(last_message_at DESC);
CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at DESC);

-- Row Level Security (RLS) Policies

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE memories ENABLE ROW LEVEL SECURITY;
ALTER TABLE echoes ENABLE ROW LEVEL SECURITY;
ALTER TABLE saves ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE hidden_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can read all profiles, but only update their own
CREATE POLICY "Public profiles are viewable by everyone" ON profiles FOR SELECT USING (true);
CREATE POLICY "Users can insert their own profile" ON profiles FOR INSERT WITH CHECK (auth.uid() = id);
CREATE POLICY "Users can update their own profile" ON profiles FOR UPDATE USING (auth.uid() = id);

-- Memories: Public feed (users can see all non-archived memories from non-hidden users)
CREATE POLICY "Memories are viewable by everyone" ON memories FOR SELECT USING (
  NOT is_archived OR user_id = auth.uid()
);
CREATE POLICY "Users can insert their own memories" ON memories FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own memories" ON memories FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own memories" ON memories FOR DELETE USING (auth.uid() = user_id);

-- Echoes: Users can see all echoes and manage their own
CREATE POLICY "Echoes are viewable by everyone" ON echoes FOR SELECT USING (true);
CREATE POLICY "Users can insert their own echoes" ON echoes FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete their own echoes" ON echoes FOR DELETE USING (auth.uid() = user_id);

-- Saves: Users can only see and manage their own saves
CREATE POLICY "Users can view their own saves" ON saves FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert their own saves" ON saves FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete their own saves" ON saves FOR DELETE USING (auth.uid() = user_id);

-- Comments: Public (users can see all comments)
CREATE POLICY "Comments are viewable by everyone" ON comments FOR SELECT USING (true);
CREATE POLICY "Users can insert their own comments" ON comments FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can update their own comments" ON comments FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can delete their own comments" ON comments FOR DELETE USING (auth.uid() = user_id);

-- Notifications: Users can only see their own notifications
CREATE POLICY "Users can view their own notifications" ON notifications FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can update their own notifications" ON notifications FOR UPDATE USING (auth.uid() = user_id);
CREATE POLICY "Users can insert notifications" ON notifications FOR INSERT WITH CHECK (true);

-- Follows: Users can see all follows and manage their own
CREATE POLICY "Follows are viewable by everyone" ON follows FOR SELECT USING (true);
CREATE POLICY "Users can insert their own follows" ON follows FOR INSERT WITH CHECK (auth.uid() = follower_id);
CREATE POLICY "Users can delete their own follows" ON follows FOR DELETE USING (auth.uid() = follower_id);

-- Hidden users: Users can only see and manage their own hidden list
CREATE POLICY "Users can view their own hidden list" ON hidden_users FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "Users can insert to their hidden list" ON hidden_users FOR INSERT WITH CHECK (auth.uid() = user_id);
CREATE POLICY "Users can delete from their hidden list" ON hidden_users FOR DELETE USING (auth.uid() = user_id);

-- Conversations: Users can only see conversations they're part of
CREATE POLICY "Users can view their own conversations" ON conversations FOR SELECT USING (
  auth.uid() = user1_id OR auth.uid() = user2_id
);
CREATE POLICY "Users can create conversations" ON conversations FOR INSERT WITH CHECK (
  auth.uid() = user1_id OR auth.uid() = user2_id
);

-- Messages: Users can only see messages from conversations they're in
CREATE POLICY "Users can view messages from their conversations" ON messages FOR SELECT USING (
  EXISTS (
    SELECT 1 FROM conversations
    WHERE conversations.id = messages.conversation_id
    AND (conversations.user1_id = auth.uid() OR conversations.user2_id = auth.uid())
  )
);
CREATE POLICY "Users can insert messages in their conversations" ON messages FOR INSERT WITH CHECK (
  auth.uid() = sender_id AND
  EXISTS (
    SELECT 1 FROM conversations
    WHERE conversations.id = messages.conversation_id
    AND (conversations.user1_id = auth.uid() OR conversations.user2_id = auth.uid())
  )
);
CREATE POLICY "Users can update messages they received" ON messages FOR UPDATE USING (
  EXISTS (
    SELECT 1 FROM conversations
    WHERE conversations.id = messages.conversation_id
    AND (conversations.user1_id = auth.uid() OR conversations.user2_id = auth.uid())
  )
);

-- Functions for updating echo counts
CREATE OR REPLACE FUNCTION update_echo_count()
RETURNS TRIGGER AS $$
BEGIN
  IF (TG_OP = 'INSERT') THEN
    UPDATE memories SET echo_count = echo_count + 1 WHERE id = NEW.memory_id;
  ELSIF (TG_OP = 'DELETE') THEN
    UPDATE memories SET echo_count = echo_count - 1 WHERE id = OLD.memory_id;
  END IF;
  RETURN NULL;
END;
$$ LANGUAGE plpgsql;

-- Trigger for echo count
CREATE TRIGGER update_memory_echo_count
AFTER INSERT OR DELETE ON echoes
FOR EACH ROW EXECUTE FUNCTION update_echo_count();

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers for updated_at
CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON profiles FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_memories_updated_at BEFORE UPDATE ON memories FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_comments_updated_at BEFORE UPDATE ON comments FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Function to update conversation's last_message_at
CREATE OR REPLACE FUNCTION update_conversation_last_message()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE conversations SET last_message_at = NOW() WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for conversation last_message_at
CREATE TRIGGER update_conversation_last_message_trigger
AFTER INSERT ON messages
FOR EACH ROW EXECUTE FUNCTION update_conversation_last_message();

-- ============================================================================
-- STORAGE BUCKET & POLICIES
-- ============================================================================

-- Storage bucket for media
-- Run this in Supabase Dashboard > Storage > Create New Bucket
-- Name: memories
-- Public: true
-- OR run this SQL:
INSERT INTO storage.buckets (id, name, public) VALUES ('memories', 'memories', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for media
CREATE POLICY "Users can upload their own media" ON storage.objects FOR INSERT WITH CHECK (
  bucket_id = 'memories' AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Media is publicly accessible" ON storage.objects FOR SELECT USING (bucket_id = 'memories');

CREATE POLICY "Users can update their own media" ON storage.objects FOR UPDATE USING (
  bucket_id = 'memories' AND auth.uid()::text = (storage.foldername(name))[1]
);

CREATE POLICY "Users can delete their own media" ON storage.objects FOR DELETE USING (
  bucket_id = 'memories' AND auth.uid()::text = (storage.foldername(name))[1]
);

-- ============================================================================
-- ADMIN & VERIFICATION FUNCTIONS
-- ============================================================================

-- Set initial admin user
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM profiles WHERE id = '6172b2d4-284c-4f08-84bb-5b415fdb6c59') THEN
    UPDATE profiles
    SET is_admin = TRUE, is_verified = TRUE
    WHERE id = '6172b2d4-284c-4f08-84bb-5b415fdb6c59';
  END IF;
END $$;

-- Function to verify/unverify users (admin only)
CREATE OR REPLACE FUNCTION verify_user(target_user_id UUID, verified_status BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
BEGIN
  -- Check if current user is admin
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  -- If not admin, reject
  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can verify users';
  END IF;

  -- Update verification status
  UPDATE profiles
  SET is_verified = verified_status
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Function to make/remove admin (admin only)
CREATE OR REPLACE FUNCTION set_admin(target_user_id UUID, admin_status BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
BEGIN
  -- Check if current user is admin
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  -- If not admin, reject
  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can manage admin status';
  END IF;

  -- Update admin status (auto-verify when making admin)
  UPDATE profiles
  SET is_admin = admin_status,
      is_verified = CASE WHEN admin_status = TRUE THEN TRUE ELSE is_verified END
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION verify_user TO authenticated;
GRANT EXECUTE ON FUNCTION set_admin TO authenticated;

-- Function to ban/unban users (admin only)
CREATE OR REPLACE FUNCTION ban_user(
  target_user_id UUID,
  banned_status BOOLEAN,
  reason TEXT DEFAULT NULL
)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
  target_is_super_admin BOOLEAN;
BEGIN
  -- Check if current user is admin
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  -- If not admin, reject
  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can ban users';
  END IF;

  -- Check if target user is super admin
  SELECT is_super_admin INTO target_is_super_admin
  FROM profiles
  WHERE id = target_user_id;

  -- Cannot ban super admins
  IF target_is_super_admin THEN
    RAISE EXCEPTION 'Cannot ban super admin users';
  END IF;

  -- Update ban status
  UPDATE profiles
  SET
    is_banned = banned_status,
    ban_reason = CASE WHEN banned_status = TRUE THEN reason ELSE NULL END,
    banned_at = CASE WHEN banned_status = TRUE THEN NOW() ELSE NULL END,
    banned_by = CASE WHEN banned_status = TRUE THEN auth.uid() ELSE NULL END
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Grant execute permissions
GRANT EXECUTE ON FUNCTION ban_user TO authenticated;

-- ========================================
-- REALTIME CONFIGURATION
-- Enable Realtime for all tables
-- ========================================

-- Enable Realtime for memories table (posts)
ALTER PUBLICATION supabase_realtime ADD TABLE memories;

-- Enable Realtime for messages table (chat messages)
ALTER PUBLICATION supabase_realtime ADD TABLE messages;

-- Enable Realtime for conversations table (chat list)
ALTER PUBLICATION supabase_realtime ADD TABLE conversations;

-- Enable Realtime for echoes table (likes)
ALTER PUBLICATION supabase_realtime ADD TABLE echoes;

-- Enable Realtime for saves table (bookmarks)
ALTER PUBLICATION supabase_realtime ADD TABLE saves;

-- Enable Realtime for comments table
ALTER PUBLICATION supabase_realtime ADD TABLE comments;

-- Enable Realtime for notifications table
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;

-- Enable Realtime for follows table
ALTER PUBLICATION supabase_realtime ADD TABLE follows;

-- Enable Realtime for profiles table
ALTER PUBLICATION supabase_realtime ADD TABLE profiles;

-- Enable Realtime for all tables
-- This allows real-time subscriptions to work properly
ALTER PUBLICATION supabase_realtime ADD TABLE memories;
ALTER PUBLICATION supabase_realtime ADD TABLE echoes;
ALTER PUBLICATION supabase_realtime ADD TABLE saves;
ALTER PUBLICATION supabase_realtime ADD TABLE comments;
ALTER PUBLICATION supabase_realtime ADD TABLE notifications;
ALTER PUBLICATION supabase_realtime ADD TABLE follows;
ALTER PUBLICATION supabase_realtime ADD TABLE conversations;
ALTER PUBLICATION supabase_realtime ADD TABLE messages;
ALTER PUBLICATION supabase_realtime ADD TABLE profiles;
