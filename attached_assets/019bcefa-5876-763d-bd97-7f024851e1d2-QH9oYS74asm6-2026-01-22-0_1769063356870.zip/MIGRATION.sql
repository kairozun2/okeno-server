-- ============================================================================
-- МИГРАЦИЯ: Система администрирования с супер-админом и баном
-- ============================================================================
-- Скопируйте этот код и запустите в Supabase SQL Editor
-- ============================================================================

-- 1. Добавить новые колонки в таблицу profiles
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS is_super_admin BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS is_banned BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS banned_at TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS banned_by UUID REFERENCES profiles(id),
ADD COLUMN IF NOT EXISTS ban_reason TEXT;

-- 2. Назначить главного администратора (SUPER ADMIN)
-- Этот пользователь не может быть забанен или удален из админов
UPDATE profiles
SET
  is_super_admin = TRUE,
  is_admin = TRUE,
  is_verified = TRUE
WHERE id = '6172b2d4-284c-4f08-84bb-5b415fdb6c59';

-- ============================================================================
-- ФУНКЦИИ ДЛЯ АДМИНОВ
-- ============================================================================

-- Функция: Верификация пользователей
CREATE OR REPLACE FUNCTION verify_user(target_user_id UUID, verified_status BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
  target_is_banned BOOLEAN;
BEGIN
  -- Проверка: текущий пользователь админ?
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can verify users';
  END IF;

  -- Проверка: целевой пользователь не забанен?
  SELECT is_banned INTO target_is_banned
  FROM profiles
  WHERE id = target_user_id;

  IF target_is_banned THEN
    RAISE EXCEPTION 'Cannot verify a banned user';
  END IF;

  -- Обновить статус верификации
  UPDATE profiles
  SET is_verified = verified_status
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Функция: Назначение младших администраторов
CREATE OR REPLACE FUNCTION set_admin(target_user_id UUID, admin_status BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
  target_is_super_admin BOOLEAN;
  target_is_banned BOOLEAN;
BEGIN
  -- Проверка: текущий пользователь админ?
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can manage admin status';
  END IF;

  -- Проверка: целевой пользователь супер-админ?
  SELECT is_super_admin INTO target_is_super_admin
  FROM profiles
  WHERE id = target_user_id;

  IF target_is_super_admin AND admin_status = FALSE THEN
    RAISE EXCEPTION 'Cannot remove super admin privileges';
  END IF;

  -- Проверка: целевой пользователь не забанен?
  SELECT is_banned INTO target_is_banned
  FROM profiles
  WHERE id = target_user_id;

  IF target_is_banned THEN
    RAISE EXCEPTION 'Cannot grant admin rights to a banned user';
  END IF;

  -- Обновить статус админа
  -- Если делаем админом, автоматически верифицируем
  UPDATE profiles
  SET
    is_admin = admin_status,
    is_verified = CASE WHEN admin_status = TRUE THEN TRUE ELSE is_verified END
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Функция: Бан пользователей
CREATE OR REPLACE FUNCTION ban_user(target_user_id UUID, banned_status BOOLEAN, reason TEXT DEFAULT NULL)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
  target_is_super_admin BOOLEAN;
  target_is_admin BOOLEAN;
  current_user_is_super_admin BOOLEAN;
BEGIN
  -- Проверка: текущий пользователь админ?
  SELECT is_admin, is_super_admin INTO current_user_is_admin, current_user_is_super_admin
  FROM profiles
  WHERE id = auth.uid();

  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can ban users';
  END IF;

  -- Проверка: целевой пользователь супер-админ?
  SELECT is_super_admin, is_admin INTO target_is_super_admin, target_is_admin
  FROM profiles
  WHERE id = target_user_id;

  IF target_is_super_admin THEN
    RAISE EXCEPTION 'Cannot ban super admin';
  END IF;

  -- Младшие админы не могут банить других админов
  IF target_is_admin AND NOT current_user_is_super_admin THEN
    RAISE EXCEPTION 'Only super admin can ban other admins';
  END IF;

  -- Обновить статус бана
  IF banned_status = TRUE THEN
    UPDATE profiles
    SET
      is_banned = TRUE,
      banned_at = NOW(),
      banned_by = auth.uid(),
      ban_reason = reason
    WHERE id = target_user_id;
  ELSE
    UPDATE profiles
    SET
      is_banned = FALSE,
      banned_at = NULL,
      banned_by = NULL,
      ban_reason = NULL
    WHERE id = target_user_id;
  END IF;

  RETURN TRUE;
END;
$$;

-- ============================================================================
-- РАЗРЕШЕНИЯ
-- ============================================================================

GRANT EXECUTE ON FUNCTION verify_user TO authenticated;
GRANT EXECUTE ON FUNCTION set_admin TO authenticated;
GRANT EXECUTE ON FUNCTION ban_user TO authenticated;

-- ============================================================================
-- ИНДЕКСЫ ДЛЯ ПРОИЗВОДИТЕЛЬНОСТИ
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_profiles_is_admin ON profiles(is_admin) WHERE is_admin = TRUE;
CREATE INDEX IF NOT EXISTS idx_profiles_is_banned ON profiles(is_banned) WHERE is_banned = TRUE;
CREATE INDEX IF NOT EXISTS idx_profiles_username ON profiles(username);

-- ============================================================================
-- ГОТОВО!
-- ============================================================================
-- После запуска этой миграции:
-- 1. Пользователь 6172b2d4-284c-4f08-84bb-5b415fdb6c59 станет супер-админом
-- 2. Супер-админ может назначать младших админов
-- 3. Супер-админ может банить любых пользователей (кроме себя)
-- 4. Младшие админы могут банить обычных пользователей (но не других админов)
-- 5. Забаненные пользователи не могут войти в приложение
-- ============================================================================
