# Memories App — Backend Architecture

## Overview

Production-ready backend for Memories app with Visual Key Pattern authentication, memory storage, and cross-device sync.

---

## Tech Stack

- **Framework**: Node.js + Express / Fastify
- **Database**: PostgreSQL 15+
- **Cache/Session**: Redis
- **Media Storage**: S3-compatible (AWS S3 / Cloudflare R2 / MinIO)
- **CDN**: CloudFront / Cloudflare
- **Auth**: Custom Visual Key Pattern + JWT
- **Deployment**: Docker + Kubernetes / Fly.io / Railway

---

## Database Schema

### Users Table
```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username VARCHAR(100) UNIQUE NOT NULL,
  visual_key_hash VARCHAR(255) NOT NULL, -- bcrypt hashed pattern
  avatar_emoji VARCHAR(10) NOT NULL, -- deterministic emoji
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_username ON users(username);
```

### Memories Table
```sql
CREATE TABLE memories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  text TEXT NOT NULL,
  emotion VARCHAR(20) NOT NULL,
  image_url TEXT,
  location_text VARCHAR(255),
  latitude DECIMAL(10, 8),
  longitude DECIMAL(11, 8),
  echo_count INTEGER DEFAULT 0,
  is_saved BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_memories_user_id ON memories(user_id);
CREATE INDEX idx_memories_created_at ON memories(created_at DESC);
```

### Sessions Table (for multi-device)
```sql
CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  token_hash VARCHAR(255) NOT NULL,
  device_info JSONB,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_token_hash ON sessions(token_hash);
```

---

## API Endpoints

### Authentication

#### POST /api/auth/register
Create new user with Visual Key Pattern.

**Request:**
```json
{
  "username": "john",
  "visualKeyPattern": [0, 1, 4, 5, 8]
}
```

**Response:**
```json
{
  "success": true,
  "user": {
    "id": "uuid",
    "username": "john",
    "avatarEmoji": "🌲"
  },
  "token": "jwt_token"
}
```

#### POST /api/auth/login
Login with Visual Key Pattern.

**Request:**
```json
{
  "username": "john",
  "visualKeyPattern": [0, 1, 4, 5, 8]
}
```

**Response:**
```json
{
  "success": true,
  "user": { ... },
  "token": "jwt_token"
}
```

#### POST /api/auth/logout
Invalidate current session.

---

### Memories

#### GET /api/memories
Get all memories for authenticated user.

**Headers:** `Authorization: Bearer <token>`

**Query Params:**
- `limit` (default: 50)
- `offset` (default: 0)
- `saved` (boolean, optional)

**Response:**
```json
{
  "memories": [
    {
      "id": "uuid",
      "text": "...",
      "emotion": "peaceful",
      "imageUrl": "https://cdn.../image.jpg",
      "locationText": "San Francisco, CA",
      "echoCount": 12,
      "isSaved": false,
      "createdAt": "2025-01-18T12:00:00Z"
    }
  ],
  "total": 150
}
```

#### POST /api/memories
Create new memory.

**Request:**
```json
{
  "text": "Beautiful sunset today",
  "emotion": "peaceful",
  "imageUrl": "https://cdn.../image.jpg",
  "locationText": "San Francisco, CA",
  "latitude": 37.7749,
  "longitude": -122.4194
}
```

**Response:**
```json
{
  "success": true,
  "memory": { ... }
}
```

#### PATCH /api/memories/:id/echo
Increment echo count.

**Response:**
```json
{
  "success": true,
  "echoCount": 13
}
```

#### PATCH /api/memories/:id/save
Toggle saved status.

**Response:**
```json
{
  "success": true,
  "isSaved": true
}
```

#### DELETE /api/memories/:id
Delete memory.

---

### Media Upload

#### POST /api/media/upload
Upload image/video. Returns CDN URL.

**Request:** `multipart/form-data`
- `file`: image or video

**Response:**
```json
{
  "success": true,
  "url": "https://cdn.memories.app/user123/abc123.jpg"
}
```

---

## Security

### Visual Key Pattern Authentication

1. **Registration:**
   - User provides pattern (array of indices)
   - Pattern is concatenated: `"0-1-4-5-8"`
   - Hash with bcrypt: `bcrypt.hash(pattern, 12)`
   - Store hash in database

2. **Login:**
   - User provides pattern
   - Concatenate pattern
   - Compare with bcrypt: `bcrypt.compare(pattern, storedHash)`
   - If valid, issue JWT token

3. **JWT Token:**
   - Payload: `{ userId, username, exp }`
   - Expiration: 30 days
   - Refresh mechanism via sessions table

### Rate Limiting

- **Login attempts**: 5 per 15 minutes per username
- **Registration**: 3 per hour per IP
- **Memory creation**: 50 per hour per user
- **Echo/Save**: 200 per hour per user

### Data Privacy

- All communication over HTTPS
- User data encrypted at rest (PostgreSQL + pgcrypto)
- Media files stored with pre-signed URLs (expiring links)
- No third-party analytics without consent

---

## Deployment Architecture

```
┌─────────────┐
│   Client    │ (React Native App)
└──────┬──────┘
       │ HTTPS
       ▼
┌─────────────┐
│     CDN     │ (CloudFront / Cloudflare)
└──────┬──────┘
       │
       ▼
┌─────────────┐
│  API Server │ (Node.js + Express)
└──────┬──────┘
       │
       ├─────► PostgreSQL (Primary)
       │
       ├─────► Redis (Cache/Sessions)
       │
       └─────► S3 (Media Storage)
```

### Scalability

- **Horizontal scaling**: Load balancer + multiple API instances
- **Database**: Read replicas for queries
- **Caching**: Redis for sessions, frequently accessed data
- **Media**: CDN caching, lazy loading

---

## Environment Variables

```bash
# Server
PORT=3000
NODE_ENV=production

# Database
DATABASE_URL=postgresql://user:pass@host:5432/memories

# Redis
REDIS_URL=redis://host:6379

# S3
S3_BUCKET=memories-media
S3_REGION=us-west-2
S3_ACCESS_KEY=xxx
S3_SECRET_KEY=xxx

# JWT
JWT_SECRET=random_secure_secret_256_bits
JWT_EXPIRATION=30d

# CDN
CDN_BASE_URL=https://cdn.memories.app
```

---

## Production Checklist

- [ ] Database migrations automated
- [ ] Backup strategy (daily PostgreSQL dumps)
- [ ] Monitoring (Prometheus + Grafana / Datadog)
- [ ] Error tracking (Sentry)
- [ ] Log aggregation (Loki / CloudWatch)
- [ ] Health checks (`/health` endpoint)
- [ ] Rate limiting implemented
- [ ] CORS configured correctly
- [ ] SSL certificates auto-renewal
- [ ] Disaster recovery plan

---

## API Client Integration (Frontend)

See `/src/lib/api.ts` for TypeScript client implementation.
