-- Migration: Add is_private column to profiles table
-- Run this SQL in your Supabase SQL Editor

-- Add is_private column for closed/private profiles
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS is_private BOOLEAN DEFAULT FALSE;

-- Verify the column was added successfully
SELECT column_name, data_type, column_default
FROM information_schema.columns
WHERE table_name = 'profiles' AND column_name = 'is_private';
