-- FIX for messages RLS policy
-- Run this in Supabase SQL Editor to fix the message sending error

-- Drop the old policy
DROP POLICY IF EXISTS "Users can insert messages in their conversations" ON messages;

-- Create new policy with proper reference
CREATE POLICY "Users can insert messages in their conversations" ON messages FOR INSERT WITH CHECK (
  auth.uid() = sender_id AND
  EXISTS (
    SELECT 1 FROM conversations
    WHERE conversations.id = messages.conversation_id
    AND (conversations.user1_id = auth.uid() OR conversations.user2_id = auth.uid())
  )
);
