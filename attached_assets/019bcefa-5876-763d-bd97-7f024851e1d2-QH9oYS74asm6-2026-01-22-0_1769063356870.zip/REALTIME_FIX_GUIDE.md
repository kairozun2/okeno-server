# 🔧 CRITICAL FIX: Realtime Subscription Manager
## Step-by-Step Implementation Guide

---

## 🎯 OBJECTIVE
Fix Supabase Realtime CHANNEL_ERROR by implementing a singleton subscription manager that prevents duplicate subscriptions.

---

## 📋 PROBLEM ANALYSIS

### **Current Broken Pattern** (src/lib/supabase-hooks.ts)
```typescript
export function useConversations() {
  // ... query setup ...

  useEffect(() => {
    if (!currentUserId) return;

    const channel = supabase.channel(`conversations:${currentUserId}`)
      .on('postgres_changes', ...)
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [currentUserId]);
}
```

### **Why This Fails**
1. Multiple components mount → multiple useConversations() calls
2. Each creates NEW channel subscription
3. Supabase sees duplicate subscription → CHANNEL_ERROR
4. Subscription dies → no realtime updates

---

## ✅ SOLUTION: Singleton Subscription Manager

### **Step 1: Create RealtimeManager Service**

Create new file: `/src/lib/realtime-manager.ts`

```typescript
import { supabase } from './supabase';
import { RealtimeChannel } from '@supabase/supabase-js';

type SubscriptionCallback<T> = (payload: T) => void;
type UnsubscribeFn = () => void;

interface ChannelSubscription {
  channel: RealtimeChannel;
  callbacks: Set<SubscriptionCallback<any>>;
  status: 'CONNECTING' | 'CONNECTED' | 'ERROR' | 'CLOSED';
  retryCount: number;
  retryTimeout?: NodeJS.Timeout;
}

class RealtimeManager {
  private subscriptions: Map<string, ChannelSubscription> = new Map();
  private readonly MAX_RETRIES = 3;
  private readonly RETRY_DELAY = 2000; // 2 seconds

  /**
   * Subscribe to a Realtime channel with automatic deduplication
   */
  subscribe<T>(
    channelName: string,
    config: {
      event: string;
      schema: string;
      table: string;
      filter?: string;
    },
    callback: SubscriptionCallback<T>
  ): UnsubscribeFn {
    console.log(`[RealtimeManager] Subscribe request: ${channelName}`);

    // Get or create subscription
    let sub = this.subscriptions.get(channelName);

    if (!sub) {
      console.log(`[RealtimeManager] Creating new channel: ${channelName}`);
      sub = this.createSubscription(channelName, config);
      this.subscriptions.set(channelName, sub);
    } else {
      console.log(`[RealtimeManager] Reusing existing channel: ${channelName}`);
    }

    // Add callback to this subscription
    sub.callbacks.add(callback);

    // Return unsubscribe function
    return () => {
      this.unsubscribe(channelName, callback);
    };
  }

  /**
   * Create a new channel subscription
   */
  private createSubscription<T>(
    channelName: string,
    config: {
      event: string;
      schema: string;
      table: string;
      filter?: string;
    }
  ): ChannelSubscription {
    const channel = supabase.channel(channelName);

    const sub: ChannelSubscription = {
      channel,
      callbacks: new Set(),
      status: 'CONNECTING',
      retryCount: 0,
    };

    // Configure channel
    let channelBuilder = channel.on(
      'postgres_changes' as any,
      {
        event: config.event as any,
        schema: config.schema,
        table: config.table,
        filter: config.filter,
      },
      (payload: any) => {
        // Broadcast to all callbacks
        sub.callbacks.forEach((cb) => cb(payload));
      }
    );

    // Subscribe with status handling
    channel
      .subscribe((status) => {
        console.log(`[RealtimeManager] ${channelName} status: ${status}`);
        sub.status = status as any;

        if (status === 'CHANNEL_ERROR') {
          this.handleError(channelName, sub);
        } else if (status === 'SUBSCRIBED') {
          sub.retryCount = 0; // Reset on success
          if (sub.retryTimeout) {
            clearTimeout(sub.retryTimeout);
            sub.retryTimeout = undefined;
          }
        }
      });

    return sub;
  }

  /**
   * Handle subscription errors with retry logic
   */
  private handleError(channelName: string, sub: ChannelSubscription) {
    if (sub.retryCount >= this.MAX_RETRIES) {
      console.error(
        `[RealtimeManager] ${channelName} failed after ${this.MAX_RETRIES} retries`
      );
      return;
    }

    sub.retryCount++;
    const delay = this.RETRY_DELAY * Math.pow(2, sub.retryCount - 1); // Exponential backoff

    console.log(
      `[RealtimeManager] Retrying ${channelName} in ${delay}ms (attempt ${sub.retryCount}/${this.MAX_RETRIES})`
    );

    sub.retryTimeout = setTimeout(() => {
      console.log(`[RealtimeManager] Reconnecting ${channelName}...`);

      // Cleanup old channel
      sub.channel.unsubscribe();

      // Create new subscription (reuses callbacks)
      const config = {
        event: '*',
        schema: 'public',
        table: 'conversations', // This should be dynamic based on channel
      };

      const newSub = this.createSubscription(channelName, config);
      newSub.callbacks = sub.callbacks; // Transfer callbacks
      this.subscriptions.set(channelName, newSub);
    }, delay);
  }

  /**
   * Unsubscribe a specific callback from a channel
   */
  private unsubscribe<T>(
    channelName: string,
    callback: SubscriptionCallback<T>
  ) {
    const sub = this.subscriptions.get(channelName);
    if (!sub) return;

    console.log(`[RealtimeManager] Unsubscribe from: ${channelName}`);
    sub.callbacks.delete(callback);

    // If no more callbacks, cleanup channel
    if (sub.callbacks.size === 0) {
      console.log(`[RealtimeManager] Cleaning up channel: ${channelName}`);
      if (sub.retryTimeout) {
        clearTimeout(sub.retryTimeout);
      }
      sub.channel.unsubscribe();
      this.subscriptions.delete(channelName);
    }
  }

  /**
   * Cleanup all subscriptions (call on app unmount)
   */
  cleanup() {
    console.log('[RealtimeManager] Cleanup all subscriptions');
    this.subscriptions.forEach((sub, channelName) => {
      if (sub.retryTimeout) {
        clearTimeout(sub.retryTimeout);
      }
      sub.channel.unsubscribe();
    });
    this.subscriptions.clear();
  }
}

// Export singleton instance
export const realtimeManager = new RealtimeManager();
```

---

### **Step 2: Update useConversations Hook**

In `/src/lib/supabase-hooks.ts`, replace the current implementation:

```typescript
export function useConversations() {
  const queryClient = useQueryClient();
  const { data: auth } = useAuth();
  const currentUserId = auth?.session?.user?.id;

  const query = useQuery({
    queryKey: ['conversations', currentUserId],
    queryFn: async () => {
      if (!currentUserId) return [];

      console.log('[Conversations] Fetching conversations for user:', currentUserId);

      const { data, error } = await supabase
        .from('conversations')
        .select(`
          *,
          messages (
            id,
            text,
            created_at
          )
        `)
        .or(`user1_id.eq.${currentUserId},user2_id.eq.${currentUserId}`)
        .order('last_message_at', { ascending: false });

      if (error) throw error;

      // Transform data...
      const transformedConversations = data.map((conv) => {
        // ... existing transform logic ...
      });

      console.log('[Conversations] Fetched', transformedConversations.length, 'conversations');
      return transformedConversations;
    },
    enabled: !!currentUserId,
    staleTime: 30 * 1000, // 30 seconds
    gcTime: 5 * 60 * 1000, // 5 minutes
  });

  // Setup Realtime subscription using singleton manager
  useEffect(() => {
    if (!currentUserId) return;

    console.log('[Conversations] Setting up Realtime subscription for user:', currentUserId);

    const channelName = `conversations:${currentUserId}`;

    const unsubscribe = realtimeManager.subscribe(
      channelName,
      {
        event: '*', // All events
        schema: 'public',
        table: 'conversations',
        filter: `user1_id=eq.${currentUserId},user2_id=eq.${currentUserId}`,
      },
      (payload) => {
        console.log('[Conversations] Realtime update:', payload);

        // Invalidate queries to refetch
        queryClient.invalidateQueries({ queryKey: ['conversations', currentUserId] });
      }
    );

    // Cleanup on unmount
    return () => {
      console.log('[Conversations] Cleaning up Realtime subscription');
      unsubscribe();
    };
  }, [currentUserId, queryClient]);

  return query;
}
```

---

### **Step 3: Update useMessages Hook**

Similar pattern for messages:

```typescript
export function useMessages(conversationId: string) {
  const queryClient = useQueryClient();

  // ... existing query logic ...

  useEffect(() => {
    if (!conversationId) return;

    console.log('[Messages] Setting up Realtime subscription for:', conversationId);

    const channelName = `messages:${conversationId}`;

    const unsubscribe = realtimeManager.subscribe(
      channelName,
      {
        event: 'INSERT',
        schema: 'public',
        table: 'messages',
        filter: `conversation_id=eq.${conversationId}`,
      },
      (payload) => {
        console.log('[Messages] New message:', payload.new);

        // Optimistic update: add new message to cache
        queryClient.setQueryData(
          ['messages', conversationId],
          (old: any[] | undefined) => {
            if (!old) return [payload.new];
            return [...old, payload.new];
          }
        );
      }
    );

    return () => {
      console.log('[Messages] Cleaning up Realtime subscription');
      unsubscribe();
    };
  }, [conversationId, queryClient]);

  return query;
}
```

---

### **Step 4: Add Cleanup on App Exit**

In `/src/app/_layout.tsx`, add cleanup:

```typescript
function RootLayoutNav() {
  // ... existing code ...

  useEffect(() => {
    // Cleanup on app unmount
    return () => {
      realtimeManager.cleanup();
    };
  }, []);

  return (
    <ThemeProvider value={navigationTheme}>
      {/* ... */}
    </ThemeProvider>
  );
}
```

---

## ✅ TESTING PROCEDURE

### **Test 1: Single Device**
1. Open Messages tab
2. Check logs: Should see ONE subscription
3. Open a chat
4. Check logs: Should see ONE more subscription (for messages)
5. Navigate away
6. Check logs: Subscriptions should cleanup

### **Test 2: Two Devices**
1. Device A: Open Messages tab
2. Device B: Send message to Device A
3. Device A: Should see message appear in real-time
4. Device A: Open the conversation
5. Device B: Send another message
6. Device A: Should see message appear instantly

### **Test 3: Error Recovery**
1. Turn off WiFi
2. Wait 5 seconds
3. Turn on WiFi
4. Should see retry logs
5. Connection should re-establish

### **Expected Logs (Success)**
```
LOG  [RealtimeManager] Subscribe request: conversations:USER_ID
LOG  [RealtimeManager] Creating new channel: conversations:USER_ID
LOG  [RealtimeManager] conversations:USER_ID status: SUBSCRIBED
LOG  [Conversations] Setting up Realtime subscription for user: USER_ID
```

### **Expected Logs (Error - Before Fix)**
```
LOG  [Conversations] Realtime subscription status: CHANNEL_ERROR
LOG  [Conversations] Realtime subscription status: CLOSED
```

---

## 📊 VERIFICATION CHECKLIST

- [ ] No CHANNEL_ERROR in logs
- [ ] Only ONE subscription per channel (check logs)
- [ ] Messages sync between 2 devices
- [ ] Subscription survives network disconnect
- [ ] Cleanup happens on unmount
- [ ] No memory leaks (test by opening/closing tabs 20 times)

---

## 🚨 IF STILL FAILING

**Check Supabase Dashboard**:
1. Go to Supabase Dashboard → Realtime
2. Verify Realtime is enabled for your project
3. Check connection limits (free tier: 200 concurrent)
4. Verify Row Level Security allows subscriptions

**Alternative Solution** (if Realtime continues to fail):
```typescript
// Fall back to polling
useEffect(() => {
  const interval = setInterval(() => {
    queryClient.invalidateQueries({ queryKey: ['conversations'] });
  }, 5000); // Poll every 5 seconds

  return () => clearInterval(interval);
}, []);
```

---

## ⏱️ ESTIMATED TIME
- Implementation: 2-3 hours
- Testing: 2 hours
- Total: 4-5 hours

---

**Priority**: 🔴 CRITICAL - Must fix before App Store submission
**Complexity**: Medium (singleton pattern + retry logic)
**Risk**: Low (well-established pattern)
