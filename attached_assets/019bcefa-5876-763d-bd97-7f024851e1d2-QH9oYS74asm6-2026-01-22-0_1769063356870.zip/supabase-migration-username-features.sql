-- Migration: Add username editing and color customization features
-- Run this script in Supabase SQL Editor to add new columns to existing profiles table

-- Add new columns for username editing and color customization
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS username_color TEXT,
ADD COLUMN IF NOT EXISTS username_last_changed TIMESTAMPTZ,
ADD COLUMN IF NOT EXISTS color_last_changed TIMESTAMPTZ;

-- Add comments for documentation
COMMENT ON COLUMN profiles.username_color IS 'Hex color for username display (premium feature)';
COMMENT ON COLUMN profiles.username_last_changed IS 'Last time username was changed (15-day cooldown)';
COMMENT ON COLUMN profiles.color_last_changed IS 'Last time username color was changed (15-day cooldown)';
