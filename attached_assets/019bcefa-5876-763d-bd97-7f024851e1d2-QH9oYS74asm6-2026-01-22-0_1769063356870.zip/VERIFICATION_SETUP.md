# Verification System Setup Guide

## Overview
The verification system allows admins to verify users with a blue checkmark badge. This guide will help you set up the database schema.

## Step 1: Run SQL Migration

You need to run this SQL in your Supabase SQL Editor **ONCE**:

```sql
-- Add verification and admin columns to profiles table
ALTER TABLE profiles
ADD COLUMN IF NOT EXISTS is_verified BOOLEAN DEFAULT FALSE,
ADD COLUMN IF NOT EXISTS is_admin BOOLEAN DEFAULT FALSE;

-- Set your account as admin (replace with your user ID)
UPDATE profiles
SET is_admin = TRUE, is_verified = TRUE
WHERE id = '6172b2d4-284c-4f08-84bb-5b415fdb6c59';

-- Function: Allow admins to verify/unverify users
CREATE OR REPLACE FUNCTION verify_user(target_user_id UUID, verified_status BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
BEGIN
  -- Check if current user is admin
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  -- Only admins can verify users
  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can verify users';
  END IF;

  -- Update verification status
  UPDATE profiles
  SET is_verified = verified_status
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Function: Allow admins to grant/revoke admin rights
CREATE OR REPLACE FUNCTION set_admin(target_user_id UUID, admin_status BOOLEAN)
RETURNS BOOLEAN
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  current_user_is_admin BOOLEAN;
BEGIN
  -- Check if current user is admin
  SELECT is_admin INTO current_user_is_admin
  FROM profiles
  WHERE id = auth.uid();

  -- Only admins can manage admin status
  IF NOT current_user_is_admin THEN
    RAISE EXCEPTION 'Only admins can manage admin status';
  END IF;

  -- Update admin status
  -- If making someone admin, also verify them automatically
  UPDATE profiles
  SET is_admin = admin_status,
      is_verified = CASE WHEN admin_status = TRUE THEN TRUE ELSE is_verified END
  WHERE id = target_user_id;

  RETURN TRUE;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION verify_user TO authenticated;
GRANT EXECUTE ON FUNCTION set_admin TO authenticated;
```

## Step 2: How to Run in Supabase

1. Go to your Supabase project dashboard
2. Click on **SQL Editor** in the left sidebar
3. Click **New Query**
4. Copy and paste the SQL above
5. Click **Run** or press `Cmd/Ctrl + Enter`
6. You should see "Success. No rows returned"

## Step 3: Verify Setup

After running the migration:

1. Restart your app
2. Go to your profile
3. You should see a **Shield icon** button in the top right (admin panel access)
4. Click it to open the admin panel
5. You can now:
   - Search for users
   - Verify/unverify users (blue checkmark badge)
   - Grant/revoke admin rights to other users

## Features

### Verification Badge
- Blue checkmark appears next to verified users
- Shows everywhere: feed, search, chat header, profile, admin panel
- Persists permanently (no reload flickering)

### Admin Panel
- Access via Shield icon in profile (only visible to admins)
- Search all users
- Verify/unverify users with confirmation dialog
- Grant/revoke admin rights with confirmation dialog
- Visual indicators for verified users and admins
- Cannot modify yourself (safety feature)

### Admin Rights
- Admins can verify any user
- Admins can make other users admins
- Admins are automatically verified
- Only admins can access the admin panel
- All actions require confirmation dialogs (iOS compliant)

## Security

- All admin functions use Supabase RPC with SECURITY DEFINER
- Only users with `is_admin = TRUE` can execute admin functions
- Row Level Security (RLS) policies protect all data
- Type-safe with TypeScript throughout

## Troubleshooting

**"column is_verified does not exist" error:**
- Run the SQL migration above in Supabase SQL Editor
- Restart your app after running the migration

**Can't see admin panel button:**
- Make sure you ran the SQL migration
- Verify your user ID is correct in the UPDATE statement
- Check that `is_admin = TRUE` in your profile row

**Verification badge not showing:**
- Run the SQL migration
- Restart the app
- The app is backward-compatible and will work without migration, but badges won't show until migration is complete

## Your Admin User ID

Your admin account ID is set to:
```
6172b2d4-284c-4f08-84bb-5b415fdb6c59
```

If you need to change this, update the SQL migration line:
```sql
WHERE id = 'YOUR-USER-ID-HERE';
```
